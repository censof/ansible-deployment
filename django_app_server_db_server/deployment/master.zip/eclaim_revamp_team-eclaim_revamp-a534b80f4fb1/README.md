# Important

Before beginning work on this repo, read first our guidelines on [commiting work to repo](COMMITTING.md)

Tutorial
--------
http://django-angular.readthedocs.org/en/latest/installation.html

Initial Setup
-------------
*** Make sure that VirtualBox, Git & PostgreSQL are up and running ***

1) Create and activate a virtual environment
    - mkvirtualenv eclaim

2) Install requirements
    - cd eclaim_revamp
    - pip install -r requirements.txt (production only)
    - pip install -r requirements.txt -r req_test.txt (development only)

3) Create a PostgreSQL database
    - su postgres
    - createdb eclaim_new

4) Create and run migrations
    - python manage.py makemigrations
    - python manage.py migrate

Possible error occured when migrating at Step 4
-----------------------------------------------
- django.db.utils.ProgrammingError: relation "masterfiles_gradelevelcategory" does not exist

- Follow the steps below:

    1) Comment all eClaim-related apps in INSTALLED_APPS

    2) python manage.py migrate

    3) Uncomment masterfiles, claim & settings apps

    4) python manage.py migrate

    5) Uncomment all apps

    6) python manage.py migrate

Optional
--------
1) to update your static content with the JavaScript files provided by django-angular.
    - python manage.py collectstatic

Possible error occured when running 'pip install'
-------------------------------------------------
- Download success but seing this error -> Failed to build Pillow

- Follow the steps below:

    1) sudo apt-get install libjpeg8-dev

    2) pip install -r requirements.txt or pip install -r requirements.txt -r req_test.txt (Development machine)

    @

    1) sudo apt-get install libjpeg8-dev

    2) pip install Pillow

    3) pip install xhtml2pdf

    4) Just to make sure --> pip install -r requirements.txt

Local Development
-----------------
- python manage.py runserver --settings=config.dev

Running Unit Tests
------------------
- python manage.py test -v 3 --settings=config.test
