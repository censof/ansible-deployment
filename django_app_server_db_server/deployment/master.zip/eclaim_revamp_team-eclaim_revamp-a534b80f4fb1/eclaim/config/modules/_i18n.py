"""Internationalization.

More info: https://docs.djangoproject.com/en/1.8/topics/i18n/
"""

_ = lambda s: s

LANGUAGE_CODE = 'en-us'

LANGUAGES = (
    ('en-us', _('English')),
    ('ms-my', _('Malay')),
)

LOCALE_PATHS = (
    '/opt/djangular/proj_eclaim/eclaim_revamp/eclaim/locale',
)

TIME_ZONE = 'UTC'

USE_I18N = True

USE_L10N = True

USE_TZ = True
