"""Template context processors."""

_DJANGO_CONTEXT_PROCESSORS = (
    'django.contrib.auth.context_processors.auth',
    'django.core.context_processors.debug',
    'django.core.context_processors.i18n',
    'django.core.context_processors.media',
    'django.core.context_processors.static',
    'django.core.context_processors.tz',
    'django.core.context_processors.request',
    'django.contrib.messages.context_processors.messages',
    )

_THIRD_PARTY_CONTEXT_PROCESSORS = (
    )

_ECLAIM_CONTEXT_PROCESSORS = (
    'eclaim.context_processors.base_settings',
    'eclaim.context_processors.pagination',
    'eclaim.settings.context_processors.settings',
    'eclaim.claim.context_processors.claim_types',
    'eclaim.masterfiles.context_processors.user_roles',
    'eclaim.masterfiles.context_processors.permissions',
    )

TEMPLATE_CONTEXT_PROCESSORS = _DJANGO_CONTEXT_PROCESSORS + \
    _THIRD_PARTY_CONTEXT_PROCESSORS + _ECLAIM_CONTEXT_PROCESSORS
