"""Project-related settings."""

ALLOW_MANAGING_OWN_CLAIMS = False
