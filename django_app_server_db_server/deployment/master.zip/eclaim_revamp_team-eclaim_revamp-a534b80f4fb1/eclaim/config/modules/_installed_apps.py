"""Application definition."""

_DJANGO_APPS = (
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    'django.contrib.humanize',
    )

_THIRD_PARTY_APPS = (
    'pagination',
    'djangular',
    'rest_framework',
    'django_countries',
    'easy_pdf',
    'django_nose',
    )

_ECLAIM_APPS = (
    'eclaim',
    'eclaim.libs',
    'eclaim.settings',
    'eclaim.claim',
    'eclaim.utils',
    'eclaim.masterfiles',
    'eclaim.lookup',
    'eclaim.lecture',
    'eclaim.localtravel',
    'eclaim.overseatravel',
    'eclaim.advance',
    'eclaim.overseaadvance',
    'eclaim.housemoving',
    'eclaim.localtransfer',
    'eclaim.overseatransfer',
    'eclaim.miscellaneous',
    'eclaim.medical',
    'eclaim.dental',
    'eclaim.miscoverseas',
    'eclaim.eadvance',
    'eclaim.dentaloverseas',
    'eclaim.medicaloverseas',
    'eclaim.integrations'
    )

INSTALLED_APPS = _DJANGO_APPS + _THIRD_PARTY_APPS + _ECLAIM_APPS
