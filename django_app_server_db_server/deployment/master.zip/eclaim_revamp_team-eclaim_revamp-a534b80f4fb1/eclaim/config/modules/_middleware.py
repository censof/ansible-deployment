"""Middleware classes."""

_DJANGO_MIDDLEWARE = (
    'django.contrib.sessions.middleware.SessionMiddleware',
    'django.middleware.locale.LocaleMiddleware',
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.auth.middleware.SessionAuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
    'django.middleware.security.SecurityMiddleware',
    )

_THIRD_PARTY_MIDDLEWARE = (
    'pagination.middleware.PaginationMiddleware',
    )

_ECLAIM_MIDDLEWARE = (
    )

MIDDLEWARE_CLASSES = _DJANGO_MIDDLEWARE + _THIRD_PARTY_MIDDLEWARE + \
    _ECLAIM_MIDDLEWARE
