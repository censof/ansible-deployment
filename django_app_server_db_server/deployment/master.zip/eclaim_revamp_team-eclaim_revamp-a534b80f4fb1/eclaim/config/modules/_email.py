"""Email settings."""

EMAIL_BACKEND = 'django.core.mail.backends.smtp.EmailBackend'

EMAIL_USE_TLS = True

EMAIL_HOST = 'smtp.gmail.com'

EMAIL_HOST_USER = 'eclaimCensof@gmail.com'

EMAIL_HOST_PASSWORD = 'eclaim123'

EMAIL_PORT = 587

SERVER_EMAIL = 'eclaimCensof@gmail.com'

ADMINS = (
    ('Aldash Bibosunoff', 'aldash@censof.com'),
    ('Mohamed Fauzi Abdul Malik', 'mohamedfauzi@censof.com'),
    ('Mohammad Masoudimoghaddam', 'mohammad@censof.com'),
    ('Ahmad Danial', 'ahmad.danial@censof.com'),
    ('Natalia Vyazova', 'natalia@censof.com'),
    )
