from django.apps import apps
from django.contrib import messages
from django.http import JsonResponse
from django.utils.translation import ugettext_lazy as _
from django.views.decorators.http import require_POST

__all__ = ['delete_objects']


@require_POST
def delete_objects(request):
    """Delete objects parametrized by their app, model and list of primary
    keys.
    """
    app = request.POST.get('app')
    model_name = request.POST.get('model')
    id_list = request.POST.getlist('id_list[]')
    if not app or not model_name or not id_list:
        return JsonResponse({'success': False})

    model = apps.get_model(app_label=app, model_name=model_name)
    qs = model.objects.filter(pk__in=id_list)
    count = qs.count()
    qs.delete()
    messages.success(request, _("{} object(s) deleted.".format(count)))
    return JsonResponse({'success': True, 'count': count})
