from django.conf.urls import patterns, url

from .views import OverseaTravelingAdvanceIndexView, OverseaTravelingAdvanceDetailView, OverseaTravelingAdvanceDraftView

urlpatterns = patterns('',
    url(r'^$', OverseaTravelingAdvanceIndexView.as_view(), name='overseatravelingadvance_index'),
    url(r'^detail/$', OverseaTravelingAdvanceDetailView.as_view(), name='overseatravelingadvance_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', OverseaTravelingAdvanceDraftView.as_view(), name='overseatravelingadvance_draft')
)
