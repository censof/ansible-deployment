import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text
from django.contrib.contenttypes.models import ContentType

from eclaim.auth.authenticate import Authenticate
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import ClaimDetailView, ClaimIndexView
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.common import SUMMARY
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory, Children
from eclaim.masterfiles.models.misc import FundType, TYPE_OF_ADVANCE, TYPE_OF_EXPENSES
from eclaim.masterfiles.utils import get_document_list, get_document_list_item, \
                                     get_document_list_item_draft

from eclaim.utils.common import get_claim_type_code, get_claim_type_prefix, \
                                get_json_from_set_obj, get_json_from_list

from .models import OVERSEA_TRAVELING_ADVANCE_TYPE, OverseaTravelingAdvance, OverseaTravelingAdvanceDraft
from .processes import oversea_traveling_advance_process

__ClaimType__ = get_claim_type_code(OVERSEA_TRAVELING_ADVANCE_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(OVERSEA_TRAVELING_ADVANCE_TYPE)


class OverseaTravelingAdvanceIndexView(ClaimIndexView):
    """
    This is index page for Oversea Traveling Advances.
    """
    template_name = 'overseatravelingadvance/oversea_traveling_advance.html'
    claim_type = OverseaTravelingAdvance.get_claim_type()
    validate_form_by_name = 'overseaTravelingAdvanceForm'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(OverseaTravelingAdvanceIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonTypeOfAdvanceList'] = get_json_from_list(TYPE_OF_ADVANCE)
        ctx['jsonTypeOfExpensesList'] = get_json_from_list(TYPE_OF_EXPENSES)
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = oversea_traveling_advance_process(
            btn_mode, form_data, request.user)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, OverseaTravelingAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaTravelingAdvance,
                                             claim_id, new_claim=True)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class OverseaTravelingAdvanceDetailView(ClaimDetailView):
    """
    This is detail view for Oversea Traveling Advance.
    """
    model = OverseaTravelingAdvance
    claim_type = OverseaTravelingAdvance.get_claim_type()
    template_name = 'overseatravelingadvance/oversea_traveling_advance.html'
    submit_success_url = reverse_lazy('claim_list')
    validate_form_by_name = 'overseaTravelingAdvanceForm'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(OverseaTravelingAdvanceDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonTypeOfAdvanceList'] = get_json_from_list(TYPE_OF_ADVANCE)
        ctx['jsonTypeOfExpensesList'] = get_json_from_list(TYPE_OF_EXPENSES)

        obj_pk = self.request.GET['pk']
        claim = OverseaTravelingAdvance.objects.get(pk=obj_pk)

        ctx['claim_no'] = claim.claim_no

        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = oversea_traveling_advance_process(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, OverseaTravelingAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaTravelingAdvance, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class OverseaTravelingAdvanceDraftView(TemplateView):
    template_name = 'overseatravelingadvance/oversea_traveling_advance.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(OverseaTravelingAdvanceDraftView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        ctx = super(OverseaTravelingAdvanceDraftView, self).get_context_data(**kwargs)
        draft_id = self.kwargs['draft_id']

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonTypeOfAdvanceList'] = get_json_from_list(TYPE_OF_ADVANCE)
        ctx['jsonTypeOfExpensesList'] = get_json_from_list(TYPE_OF_EXPENSES)

        draft = OverseaTravelingAdvanceDraft.objects.get(id=int(draft_id))

        ctx['draftID'] = draft.id

        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = oversea_traveling_advance_process(
            btn_mode, form_data, request.user)

        response_data = {'errors': False, 'draft_id':draft_id, 'claim_id':claim_id, 'submit_success_url': force_text(self.submit_success_url)}
        return HttpResponse(json.dumps(response_data), content_type="application/json")