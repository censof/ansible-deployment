from decimal import *
from django.db import models
from django.core.urlresolvers import reverse_lazy
from eclaim.claim.models import ClaimType
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import FundType, TYPE_OF_ADVANCE, TYPE_OF_EXPENSES
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.common import CLAIM_STATUS


# claim_type pk for Oversea Advance is 19
OVERSEA_TRAVELING_ADVANCE_TYPE = 19


class OverseaTravelingAdvanceAbstract(BaseModel):
    status = models.CharField(max_length=CLAIM_STATUS.DEFAULT_LENGTH)
    apply_date = models.DateField()

    class Meta:
        app_label = 'overseatravelingadvance'
        abstract = True

    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=OVERSEA_TRAVELING_ADVANCE_TYPE)


class OverseaTravelingAdvanceParentItemAbstract(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    for parent in ('total_hotel_allowance', 'total_lodging_allowance', 'total_meal_allowance', 'grand_total'
                , 'total_advance_allowed'):
        exec("%s = models.DecimalField(**default_arguments)" % parent)

    class Meta:
        app_label = 'overseatravelingadvance'
        abstract = True


class OverseaTravelingAdvance(OverseaTravelingAdvanceAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    class Meta(OverseaTravelingAdvanceAbstract.Meta):
        app_label = 'overseatravelingadvance'
        verbose_name = 'Oversea Traveling Advance'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('overseatravelingadvance_detail'), self.pk)


class OverseaTravelingAdvanceParentItem(OverseaTravelingAdvanceParentItemAbstract):
    oversea_traveling_advance = models.ForeignKey(OverseaTravelingAdvance)

    class Meta(OverseaTravelingAdvanceParentItemAbstract.Meta):
        app_label = 'overseatravelingadvance'
        verbose_name = 'Oversea Traveling Advance Parent Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class OverseaTravelingAdvanceDraft(OverseaTravelingAdvanceAbstract):

    class Meta(OverseaTravelingAdvanceAbstract.Meta):
        app_label = 'overseatravelingadvance'
        verbose_name = 'Oversea Traveling Advance Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('overseatravelingadvance_draft', args=[self.pk])


class OverseaTravelingAdvanceParentItemDraft(OverseaTravelingAdvanceParentItemAbstract):
    oversea_traveling_advance_draft = models.ForeignKey(OverseaTravelingAdvanceDraft)

    class Meta(OverseaTravelingAdvanceParentItemAbstract.Meta):
        app_label = 'overseatravelingadvance'
        verbose_name = 'Oversea Traveling Advance Parent Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class OverseaTravelingAdvanceChildItemAbstract(models.Model):
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=125)
    type_of_advance = models.CharField(max_length=30, choices=TYPE_OF_ADVANCE, null=True)
    country_destination = models.CharField(max_length=30, choices=TYPE_OF_ADVANCE, null=True)
    country_code = models.CharField(max_length=30, choices=TYPE_OF_ADVANCE, null=True)
    location = models.TextField(null=True)
    type_of_expenses = models.CharField(max_length=30, choices=TYPE_OF_EXPENSES, null=True)
    allowance_no_of_days = models.IntegerField(null=True, default=0)
    hotel_rate = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))
    lodging_rate = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))
    meal_rate = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    class Meta:
        app_label = 'overseatravelingadvance'
        abstract = True


class OverseaTravelingAdvanceChildItem(OverseaTravelingAdvanceChildItemAbstract):
    oversea_traveling_advance = models.ForeignKey(OverseaTravelingAdvance)

    class Meta(OverseaTravelingAdvanceChildItemAbstract.Meta):
        app_label = 'overseatravelingadvance'
        verbose_name = 'Oversea Traveling Advance Child Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class OverseaTravelingAdvanceChildItemDraft(OverseaTravelingAdvanceChildItemAbstract):
    oversea_traveling_advance_draft = models.ForeignKey(OverseaTravelingAdvanceDraft)

    class Meta(OverseaTravelingAdvanceChildItemAbstract.Meta):
        app_label = 'overseatravelingadvance'
        verbose_name = 'Oversea Traveling Advance Child Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']