import datetime
from decimal import *

from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.utils import save_claimant_history, save_document_list_item_draft, save_document_list_item
from eclaim.utils.date import get_date_from_str
from eclaim.utils.common import generate_claim_no, get_claim_type_code, get_claim_type_prefix, get_fund_type
from .models import (OVERSEA_TRAVELING_ADVANCE_TYPE, OverseaTravelingAdvance, OverseaTravelingAdvanceDraft
                    , OverseaTravelingAdvanceParentItem, OverseaTravelingAdvanceParentItemDraft
                    , OverseaTravelingAdvanceChildItem, OverseaTravelingAdvanceChildItemDraft)


__ClaimType__ = get_claim_type_code(OVERSEA_TRAVELING_ADVANCE_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(OVERSEA_TRAVELING_ADVANCE_TYPE)


def oversea_traveling_advance_process(btn_mode, form_data, created_by=None):
    draft_id = None
    claim_id = None

    if btn_mode in ['save_draft']:
        draft_id = save_draft(form_data, created_by)
    elif btn_mode in ['submit']:
        claim_id = submit_claim(form_data)

    return draft_id, claim_id


def save_draft(form_data, created_by=None):
    draft_id = form_data.get('draft_id')

    draft_id = None if (draft_id is None or draft_id == '') else int(draft_id)
    status = '' if draft_id else 'D'
    created_by = '' if (created_by is None) else created_by
    claim_draft = OverseaTravelingAdvanceDraft(id=draft_id)
    claim_draft.apply_date = datetime.date.today()
    claim_draft.save()
    save_oversea_traveling_advance('save_draft', claim_draft, form_data)

    if draft_id:
        return draft_id
    else:
        return claim_draft.id


def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')
    draft_id = form_data.get('draft_id')

    claim = OverseaTravelingAdvance()
    claim.status = 'S'
    claim.apply_date = datetime.date.today()
    claim.save()

    claim.claim_no = generate_claim_no(__ClaimPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_oversea_traveling_advance('submit_claim', claim, form_data)

    if draft_id != '':
        delete_oversea_traveling_advance_draft(OverseaTravelingAdvanceDraft(id=int(draft_id)))
        delete_oversea_traveling_advance_draft(OverseaTravelingAdvanceParentItemDraft(id=int(draft_id)))
        delete_oversea_traveling_advance_draft(OverseaTravelingAdvanceChildItemDraft(id=int(draft_id)))

    return claim.id


def save_oversea_traveling_advance(mode, overseatravelingadvance, form_data):

    if mode in ['save_draft']:
        saveObjParentAdvance = OverseaTravelingAdvanceParentItemDraft()
        saveObjParentAdvance.oversea_traveling_advance_draft = overseatravelingadvance
    elif mode in ['submit_claim']:
        saveObjParentAdvance = OverseaTravelingAdvanceParentItem()
        saveObjParentAdvance.oversea_traveling_advance = overseatravelingadvance

    for parent in ('hotel_allowance', 'lodging_allowance', 'meal_allowance', 'advance_allowed'):
        exec("saveObjParentAdvance.total_%s = form_data.get('total%s')" % (parent, ''.join([x.capitalize() for x in parent.split('_')])))
    saveObjParentAdvance.grand_total = form_data.get('grandTotal')
    saveObjParentAdvance.save()

    for details in form_data.get('advanceDetailsItems'):
        if mode in ['save_draft']:
            saveObjParentAdvance = OverseaTravelingAdvanceParentItemDraft()
            saveObjChildAdvance = OverseaTravelingAdvanceChildItemDraft()

            saveObjParentAdvance.oversea_traveling_advance_draft = overseatravelingadvance
            saveObjChildAdvance.oversea_traveling_advance_draft = overseatravelingadvance

        elif mode in ['submit_claim']:
            saveObjParentAdvance = OverseaTravelingAdvanceParentItem()
            saveObjChildAdvance = OverseaTravelingAdvanceChildItem()

            saveObjParentAdvance.oversea_traveling_advance = overseatravelingadvance
            saveObjChildAdvance.oversea_traveling_advance = overseatravelingadvance

        saveObjChildAdvance.from_date = get_date_from_str(details['fromDateTxt'])
        saveObjChildAdvance.to_date = get_date_from_str(details['toDateTxt'])
        saveObjChildAdvance.fund_type = get_fund_type(details['fundType'].get('code'))
        saveObjChildAdvance.project_code = details['projectCode']
        saveObjChildAdvance.type_of_advance = details['typeOfAdvance'].get('code')
        saveObjChildAdvance.countryDestination = details['countryDestination'].get('code')
        saveObjChildAdvance.countryCode = details['countryCode']
        saveObjChildAdvance.location = details['location']
        saveObjChildAdvance.type_of_expenses = details['typeOfExpenses'].get('code')
        saveObjChildAdvance.allowance_no_of_days = details['allowanceNoOfDays']
        saveObjChildAdvance.hotel_rate = details['hotelRate']
        saveObjChildAdvance.lodging_rate = details['lodgingRate']
        saveObjChildAdvance.meal_rate = details['mealRate']
        saveObjChildAdvance.save()


def delete_oversea_traveling_advance_draft(draft):
    deleteObj = draft
    deleteObj.delete()