from rest_framework import viewsets
from .serializers import OverseaTravelingAdvanceSerializer, OverseaTravelingAdvanceDraftSerializer
from ..models import OverseaTravelingAdvance, OverseaTravelingAdvanceDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'OverseaTravelingAdvanceViewSet',
    'OverseaTravelingAdvanceDraftViewSet'
    ]


class OverseaTravelingAdvanceViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaTravelingAdvanceSerializer
    queryset = OverseaTravelingAdvance.objects.all()


class OverseaTravelingAdvanceDraftViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaTravelingAdvanceDraftSerializer
    queryset = OverseaTravelingAdvanceDraft.objects.all()
