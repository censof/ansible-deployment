from eclaim.overseatravelingadvance.processes import oversea_traveling_advance_process
from unittest import TestCase
from mock import call, patch


class OverseaTravelingAdvanceTests(TestCase):

    @patch('eclaim.overseatravelingadvance.processes.save_draft')
    @patch('eclaim.overseatravelingadvance.processes.submit_claim')
    def test_oversea_traveling_advance_process(self, mock_submit_claim, mock_save_draft):

        """Test oversea_traveling_advance_process"""
        oversea_traveling_advance_process('save_draft', {'a': 'a', 'b': 'b'},
                              created_by='mock_user')
        self.assertEqual(mock_save_draft.call_args,
                         call({'a': 'a', 'b': 'b'}, 'mock_user'))

        oversea_traveling_advance_process('submit', {'a': 'a', 'b': 'b'})
        self.assertEqual(mock_submit_claim.call_args, call({'a': 'a', 'b': 'b'}))