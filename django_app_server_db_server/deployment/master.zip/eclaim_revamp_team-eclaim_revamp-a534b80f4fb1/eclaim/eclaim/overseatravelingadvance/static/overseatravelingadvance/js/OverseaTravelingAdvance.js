/*
 ********************************************
 *      CREATED BY  :   MOHAMED FAUZI       *
 *      DATE        :   MAY 2016          *
 ********************************************
*/
console.log('Oversea Traveling Advance JS Loaded!!!');

uiBootstrapApp.controller('OverseaTravelingAdvanceCtrl', function ($scope, $http) {
	/**
    *************************
    *   Start : Accordion   *
    *************************
   */
    $scope.oneAtATime = false;
    
    $scope.panels = [
        {name: 'panel1', open: false},
        {name: 'panel2', open: true},
        {name: 'panel3', open: false},
        {name: 'panel4', open: false},
        {name: 'panel5', open: false},
        {name: 'panel6', open: false}
    ];
    $scope.toggleAllPanels = function() {
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    $scope.closeAllPanels = function() {
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** End : Accordion */
	
	if (PK) {  // detail view
        $http({
            url: API_URL+'oversea-traveling-advances/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, 3, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, 3, 1);
    }

    var claim_api_url = API_URL+'oversea-traveling-advances/';
    init_workflow($scope, $http, 'overseatravelingadvance', 'OverseaTravelingAdvance', PK, claim_api_url, WF_TEMPLATE);

    $scope.popup_query_pdf = function () {
        window.open($scope.url_query_pdf, '', 'width=800,height=600,left=200,resizable=0');
    }
});

uiBootstrapApp.controller('AdvanceDetailsCtrl', function ($scope, $filter, $http, $q, DataClaimant, DataFundType, DataLookup, DataFormAdvanceDetails) {

    $scope.initAdvanceDetailsCtrl = function (jsonTypeOfAdvanceList, jsonTypeOfExpensesList, draftID) {
		
		$scope.pageSize = 5;
        $scope.currentPage = 1;
		
		$scope.dateFormats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MM-yyyy'];
		$scope.standardDateOptions = {
			formatYear: 'yy',
			startingDay: 1
		};
		$scope.formatDate = $scope.dateFormats[0];
		
		$scope.typeOfAdvanceList = [];
		$scope.typeOfExpensesList = [];
		$scope.countryDestinationList = [];
        $scope.advanceDetailsItems = [];
		setEmptyTable();
		
		$http({
			url: API_URL+'countries/',
			method: 'GET'
		})
		.success(function (data, status, headers, config) {
			$scope.countryDestinationList = data.results;
		});
		getAngularObjFromJson(jsonTypeOfAdvanceList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.typeOfAdvanceList.push({code:code, description:description});
		});
		getAngularObjFromJson(jsonTypeOfExpensesList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.typeOfExpensesList.push({code:code, description:description});
		});
		
		if (draftID || PK) {
			if (draftID) { // draft view
				$http({
					url: API_URL+'oversea-traveling-advance-drafts/'+draftID+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					if (data.advance_details.advance_details[0]) {
						data.advance_details.child_items.forEach(function(obj) {
							$scope.addItem(obj);
						});
					};
				});
			} else if (PK) { // detail view
				$http({
					url: API_URL+'oversea-traveling-advances/'+PK+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					if (data.advance_details.advance_details[0]) {
						data.advance_details.child_items.forEach(function(obj) {
							$scope.addItem(obj);
						});
					};
				});
			}
        }
    };

	$scope.getDataByCode = function (code, dropdown) {
		var objSelect = $filter("filter")(dropdown, { code: code });
		return objSelect[0];
	};

	var disableEditMode = function() {
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

	var setEmptyTable = function() {
        $scope.currIndex = '';
        $scope.isEmptyTable = true;
        disableEditMode();
    };
	
	var setEditMode = function(itemIndex) {
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };

	var getItems = function(index) {
        var obj = [];
        obj = $scope.advanceDetailsItems;
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

	$scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var currItem = '';
        var list = getItems();
        if (list.length > 0) {
            if ($scope.directIndex == list.length) {
                $scope.directIndex = list.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= list.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

	 $scope.addItem = function(objDB) {
        var items = getItems();
        items.push(setRow(objDB));
        $scope.isEmptyTable = false;
        resetForm();
        calculateAdvanceTotal();
    };
	
    $scope.deleteItem = function(itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
		var items = [];
        items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAdvanceTotal();
    };

    $scope.editItem = function(itemIndex) {
		var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal('editForm');
        setForm(getItems(index));
    };

	$scope.openModal = function(mode) {
        $('#overseaTravelingAdvanceModalForm').modal('show');
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };
	
    var setRow = function(objDB) {
        if (objDB) {
			DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
			$scope.fromDate = getDateFromStr(objDB.from_date);
			$scope.toDate = getDateFromStr(objDB.to_date);
			$scope.typeOfAdvance = $scope.getDataByCode(objDB.type_of_advance, $scope.typeOfAdvanceList);
			$scope.location = objDB.location;
			$scope.countryDestination = $scope.getDataByCode(objDB.countryDestination, $scope.countryDestinationList);
			$scope.countryCode = objDB.countryCode;
			$scope.typeOfExpenses = $scope.getDataByCode(objDB.type_of_expenses, $scope.typeOfExpensesList);
			$scope.allowanceNoOfDays = objDB.allowance_no_of_days;
			$scope.hotelRate = objDB.hotel_rate;
			$scope.lodgingRate = objDB.lodging_rate;
			$scope.mealRate = objDB.meal_rate;
			$scope.totalHotelAllowance = objDB.total_hotel_allowance;
			$scope.totalLodgingAllowance = objDB.total_lodging_allowance;
			$scope.totalMealAllowance = objDB.total_meal_allowance;
			$scope.grandTotal = objDB.grand_total;
			$scope.totalAdvanceAllowed = objDB.total_advance_allowed;
        }
        return {
			fundType: DataFundType.getFundType()
            , projectCode: DataLookup.getProjectCode()
            , fromDate: $scope.fromDate
			, fromDateTxt: getDateStr($filter, $scope.fromDate)
			, toDate: $scope.toDate
			, toDateTxt: getDateStr($filter, $scope.toDate)
			, typeOfAdvance: $scope.typeOfAdvance 
			, location: $scope.location
			, countryDestination: $scope.countryDestination
			, countryCode: $scope.countryCode
			, typeOfExpenses: $scope.typeOfExpenses
			, allowanceNoOfDays: $scope.allowanceNoOfDays
			, hotelRate: get2Float($scope.hotelRate)
			, lodgingRate: get2Float($scope.lodgingRate)
			, mealRate: get2Float($scope.mealRate)
			, totalHotelAllowance: $scope.totalHotelAllowance
			, totalLodgingAllowance: $scope.totalLodgingAllowance
			, totalMealAllowance: $scope.totalMealAllowance
			, grandTotal: $scope.grandTotal
			, totalAdvanceAllowed: $scope.totalAdvanceAllowed
        };
    };

    var setForm = function(currItem) {
		DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        $scope.fromDate = currItem.fromDate;
		$scope.toDate = currItem.toDate;
		$scope.typeOfAdvance = currItem.typeOfAdvance
		$scope.location = currItem.location
		$scope.countryDestination = currItem.countryDestination
		$scope.countryCode = currItem.countryCode
		$scope.typeOfExpenses = currItem.typeOfExpenses
		$scope.allowanceNoOfDays = currItem.allowanceNoOfDays
		$scope.hotelRate = currItem.hotelRate
		$scope.lodgingRate = currItem.lodgingRate
		$scope.mealRate = currItem.mealRate
    }
	
	var resetForm = function(){
        DataFormAdvanceDetails.reset();
		DataFundType.setFundType({});
        DataLookup.setProjectCode('');
        $scope.fromDate = '';
        $scope.toDate = '';
        $scope.typeOfAdvance = [];
        $scope.location = '';
        $scope.countryDestination = [];
        $scope.countryCode = '';
        $scope.typeOfExpenses = [];
		$scope.allowanceNoOfDays = 0;
		$scope.hotelRate = get2Float(0);
        $scope.lodgingRate = get2Float(0);
        $scope.mealRate = get2Float(0);
    };

	var calculateDiffDays = function () {
		var intDays = 0;
		if (angular.isDate($scope.fromDate) && angular.isDate($scope.toDate)) {
			intDays = getNightDiffDate($scope.fromDate, $scope.toDate) + 1;
		}
		$scope.allowanceNoOfDays = getNumber(intDays);
		changeItemVal('allowanceNoOfDays');
	};
	
	$scope.openFromDate = function($event) {
        $scope.statusFromDate.opened = true;
    };
	$scope.openToDate = function($event) {
        $scope.statusToDate.opened = true;
    };
	$scope.statusFromDate = {
        opened: false
    };
	$scope.statusToDate = {
        opened: false
    };

	var changeItemVal = function(obj) {
		 if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
				if (obj == 'fromDate') {
					currItem.fromDate = $scope.fromDate
					currItem.fromDateTxt = getDateStr($filter, $scope.fromDate);
				} else if (obj == 'toDate') {
					currItem.toDate = $scope.toDate
					currItem.toDateTxt = getDateStr($filter, $scope.toDate);
				} else if (obj == 'typeOfAdvance') {
					currItem.typeOfAdvance = $scope.typeOfAdvance;
				} else if (obj == 'countryDestination') {
					currItem.countryDestination = $scope.countryDestination;
				} else if (obj == 'countryCode') {
					currItem.countryCode = $scope.countryCode;
				} else if (obj == 'location') {
					currItem.location = $scope.location;
				} else if (obj == 'typeOfExpenses') {
					currItem.typeOfExpenses = $scope.typeOfExpenses;
				} else if (obj == 'allowanceNoOfDays') {
					currItem.allowanceNoOfDays = $scope.allowanceNoOfDays;
				} else if (obj == 'hotelRate') {
					currItem.hotelRate = get2Float($scope.hotelRate);
				} else if (obj == 'lodgingRate') {
					currItem.lodgingRate = get2Float($scope.lodgingRate);
				} else if (obj == 'mealRate') {
					currItem.mealRate = get2Float($scope.mealRate);
				}
			}
		} else if (obj == 'newEntitlement') {
			if ($scope.newEntitlement) {
				$scope.newEntitlement.forEach(function (obj) {
					$scope.dutyMeal = obj.duty_meal;
					$scope.dutyHotel = obj.duty_hotel;
					$scope.dutyLodging = obj.duty_lodging;
					$scope.courseMeal = obj.course_meal;
					$scope.courseHotel = obj.course_hotel;
					$scope.courseLodging = obj.course_lodging;
				})
			} else {
				$scope.dutyMeal = get2Float(0);
				$scope.dutyHotel = get2Float(0);
				$scope.dutyLodging = get2Float(0);
				$scope.courseMeal = get2Float(0);
				$scope.courseHotel = get2Float(0);
				$scope.courseLodging = get2Float(0);
			}
		}
	};

	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
		changeItemVal('localAdvanceFundType');
	});
	$scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
		changeItemVal('localAdvanceProjectCode');
	});
	$scope.$watch('fromDate', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('fromDate');
			calculateDiffDays();
		}
	});
	$scope.$watch('toDate', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('toDate');
			calculateDiffDays();
		}
	});
	$scope.$watch('typeOfAdvance', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('typeOfAdvance');
			setTriggerRateFunction();
		}
	});
	$scope.$watch('countryDestination', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('countryDestination');
			$scope.countryCode = newValue.category_name
			$http({
				url: API_URL+'category-rates/',
				method: 'GET',
				params: {'categoryId': newValue.category}
			})
			.success(function (data, status, headers, config) {
				$scope.newEntitlement = data.results;
				changeItemVal('newEntitlement');
				setTriggerRateFunction();
			});
		}
	});	
	$scope.$watch('location', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('location');}
	});
	$scope.$watch('typeOfExpenses', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('typeOfExpenses');
			setTriggerRateFunction();
		}
	});
	$scope.$watch('advanceDetailsItems', function() {
        DataFormAdvanceDetails.setAdvanceDetailsItems($scope.advanceDetailsItems);
    }, true);

	var setTriggerRateFunction = function() {
		if ($scope.typeOfAdvance != '' && $scope.countryDestination != '' && $scope.typeOfExpenses != '') {
			setRateByType($scope.typeOfAdvance.code);
			setRateByTypeExpenses($scope.typeOfExpenses.code);
			calculateEachRate();
			changeItemVal('hotelRate');
			changeItemVal('lodgingRate');
			changeItemVal('mealRate');
			calculateAdvanceTotal();
		}
	}

	var setRateByType = function(typeAdvance) {
		if (typeAdvance == 'OfficialDuty') {
			$scope.hotelRate = $scope.dutyHotel;
			$scope.lodgingRate = $scope.dutyLodging;
			$scope.mealRate = $scope.dutyMeal;
		} else if (typeAdvance == 'Course') {
			$scope.hotelRate = $scope.courseHotel;
			$scope.lodgingRate = $scope.courseLodging;
			$scope.mealRate = $scope.courseMeal;
		}
	};
	
	var setRateByTypeExpenses = function(typeExpenses) {
		if (typeExpenses == 'MealHotel') {
			$scope.hotelEntitle = $scope.hotelRate;
			$scope.lodgingEntitle = get2Float(0);
			$scope.mealEntitle = $scope.mealRate;
		} else if (typeExpenses == 'MealLodging') {
			$scope.hotelEntitle = get2Float(0);
			$scope.lodgingEntitle = $scope.lodgingRate;
			$scope.mealEntitle = $scope.mealRate;
		} else if (typeExpenses == 'MealOnly') {
			$scope.hotelEntitle = get2Float(0);
			$scope.lodgingEntitle = get2Float(0);
			$scope.mealEntitle = $scope.mealRate;
		} else if (typeExpenses == 'HotelOnly') {
			$scope.hotelEntitle = $scope.hotelRate;
			$scope.lodgingEntitle = get2Float(0);
			$scope.mealEntitle = get2Float(0);
		} else if (typeExpenses == 'LodgingOnly') {
			$scope.hotelEntitle = get2Float(0);
			$scope.lodgingEntitle = $scope.lodgingRate;
			$scope.mealEntitle = get2Float(0);
		}
	};

	var calculateEachRate = function() {
		var totalHotel = 0;
		var totalLodging = 0;
		var totalMeal = 0;

		totalHotel = parseFloat($scope.hotelEntitle) * parseFloat($scope.allowanceNoOfDays);
		totalLodging = parseFloat($scope.lodgingEntitle) * parseFloat($scope.allowanceNoOfDays);
		totalMeal = parseFloat($scope.mealEntitle) * parseFloat($scope.allowanceNoOfDays);

		$scope.hotelRate = get2Float(totalHotel);
		$scope.lodgingRate = get2Float(totalLodging);
		$scope.mealRate = get2Float(totalMeal);
	};

	var calculateAdvanceTotal = function() {
		var totalHotelAllowance = 0;
		var totalLodgingAllowance = 0;
		var totalMealAllowance = 0;
		var grandTotal = 0;
		var totalAdvanceAllowed = 0;

		angular.forEach(getItems(), function(obj) {
			totalHotelAllowance = totalHotelAllowance + parseFloat(obj.hotelRate);
			totalLodgingAllowance = totalLodgingAllowance + parseFloat(obj.lodgingRate);
			totalMealAllowance = totalMealAllowance + parseFloat(obj.mealRate);
			grandTotal = grandTotal + parseFloat(obj.hotelRate) + parseFloat(obj.lodgingRate) + parseFloat(obj.mealRate);
		});

		totalAdvanceAllowed = (parseFloat(grandTotal) * 90) / 100;

		$scope.totalHotelAllowance = get2Float(totalHotelAllowance);
		$scope.totalLodgingAllowance = get2Float(totalLodgingAllowance);
		$scope.totalMealAllowance = get2Float(totalMealAllowance);
		$scope.grandTotal = get2Float(grandTotal);
		$scope.totalAdvanceAllowed = get2Float(totalAdvanceAllowed);
		
		DataFormAdvanceDetails.setTotalHotelAllowance($scope.totalHotelAllowance);
		DataFormAdvanceDetails.setTotalLodgingAllowance($scope.totalLodgingAllowance);
		DataFormAdvanceDetails.setTotalMealAllowance($scope.totalMealAllowance);
		DataFormAdvanceDetails.setGrandTotal($scope.grandTotal);
		DataFormAdvanceDetails.setTotalAdvanceAllowed($scope.totalAdvanceAllowed);
	};
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataClaimant', 'DataFormAdvanceDetails', function ($scope, $uibModal, $http, $window, DataClaimant, DataFormAdvanceDetails) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);

		form_data = {
			btn_mode:btnMode,
			advanceDetailsItems: DataFormAdvanceDetails.getAdvanceDetailsItems(),
			totalHotelAllowance:DataFormAdvanceDetails.getTotalHotelAllowance(),
			totalLodgingAllowance:DataFormAdvanceDetails.getTotalLodgingAllowance(),
			totalMealAllowance:DataFormAdvanceDetails.getTotalMealAllowance(),
			grandTotal:DataFormAdvanceDetails.getGrandTotal(),
			totalAdvanceAllowed:DataFormAdvanceDetails.getTotalAdvanceAllowed(),
			claimant_no:DataClaimant.getStaffNo(),
			draft_id:DataFormAdvanceDetails.getDraftID()
		}

		if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		} else if (btnMode == 'submit') {
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

				if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                }
				else
				{
					$http({
						url: '',
						method: 'POST',
						data: form_data
					})
					.success(function (data, status, headers, config) {
                        enable_claim_controls();
						var submit_success_url = data.submit_success_url;

						if (btnMode == 'submit') {
							$window.location.href = submit_success_url;
						} else if (btnMode == 'save_draft') {
							$scope.initSubmitCtrl(data.draft_id);
							$uibModal.open({
								animation: $scope.animationsEnabled,
								templateUrl: 'SaveSuccess.html',
								controller: 'ModalInstanceInfoCtrl',
								size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
								resolve: {
								  data: function () {
									return data;
								  }
								}
							});
                            $window.location.href = submit_success_url;
						}
					}).error(function () {
                        enable_claim_controls();
                    });
				}
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id) {
		$scope.draft_id = draft_id;
		DataFormAdvanceDetails.setDraftID(draft_id);
	};
}]);

uiBootstrapApp.factory('DataFormAdvanceDetails', function ($filter) {

    var data = {
		advanceDetailsItems : [],
		draft_id : '',
		totalHotelAllowance : 0,
		totalLodgingAllowance : 0,
		totalMealAllowance : 0,
		grandTotal : 0,
		totalAdvanceAllowed : 0,
    };

    return {
		getAdvanceDetailsItems: function () {
            return data.advanceDetailsItems;
        },
        setAdvanceDetailsItems: function (obj) {
            data.advanceDetailsItems = obj;
        },
		getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
		getTotalHotelAllowance: function () {
            return data.totalHotelAllowance;
        },
        setTotalHotelAllowance: function (obj) {
            data.totalHotelAllowance = obj;
        },
		getTotalLodgingAllowance: function () {
            return data.totalLodgingAllowance;
        },
        setTotalLodgingAllowance: function (obj) {
            data.totalLodgingAllowance = obj;
        },
		getTotalMealAllowance: function () {
            return data.totalMealAllowance;
        },
        setTotalMealAllowance: function (obj) {
            data.totalMealAllowance = obj;
        },
		getGrandTotal: function () {
            return data.grandTotal;
        },
        setGrandTotal: function (obj) {
            data.grandTotal = obj;
        },
		getTotalAdvanceAllowed: function () {
            return data.totalAdvanceAllowed;
        },
        setTotalAdvanceAllowed: function (obj) {
            data.totalAdvanceAllowed = obj;
        },
		reset: function (){

        }
    };
});