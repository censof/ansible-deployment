from decimal import *
from django.db import models
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import FundType, GSTTax
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.common import CLAIM_STATUS

LECTURER_CLAIM_TYPE = 10

LECTURE_TYPE_LIST = (
    ('PartimeLecturer', unicode(_('Part-time Lecturer'))),
    ('PartimeFacilitator', unicode(_('Part-time Facilitator'))),
    ('CorporateLecturer', unicode(_('Corporate Lecturer'))),
)


class LectureClaimAbstract(BaseModel):
    CLAIM_TYPE = 10

    status = models.CharField(max_length=CLAIM_STATUS.DEFAULT_LENGTH)  # deprecated, to be removed

    class Meta:
        app_label = 'lecture'
        abstract = True


class LectureClaimItemAbstract(models.Model):
    date = models.DateField()
    time_start = models.TimeField()
    time_end = models.TimeField()
    fund_type = models.ForeignKey(FundType, null=True, blank=True)
    lecture_type = models.CharField(max_length=30, choices=LECTURE_TYPE_LIST)
    rate = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    description = models.TextField()
    total_hour = models.DecimalField(max_digits=9, decimal_places=1, default=Decimal('0.0'))
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    gst_tax = models.ForeignKey(GSTTax)
    gst_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    nett_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))

    def __unicode__(self):
        return 'id=%s | date=%s | time_start=%s | time_end=%s ' % (self.id, self.date, self.time_start, self.time_end)

    class Meta:
        app_label = 'lecture'
        abstract = True


class LectureClaim(LectureClaimAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    class Meta(LectureClaimAbstract.Meta):
        app_label = 'lecture'
        verbose_name = 'Lecture Claim'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('lecture_detail'), self.pk)


class LectureClaimItem(LectureClaimItemAbstract):
    lecture_claim = models.ForeignKey(LectureClaim, null=True, blank=True)

    class Meta(LectureClaimItemAbstract.Meta):
        app_label = 'lecture'
        verbose_name = 'Lecture Claim Item'
        verbose_name_plural = verbose_name


class LectureClaimDraft(LectureClaimAbstract):

    class Meta(LectureClaimAbstract.Meta):
        app_label = 'lecture'
        verbose_name = 'Lecture Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('lecture_draft', args=[self.pk])


class LectureClaimItemDraft(LectureClaimItemAbstract):
    lecture_claim_draft = models.ForeignKey(LectureClaimDraft, null=True, blank=True)

    class Meta(LectureClaimAbstract.Meta):
        app_label = 'lecture'
        verbose_name = 'Lecture Claim Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
