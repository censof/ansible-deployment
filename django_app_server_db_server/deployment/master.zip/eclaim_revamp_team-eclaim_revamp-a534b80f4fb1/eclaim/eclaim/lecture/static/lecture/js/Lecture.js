/* Author 	: Danial
 * Date	: December 2015 */

console.log('Lecture Claim JS Loaded!!!');

uiBootstrapApp.controller('LectureClaimCtrl', function ($scope, $sce, $http, $log, $filter, DataGST, DataRates, DataSummary, DataLookup, DataFormMain) {

    /**
    *************************
    *   Start : Accordion   *
    *************************
   */
    $scope.oneAtATime = false;

    $scope.panels = [
        {name: 'claimantDetails', open: false},
        {name: 'claimantEntitlements', open: false},
        {name: 'claimDetails', open: true},
        {name: 'supportingDocuments', open: false},
        {name: 'summary', open: true},
        {name: 'formDeclaration', open: false},
    ];

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** End : Accordion */

    /*************** Initial Variable Start ***************/
    $scope.error_validation = false;
    $scope.claimant_no = '';
    $scope.draft_id = '';
    $scope.claim_no = '';
    $scope.object_pk = PK;
    $scope.showLectureForm = true;
    $scope.url_query_pdf = '';

    /* Start : General Config for Smart Table */
        $scope.pageSize = 5;
        $scope.currentPage = 1;
    /* End : General Config for Smart Table */

    /*************** Initial Variable End ***************/

    $scope.lectureTypes = [];
    $http({
        url: '/eclaim/claim-forms/lecture/lecture-type-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.lectureTypes = data;
        DataFormMain.setLectureTypes(data);
    });

    $http({
        url: API_URL+'expenses/',
        method: 'GET',
        params: {'claim_code':'LC'}
    })
    .success(function (data, status, headers, config) {
        $scope.expenses = data.results;
    });

    var claim_api_url = API_URL+'lecture-claims/';

    if (PK) {  // detail view
        $http({
            url: claim_api_url+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, $sce, 10, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, $sce, 10, 1);
    }

    init_workflow($scope, $http, 'lecture', 'LectureClaim', PK, claim_api_url, WF_TEMPLATE);
});


uiBootstrapApp.factory('DataFormMain', function ($filter) {
	var data = {
			LectureItems: [],
			error_validation: '',
			draft_id: '',
			claim_id: '',
            LectureTypes: ''
		};
	return {
        getLectureItems: function () {
            return data.LectureItems;
        },
        setLectureItems: function (obj) {
            data.LectureItems = obj;
        },
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (obj) {
            data.error_validation = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        },
        getLectureTypeByCode: function(code){
            var objSelect = $filter("filter")(data.LectureTypes, {code:code});
            return objSelect[0];
        },
        setLectureTypes: function(obj){
            return data.LectureTypes = obj;
        }
	};
});


uiBootstrapApp.controller('LectureFormCtrl', function($http, $scope, DataFundType, DataLookup, DataRates, DataGST,
                                                      DataFormMain, DataFormLecture){
    /**
     *  Initial data
     */
    $scope.lectureItems = [];
    $scope.lectureType = {};
    $scope.isDBMode = false;

    $scope.loadDataDB = function(draftID, claimID){
        if (draftID) {
            console.log('Load draft items for Draft [',draftID,']');
            $http({
                url: API_URL+'lecture-claim-drafts/'+draftID+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                data.items.forEach(function(obj){
                    $scope.addItem(obj);
                });
            });
        };
        if (claimID) {
            console.log('Load claim items for Claim [',claimID,']');
            $http({
                url: API_URL+'lecture-claims/'+claimID+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                data.items.forEach(function(obj){
                    $scope.addItem(obj);
                });
            });
        };
    };

    var setEmptyTable = function() {
        $scope.currIndex = '';
        $scope.isEmptyTable = true;
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    var setEditMode = function(itemIndex){
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };

    var setRow = function(objDB) {
        if (objDB) {
            DataFormLecture.setDate(getDateFromStr(objDB.date));
            DataFormLecture.setTimeFrom(getTimeFromStr(objDB.time_start));
            DataFormLecture.setTimeTo(getTimeFromStr(objDB.time_end));
            $scope.lectureType = DataFormMain.getLectureTypeByCode(objDB.lecture_type);
            $scope.lectureDescription = objDB.description;
            $scope.lectureTotalHours = objDB.total_hour;
            $scope.lectureTotalAmountGSTExclusive = objDB.amount;
            $scope.lectureGSTAmount = objDB.gst_amount;
            $scope.lectureTotalAmountGSTInclusive = objDB.nett_amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
        }
        return {
            lectureDate: DataFormLecture.getDate(), lectureDateTxt: DataFormLecture.getDateTxt()
            , lectureTimeFrom: DataFormLecture.getTimeFrom(), lectureTimeFromTxt: DataFormLecture.getTimeFromTxt()
            , lectureTimeTo: DataFormLecture.getTimeTo(), lectureTimeToTxt: DataFormLecture.getTimeToTxt()
            , lectureType: $scope.lectureType, lectureTypeRate: get2Float(DataRates.getSelectedRate())
            , lectureDescription: $scope.lectureDescription
            , lectureTotalHours: getNumber($scope.lectureTotalHours)
            , lectureTotalAmountGSTExclusive: get2Float($scope.lectureTotalAmountGSTExclusive)
            , lectureGSTType: DataGST.getGSTType()
            , lectureGSTPercentage: DataGST.getGSTType()
            , lectureGSTAmount: get2Float($scope.lectureGSTAmount)
            , lectureTotalAmountGSTInclusive: get2Float($scope.lectureTotalAmountGSTInclusive)
            , lectureFundType: DataFundType.getFundType()
            , lectureProjectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem) {
        DataFormLecture.setDate(currItem.lectureDate);
        DataFormLecture.setTimeFrom(currItem.lectureTimeFrom);
        DataFormLecture.setTimeTo(currItem.lectureTimeTo);
        $scope.lectureType = currItem.lectureType;
        $scope.lectureDescription = currItem.lectureDescription;
        $scope.lectureTotalHours = currItem.lectureTotalHours;
        $scope.lectureTotalAmountGSTExclusive = currItem.lectureTotalAmountGSTExclusive;
        /*$scope.lectureGSTType = currItem.lectureGSTType;
        $scope.lectureGSTPercentage = currItem.lectureGSTPercentage;
        $scope.lectureGSTAmount = currItem.lectureGSTAmount;*/
        $scope.lectureTotalAmountGSTInclusive = currItem.lectureTotalAmountGSTInclusive;
        DataFundType.setFundType(currItem.lectureFundType);
        DataLookup.setProjectCode(currItem.lectureProjectCode);
        DataGST.setGSTType(currItem.lectureGSTType);
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode && !$scope.isDBMode) {
            var currItem = getItems($scope.currIndex);
            if (obj == 'lectureDate') {
                currItem.lectureDate = DataFormLecture.getDate();
                currItem.lectureDateTxt = DataFormLecture.getDateTxt();
            }else if (obj == 'lectureTimeFrom') {
                currItem.lectureTimeFrom = DataFormLecture.getTimeFrom();
                currItem.lectureTimeFromTxt = DataFormLecture.getTimeFromTxt();
            }else if (obj == 'lectureTimeTo') {
                currItem.lectureTimeTo = DataFormLecture.getTimeTo();
                currItem.lectureTimeToTxt = DataFormLecture.getTimeToTxt();
            }else if (obj == 'lectureType') {
                currItem.lectureType = $scope.lectureType;
            }else if (obj == 'lectureDescription') {
                currItem.lectureDescription = $scope.lectureDescription;
            }else if (obj == 'lectureTotalHours') {
                currItem.lectureTotalHours = $scope.lectureTotalHours;
            }else if (obj == 'lectureTotalAmountGSTExclusive') {
                currItem.lectureTotalAmountGSTExclusive = $scope.lectureTotalAmountGSTExclusive;
            }else if (obj == 'lectureGSTType') {
                currItem.lectureGSTType = DataGST.getGSTType();
                currItem.lectureGSTPercentage = DataGST.getGSTType();
            }else if (obj == 'lectureGSTAmount') {
                currItem.lectureGSTAmount = $scope.lectureGSTAmount;
            }else if (obj == 'lectureTotalAmountGSTInclusive') {
                currItem.lectureTotalAmountGSTInclusive = $scope.lectureTotalAmountGSTInclusive;
            }else if (obj == 'lectureFundType') {
                currItem.lectureFundType = DataFundType.getFundType();
            }else if (obj == 'lectureProjectCode') {
                currItem.lectureProjectCode = DataLookup.getProjectCode();
            }
        }
    };

    var getItems = function(itemIndex){
        var obj = [];
        if (itemIndex == undefined) {
            obj = $scope.lectureItems;
        }else{
            obj = $scope.lectureItems[itemIndex];
        }
        return obj;
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

    $scope.addItem = function(objDB){
        getItems().push(setRow(objDB));
        $scope.isEmptyTable = false;
        //$scope.resetForm();
        calculateAllSummary();
    };

    $scope.deleteItem = function(itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAllSummary();
    };

    $scope.editItem = function(itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        var currItem = $scope.lectureItems[index];
        setForm(currItem);
        $scope.isEditMode = true;
        $scope.openModal();
    };

    $scope.openModal = function(){
        $('#lectureModalForm').modal('show');
    };

    /* Start : Calculation */
        var lectureTimeDiff = function (timeStart, timeEnd) {
            /* Based on LHDN secular
            1) Must be minimum of 1 hour
                etc:
                start_time = 08:00, end_time = 08:45
                Total Hour is 0 Hour
            2) Minutes is calculated as 30 min whole
                etc:
                start_time = 08:00, end_time = 09:45
                Total Hour is 1 Hour 30 Min, hence to displayed as 1.5 hours
            */

            if (angular.isDate(timeStart) && angular.isDate(timeEnd)) {
                var exactTime = 0;
                var diff = timeEnd - timeStart;
                var hours = Math.floor(diff / 1000 / 60 / 60);
                diff -= hours * 1000 * 60 * 60;
                var minutes = Math.floor(diff / 1000 / 60);
                if (hours > 0) {
                    if (minutes >= 30) {
                        minutes = 30;
                    } else {
                        minutes = 0;
                    }
                    minutes = minutes / 60; //to display as 0.5 instead of 30
                    exactTime = hours+minutes;
                }
                $scope.lectureTotalHours = exactTime;
                changeItemVal('lectureTotalHours');
                calculateAllSummary();
            }
            //console.log(strStart+' | '+strEnd+' | '+exact_time);
        };

        var calculateTotal = function () {
            var amountOri = parseFloat(DataRates.getSelectedRate()) * parseFloat(get2Float($scope.lectureTotalHours));
            var gstAmount = parseFloat(DataGST.getGSTFloat()) * parseFloat(amountOri);
            $scope.lectureTotalAmountGSTExclusive = get2Float(amountOri);
            $scope.lectureGSTAmount = get2Float(gstAmount);
            $scope.lectureTotalAmountGSTInclusive = get2Float(parseFloat(amountOri) + parseFloat(gstAmount));
            changeItemVal('lectureTotalAmountGSTExclusive');
            changeItemVal('lectureGSTAmount');
            changeItemVal('lectureTotalAmountGSTInclusive');
            //calculateGrandTotal();
        };

        var calculateGrandTotal = function() {
            var grandTotalGSTExclusive = 0;
            var grandTotalGSTAmount = 0;
            var grandTotalGSTInclusive = 0;

            angular.forEach(getItems(), function(obj){
                grandTotalGSTExclusive = grandTotalGSTExclusive + parseFloat(obj.lectureTotalAmountGSTExclusive);
                grandTotalGSTAmount = grandTotalGSTAmount + parseFloat(obj.lectureGSTAmount);
                grandTotalGSTInclusive = grandTotalGSTInclusive + parseFloat(obj.lectureTotalAmountGSTInclusive);
            });
            $scope.grandTotalGSTExclusive = get2Float(grandTotalGSTExclusive);
            $scope.grandTotalGSTAmount = get2Float(grandTotalGSTAmount);
            $scope.grandTotalGSTInclusive = get2Float(grandTotalGSTInclusive);
        };

        var calculateAllSummary = function () {
            calculateGrandTotal();
        };

    /* End : Calculation */

    $scope.$watch('lectureType', function(newValue, oldValue){
        if (newValue != oldValue) {
            changeItemVal('lectureType');
            var lectureTypeRate = 0;
            if ($scope.lectureType) {
                var lecture = $scope.lectureType.code;
                if (lecture=='PartimeLecturer') {
                    lectureTypeRate = DataRates.getParttimeRate();
                }else if (lecture=='PartimeFacilitator') {
                    lectureTypeRate = DataRates.getFacilitatorRate();
                }else if (lecture=='CorporateLecturer') {
                    lectureTypeRate = DataRates.getCorporateRate();
                }
            }
            console.log(lectureTypeRate);
            DataRates.setSelectedRate(get2Float(lectureTypeRate));
            calculateTotal();
        }
    });

    $scope.$watch('lectureDescription', function(newValue, oldValue){
        changeItemVal('lectureDescription');
    });

    $scope.$watch(function () { return DataFormLecture.getDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('lectureDate');
            lectureTimeDiff(DataFormLecture.getTimeFrom(), DataFormLecture.getTimeTo());
        }
    });

    $scope.$watch(function () { return DataFormLecture.getTimeFrom(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('lectureTimeFrom');
            lectureTimeDiff(DataFormLecture.getTimeFrom(), DataFormLecture.getTimeTo());
        }
    });

    $scope.$watch(function () { return DataFormLecture.getTimeTo(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('lectureTimeTo');
            lectureTimeDiff(DataFormLecture.getTimeFrom(), DataFormLecture.getTimeTo());
        }
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('lectureFundType');
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('lectureProjectCode');
    });

    $scope.$watch(function () { return DataGST.getGSTType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('lectureGSTType');
            calculateTotal();
        }
    });

    $scope.$watch('lectureItems', function() {
        DataFormMain.setLectureItems($scope.lectureItems);
    }, true);

    /**
     *  Do initial setup when controller loaded.
     */
    setEmptyTable();
});


uiBootstrapApp.controller('LectureDateCtrl', function($scope, DataFormLecture){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.lectureDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initLectureDate = function(){
        //console.log('Load initMileageDepartDate (Default)');
    };

	$scope.dateChanged = function(){
        DataFormLecture.setDate($scope.lectureDate);
	};

    $scope.$watch(function () { return DataFormLecture.getDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.lectureDate = newValue;
        }
    });
});


uiBootstrapApp.controller('LectureTimeCtrl', function ($scope, DataFormLecture) {

	$scope.hstep = 1;
	$scope.mstep = 1;

	$scope.options = {
	  hstep: [1, 2, 3],
	  mstep: [1, 5, 10, 15, 25, 30]
	};

	$scope.ismeridian = false;

    $scope.resetTime = function(){
        var initTime = new Date();
        initTime.setHours(0);
        initTime.setMinutes(0);
        $scope.lectureTimeFrom = initTime;
        $scope.lectureTimeTo = initTime;
    };

    $scope.$watch('lectureTimeFrom', function(newValue, oldValue){
        if (newValue != oldValue) {
            DataFormLecture.setTimeFrom(newValue);
        }
    });

    $scope.$watch('lectureTimeTo', function(newValue, oldValue){
        if (newValue != oldValue) {
            DataFormLecture.setTimeTo(newValue);
        }
    });

    $scope.$watch(function () { return DataFormLecture.getTimeFrom(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.lectureTimeFrom = newValue;
        }
    });

    $scope.$watch(function () { return DataFormLecture.getTimeTo(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.lectureTimeTo = newValue;
        }
    });

    $scope.resetTime();
});


uiBootstrapApp.factory('DataFormLecture', function ($filter) {
    var data = {
        LectureItems : [],
		Date : '',
		DateTxt : '-',
        TimeFrom : '',
        TimeFromTxt : '00:00',
        TimeTo : '',
        TimeToTxt : '00:00',
    };

    return {
        getLectureItems: function () {
            return data.LectureItems;
        },
        setLectureItems: function (obj) {
            data.LectureItems = obj;
        },
        reset: function (){
            data.Date = 'reset';
            data.DateTxt = '-';
            data.TimeFrom = 'reset';
            data.TimeFromTxt = '00:00';
            data.TimeTo = 'reset';
            data.TimeToTxt = '00:00';
        },
        getDate: function () {
            return data.Date;
        },
        getDateTxt: function () {
            return data.DateTxt;
        },
        setDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.Date = obj;
            data.DateTxt = minDate;
        },
        getTimeFrom: function () {
            return data.TimeFrom;
        },
        getTimeFromTxt: function () {
            return data.TimeFromTxt;
        },
        setTimeFrom: function (obj) {
            data.TimeFrom = obj;
            data.TimeFromTxt = getTimeStr(obj);
        },
        getTimeTo: function () {
            return data.TimeTo;
        },
        getTimeToTxt: function () {
            return data.TimeToTxt;
        },
        setTimeTo: function (obj) {
            data.TimeTo = obj;
            data.TimeToTxt = getTimeStr(obj);
        }
    };
});


uiBootstrapApp.controller('RatesCtrl', function ($scope, $log, DataRates) {
	$scope.parttimelecture_rate = 0;
	$scope.facilitator_rate = 0;
	$scope.corporate_rate = 0;

	$scope.initRatesCtrl = function(jsonLectureTypeRates){
		if (!$.isEmptyObject(jsonLectureTypeRates)) {
			console.log('Load initRatesCtrl (Django Obj)');

			var rates = getAngularObjFromJson(jsonLectureTypeRates)[0];
			var parttimelecture_rate = rates.parttimelecture_rate;
			var facilitator_rate = rates.facilitator_rate;
			var corporate_rate = rates.corporate_rate;

			$scope.parttimelecture_rate = parttimelecture_rate;
			$scope.facilitator_rate = facilitator_rate;
			$scope.corporate_rate = corporate_rate;

			DataRates.setParttimeRate(parttimelecture_rate);
			DataRates.setFacilitatorRate(facilitator_rate);
			DataRates.setCorporateRate(corporate_rate);
		}
	};
});


uiBootstrapApp.factory('DataRates', function (){
	var data = {
		ParttimeRate : 0,
		FacilitatorRate : 0,
		CorporateRate : 0,
        SelectedRate : 0
	};

	return {
		getParttimeRate : function(){
			return data.ParttimeRate;
		},
		setParttimeRate : function(val){
			return data.ParttimeRate = val;
		},
		getFacilitatorRate : function(){
			return data.FacilitatorRate;
		},
		setFacilitatorRate : function(val){
			return data.FacilitatorRate = val;
		},
		getCorporateRate : function(){
			return data.CorporateRate;
		},
		setCorporateRate : function(val){
			return data.CorporateRate = val;
		},
		getSelectedRate : function(){
			return data.SelectedRate;
		},
		setSelectedRate : function(val){
			return data.SelectedRate = val;
		}
	};
});


uiBootstrapApp.controller('SummaryCtrl', function($http, $scope, DataFormMain){
    $scope.masterExpensesSummary = [];
    $scope.masterGSTSummary = [];
    $scope.claimGrandTotal = get2Float(0);
    $scope.claimNettTotal = get2Float(0);
    $scope.claimGSTTotal = get2Float(0);

    /**
     * Values in codeMap must exist in expenses.type_code DB Table
    */
    var PARTTIME_LECTURER = {codeMap: 'PARTTIME_LECTURER', items: [], objFundType: 'lectureFundType', objAmount: 'lectureTotalAmountGSTExclusive', objGSTType: 'lectureGSTType', objGSTAmount: 'lectureGSTAmount'};
    var PARTTIME_FACILITATOR = {codeMap: 'PARTTIME_FACILITATOR', items: [], objFundType: 'lectureFundType', objAmount: 'lectureTotalAmountGSTExclusive', objGSTType: 'lectureGSTType', objGSTAmount: 'lectureGSTAmount'};
    var CORPORATE_LECTURER = {codeMap: 'CORPORATE_LECTURER', items: [], objFundType: 'lectureFundType', objAmount: 'lectureTotalAmountGSTExclusive', objGSTType: 'lectureGSTType', objGSTAmount: 'lectureGSTAmount'};

    /**
     * Set to display in Sub/Panel Summary
    */
    $scope.setExpenses = [PARTTIME_LECTURER, PARTTIME_FACILITATOR, CORPORATE_LECTURER];

    var calculateGrandTotal = function(){
        var claimGrandTotal = 0;
        var claimGSTTotal = 0;
        var claimNettTotal = 0;

        claimGrandTotal = getListTotalAmount(DataFormMain.getLectureItems(), 'lectureTotalAmountGSTExclusive');
        claimGSTTotal = getListTotalAmount(DataFormMain.getLectureItems(), 'lectureGSTAmount');
        claimNettTotal = parseFloat(claimGrandTotal) + parseFloat(claimGSTTotal);

        $scope.claimGrandTotal = get2Float(claimGrandTotal);
        $scope.claimGSTTotal = get2Float(claimGSTTotal);
        $scope.claimNettTotal = get2Float(claimNettTotal);
    };

    var loadSummary = function(){
        var parttime_lecturer_items = [];
        var parttime_facillitator_items = [];
        var corporate_lecturer_items = [];

        /* Divide items by lecture type */
        DataFormMain.getLectureItems().forEach(function(obj){
            if (obj.lectureType.code == 'PartimeLecturer') {
                parttime_lecturer_items.push(obj);
            }else if (obj.lectureType.code == 'PartimeFacilitator') {
                parttime_facillitator_items.push(obj);
            }else if (obj.lectureType.code == 'CorporateLecturer') {
                corporate_lecturer_items.push(obj);
            }
        });

        /* Update items */
        $scope.setExpenses[0].items = parttime_lecturer_items;
        $scope.setExpenses[1].items = parttime_facillitator_items;
        $scope.setExpenses[2].items = corporate_lecturer_items;

        /* Load grouped Fund Type for sub expenses summary */
        $scope.masterExpensesSummary = $scope.expenses;

        $scope.masterExpensesSummary.forEach(function (obj) {
            obj.show = false;
            obj.amount = get2Float(0);
            obj.groupedFundType = [];

            $scope.setExpenses.forEach(function (objSet) {
                var group = [];
                var amount = get2Float(0);

                if (obj.type_code == objSet.codeMap) {
                    if (objSet.items) {
                        group = getGroupedType(objSet.items, objSet.objFundType, objSet.objAmount);
                        amount = getListTotalAmount(objSet.items, objSet.objAmount);
                    }
                    angular.merge(obj, {show: true, amount: get2Float(amount), groupedFundType: group});
                }
            });
        });

        // Load grouped GST Type for sub expenses summary
        var groupedGSTType = [];

        $scope.setExpenses.forEach(function (objSet) {
            var group = [];
            var amount = get2Float(0);

            if (objSet.items) {
                group = getGroupedType(objSet.items, objSet.objGSTType, objSet.objGSTAmount);
                amount = getListTotalAmount(objSet.items, objSet.objGSTAmount);
            }
            groupedGSTType.push(group);
        });

        $scope.masterGSTSummary = getMixGroupedType(groupedGSTType);
        calculateGrandTotal();
    };

    /* Watch Items */
    $scope.$watch(function () { return DataFormMain.getLectureItems(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            loadSummary();
        }
    }, true);
});


uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataClaimant', 'DataLookup', 'DataFormMain', function ($scope, $uibModal, $http, $window, DataClaimant, DataLookup, DataFormMain) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);
		//console.log(DataLookup.getPTJCharged());
		//console.log(DataFormMain.getTabs());
		//console.log(DataFormMain.getErrorValidation());
		//console.log(DataFormMain.getClaimantNo());
		//console.log(DataDocumentList.getDocumentList())

		form_data = {
			btn_mode:btnMode,
			lectureItems: DataFormMain.getLectureItems(),
			//ptj_charged: DataLookup.getPTJCharged(),
			claimant_no: DataClaimant.getStaffNo(),
			draft_id: DataFormMain.getDraftID(),
            //document_list: DataDocumentList.getDocumentList()
			document_list: []
		}

        if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

                // if (PK && $scope.claim.query) {
                //     var params = {
                //         claim_no: $scope.claim.claim_no,
                //         claim_ctype: $scope.claim.claim_ctype_id
                //     };

                //     $http({
                //         url: URL_AJAX_RESUBMIT_TO,
                //         method: 'POST',
                //         data: params
                //     })
                //     .success(function (data, status, headers, config) {
                //         $window.location.href = submit_success_url;
                //     });
                // }

                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                } else {
    				$http({
    					url: '',
    					method: 'POST',
    					data: form_data
    				})
    				.success(function (data, status, headers, config) {
                        var submit_success_url = data.submit_success_url || URL_HOMEPAGE;

    					if (btnMode == 'submit') {
                            $window.location.href = submit_success_url;
                        } else if (btnMode == 'save_draft') {
    						$scope.initSubmitCtrl(data.draft_id);
    						$uibModal.open({
    							animation: $scope.animationsEnabled,
    							templateUrl: 'SaveSuccess.html',
    							controller: 'ModalInstanceInfoCtrl',
    							size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
    							resolve: {
    							  data: function () {
    								return data;
    							  }
    							}
    						});
                            $window.location.href = submit_success_url;
    					}
    				}).error(function () {
                        enable_claim_controls();
                    });
                }
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id){
		$scope.draft_id = draft_id;
		DataFormMain.setDraftID(draft_id);
	};
}]);
