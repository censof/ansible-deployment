import datetime
from decimal import *

from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.common import CLAIM_TYPE
from eclaim.masterfiles.utils import save_claimant_history, save_document_list_item_draft, \
                                     save_document_list_item
from eclaim.utils.common import get_claim_type_code, get_claim_type_prefix, \
                                generate_claim_no, get_fund_type, get_gst_tax
from .models import LECTURER_CLAIM_TYPE, LectureClaimDraft, LectureClaimItemDraft, \
                    LectureClaim, LectureClaimItem


__ClaimType__ = get_claim_type_code(LECTURER_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(LECTURER_CLAIM_TYPE)


def process_controller(btn_mode, form_data, created_by=None):
    draft_id = None
    claim_id = None
    display_id = None

    # MODE = DRAFT @ SUBMIT
    print '*** Process MODE [',btn_mode,'] ***'

    if btn_mode in ['save_draft']:
        draft_id = save_draft(form_data, created_by)
        display_id = draft_id
    elif btn_mode in ['submit']:
        claim_id = submit_claim(form_data)
        display_id = claim_id

    print '*** Process MODE [%s] <> ID [%s], complete successfully ***' % (btn_mode , str(display_id))
    return draft_id, claim_id

def save_draft(form_data, created_by=None):
    draft_id = form_data.get('draft_id')

    if draft_id == '':
        claim_draft = LectureClaimDraft()
        claim_draft.status = 'D'
        if created_by is not None:
            claim_draft.created_by = created_by
        claim_draft.save()
        print '>>> New ID [',claim_draft.id,'] created'

        save_lecture_claim_item('save_draft', claim_draft, form_data)
        save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)
        return claim_draft.id
    else:
        print '>>> Re-Processing form_data for ID [',draft_id,']'
        claim_draft = LectureClaimDraft(id=int(draft_id))
        if created_by is not None:
            claim_draft.created_by = created_by
        delete_lecture_claim_draft_item(claim_draft)
        save_lecture_claim_item('save_draft', claim_draft, form_data)
        save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)
        return draft_id

def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')

    claim = LectureClaim()
    claim.status = 'S'  # deprecated field, to be removed
    claim.save()
    claim.claim_no = generate_claim_no(__ClaimPrefix__, claim.id)
    claim.save()
    print '>>> New ID [',claim.id,'] created'

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_lecture_claim_item('submit_claim', claim, form_data)
    save_document_list_item(claim.claim_no, __ClaimType__, form_data)
    return claim.id

def save_lecture_claim_item(mode, parent, form_data):
    print '      >>> Saving Lecture Items',
    for i in form_data.get('lectureItems'):
        date = i['lectureDateTxt']
        time_start = i['lectureTimeFromTxt']
        time_end = i['lectureTimeToTxt']
        lecture_type_code = i['lectureType'].get('code')
        lecture_type_rate = i['lectureTypeRate']
        description = i['lectureDescription']
        total_hour = i['lectureTotalHours']
        amount = i['lectureTotalAmountGSTExclusive']
        gst_type_code = i['lectureGSTType'].get('code')
        gst_amount = i['lectureGSTAmount']
        nett_amount = i['lectureTotalAmountGSTInclusive']
        fund_type_code = i['lectureFundType'].get('code')

        if mode in ['save_draft']:
            saveObj = LectureClaimItemDraft()
            saveObj.lecture_claim_draft = parent

        elif mode in ['submit_claim']:
            saveObj = LectureClaimItem()
            saveObj.lecture_claim = parent

        saveObj.rate = Decimal(lecture_type_rate)
        saveObj.date = datetime.datetime.strptime(date, "%Y-%m-%d")
        saveObj.time_start = time_start
        saveObj.time_end = time_end
        saveObj.fund_type = get_fund_type(fund_type_code)
        saveObj.lecture_type = lecture_type_code
        saveObj.description = description
        saveObj.total_hour = total_hour
        saveObj.amount = amount
        saveObj.gst_tax = get_gst_tax(gst_type_code)
        saveObj.gst_amount = gst_amount
        saveObj.nett_amount = nett_amount
        saveObj.save()
    print '...Success'

def delete_lecture_claim_draft_item(parent):
    delObj = LectureClaimItemDraft.objects.filter(lecture_claim_draft=parent)
    delObj.delete()

