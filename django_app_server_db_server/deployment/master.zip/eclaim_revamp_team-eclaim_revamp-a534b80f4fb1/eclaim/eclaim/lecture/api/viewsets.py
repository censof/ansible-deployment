from rest_framework import viewsets

from .serializers import LectureClaimDraftSerializer, LectureClaimSerializer
from ..models import LectureClaimDraft, LectureClaim

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LectureClaimDraftViewSet',
    'LectureClaimViewSet'
    ]


class LectureClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = LectureClaimDraftSerializer
    queryset = LectureClaimDraft.objects.all()


class LectureClaimViewSet(viewsets.ModelViewSet):
    serializer_class = LectureClaimSerializer
    queryset = LectureClaim.objects.all()
