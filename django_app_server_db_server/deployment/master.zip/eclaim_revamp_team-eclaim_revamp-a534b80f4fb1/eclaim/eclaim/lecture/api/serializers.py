from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from eclaim.settings.models import (
    WorkflowState, SelectedAssignee, UserGroup, FormDeclaration)
from ..models import LectureClaimDraft, LectureClaim

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LectureClaimDraftSerializer',
    'LectureClaimSerializer'
    ]


class LectureClaimDraftSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = LectureClaimDraft
        fields = ('id', 'status', 'items', 'created_by')

    def get_items(self, obj):
        return list(obj.lectureclaimitemdraft_set.values())


class LectureClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = LectureClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        return list(obj.lectureclaimitem_set.values())
