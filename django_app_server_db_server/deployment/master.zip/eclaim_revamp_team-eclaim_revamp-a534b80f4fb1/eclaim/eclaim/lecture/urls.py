# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import LectureIndexView, LectureDraftView, LectureDetailView

urlpatterns = patterns('',
    url(r'^$', LectureIndexView.as_view(), name='lecture_index'),
    url(r'^detail/$', LectureDetailView.as_view(), name='lecture_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', LectureDraftView.as_view(), name='lecture_draft')
)

urlpatterns += patterns(
    'eclaim.lecture.ajax',

    url(r'^lecture-type-list/$', 'get_lecture_type_list', name='lecture_type_list')
)
