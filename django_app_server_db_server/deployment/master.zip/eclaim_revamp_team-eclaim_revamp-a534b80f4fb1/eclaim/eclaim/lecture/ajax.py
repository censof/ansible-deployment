from django.http import HttpResponse

from eclaim.utils.common import get_json_from_list

from .models import LECTURE_TYPE_LIST


def get_lecture_type_list(request):
    return HttpResponse(get_json_from_list(LECTURE_TYPE_LIST))