import json
from django.db.models import Max
from eclaim.claim.models import ClaimType
from eclaim.utils.common import get_json_from_list
from eclaim.masterfiles.models.entitlement import LectureClaimEntitlement


def get_lecture_type_rate(claimant_salary_grade):
    rate = {}
    lecture_rate = LectureClaimEntitlement.objects.filter(ssm_grade_from__code__lte=claimant_salary_grade, ssm_grade_to__code__gte=claimant_salary_grade).annotate(Max('effective_date'))

    # Expences code for Corporate & International Lecture, use to extract PTJ charging
    # etc : A-W-W15-18103-B29412, W15 is default ptj charging
    # Assuming Corporate & International are using same PTJ Charging
    try:
        expences_code = ClaimType.objects.get(code=100)
        auto_ptjcharging = str(expences_code.expense_code).split('-')[2]
    except:
        auto_ptjcharging = None

    for i in lecture_rate:
        rate = {'parttimelecture_rate':str(i.lecture_rate), 'facilitator_rate':str(i.facilitator_rate)
                , 'corporate_rate':str(i.lecture_rate)
                , 'monthly_claim_limit_bysalary':str(i.monthly_claim_limit_bysalary)
                , 'auto_ptjcharging':auto_ptjcharging}

    return rate


def get_json_lecture_type_rate(claimant_salary_grade):
    rate = {}
    lecture_rate = LectureClaimEntitlement.objects.filter(ssm_grade_from__code__lte=claimant_salary_grade, ssm_grade_to__code__gte=claimant_salary_grade).annotate(Max('effective_date'))

    # Expences code for Corporate & International Lecture, use to extract PTJ charging
    # etc : A-W-W15-18103-B29412, W15 is default ptj charging
    # Assuming Corporate & International are using same PTJ Charging
    try:
        expences_code = ClaimType.objects.get(code=100)
        auto_ptjcharging = str(expences_code.expense_code).split('-')[2]
    except:
        auto_ptjcharging = None

    for i in lecture_rate:
        rate = [{'parttimelecture_rate':str(i.lecture_rate), 'facilitator_rate':str(i.facilitator_rate)
                , 'corporate_rate':str(i.lecture_rate)
                , 'monthly_claim_limit_bysalary':str(i.monthly_claim_limit_bysalary)
                , 'auto_ptjcharging':auto_ptjcharging}]

    return json.dumps(rate)
