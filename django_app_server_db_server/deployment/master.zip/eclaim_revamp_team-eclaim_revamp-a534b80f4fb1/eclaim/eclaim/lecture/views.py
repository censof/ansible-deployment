import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text

from eclaim.claim.models import ClaimType
from eclaim.auth.authenticate import Authenticate
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import ClaimDetailView, ClaimIndexView
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.misc import FundType, GST_LIST
from eclaim.masterfiles.utils import (
    get_document_list, get_document_list_item, get_document_list_item_draft)
from eclaim.masterfiles.common import CLAIM_TYPE, SUMMARY
from eclaim.utils.common import get_claim_type_code, get_claim_type_prefix, \
                                get_json_from_set_obj, get_json_from_list

from .models import (
    LECTURER_CLAIM_TYPE, LECTURE_TYPE_LIST, LectureClaim, LectureClaimDraft, LectureClaimItemDraft)
from .entitlement import get_lecture_type_rate, get_json_lecture_type_rate
from .processes import process_controller


__ClaimType__ = get_claim_type_code(LECTURER_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(LECTURER_CLAIM_TYPE)


class LectureIndexView(ClaimIndexView):
    """
    This is index page for Lecture Claims.
    """
    template_name = 'lecture/lecture_claim.html'
    claim_type = ClaimType.get_claim_type(10)
    submit_success_url = reverse_lazy('claim_list')
    #form_class = ClaimantViewFormMixin
    #model = Claimant

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(LectureIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None
            rates_entitlements = None

        if claimant:
            rates_entitlements = get_json_lecture_type_rate(claimant.grade_level_category.code)

        context['claimant'] = claimant
        context['DOC_LIST'] = get_document_list(__ClaimType__)
        context['SUMMARY'] = SUMMARY().get_summary(__ClaimType__)

        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        context['jsonGSTList'] = get_json_from_list(GST_LIST)
        context['jsonLectureTypeList'] = get_json_from_list(LECTURE_TYPE_LIST)
        context['jsonLectureTypeRates'] = rates_entitlements
        return context

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(
            btn_mode, form_data, request.user)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, LectureClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, LectureClaim, claim_id,
                                             new_claim=True)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class LectureDetailView(ClaimDetailView):
    """
    This is detail view for Lecture Claims.
    """
    model = LectureClaim
    claim_type = ClaimType.get_claim_type(10)
    template_name = 'lecture/lecture_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(LectureDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None
            rates_entitlements = None

        if claimant:
            rates_entitlements = get_json_lecture_type_rate(claimant.grade_level_category.code)

        ctx['claimant'] = claimant
        ctx['FUND_TYPE_LIST'] = FundType.objects.all()
        ctx['LECTURE_TYPE_LIST'] = LECTURE_TYPE_LIST
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)
        ctx['SUMMARY'] = SUMMARY().get_summary(__ClaimType__)

        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonGSTList'] = get_json_from_list(GST_LIST)
        ctx['jsonLectureTypeList'] = get_json_from_list(LECTURE_TYPE_LIST)
        ctx['jsonLectureTypeRates'] = rates_entitlements

        obj_pk = self.request.GET['pk']
        # claim = LectureClaim.objects.get(pk=obj_pk)
        # rates = json.dumps(rates_entitlements)
        # tabs = get_json_from_set_obj(claim.lectureclaimitem_set.all())
        # doclist = get_document_list_item(claim.claim_no, __ClaimType__)
        # document_list = get_json_from_set_obj(doclist)
        #
        # ctx['claim_no'] = claim.claim_no
        # ctx['json_tabs'] = tabs
        # ctx['json_rates'] = rates
        # ctx['json_documentlist'] = document_list
        ctx['draftID'] = ''
        ctx['claimID'] = obj_pk
        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                try:
                    print '>>> Creating workflow',
                    create_new_states(claimant, LectureClaim, claim_id)
                    print '...Success'
                except:
                    print '...Failed'
                    raise

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, LectureClaim, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class LectureDraftView(TemplateView):
    template_name = 'lecture/lecture_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(LectureDraftView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        context = super(LectureDraftView, self).get_context_data(**kwargs)
        draft_id = self.kwargs['draft_id']

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None
            rates_entitlements = None

        if claimant:
            rates_entitlements = get_json_lecture_type_rate(claimant.grade_level_category.code)

        context['claimant'] = claimant
        context['FUND_TYPE_LIST'] = FundType.objects.all()
        context['LECTURE_TYPE_LIST'] = LECTURE_TYPE_LIST
        context['DOC_LIST'] = get_document_list(__ClaimType__)
        context['SUMMARY'] = SUMMARY().get_summary(__ClaimType__)

        draft = LectureClaimDraft.objects.get(id=int(draft_id))
        lecture_items = get_json_from_set_obj(draft.lectureclaimitemdraft_set.all())
        document_list = get_json_from_set_obj(get_document_list_item_draft(draft.id, __ClaimType__))

        context['json_documentlist'] = document_list

        context['jsonLectureItems'] = lecture_items
        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        context['jsonGSTList'] = get_json_from_list(GST_LIST)
        context['jsonLectureTypeList'] = get_json_from_list(LECTURE_TYPE_LIST)
        context['jsonLectureTypeRates'] = rates_entitlements

        context['draftID'] = draft.id
        context['claimID'] = ''
        return context

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(
            btn_mode, form_data, request.user)

        response_data = {'errors': False, 'draft_id':draft_id, 'claim_id':claim_id, 'submit_success_url': force_text(self.submit_success_url)}
        return HttpResponse(json.dumps(response_data), content_type="application/json")
