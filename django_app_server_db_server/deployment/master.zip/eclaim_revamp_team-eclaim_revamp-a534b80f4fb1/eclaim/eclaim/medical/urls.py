# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import MedicalIndexView, MedicalDetailView, MedicalDraftView

urlpatterns = patterns('',
    url(r'^medical/$', MedicalIndexView.as_view(), name='medical_index'),
    url(r'^medical/detail/$', MedicalDetailView.as_view(), name='medical_detail'),
    url(r'^medical/draft/(?P<draft_id>[0-9]+)/$', MedicalDraftView.as_view(), name='medical_draft')
)
