from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)

from .serializers import *
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MedicalClaimViewSet',
    'MedicalClaimDraftViewSet'
    ]



class MedicalClaimViewSet(viewsets.ModelViewSet):
    serializer_class = MedicalClaimSerializer
    queryset = MedicalClaim.objects.all()


class MedicalClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = MedicalClaimDraftSerializer
    queryset = MedicalClaimDraft.objects.all()
