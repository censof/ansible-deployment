from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MedicalClaimSerializer',
    'MedicalClaimDraftSerializer'
    ]


class MedicalClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MedicalClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        draftList = obj.medicalclaimitem_set.all()
        return list(draftList.values())


class MedicalClaimDraftSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MedicalClaimDraft
        fields = ('id', 'items')

    def get_items(self, obj):
        draftList = obj.medicalclaimitemdraft_set.all()
        return list(draftList.values())
