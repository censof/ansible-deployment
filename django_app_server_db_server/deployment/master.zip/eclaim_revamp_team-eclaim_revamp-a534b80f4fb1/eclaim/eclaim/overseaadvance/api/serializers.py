from datetime import datetime
from django.contrib.humanize.templatetags.humanize import intcomma
from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from eclaim.settings.api.serializers import (
    CountrySerializer, CurrencySerializer, FundTypeSerializer)
from ..models import (
    OverseaMiscAdvance, OverseaMiscAdvanceDraft, OverseaMiscAdvanceItemDraft)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'OverseaMiscAdvanceSerializer',
    'OverseaMiscAdvanceDraftSerializer',
    'OverseaMiscAdvanceItemDraftSerializer'
    ]


class OverseaMiscAdvanceSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = OverseaMiscAdvance
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        def _format_date(date_obj):
            return datetime.strftime(
                date_obj, '%Y-{}-%d'.format(date_obj.month))

        itemlist = []
        for item in obj.overseamiscadvanceitem_set.all():
            _values = {
                'overseaMiscDateFrom': item.date_from,
                'overseaMiscDateFromTxt': _format_date(item.date_from),
                'overseaMiscDateTo': item.date_to,
                'overseaMiscDateToTxt': _format_date(item.date_to),
                'overseaMiscFundType': item.fund_type.code,
                'overseaMiscFundTypeTxt': item.fund_type.description,
                'miscProjectTxt': item.project_code,
                'overseaMiscPurpose': item.purpose,
                'overseaMiscReason': item.reason,
                'overseaMiscItem': item.item,
                'overseaMiscQuantity': intcomma(item.quantity),
                'overseaMiscPrice': intcomma(item.price)
                }
            itemlist.append(_values)
        return itemlist


class OverseaMiscAdvanceDraftSerializer(serializers.ModelSerializer):
    class Meta:
        model = OverseaMiscAdvanceDraft
        fields = ('id', 'status')


class OverseaMiscAdvanceItemDraftSerializer(serializers.ModelSerializer):
    fund_type = FundTypeSerializer()
    country = CountrySerializer()
    currency_type = CurrencySerializer()

    class Meta:
        model = OverseaMiscAdvanceItemDraft
        fields = ('draft', 'date_from', 'date_to', 'fund_type', 'purpose',
                  'reason', 'item', 'country', 'currency_type',
                  'currency_rate', 'quantity', 'price', 'total', 'grand_total')
