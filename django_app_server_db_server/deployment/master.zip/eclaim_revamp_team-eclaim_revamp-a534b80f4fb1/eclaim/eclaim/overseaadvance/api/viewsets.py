from rest_framework import viewsets
from .serializers import (
    OverseaMiscAdvanceSerializer, OverseaMiscAdvanceDraftSerializer,
    OverseaMiscAdvanceItemDraftSerializer)
from ..models import (
    OverseaMiscAdvance, OverseaMiscAdvanceDraft, OverseaMiscAdvanceItemDraft)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'OverseaMiscAdvanceViewSet',
    'OverseaMiscAdvanceDraftViewSet',
    'OverseaMiscAdvanceItemDraftViewSet'
    ]


class OverseaMiscAdvanceViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaMiscAdvanceSerializer
    queryset = OverseaMiscAdvance.objects.all()


class OverseaMiscAdvanceDraftViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaMiscAdvanceDraftSerializer

    def get_queryset(self):
        qs = OverseaMiscAdvanceDraft.objects.all()
        draft_id = self.request.GET.get('draft_id')
        if draft_id:
            qs = qs.filter(pk=draft_id)
        return qs


class OverseaMiscAdvanceItemDraftViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaMiscAdvanceItemDraftSerializer

    def get_queryset(self):
        draft_id = self.request.GET.get('draft_id')
        if draft_id:
            qs = OverseaMiscAdvanceItemDraft.objects.filter(draft__pk=draft_id)
        return qs
