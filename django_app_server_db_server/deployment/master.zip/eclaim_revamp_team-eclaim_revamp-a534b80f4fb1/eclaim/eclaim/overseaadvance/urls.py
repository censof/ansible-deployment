from django.conf.urls import patterns, url
from .views import *


urlpatterns = patterns(
    '',
    url(r'^oversea-misc-advance/$',
        OverseaMiscAdvanceIndexView.as_view(),
        name='overseamiscadvance_index'),

    url(r'^oversea-misc-advance/detail/$',
        OverseaMiscAdvanceDetailView.as_view(),
        name='overseamiscadvance_detail'),

    url(r'^oversea-misc-advance/draft/(?P<draft_id>[0-9]+)/$',
        OverseaMiscAdvanceDraftView.as_view(),
        name='overseamiscadvance_draft')
)
