/**
 * Oversea Miscellaneous Advance
 * @app uiBootstrapApp
 * @author Aldash B.
 */
uiBootstrapApp.controller('OverseaMiscAdvanceCtrl', function ($scope, $sce, $http, DataSummary,
                                                              DataLookup, DataMiscAdvForm, DataFundType,
                                                              DataOverseaMiscAdvForm) {
    /*************** Initial Variable Start ***************/
    $scope.error_validation = false;
    $scope.claimant_no = '';
    $scope.draft_id = '';
    $scope.claim_no = '';

    $scope.fundTypes = [];
    $scope.country_list = [];
    $scope.currency_list = [];
    $scope.currRate_list = [];
    /*************** Initial Variable End ***************/

    $http({
        url: API_URL+'fund-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.fundTypes = data.results;
        DataFundType.setFundTypes($scope.fundTypes);
    });

    $http({
        url: API_URL+'countries/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.country_list = data.results;
        DataMiscAdvForm.setCountryLists($scope.country_list);
    });

    $http({
        url: API_URL+'currencies/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.currency_list = data.results;
        DataMiscAdvForm.setCurrencyTypeLists($scope.currency_list);
    });

    $http({
        url: API_URL+'currency-rates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.currRate_list = data.results;
        DataMiscAdvForm.setCurrencyRates($scope.currRate_list);
    });

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;

    $scope.panel1 = {
        open: false
    };

    $scope.panel2 = {
        open: true
    };

    $scope.panel3 = {
        open: false
    };

    $scope.panel4 = {
        open: false
    };

    $scope.panel5 = {
        open: false
    };

    $scope.panel6 = {
        open: false
    };

    $scope.panel7 = {
        open: false
    };

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel1.open = true;
        $scope.panel2.open = true;
        $scope.panel3.open = true;
        $scope.panel4.open = true;
        $scope.panel5.open = true;
        $scope.panel6.open = true;
        $scope.panel7.open = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel1.open = false;
        $scope.panel2.open = false;
        $scope.panel3.open = false;
        $scope.panel4.open = false;
        $scope.panel5.open = false;
        $scope.panel6.open = false;
        $scope.panel7.open = false;
    };
    /*************** Accordion End ***************/

    var claim_api_url = API_URL+'oversea-misc-advance/';

    if (PK) {  // detail view
        $http({
            url: claim_api_url+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, $sce, 16, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, $sce, 16, 1);
    }

    init_workflow($scope, $http, 'overseaadvance', 'OverseaMiscAdvance', PK, claim_api_url, WF_TEMPLATE);
});

uiBootstrapApp.controller('OverseaMiscAdvanceFormCtrl', ['$scope', '$http', '$filter', '$location',
                                                         '$anchorScroll', '$validation', 'DataLookup',
                                                         'DataOverseaMiscAdvForm', 'DataMiscAdvForm',
                                                         'DataFundType',
                                                         function ($scope, $http, $filter, $location,
                                                                   $anchorScroll, $validation, DataLookup,
                                                                   DataOverseaMiscAdvForm, DataMiscAdvForm,
                                                                   DataFundType) {
    $scope.openModal = function (reset) {
        if (reset)
            $scope.resetForm();
        $('#OverseaMiscAdvanceFormModal').modal('show');
    };

    $scope.resetForm = function(){
        DataOverseaMiscAdvForm.reset();
        DataLookup.setProjectCode('');
        DataFundType.setFundType({});
        $scope.overseaMiscDateFrom = '';
        $scope.overseaMiscDateTo = '';
        $scope.overseaMiscPurpose = '';
        $scope.overseaMiscReason = '';
        $scope.overseaMiscItem = '';
        $scope.overseaMiscQuantity = get1Float(0);
        $scope.overseaMiscPrice = get2Float(0);
        $scope.overseaMiscAmount = get2Float(0);
        $scope.isEditMode = false;
    };

    $scope.initOverseaMiscAdvCtrl = function (jsonFundTypeList) {
        console.log('Load initOverseaMiscAdvCtrl (Default)');

        $scope.overseaMiscFundType = {'label': '-'};

        /* Start : Global var might be used in Child controller */
        setEmptyTable();
        $scope.pageSize = 5;
        $scope.currentPage = 1;
        $scope.overseaMiscAdvItems = [];
        /* End : Global var might be used in Child controller */

        /* Start : Mileageform */
        $scope.showOverseaMiscAdvForm = false;
        /* End : Mileageform */

        /* Start : Calculation variable */
        $scope.overseaMiscAmount = get2Float(0);

        $scope.grandTotalOverseaMiscAmount = get2Float(0);
        /* End : Calculation variable */
    };

    $scope.initOverseaTable = function (draft_id) {
        console.log('Load initOverseaTable');

        if (draft_id != null && draft_id != '') {
            $scope.draft_item_list = [];
            $scope.overseaMiscAdvItems = [];
            $scope.fund_type = [];

            $http({
                url: API_URL+'oversea-misc-advance-draftitems/?draft_id='+draft_id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.draft_item_list = data.results;

                var draft_item_list = $scope.draft_item_list;
                for (var i=0; i < draft_item_list.length; i++) {
                    var id = i + 1;
                    var minDate = $filter('date')(draft_item_list[i].date_from, 'yyyy-M-dd');
                    DataOverseaMiscAdvForm.setOverseaDateFrom(draft_item_list[i].date_from, minDate);
                    var maxDate = $filter('date')(draft_item_list[i].date_to, 'yyyy-M-dd');
                    DataOverseaMiscAdvForm.setOverseaDateTo(draft_item_list[i].date_to, maxDate);

                    if (draft_item_list[i].country == null && draft_item_list[i].currency_type == null ) {
                        for (var j=0; j < $scope.fundTypes.length; j++){
                            if ($scope.fundTypes[j].code == draft_item_list[i].fund_type.code) {
                                $scope.fund_type = $scope.fundTypes[j];
                                DataFundType.setFundType($scope.fundTypes[j]);
                            }
                        }

                        var setOverseaMiscAdvItem = function(id){
                            return {
                                  id:id, active:true
                                , overseaMiscDateFrom: DataOverseaMiscAdvForm.getOverseaDateFrom(), overseaMiscDateFromTxt: DataOverseaMiscAdvForm.getOverseaDateFromTxt()
                                , overseaMiscDateTo: DataOverseaMiscAdvForm.getOverseaDateTo(), overseaMiscDateToTxt: DataOverseaMiscAdvForm.getOverseaDateToTxt()
                                , overseaMiscFundType: DataFundType.getFundTypeCode(), overseaMiscFundTypeCode: DataFundType.getFundTypeCode()
                                , overseaMiscFundTypeTxt: DataFundType.getFundType().description, miscProjectTxt: DataLookup.getProjectCode()
                                , overseaMiscPurpose: draft_item_list[i].purpose, overseaMiscReason: draft_item_list[i].reason
                                , overseaMiscItem: draft_item_list[i].item, overseaMiscQuantity: get1Float(draft_item_list[i].quantity)
                                , overseaMiscPrice: get2Float(draft_item_list[i].price), overseaMiscAmount: get2Float(draft_item_list[i].total)
                            };
                        };

                        $scope.overseaMiscAdvItems.push(setOverseaMiscAdvItem(id));
                        $scope.overseaMiscAdvCounter = id+1;
                        calculateAllSummary();
                        $scope.isEmptyTable = false;
                    }
                }

            });
        } else {

        }
    };

    $scope.overseaMiscAdvTableHeader = [
        {label: ''}, {label:'Activity Date From'}, {label:'Activity Date To'}
        , {label:'Fund Type'}, {label:'Project Code'}, {label:'Purpose of Activity'}
        , {label:'Reason not using Purchase Requisition'},  {label:'Item'}
        , {label:'Quantity'}, {label:'Price (RM)'}, {label:'Total (RM)'}
        , {label:''}
    ];

    var setOverseaMisAdvRow = function(id){
        return {
            id: id, active:true
            , overseaMiscDateFrom: DataOverseaMiscAdvForm.getOverseaDateFrom(), overseaMiscDateFromTxt: DataOverseaMiscAdvForm.getOverseaDateFromTxt()
            , overseaMiscDateTo: DataOverseaMiscAdvForm.getOverseaDateTo(), overseaMiscDateToTxt: DataOverseaMiscAdvForm.getOverseaDateToTxt()
            , overseaMiscFundType: $scope.overseaMiscFundType.description, overseaMiscFundTypeCode: $scope.overseaMiscFundType.code
            , overseaMiscFundTypeTxt: $scope.overseaMiscFundType.description, miscProjectTxt: DataLookup.getProjectCode()
            , overseaMiscPurpose: $scope.overseaMiscPurpose, overseaMiscReason: $scope.overseaMiscReason
            , overseaMiscItem: $scope.overseaMiscItem, overseaMiscQuantity: get1Float($scope.overseaMiscQuantity)
            , overseaMiscPrice: get2Float($scope.overseaMiscPrice), overseaMiscAmount: get2Float($scope.overseaMiscAmount)
        };
    };

    $scope.addOverseaMiscAdvItem = function(form){
        var dateFrom = DataOverseaMiscAdvForm.getOverseaDateFrom(),
            dateTo   = DataOverseaMiscAdvForm.getOverseaDateTo();

        if (dateFrom <= dateTo) {  // dateFrom must not be after dateTo
            $scope.addButtonActive = false;
            $scope.overseaMiscAdvItems.push(setOverseaMisAdvRow($scope.overseaMiscAdvCounter));
            $scope.overseaMiscAdvCounter++;
            $scope.isEmptyTable = false;
            $scope.resetForm();
            calculateAllSummary();
            $('[name="overseaMiscDateFrom"]').removeClass('ng-invalid');
            $('[name="overseaMiscDateTo"]').removeClass('ng-invalid');
        } else {
            $('[name="overseaMiscDateFrom"]').addClass('ng-invalid');
            $('[name="overseaMiscDateTo"]').addClass('ng-invalid');
        }
    };

    $scope.deleteOverseaMiscAdvItem = function (tabIndex){
        var index = tabIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.overseaMiscAdvItems.splice(index, 1); //remove the object from the array based on index
        $scope.overseaMiscAdvCounter = $scope.overseaMiscAdvItems.length;
        if ($scope.overseaMiscAdvItems.length == 0)
            setEmptyTable();
    };

    $scope.editOverseaMiscAdvItem = function (tabIndex){
        $scope.isEditMode = true;
        var index = tabIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        var currTab = $scope.overseaMiscAdvItems[index];
        setOverseaMiscAdvScope(currTab);
        $scope.openModal(false);
    };

    var setOverseaMiscAdvScope = function (currTab) {
        DataOverseaMiscAdvForm.setOverseaDateFrom(currTab.overseaMiscDateFrom);
        DataOverseaMiscAdvForm.setOverseaDateTo(currTab.overseaMiscDateTo);
        DataFundType.setFundType(DataFundType.getFundTypeByCode(currTab.overseaMiscFundType));
        $scope.overseaMiscFundType = DataFundType.getFundType();
        DataLookup.setProjectCode(currTab.miscProjectTxt);
        $scope.overseaMiscPurpose = currTab.overseaMiscPurpose;
        $scope.overseaMiscReason = currTab.overseaMiscReason;
        $scope.overseaMiscItem = currTab.overseaMiscItem;
        $scope.overseaMiscQuantity = currTab.overseaMiscQuantity;
        $scope.overseaMiscPrice = currTab.overseaMiscPrice;
        $scope.overseaMiscAmount = currTab.overseaMiscAmount;
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currTab = '';
        if ($scope.overseaMiscAdvItems.length > 0) {
            if ($scope.directIndex == $scope.overseaMiscAdvItems.length) {
                $scope.directIndex = $scope.overseaMiscAdvItems.length - 1;
            } else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                currTab = $scope.overseaMiscAdvItems[$scope.directIndex];
                setOverseaMiscAdvScope(currTab);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            } else if (direct == 'next' && !($scope.directIndex >= $scope.overseaMiscAdvItems.length-1)) {
                $scope.directIndex++;
                currTab = $scope.overseaMiscAdvItems[$scope.directIndex];
                setOverseaMiscAdvScope(currTab);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };

    var setEmptyTable = function(){
        $scope.currIndex = '';
        $scope.overseaMiscAdvCounter = 1;
        $scope.isEmptyTable = true;
        $scope.isEditMode = false;
        $scope.directIndex = 0;
        $scope.grandTotalAmount = get2Float(0);
    };

    var calculateAllSummary = function () {
        var totalSummaryOverseaMiscAmount = 0;
        angular.forEach($scope.overseaMiscAdvItems, function(obj){
            totalSummaryOverseaMiscAmount = totalSummaryOverseaMiscAmount + parseFloat(obj.overseaMiscAmount);
        });
        $scope.grandTotalOverseaMiscAmount = get2Float(totalSummaryOverseaMiscAmount);
        DataOverseaMiscAdvForm.setOverseaGrandTotal($scope.grandTotalOverseaMiscAmount);
    };

    $scope.$watch('overseaMiscAdvItems', function () {
        return DataOverseaMiscAdvForm.setOverseaMiscAdvItems($scope.overseaMiscAdvItems);
    }, true);

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            if (newValue != oldValue) {
                var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
                currTab.miscProjectTxt = newValue;
            }
        }
    });

    $scope.$watch('overseaMiscFundType', function (newValue, oldValue) {
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            if ($scope.overseaMiscFundType) {
                DataFundType.setFundType(DataFundType.getFundTypeByCode($scope.overseaMiscFundType.code));
                currTab.overseaMiscFundType = DataFundType.getFundTypeCode();
                currTab.overseaMiscFundTypeTxt = $scope.overseaMiscFundType.description;
            }else{
                currTab.overseaMiscFundTypeTxt = '';
            }
        }
    });

    $scope.$watch('overseaMiscPurpose',function() {
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            currTab.overseaMiscPurpose = $scope.overseaMiscPurpose;
        }
    });

    $scope.$watch('overseaMiscReason',function() {
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            currTab.overseaMiscReason = $scope.overseaMiscReason;
        }
    });

    $scope.$watch('overseaMiscItem',function() {
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            currTab.overseaMiscItem = $scope.overseaMiscItem;
        }
    });

    $scope.$watch('overseaMiscQuantity', function() {
        var quantity = $scope.overseaMiscQuantity;
        var overseaMiscAmount = parseFloat($scope.overseaMiscPrice) * parseFloat(quantity);
        $scope.overseaMiscAmount = get2Float(overseaMiscAmount);
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            currTab.overseaMiscQuantity = get1Float(quantity);
            currTab.overseaMiscAmount = get2Float(overseaMiscAmount)
            calculateAllSummary();
        }
    });

    $scope.$watch('overseaMiscPrice', function() {
        var price = $scope.overseaMiscPrice;
        var overseaMiscAmount = parseFloat($scope.overseaMiscQuantity) * parseFloat(price);
        $scope.overseaMiscAmount = get2Float(overseaMiscAmount);
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            currTab.overseaMiscPrice = get2Float(price);
            currTab.overseaMiscAmount = get2Float(overseaMiscAmount)
            calculateAllSummary();
        }
    });

    $scope.$watch('overseaMiscAmount', function() {
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            currTab.overseaMiscAmount = get2Float($scope.overseaMiscAmount);
        }
    });

    if (PK) {  // detail view
        $http({
            url: API_URL+'oversea-misc-advance/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.overseaMiscAdvItems = data.items;
            $scope.isEmptyTable = false;
            angular.forEach($scope.overseaMiscAdvItems, function (obj) {
                obj.overseaMiscAmount = get2Float(parseFloat(obj.overseaMiscPrice) * parseFloat(obj.overseaMiscQuantity));
            });
            calculateAllSummary();
        });
    }
}]);

uiBootstrapApp.controller('OverseaSummaryCtrl', function ($scope, $http, DataOverseaMiscAdvForm) {
    $scope.fund_types = [];
    $scope.grandTotalAmount = get2Float(0);
    $scope.expense_type = {};

    $scope.$watch(function () { return DataOverseaMiscAdvForm.getOverseaGrandTotal(); }, function(newValue, oldValue) {
        $scope.grandTotalAmount = newValue;
        $http({
            url: API_URL+'expenses/',
            method: 'GET',
            params: { claim_code: 'OMADV' }
        })
        .success(function (data, status, headers, config) {
            $scope.expense_type = data.results[0];
        });
    });

    $scope.$watchCollection(function () { return DataOverseaMiscAdvForm.getOverseaMiscAdvItems(); }, function (newValue, oldValue) {
        var items           = DataOverseaMiscAdvForm.getOverseaMiscAdvItems(),
            fund_type_data  = {};

        // Get list of fund types collected from added table rows
        angular.forEach(items, function (obj) {
            var _in_array = false;
            $.each(fund_type_data, function (ftcode, ftobj) {
                if (ftcode == obj.overseaMiscFundType)
                    _in_array = true;
            });
            if (_in_array) {
                var _amount = parseFloat(obj.overseaMiscPrice) * parseFloat(obj.overseaMiscQuantity);
                fund_type_data[obj.overseaMiscFundType].amount = get2Float(parseFloat(fund_type_data[obj.overseaMiscFundType].amount)+_amount);
            } else {
                fund_type_data[obj.overseaMiscFundType] = {
                    label:  obj.overseaMiscFundTypeTxt,
                    amount: get2Float(parseFloat(obj.overseaMiscPrice)*parseFloat(obj.overseaMiscQuantity))
                };
            }
        });
        $scope.fund_type_data = fund_type_data;
    });
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataLookup',
                                         'DataOverseaMiscAdvForm', 'DataOverseaMiscAdvForm',
                                         'DataMiscAdvForm', function ($scope, $uibModal, $http, $window,
                                                                      DataLookup, DataOverseaMiscAdvForm,
                                                                      DataOverseaMiscAdvForm, DataMiscAdvForm) {
    $scope.animationsEnabled = true;

    $scope.submit = function(btnMode) {
        form_data = {
            btn_mode: btnMode,
            claimant_no: DataMiscAdvForm.getClaimantNo(),
            draft_id: DataMiscAdvForm.getDraftID(),
            overseaTabs: DataOverseaMiscAdvForm.getOverseaMiscAdvItems(),
            overseaGrandTotal: DataOverseaMiscAdvForm.getOverseaGrandTotal()
        }
        if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

        var instance_controller = '';

        if (btnMode == 'save_draft') {
            instance_controller = 'ModalInstanceSaveCtrl';
            ng_template = 'SaveConformation.html';
        }else if (btnMode == 'submit'){
            instance_controller = 'ModalInstanceSubmitCtrl';
            ng_template = 'SubmitConformation.html';
        }

        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: ng_template,
            controller: instance_controller,
            size: 'sm',
            resolve: {
                data: function () {
                    return form_data;
                }
            }
        });

        modalInstance.result.then(
            function () {
                disable_claim_controls();

                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };
                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                } else {
                    $http({
                        url: '',
                        method: 'POST',
                        data: form_data
                    })
                    .success(function (data, status, headers, config) {
                        enable_claim_controls();
                        var submit_success_url = data.submit_success_url;

                        if (btnMode == 'submit') {
                            $window.location.href = submit_success_url;
                        } else if (btnMode == 'save_draft') {
                            $scope.initSubmitCtrl(data.draft_id);
                            $uibModal.open({
                                animation: $scope.animationsEnabled,
                                templateUrl: 'SaveSuccess.html',
                                controller: 'ModalInstanceInfoCtrl',
                                size: 'sm',
                                resolve: {
                                  data: function () {
                                    return data;
                                  }
                                }
                            });
                            $window.location.href = submit_success_url;
                        }
                    }).error(function () {
                        enable_claim_controls();
                    });
                }
            },
            function () {
                console.log('Cancel, confirmation box closed');
            }
        );
    };

    $scope.initSubmitCtrl = function(draft_id){
        $scope.draft_id = draft_id;
        DataMiscAdvForm.setDraftID(draft_id);
    };
}]);
