from decimal import Decimal
from django.db import models
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from eclaim.advance.basemodels import BaseMiscAdvance, BaseMiscAdvanceItem

__all__ = [
    'OverseaMiscAdvance',
    'OverseaMiscAdvanceItem',
    'OverseaMiscAdvanceDraft',
    'OverseaMiscAdvanceItemDraft'
    ]


class OverseaMiscAdvance(BaseMiscAdvance):
    CLAIM_TYPE = 16

    class Meta:
        verbose_name = _("Oversea Miscellaneous Advance")
        verbose_name_plural = verbose_name

    def get_absolute_url(self):
        _url = reverse_lazy('overseamiscadvance_detail')
        return "{}?pk={}".format(_url, self.pk)


class OverseaMiscAdvanceItem(BaseMiscAdvanceItem):
    advance = models.ForeignKey(OverseaMiscAdvance)

    class Meta:
        verbose_name = _("Oversea Miscellaneous Advance Item")
        verbose_name_plural = _("Oversea Miscellaneous Advance Items")


class OverseaMiscAdvanceDraft(BaseMiscAdvance):
    CLAIM_TYPE = 16

    class Meta:
        verbose_name = _("Oversea Miscellaneous Advance Draft")
        verbose_name_plural = _("Oversea Miscellaneous Advance Drafts")

    def get_absolute_url(self):
        return reverse_lazy('overseamiscadvance_draft', args=[self.pk])


class OverseaMiscAdvanceItemDraft(BaseMiscAdvanceItem):
    draft = models.ForeignKey(OverseaMiscAdvanceDraft)
    total = models.DecimalField(_("Total"), max_digits=9, decimal_places=2, default=Decimal('0.00'))
    grand_total = models.DecimalField(_("Grand Total"), max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        verbose_name = _("Oversea Miscellaneous Advance Item Draft")
        verbose_name_plural = _("Oversea Miscellaneous Advance Item Drafts")
