import json

from django.http import JsonResponse
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text
from eclaim.claim.models import ClaimType
from eclaim.libs.views import ClaimDetailView, ClaimIndexView, ClaimDraftVIew
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.common import SUMMARY
from .models import OverseaMiscAdvance
from .processes import process_controller

__all__ = [
    'OverseaMiscAdvanceIndexView',
    'OverseaMiscAdvanceDetailView',
    'OverseaMiscAdvanceDraftView'
    ]


class OverseaMiscAdvanceIndexView(ClaimIndexView):
    template_name = 'overseaadvance/main.html'
    claim_type = ClaimType.get_claim_type(OverseaMiscAdvance.CLAIM_TYPE)
    submit_success_url = reverse_lazy('claim_list')

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')
        user = request.user
        draft_id, claim_id = process_controller(btn_mode, form_data, user)

        if btn_mode == 'submit':
            # Send a claim to workflow.
            if self.claimant is not None:
                create_new_states(self.claimant, OverseaMiscAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaMiscAdvance,
                                             claim_id)
        data = {
            'draft_id': draft_id,
            'claim_id': claim_id,
            'submit_success_url': force_text(self.submit_success_url),
            'errors': False
            }
        return JsonResponse(data)


class OverseaMiscAdvanceDetailView(ClaimDetailView):
    model = OverseaMiscAdvance
    claim_type = ClaimType.get_claim_type(OverseaMiscAdvance.CLAIM_TYPE)
    template_name = 'overseaadvance/main.html'
    submit_success_url = reverse_lazy('claim_list')

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')
        draft_id, claim_id = process_controller(btn_mode, form_data)

        if btn_mode == 'submit':
            # Send a claim to workflow.
            if self.claimant is not None:
                create_new_states(self.claimant, OverseaMiscAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaMiscAdvance,
                                             claim_id)
        data = {
            'submit_success_url': force_text(self.submit_success_url),
            'draft_id': draft_id,
            'claim_id': claim_id,
            'errors': False
            }
        return JsonResponse(data)


class OverseaMiscAdvanceDraftView(ClaimDraftVIew):
    template_name = 'overseaadvance/main.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        ctx = super(OverseaMiscAdvanceDraftView, self
                    ).get_context_data(**kwargs)
        ctx['SUMMARY'] = SUMMARY().get_summary('MADV')
        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')
        user = request.user
        draft_id, claim_id = process_controller(btn_mode, form_data, user)

        if btn_mode == 'submit':
            # Send a claim to workflow.
            if self.claimant is not None:
                create_new_states(self.claimant, OverseaMiscAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaMiscAdvance,
                                             claim_id)
        data = {
            'submit_success_url': force_text(self.submit_success_url),
            'draft_id': draft_id,
            'claim_id': claim_id,
            'errors': False
            }
        return JsonResponse(data)
