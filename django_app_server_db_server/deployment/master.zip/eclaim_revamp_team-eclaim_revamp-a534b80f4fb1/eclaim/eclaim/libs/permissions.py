# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'is_implementer',
    'is_admin',
    'is_in_workflow_group',
    'get_user_permissions'
    ]


def is_implementer(user):
    """User is an implementer, i.e. has absolute permissions."""
    return user.is_authenticated() and user.username.lower() == 'implementer'


def is_admin(user):
    """User is an admin, i.e. has every permission except an implementation
    setup management.
    """
    return user.is_authenticated() and user.claimant.is_admin


def is_in_workflow_group(user):
    if user.is_authenticated():
        clt = user.claimant
        return hasattr(clt, 'assignee') and clt.assignee.groups.all().exists()
    return False


def get_user_permissions(user):
    """Return a dictionary of boolean values, which mean whether the user
    has a special permission to access or manage something.
    """
    perms = {
        # Settings
        'CAN_MANAGE_IMPLEMENTATION': False,
        'CAN_MANAGE_SETTINGS': False,
        'CAN_MANAGE_WORKFLOW_SETTINGS': False,

        # Claims and drafts
        'CAN_ACCESS_MY_TASKS': False,
        'CAN_ACCESS_MY_CLAIMS': True,
        'CAN_APPROVE_CLAIMS': False,  # approve/reject/query
        'CAN_CANCEL_CLAIMS': True,
        'CAN_MANAGE_DRAFTS': True,

        # Other
        'CAN_ACCESS_DASHBOARD_ADMIN': False,
        'CAN_VIEW_REPORTS': False,
        'CAN_CHANGE_PWD': False
        }

    if is_implementer(user):
        perms = {k: True for k in perms.keys()}  # absolute permissions
    elif is_admin(user):
        perms = {k: True for k in perms.keys()}
        perms['CAN_MANAGE_IMPLEMENTATION'] = False
    elif is_in_workflow_group(user):
        perms['CAN_ACCESS_MY_TASKS'] = True
        perms['CAN_APPROVE_CLAIMS'] = True
        perms['CAN_MANAGE_DRAFTS'] = False
        perms['CAN_CANCEL_CLAIMS'] = False
        perms['CAN_VIEW_REPORTS'] = True

    return perms
