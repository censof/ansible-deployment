from django.contrib import messages
from django.utils.translation import ugettext_lazy as _

__all__ = ['ModelViewSetMessagesMixin']


class ModelViewSetMessagesMixin(object):
    """Mix with a ModelViewSet class to enable Django messaging framework
    within the view.
    """
    class Meta:
        abstract = True

    def __init__(self, *args, **kwargs):
        try:
            self.vbname = self.serializer_class.Meta.model._meta.verbose_name
            self.vbname = self.vbname.title()
        except AttributeError:
            self.vbname = "Object"

        super(ModelViewSetMessagesMixin, self).__init__(*args, **kwargs)

    def perform_create(self, serializer):
        try:
            serializer.save()
        except Exception as e:
            messages.error(self.request._request, e)
        else:
            msg = _("{} created.".format(self.vbname))
            messages.success(self.request._request, msg)

    def perform_update(self, serializer):
        try:
            serializer.save()
        except Exception as e:
            messages.error(self.request._request, e)
        else:
            msg = _("{} updated.".format(self.vbname))
            messages.success(self.request._request, msg)

    def perform_destroy(self, instance):
        try:
            instance.delete()
        except Exception as e:
            messages.error(self.request._request, e)
        else:
            msg = _("{} deleted.".format(self.vbname))
            messages.success(self.request._request, msg)
