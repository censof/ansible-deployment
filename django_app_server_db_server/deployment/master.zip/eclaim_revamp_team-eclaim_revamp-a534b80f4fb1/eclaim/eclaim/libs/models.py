"""Helper models."""
from django.db import models
from django.utils import timezone
from django.utils.translation import ugettext_lazy as _

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = ['BaseModel']


class BaseModel(models.Model):
    created = models.DateTimeField(_("Created On"), default=timezone.now, null=True)
    modified = models.DateTimeField(_("Modified On"), auto_now=True, null=True)
    created_by = models.ForeignKey('auth.User', blank=True, null=True, verbose_name=_("Created By"))

    class Meta:
        abstract = True

    def save(self, *args, **kwargs):
        self.modified = timezone.now()
        super(BaseModel, self).save(*args, **kwargs)
