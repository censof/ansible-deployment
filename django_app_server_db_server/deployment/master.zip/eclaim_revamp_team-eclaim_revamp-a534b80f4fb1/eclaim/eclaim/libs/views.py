"""Base and helper views."""
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.views.generic.base import TemplateView
from django.views.generic import DetailView
from django.utils.decorators import method_decorator
from django.utils.translation import ugettext_lazy as _
from eclaim.settings.models import WorkflowTemplate
from eclaim.masterfiles.models.claimant import Claimant
from .exceptions import MissingGETKeyException

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'AngularTemplateView',
    'AngularUpdateAndDetailView',
    'ClaimIndexView',
    'ClaimDetailView',
    'ClaimDraftVIew'
    ]


class _AuthMixin(object):
    class Meta:
        abstract = True

    @method_decorator(login_required)
    def dispatch(self, request, *args, **kwargs):
        self.user = request.user
        try:
            self.claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            self.claimant = None
        return super(_AuthMixin, self).dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        ctx = super(_AuthMixin, self).get_context_data(**kwargs)
        ctx['claimant'] = self.claimant
        return ctx


class AngularTemplateView(_AuthMixin, TemplateView):
    class Meta:
        abstract = True


class AngularUpdateAndDetailView(_AuthMixin, DetailView):
    class Meta:
        abstract = True

    def get_object(self):
        if 'pk' not in self.request.GET:
            errmsg = _("Object's primary key must be provided as a parameter "
                       "via GET request.")
            raise MissingGETKeyException(errmsg)
        pk = self.request.GET['pk']
        return get_object_or_404(self.model, pk=pk)

    def get_context_data(self, **kwargs):
        ctx = super(AngularUpdateAndDetailView, self
                    ).get_context_data(**kwargs)
        ctx['update'] = 'update' in self.request.GET
        return ctx


class _ClaimContextMixin(object):
    validate_form_by_name = ''

    def get_context_data(self, **kwargs):
        ctx = super(_ClaimContextMixin, self).get_context_data(**kwargs)

        # Show a warning message in a claim form if a corresponding workflow
        # template hasn't been defined yet.
        wf_templates = WorkflowTemplate.objects.filter(
            claimtype=self.claim_type
            )
        if wf_templates.exists():
            ctx['WORKFLOW_TEMPLATE'] = wf_templates.get()
            ctx['ERR_NO_WF_TEMPLATE'] = False
        else:
            ctx['WORKFLOW_TEMPLATE'] = None
            ctx['ERR_NO_WF_TEMPLATE'] = True

        if self.validate_form_by_name:
            ctx['form_name'] = self.validate_form_by_name
        return ctx


class ClaimIndexView(_ClaimContextMixin, AngularTemplateView):
    pass


class ClaimDetailView(_ClaimContextMixin, AngularUpdateAndDetailView):
    def dispatch(self, request, *args, **kwargs):
        if 'status_ref' not in self.request.GET:
            errmsg = _("Status reference must be provided as a parameter "
                       "via GET request.")
            raise MissingGETKeyException(errmsg)
        return super(ClaimDetailView, self).dispatch(request, *args, **kwargs)


class ClaimDraftVIew(AngularTemplateView):
    pass
