from django.test import TestCase as NoseTestCase
from django.test.client import Client
from eclaim.masterfiles.models.claimant import Claimant

__all__ = ['TestCase']


class TestCase(NoseTestCase):
    """In order to create new fixtures use following syntax:

        ./manage.py dumpdata auth.User -o users.json --indent=2
                    --natural-foreign --exclude=contenttypes
    """
    fixtures = ['misc_claims.json',
                'users.json',
                'claimants.json',
                'claimant_bank_info.json',
                'salary_groups.json',
                'salary_grades.json',
                'positions.json',
                'claim_types.json',
                'workflow_templates.json']

    def setUp(self):
        self.client = Client()
        self.claimant = Claimant.objects.get(staff_no='00901991')
        self.login()

    def login(self):
        self.client.login(username='551212-10-6175', password='12345')

    def logout(self):
        self.client.logout()
