from django.utils.encoding import force_text
from django.contrib.contenttypes.models import ContentType
from rest_framework import serializers
from eclaim.claim.models import ClaimType
from eclaim.settings.models import (
    WorkflowState, SelectedAssignee, UserGroup, WorkflowQueryState)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = ['BaseClaimSerializer']


class BaseClaimSerializer(serializers.ModelSerializer):
    """Base class for claim serializers.

    It serves as a glue between workflow and a claim. All claim
    serializers should inherit from this class.
    """
    claim_type = serializers.SerializerMethodField()
    claim_ctype_id = serializers.SerializerMethodField()
    workflow_state = serializers.SerializerMethodField()
    workflow_template = serializers.SerializerMethodField()
    current_level_ordering = serializers.SerializerMethodField()
    status = serializers.SerializerMethodField()
    on_latest_level = serializers.SerializerMethodField()
    query = serializers.SerializerMethodField()
    query_list = serializers.SerializerMethodField()
    query_type_name = serializers.SerializerMethodField()
    query_notes = serializers.SerializerMethodField()
    claimant_staff_no = serializers.SerializerMethodField()
    approved = serializers.SerializerMethodField()
    rejected = serializers.SerializerMethodField()
    current_assignee = serializers.SerializerMethodField()
    current_assigned_group = serializers.SerializerMethodField()
    notes = serializers.SerializerMethodField()
    rejection_reason = serializers.SerializerMethodField()
    query_reason = serializers.SerializerMethodField()

    class Meta:
        fields = ('id', 'claim_no', 'status', 'claim_type', 'claim_ctype_id',
                  'workflow_state', 'query', 'query_notes', 'query_type_name',
                  'claimant_staff_no', 'approved', 'notes', 'rejected',
                  'current_assignee', 'current_assigned_group', 'query_list',
                  'current_level_ordering', 'workflow_template',
                  'on_latest_level', 'rejection_reason', 'query_reason')

    def __init__(self, *args, **kwargs):
        self._model = self.Meta.model
        self._content_type = ContentType.objects.get_for_model(self._model)
        super(BaseClaimSerializer, self).__init__(*args, **kwargs)

    def get_claim_type(self, obj):
        try:
            claim_type = self._model.get_claim_type()  # legacy
        except AttributeError:
            claim_type = ClaimType.get_claim_type(self._model.CLAIM_TYPE)
        return claim_type.pk

    def get_claim_ctype_id(self, obj):
        return self._content_type.pk

    def _get_workflow_state_object(self, obj):
        qs = WorkflowState.objects.filter(
            content_type=self._content_type.pk,
            object_id=obj.pk,
            level__ordering__gt=1
            )
        try:
            return qs.latest()
        except WorkflowState.DoesNotExist:
            pass

    def get_workflow_state(self, obj):
        return self._get_workflow_state_object(obj).pk

    def get_current_level_ordering(self, obj):
        state = self._get_workflow_state_object(obj)
        return state.level.ordering

    def get_status(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return state.get_status()

    def get_query(self, obj):
        qs = WorkflowState.objects.filter(
            content_type=self._content_type.pk,
            object_id=obj.pk
            )
        try:
            state = qs.latest().get_latest_state()
        except WorkflowState.DoesNotExist:
            return False
        return state.has_active_query

    def get_query_list(self, obj):
        qs = WorkflowQueryState.objects.filter(
            state__content_type=self._content_type.pk,
            state__object_id=obj.pk
            )
        return qs.values()

    def _get_query_state(self, obj):
        if self.get_query(obj):
            qs = WorkflowState.objects.filter(
                content_type=self._content_type.pk,
                object_id=obj.pk
                )
            if qs.exists():
                state = qs.latest()
                query_states = state.query_states.all()
                if query_states.exists():
                    return query_states.latest()

    def get_query_type_name(self, obj):
        query_state = self._get_query_state(obj)
        if query_state is not None:
            return force_text(query_state.query.query_type)

    def get_query_reason(self, obj):
        query_state = self._get_query_state(obj)
        if query_state is not None:
            return force_text(query_state.reason)

    def get_query_notes(self, obj):
        query_state = self._get_query_state(obj)
        if query_state is not None:
            return query_state.notes

    def get_claimant_staff_no(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return state.claimant.staff_no

    def get_approved(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return state.is_approved or False
        return False

    def get_rejected(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return not state.is_approved and state.is_approved is not None
        return False

    def get_current_assignee(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            latest_state = state.get_latest_state()
            entity = latest_state.get_assigned_entity()
            if isinstance(entity, SelectedAssignee):
                return entity.assignee.claimant.staff_no

    def get_current_assigned_group(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            latest_state = state.get_latest_state()
            entity = latest_state.get_assigned_entity()
            if isinstance(entity, UserGroup):
                return entity.pk

    def get_notes(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return state.notes

    def get_workflow_template(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return state.level.template.pk

    def get_on_latest_level(self, obj):
        state = self._get_workflow_state_object(obj)
        if state is not None:
            return state.on_latest_level

    def get_rejection_reason(self, obj):
        state = self._get_workflow_state_object(obj)
        is_rejected = not state.is_approved and state.is_approved is not None
        if state is not None and is_rejected:
            return force_text(state.rejection_reason)
