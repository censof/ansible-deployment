# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = ['MissingGETKeyException']


class MissingGETKeyException(Exception):
    pass
