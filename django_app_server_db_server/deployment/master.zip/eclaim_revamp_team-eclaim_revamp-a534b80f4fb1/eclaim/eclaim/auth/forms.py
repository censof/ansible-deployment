from django import forms
from django.utils.translation import ugettext_lazy as _
from djangular.forms import NgModelFormMixin, NgFormValidationMixin
from djangular.styling.bootstrap3.forms import Bootstrap3Form
from eclaim.auth.authenticate import Authenticate

__all__ = [
    'LoginForm',
    'LoginFormValidation'
    ]


class LoginForm(Bootstrap3Form):
    user_name = forms.CharField(label=_("Username"), max_length=20)
    password = forms.CharField(label=_("Password"), widget=forms.PasswordInput)


class LoginFormValidation(NgModelFormMixin, NgFormValidationMixin, LoginForm):
    scope_prefix = 'login_data'
    form_name = 'login_form'

    def __init__(self, *args, **kwargs):
        self.request = kwargs.pop('request', None)
        super(LoginFormValidation, self).__init__(*args, **kwargs)

    def clean(self):
        # Validation logic can be done here
        auth = Authenticate(self.request, self.cleaned_data.get('user_name'),
                            self.cleaned_data.get('password'))
        auth.login()
        return super(LoginForm, self).clean()
