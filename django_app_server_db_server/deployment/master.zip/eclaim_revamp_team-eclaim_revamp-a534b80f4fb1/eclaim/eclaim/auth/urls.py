# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import LoginView

urlpatterns = patterns('',
    url(r'^login/', LoginView.as_view(), name='loginAuth'),
    url(r'^logout/', 'django.contrib.auth.views.logout', {'next_page': '/eclaim/login/'}, name='logoutAuth'),
)
