# From Django
import json

from urllib import urlencode
from django.http import HttpResponse
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import redirect
from django.utils.encoding import force_text
from django.views.generic.edit import FormView

# From eClaim
from .forms import LoginFormValidation


class LoginView(FormView):
    template_name = 'login/login_form.html'
    form_class = LoginFormValidation

    def get(self, request, *args, **kwargs):
        if request.user.is_authenticated():
            return redirect(self.get_success_url())
        return super(LoginView, self).get(request, *args, **kwargs)

    def post(self, request, **kwargs):
        if request.is_ajax():
            return self.ajax(request)
        return super(LoginView, self).post(request, **kwargs)

    def ajax(self, request):
        form = self.form_class(data=json.loads(request.body), request=request)
        response_data = {'errors': form.errors, 'success_url': force_text(self.get_success_url())}
        return HttpResponse(json.dumps(response_data), content_type="application/json")

    def get_success_url(self):
        """Send user to the dashboard by default."""
        return reverse_lazy('claim_list')
