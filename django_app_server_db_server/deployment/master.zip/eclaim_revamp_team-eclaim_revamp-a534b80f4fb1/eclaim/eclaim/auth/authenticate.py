from django.contrib.auth import authenticate, login, logout
from django.core.exceptions import ValidationError
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import redirect, render

class Authenticate():
    def __init__(self, request, username=None, password=None):
        self.username = username
        self.password = password
        self.request = request
        
    def login(self):
        user = authenticate(username=self.username, password=self.password)
        if user is not None and user.is_active:
            login(self.request, user)
        else:
            raise ValidationError("Wrong Username or Password")
    
    def validate_session(self):
        if self.request.user.is_authenticated():
            return self.request.user
        else:
            return False