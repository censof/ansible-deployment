from decimal import *
from django.utils import timezone
from eclaim.masterfiles.models.misc import FundType, MiscellaneousType, GSTTax
from eclaim.masterfiles.common import CLAIM_TYPE
from eclaim.masterfiles.utils import save_claimant_history
from eclaim.utils.common import generate_claim_no
from .models import *


__ClaimType__ = CLAIM_TYPE.LMISC
__ClaimNoPrefix__ = CLAIM_TYPE.MiscellaneousNoPrefix


def process_controller(form_data):
    claim_id = None

    if form_data.get('btn_mode') in ['save_draft']:
        save_draft(form_data)

    elif form_data.get('btn_mode') in ['submit']:
        claim_id = submit_claim(form_data)

    return claim_id

def save_draft(form_data):
    draft_id = form_data.get('draft_id')

    if draft_id == '':
        claim_draft = MiscellaneousClaimDraft()
        claim_draft.status = 'D'
        claim_draft.net_total = form_data.get('net_total')
        claim_draft.grand_total = form_data.get('grand_total')
        claim_draft.save()

        save_miscellaneous_claim_item('save_draft', claim_draft, form_data)
        #save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)

    else:
        claim_draft = MiscellaneousClaimDraft(id=int(draft_id))
        delete_miscellaneous_claim_draft_item(claim_draft)
        claim_draft.status = 'D'
        claim_draft.net_total = form_data.get('net_total')
        claim_draft.grand_total = form_data.get('grand_total')
        save_miscellaneous_claim_item('save_draft', claim_draft, form_data)
        #save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)

def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')

    claim = MiscellaneousClaim()
    claim.status = 'S'
    claim.net_total = form_data.get('net_total')
    claim.grand_total = form_data.get('grand_total')
    claim.save()
    claim.claim_no = generate_claim_no(__ClaimNoPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_miscellaneous_claim_item('submit_claim', claim, form_data)
    #save_document_list_item(claim.claim_no, __ClaimType__, form_data)
    return claim.id

def save_miscellaneous_claim_item(mode, parent, form_data):
    for i in form_data.get('miscellaneousItems'):

        if mode in ['save_draft']:
            saveObj = MiscellaneousClaimItemDraft()
            saveObj.miscellaneousClaimDraft = parent
            saveObj.miscellaneousClaimDraft.modified = timezone.now()
            saveObj.miscellaneousClaimDraft.save()

        elif mode in ['submit_claim']:
            saveObj = MiscellaneousClaimItem()
            saveObj.miscellaneousClaim = parent
            saveObj.miscellaneousClaim.modified = timezone.now()
            saveObj.miscellaneousClaim.save()

        saveObj.date = i['date']
        saveObj.receiptNumber = i['receiptNumber']
        saveObj.expensesType = MiscellaneousType.objects.get(code=i['expensesType'].get('code'))
        saveObj.fundType = FundType.objects.get(code=i['fundType'].get('code'))
        saveObj.projectCode = i['projectCode']
        saveObj.totalBeforeGST = Decimal(i['totalBeforeGST'])
        saveObj.gstType = GSTTax.objects.get(code=i['gstType'].get('code'))
        saveObj.totalAfterGST = Decimal(i['totalAfterGST'])
        saveObj.expenseDetails = i['expenseDetails']
        saveObj.save()

def delete_miscellaneous_claim_draft_item(parent):
    delObj = MiscellaneousClaimItemDraft.objects.filter(miscellaneousClaimDraft=parent)
    delObj.delete()
