from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)
from .serializers import *
from ..models import *
from datetime import datetime
from eclaim.masterfiles.models.misc import MiscellaneousType

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MiscellaneousClaimViewSet',
    'MiscellaneousClaimDraftViewSet',
    'MiscExpenseCodeViewSet'
    ]



class MiscellaneousClaimViewSet(viewsets.ModelViewSet):
    serializer_class = MiscellaneousClaimSerializer
    queryset = MiscellaneousClaim.objects.all()


class MiscellaneousClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = MiscellaneousClaimDraftSerializer
    queryset = MiscellaneousClaimDraft.objects.all()

class MiscExpenseCodeViewSet(viewsets.ModelViewSet):
    serializer_class =  MiscExpenseCodeSerializer

    def get_queryset(self):

        year = (datetime.strptime(self.request.GET.get('date'),  '%Y-%m-%d')).year
        exp_code = self.request.GET.get('exp_code')
        description = self.request.GET.get('description')

        limit = (MiscellaneousType.objects.get(claim_type = 'Misc', description = description, exp_code = exp_code)).limit_claim

        number_of_obj = MiscellaneousClaim.objects.filter(miscellaneousclaimitem__date__year = year,
          miscellaneousclaimitem__expensesType__description = description,
           miscellaneousclaimitem__expensesType__exp_code = exp_code).count()

        if number_of_obj >= limit:
            return [dict(is_allowed=False, number_of_obj=number_of_obj, limit=limit)]

        return [dict(is_allowed=True, number_of_obj=number_of_obj, limit=limit)]
