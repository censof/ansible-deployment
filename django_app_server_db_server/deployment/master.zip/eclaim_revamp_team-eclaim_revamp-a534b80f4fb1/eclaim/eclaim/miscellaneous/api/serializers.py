from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MiscellaneousClaimSerializer',
    'MiscellaneousClaimDraftSerializer',
    'MiscExpenseCodeSerializer'
    ]


class MiscellaneousClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MiscellaneousClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        draftList = obj.miscellaneousclaimitem_set.all()
        return list(draftList.values())


class MiscellaneousClaimDraftSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MiscellaneousClaimDraft
        fields = ('id', 'items')

    def get_items(self, obj):
        draftList = obj.miscellaneousclaimitemdraft_set.all()
        return list(draftList.values())

class MiscExpenseCodeSerializer(serializers.ModelSerializer):
    is_allowed = serializers.SerializerMethodField()
    number_of_obj = serializers.SerializerMethodField()
    limit = serializers.SerializerMethodField()

    class Meta:
        model = MiscellaneousClaim
        fields = ('id', 'is_allowed', 'number_of_obj', 'limit')

    def get_is_allowed(self, obj):
        return obj['is_allowed']

    def get_number_of_obj(self, obj):
        return obj['number_of_obj']

    def get_limit (self, obj):
        return obj['limit']

