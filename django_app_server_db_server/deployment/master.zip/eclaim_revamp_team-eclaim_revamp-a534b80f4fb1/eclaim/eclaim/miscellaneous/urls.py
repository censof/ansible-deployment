# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import *

urlpatterns = patterns('',
    url(r'^miscellaneous/$', MiscellaneousIndexView.as_view(), name='miscellaneous_index'),
    url(r'^miscellaneous/detail/$', MiscellaneousDetailView.as_view(), name='miscellaneous_detail'),
    url(r'^miscellaneous/draft/(?P<draft_id>[0-9]+)/$', MiscellaneousDraftView.as_view(), name='miscellaneous_draft'),
    url(r'^miscellaneous/print-form/$', PrintView.as_view(), name='print_form' )
)
