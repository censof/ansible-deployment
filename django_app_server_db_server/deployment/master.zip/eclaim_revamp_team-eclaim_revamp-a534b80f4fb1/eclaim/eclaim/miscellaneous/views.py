import json
from eclaim.libs.views import ClaimIndexView
from django.shortcuts import redirect
from django.core.urlresolvers import reverse_lazy
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import AngularUpdateAndDetailView
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.claim.models import ClaimType
from .processes import process_controller
from .models import *
from eclaim.utils.common import (get_json_from_list)
from itertools import groupby
from eclaim.settings.models import WorkflowStateLog
from django.contrib.contenttypes.models import ContentType


class MiscellaneousIndexView(ClaimIndexView):
    template_name = 'miscellaneous/miscellaneous_claim.html'
    claim_type = ClaimType.get_claim_type(8)

    def get_context_data(self, **kwargs):
        ctx = super(ClaimIndexView, self).get_context_data(**kwargs)
        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['print_url'] = reverse_lazy('print_form')
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        claim_id = process_controller(form_data)
        btn_mode = form_data.get('btn_mode')

        if btn_mode in ['submit']:
            # Send a claim to workflow.
            try:
                claimant = Claimant.objects.get(user=self.request.user)
            except Claimant.DoesNotExist:
                claimant = None

            if claimant is not None:
                create_new_states(claimant, MiscellaneousClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscellaneousClaim, claim_id)

        return redirect(reverse_lazy('claim_list'))


class MiscellaneousDetailView(AngularUpdateAndDetailView):

    model = MiscellaneousClaim
    template_name = 'miscellaneous/miscellaneous_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(MiscellaneousDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['print_url'] = reverse_lazy('print_form')

        obj_pk = self.request.GET['pk']
        claim = MiscellaneousClaim.objects.get(pk=obj_pk)

        ctx['claim_no'] = claim.claim_no
        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscellaneousClaim, claim_id)

        return redirect(reverse_lazy('claim_list'))


class MiscellaneousDraftView(ClaimIndexView):
    template_name = 'miscellaneous/miscellaneous_claim.html'
    claim_type = ClaimType.get_claim_type(8)

    def get_context_data(self, **kwargs):
        ctx = super(ClaimIndexView, self).get_context_data(**kwargs)
        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['print_url'] = reverse_lazy('print_form')
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        claim_id = process_controller(form_data)
        btn_mode = form_data.get('btn_mode')

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscellaneousClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscellaneousClaim, claim_id)

        return redirect(reverse_lazy('claim_list'))


from easy_pdf.views import PDFTemplateView

class PrintView(PDFTemplateView):
    template_name = "miscellaneous/printing_form.html"
    def get_context_data(self, **kwargs):
        ctx = super(PrintView, self).get_context_data(**kwargs)
        claimType = self.request.GET.get('claimType')
        claimNo = self.request.GET.get('claimNo')

        claim_lst = []
        claim_model = None

        if claimType == 'draft':
            claim_lst = MiscellaneousClaimItemDraft.objects.filter(miscellaneousClaimDraft=claimNo)
            claim_model = MiscellaneousClaimDraft
        elif claimType == 'submit':
            claim_lst = MiscellaneousClaimItem.objects.filter(miscellaneousClaim=claimNo)
            claim_model = MiscellaneousClaim

        try:
            wrkfLog =  WorkflowStateLog.objects.filter(object_id=claimNo, content_type=ContentType.objects.get_for_model(claim_model)).latest()
            wrkf = dict(name=Claimant.objects.get(staff_no = wrkfLog.claimant).name, status=wrkfLog.status, date=wrkfLog.modified)
        except:
            wrkf = None

        groups = []
        uniquekeys = []
        for k, g in groupby(sorted(claim_lst, key=lambda x : x.expensesType.code), key=lambda x : x.expensesType.code):
            groups.append(list(g))
            uniquekeys.append(k)

        exp_list = []
        expObj = {}
        total_exp = 0
        total = 0
        for item_list in groups:
            expObj['title'] = item_list[0].expensesType.description
            for item in item_list:
                total += item.totalBeforeGST
                total_exp += item.totalBeforeGST
            expObj['total'] =total
            exp_list.append(expObj)
            expObj = {}
            total = 0

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None
        ctx['claimant'] = claimant
        ctx['claimType'] = claimType
        ctx['claimNo'] = claimNo
        ctx['exp_list'] = exp_list
        ctx['total_exp'] = total_exp
        ctx['wrkf'] = wrkf
        return ctx
