console.log('miscellaneous App Loaded!!!');

uiBootstrapApp.controller('miscellaneousClaimCtrl', function ($scope, $http, $sce, MiscellaneousLocalData, printdata) {

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;
    $scope.panel = {};
    $scope.panel.p2 = true;
    $scope.btnPrint = printdata.getbtnShow();

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel.p1 = true;
        $scope.panel.p2 = true;
        $scope.panel.p3 = true;
        $scope.panel.p4 = true;
        $scope.panel.p5 = true;
        $scope.panel.p6 = true;
        $scope.panel.p7 = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel.p1 = false;
        $scope.panel.p2 = false;
        $scope.panel.p3 = false;
        $scope.panel.p4 = false;
        $scope.panel.p5 = false;
        $scope.panel.p6 = false;
        $scope.panel.p7 = false;
    };
    /*************** Accordion End ***************/

    /**
     * Detail view
     */
    if (PK) {
        // Initialize variables.
        $scope.viewClaim = false;
        $scope.grandColspan = 9;

        $http({
            url: API_URL+'miscellaneous-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            // Add a form declaration to the scope.
            add_form_declaration($scope, $sce, 8, data.current_level_ordering);
        });
    } else {
        $scope.viewClaim = true;
        $scope.grandColspan = 10;

        // Add a form declaration to the scope.
        add_form_declaration($scope, $sce, 8, 1);
    }

    var claim_api_url = API_URL+'miscellaneous-claims/';
    init_workflow($scope, $http, 'miscellaneous', 'MiscellaneousClaim', PK, claim_api_url, WF_TEMPLATE);

    $scope.print = function(){
        claimDetails = {
            claimNo : printdata.getClaimID(),
            claimType : printdata.getClaimType()
        };

        window.location.href = print_url+'?claimNo='+printdata.getClaimID()+'&claimType='+printdata.getClaimType();
    }

});

uiBootstrapApp.controller('miscellaneousLocalClaimCtrl', function ($scope, $http, $q, $filter, DataGST, DataFundType, DataLookup, DataClaimant, MiscellaneousLocalData, DataAdvance, printdata) {

    $scope.ng_form = {};
    $scope.ng_form.gst_amount = 0;
    $scope.ng_form.ngDescription = '';

    $scope.miscClaimList = [];
    $scope.isEmptyTable = true;
    $scope.grandTotal = 0;
    MiscellaneousLocalData.setClaimantNo($scope.claimant_no);
    var indxOfChangedItem;

    $scope.expenditure_list = [];
    $scope.fundType_list = [];
    $scope.gstType_list = [];

    var _promises = {};

    _promises['misc_type'] =
        $http({
            url: API_URL+'miscellaneous-type/',
            method: 'GET'
        });

    _promises['fund_type'] =
        $http({
            url: API_URL+'fund-type/',
            method: 'GET'
        });

    _promises['gst'] =
        $http({
            url: API_URL+'gst-tax/',
            method: 'GET'
        });

    if(PK){
        _promises['claim_details'] =
            $http({
                url: API_URL+'miscellaneous-claims/'+PK+'/',
                method: 'GET'
            });
    }

    $q.all(_promises).then(function (resolutions) {
        var _expenditure_list = resolutions.misc_type.data.results;
        for (var i=0; i<_expenditure_list.length; i++){
            if(_expenditure_list[i].claim_type == 'Misc')
                $scope.expenditure_list.push(_expenditure_list[i]);
        }
    });

    $scope.getDraft_id = function(draft_id){

        $q.all(_promises).then(function (resolutions) {
                // Misc type
            if($scope.expenditure_list.length<1){
                var _expenditure_list = resolutions.misc_type.data.results;
                for (var i=0; i<_expenditure_list.length; i++){
                    if(_expenditure_list[i].claim_type == 'Misc'){
                        $scope.expenditure_list.push(_expenditure_list[i]);
                    }
                }
            }
            // GST
            $scope.gstType_list = resolutions.gst.data.results;

            // Fund type
            $scope.fundType_list = resolutions.fund_type.data.results;

            //claim details
            if(PK){
                $scope.claim_details = resolutions.claim_details.data.results;
                printdata.setClaimID(PK);
                printdata.setClaimType('submit');
            }

            if(draft_id){
                printdata.setClaimID(draft_id);
                printdata.setClaimType('draft');
                $http({
                        url: API_URL+'miscellaneous-claim-drafts/'+draft_id+'/',
                        method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    MiscellaneousLocalData.setMiscellaneousItems(data.items);
                    takeItems();
                });
            }else{
                if(PK){
                    MiscellaneousLocalData.setMiscellaneousItems($scope.claim.items);
                    takeItems();
                }
            }
        });

    }

    function takeItems(){
        printdata.setbtnShow(true);
        $scope.btnPrint = printdata.getbtnShow();
        $scope.miscClaimList = MiscellaneousLocalData.getMiscellaneousItems();
        if($scope.miscClaimList.length)
            $scope.isEmptyTable = false;
        $scope.grandTotal = getGrandTotal();

        for(var i=0; i<$scope.miscClaimList.length; i++){

            $scope.miscClaimList[i].dateToUpdate = getDateFromStr($scope.miscClaimList[i].date);

            for (var ft=0; ft<$scope.fundType_list.length; ft++){
                if ($scope.miscClaimList[i].fundType_id == $scope.fundType_list[ft].code){
                    $scope.miscClaimList[i].fundType = $scope.fundType_list[ft];
                }
            }

            for (var gs=0; gs<$scope.gstType_list.length; gs++){
                if ($scope.miscClaimList[i].gstType_id == $scope.gstType_list[gs].code){
                    $scope.miscClaimList[i].gstType = $scope.gstType_list[gs];
                }
            }

            for (var ex=0; ex<$scope.expenditure_list.length; ex++){
                if ($scope.miscClaimList[i].expensesType_id == $scope.expenditure_list[ex].id){
                    $scope.miscClaimList[i].expensesType = $scope.expenditure_list[ex];
                }
            }
        }
    }

    $scope.getToUpdate = function(indx){
        var currentItem = $scope.miscClaimList[indx];
        $scope.openModal();
        $scope.btnUpdate = true;
        $scope.total_after_gst = 0;
        $scope.totalBeforeGST = 0;
        indxOfChangedItem = indx;

        MiscellaneousLocalData.setDate(currentItem.dateToUpdate);
        $scope.ng_form.ngReceipt = currentItem.receiptNumber;
        $scope.ng_form.expenditure = currentItem.expensesType;
        DataFundType.setFundType(currentItem.fundType);
        DataLookup.setProjectCode(currentItem.projectCode);
        $scope.ng_form.total_before_gst = currentItem.totalBeforeGST;
        $scope.updateTotal();
        DataGST.setGSTType(currentItem.gstType);
        $scope.gst_amount = currentItem.totalBeforeGST*(currentItem.gstType.rate/100);
        $scope.ng_form.ngDescription = currentItem.expenseDetails;
    }

    $scope.updateTotal = function(){
        $scope.total_after_gst = Number($scope.ng_form.total_before_gst) + Number($scope.ng_form.total_before_gst) * DataGST.getGSTFloat();
        $scope.gst_amount = Number($scope.ng_form.total_before_gst) * DataGST.getGSTFloat();

        $scope.total_after_gst = get2Float($scope.total_after_gst);
        $scope.gst_amount = get2Float($scope.gst_amount);

        if(isNaN($scope.total_after_gst))
            $scope.total_after_gst = 0;
        if(isNaN($scope.gst_amount))
            $scope.gst_amount = 0;
    }

    $scope.$watch(function () { return DataGST.getGSTFloat(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.total_after_gst = Number($scope.ng_form.total_before_gst)
                                     + Number($scope.ng_form.total_before_gst) * newValue;
            $scope.gst_amount = Number($scope.ng_form.total_before_gst) * newValue;
        }

        $scope.total_after_gst = get2Float($scope.total_after_gst);
        $scope.gst_amount = get2Float($scope.gst_amount);

        if(isNaN($scope.total_after_gst))
            $scope.total_after_gst = 0;
        if(isNaN($scope.gst_amount))
            $scope.gst_amount = 0;
    });

    $scope.deleteMiscLocalItem = function(indx){
        $scope.miscClaimList.splice(indx, 1);
        if( !$scope.miscClaimList.length)
            $scope.isEmptyTable = true;

        $scope.grandTotal = getGrandTotal();

        $scope.$watch('MiscellaneousLocalData', function() {
            MiscellaneousLocalData.setMiscellaneousItems($scope.miscClaimList);
        }, true);
    }

    $scope.addClaimItem = function(indx){
        if (Number(indx) > -1){
            $scope.addItem(indx);
        }else{
            limExpensesType = $scope.ng_form.expenditure;
            params = {
                exp_code : $scope.ng_form.expenditure.exp_code,
                description : $scope.ng_form.expenditure.description,
                date : MiscellaneousLocalData.getDateTxt()
            }
            $http({
                url: API_URL+'miscellaneous-claims-expense',
                method: 'GET',
                params: params
                })
                .success(function (data, status, headers, config) {
                    obj_to_check_limit = data.results[0];
                    if (obj_to_check_limit.is_allowed){
                        lim = 0;
                        for (var i=0; i<$scope.miscClaimList.length; i++){
                            if( $scope.miscClaimList[i].expensesType.exp_code==limExpensesType.exp_code
                             && $scope.miscClaimList[i].expensesType.description==limExpensesType.description)
                                lim+=1;
                        }
                        if(lim+obj_to_check_limit.number_of_obj < obj_to_check_limit.limit)
                        {
                            $scope.addItem(indx);
                        }
                        else{
                            window.alert('Exceed Limitation Using This Expense Type ');
                        }
                    }
                    else{
                        window.alert('Exceed Limitation Using This Expense Type ');
                    }

                });
        }
    }

    $scope.addItem = function(indx){
        var item = {}, gstType = {},
            gstType = DataGST.getGSTType();

        item.dateToUpdate   = MiscellaneousLocalData.getDate();
        item.date           = MiscellaneousLocalData.getDateTxt();
        item.receiptNumber  = $scope.ng_form.ngReceipt;
        item.expensesType   = $scope.ng_form.expenditure;
        item.fundType       = DataFundType.getFundType();
        item.projectCode    = DataLookup.getProjectCode();
        item.totalBeforeGST = $scope.ng_form.total_before_gst;
        item.gstType        = gstType;
        item.totalAfterGST  = Number(item.totalBeforeGST) + Number(item.totalBeforeGST) * DataGST.getGSTFloat();
        item.expenseDetails =  $scope.ng_form.ngDescription;

        if(Number(indx) > -1){
            $scope.miscClaimList[indx] = item;
        }
        else{
            $scope.miscClaimList.push(item);
        }

        $scope.grandTotal = getGrandTotal();

        if( $scope.miscClaimList.length)
             $scope.isEmptyTable = false;


        DataFundType.setFundType({});
        MiscellaneousLocalData.setDate('');
        DataGST.setGSTType({});
        $scope.ng_form = {};
        $scope.ng_form.ngDescription = '';
    }

    $scope.update = function(){
        $scope.addClaimItem(indxOfChangedItem);
        $scope.btnUpdate = false;
    }

    function getGrandTotal(){
        var total = 0;
        for (var i=0; i<$scope.miscClaimList.length; i++)
            total += Number($scope.miscClaimList[i].totalAfterGST);
        total = total.toFixed(2);
        DataAdvance.setClaimGrandTotal(total);
        MiscellaneousLocalData.setGrandTotal(total);
        return total;
    }

    $scope.openModal = function(){
        $scope.btnUpdate = false;
        $('#miscModalForm').modal('show');
    };

    $scope.$watch('miscClaimList', function() {
        MiscellaneousLocalData.setMiscellaneousItems($scope.miscClaimList);
    }, true);

});

uiBootstrapApp.factory('MiscellaneousLocalData', function ($filter) {
    var data = {
            miscellaneousItems:[],
            error_validation:'',
            claimant_no:'',
            draft_id:'',
            claim_id:'',
            claim_date:'',
            DateTxt:'-',
            grand_total:0
        };
    return {
        getMiscellaneousItems: function () {
            return data.miscellaneousItems;
        },
        setMiscellaneousItems: function (objt){
            data.miscellaneousItems = objt;
        },
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (objt){
            data.error_validation = objt;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        },
        getDate: function () {
            return data.claim_date;
        },
        getDateTxt: function () {
            return data.DateTxt;
        },
        setDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.claim_date = obj;
            data.DateTxt = minDate;
        },
        getGrandTotal: function () {
            return data.grand_total;
        },
        setGrandTotal: function (obj) {
            data.grand_total = obj;
        }
    };
});
//submit and draft controller

uiBootstrapApp.factory('printdata', function () {
    var data = {
        claimID:'',
        claimType:'',
        showbtn : false
    };
    return{
        setClaimID : function(dataID){
            data.claimID = dataID;
        },
        getClaimID : function(){
            return data.claimID;
        },
        setClaimType : function(dataType){
            data.claimType = dataType;
        },
        getClaimType : function(){
            return data.claimType;
        },
        setbtnShow : function(data){
            data.showbtn = data;
        },
        getbtnShow : function(){
            return data.showbtn;
        },
    };
});

uiBootstrapApp.controller('SubmitCtrl', function ($scope, $http, $window, MiscellaneousLocalData, DataClaimant, $uibModal, DataAdvance) {

    $scope.animationsEnabled = true;

    $scope.submit = function(btnMode) {
        form_data = {
            btn_mode:btnMode,
            miscellaneousItems:MiscellaneousLocalData.getMiscellaneousItems(),
            claimant_no: DataClaimant.getStaffNo(),
            draft_id:MiscellaneousLocalData.getDraftID(),
            net_total:DataAdvance.getClaimNettTotal(),
            grand_total:MiscellaneousLocalData.getGrandTotal()
        }

        if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

        var instance_controller = '';

        if (btnMode == 'save_draft') {
            instance_controller = 'ModalInstanceSaveCtrl';
            ng_template = 'SaveConformation.html';
        }else if (btnMode == 'submit'){
            instance_controller = 'ModalInstanceSubmitCtrl';
            ng_template = 'SubmitConformation.html';
        }
        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: ng_template,
            controller: instance_controller,
            size: 'sm',
            resolve: {
                data: function () {
                    return form_data;
                }
            }
        });

        modalInstance.result.then( function () {
                console.log('OK, conformation box closed');
                disable_claim_controls();

                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                } else {
                    $http({
                        url: '',
                        method: 'POST',
                        data: form_data
                    })
                    .success(function (data, status, headers, config) {
                        var submit_success_url = data.submit_success_url || URL_HOMEPAGE;

                        if (btnMode == 'submit') {
                            $window.location.href = submit_success_url;
                        } else if (btnMode == 'save_draft') {
                            $scope.initSubmitCtrl(data.draft_id);
                            $uibModal.open({
                                animation: $scope.animationsEnabled,
                                templateUrl: 'SaveSuccess.html',
                                controller: 'ModalInstanceInfoCtrl',
                                size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
                                resolve: {
                                  data: function () {
                                    return data;
                                  }
                                }
                            });
                            window.location.href = URL_HOMEPAGE;
                        }
                    });
                }
            },
            function () {
                console.log('Cancel, conformation box closed');
            }
        );
    };

    $scope.initSubmitCtrl = function(draft_id){
        $scope.draft_id = draft_id;
        MiscellaneousLocalData.setDraftID(draft_id);
    };
});

uiBootstrapApp.controller('ModalInstanceSaveCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

uiBootstrapApp.controller('ModalInstanceSubmitCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

uiBootstrapApp.controller('ModalInstanceInfoCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };
}]);

uiBootstrapApp.controller('ModalDemoCtrl', ['$scope', '$uibModal', function ($scope, $uibModal) {

    $scope.items = ['item1', 'item2', 'item3'];

    $scope.animationsEnabled = true;

    $scope.open = function (size) {

    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'myModalContent.html',
      controller: 'ModalInstanceCtrl',
      size: size,
      resolve: {
        items: function () {
          return $scope.items;
        }
      }
    });

    modalInstance.result.then(
        function (selectedItem) {
            $scope.selected = selectedItem;
        },
        function () {
            $log.info('Modal dismissed at: ' + new Date());
        }
    );
  };

  $scope.toggleAnimation = function () {
    $scope.animationsEnabled = !$scope.animationsEnabled;
  };

}]);

uiBootstrapApp.controller('ModalInstanceCtrl', ['$scope', '$modalInstance', 'items', function ($scope, $uibModalInstance, items) {

  $scope.items = items;
  $scope.selected = {
    item: $scope.items[0]
  };

  $scope.ok = function () {
    $uibModalInstance.close($scope.selected.item);
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
}]);

uiBootstrapApp.controller('claimDateCtrl', function($scope, MiscellaneousLocalData){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.miscDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.dateChanged = function(){
        MiscellaneousLocalData.setDate($scope.miscDate);
    };

    $scope.$watch(function () { return MiscellaneousLocalData.getDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.miscDate = newValue;
        }
    });
});

uiBootstrapApp.controller('summaryCtr', function($scope, $http, MiscellaneousLocalData){

    $scope.$watchCollection(function () { return MiscellaneousLocalData.getMiscellaneousItems(); }, function (newValue, oldValue) {
        $scope.summary_list = [];
        $scope.GSTsummary_list = [];
        $scope.grandSummaryTotal = 0;

        var miscClaim_list = $.extend(true, [], MiscellaneousLocalData.getMiscellaneousItems());

        if(miscClaim_list.length)
        {
            getGSTSummary(miscClaim_list);
            getSummaryList(getExpensesObjects(groupByExp(miscClaim_list)));
            $scope.grandSummaryTotal = $scope.grandSummaryTotal.toFixed(2);
        }
    });

    function groupByExp(miscClaim_list){
        grouped_list = [];

        while(miscClaim_list.length>0){
            grouped_list.push(miscClaim_list[0]);
            exp = miscClaim_list[0].expensesType.id;
            miscClaim_list.splice(0, 1);

            for (var i=0; i<miscClaim_list.length; i++){
                if(miscClaim_list[i].expensesType.id == exp){
                    grouped_list.push(miscClaim_list[i]);
                    miscClaim_list.splice(i, 1);
                    i--;
                 }
            }
        }

        return grouped_list;
    }

    function getExpensesObjects(expGrouped_list){
        expensesObjs = [];
        ls = [];
        var j=0;

        for (var i=0; i<expGrouped_list.length; i++){
            while(i<expGrouped_list.length){
                if(expGrouped_list[i].expensesType.id==expGrouped_list[j].expensesType.id){
                    ls.push(expGrouped_list[i]);
                    i++;
                }
                else{ j=i; i--; break; }
            }
            expensesObjs.push(ls);
            ls = [];
        }
        return expensesObjs;
    }

    function fundObjExist(fund_list, _description){
        for (var i=0; i<fund_list.length; i++){
            if(fund_list[i].description == _description)
                return i;
        }
        return -1;
    }

    function getSummaryList(expensesObjs_list){
        for (var i=0; i<expensesObjs_list.length; i++){

            sumryObj = {};
            sumryObj.fundType = [];
            sumryObj.title = expensesObjs_list[i][0].expensesType.description;
            sumryObj.expenseCode = expensesObjs_list[i][0].expensesType.exp_code;
            sumryObj.amount = 0;

            for(var j=0; j<expensesObjs_list[i].length; j++){

                sumryObj.amount +=  Number(expensesObjs_list[i][j].totalBeforeGST);

                indx = fundObjExist(sumryObj.fundType, expensesObjs_list[i][j].fundType.description);
                if(indx != -1){
                    sumryObj.fundType[indx].amount += Number(expensesObjs_list[i][j].totalBeforeGST);
                }else{
                    fundObj = {};
                    fundObj.amount = Number(expensesObjs_list[i][j].totalBeforeGST);
                    fundObj.description = expensesObjs_list[i][j].fundType.description;
                    sumryObj.fundType.push(fundObj);
                }
            }
            $scope.summary_list.push(sumryObj);
        }
    }

    // GST Summary
    function gstObjExist(gst_list, gstDescription){
        for (var i=0; i<gst_list.length; i++){
            if(gst_list[i].description == gstDescription)
                return i;
        }
        return -1;
    }

    function getGSTSummary(miscClaim_list){
        ls = [];
        for (var i=0; i<miscClaim_list.length; i++){
            gstObj = {}
            indx = (gstObjExist(ls, miscClaim_list[i].gstType.description));
            if(indx != -1){
                ls[indx].amount += miscClaim_list[i].gstType.rate * miscClaim_list[i].totalBeforeGST / 100;
                $scope.grandSummaryTotal += miscClaim_list[i].totalAfterGST;
            }
            else{
                gstObj.description = miscClaim_list[i].gstType.description;
                gstObj.amount = miscClaim_list[i].gstType.rate * miscClaim_list[i].totalBeforeGST / 100;
                ls.push(gstObj);
                $scope.grandSummaryTotal += miscClaim_list[i].totalAfterGST;
            }
        }
        $scope.GSTsummary_list = ls;
    }
});
