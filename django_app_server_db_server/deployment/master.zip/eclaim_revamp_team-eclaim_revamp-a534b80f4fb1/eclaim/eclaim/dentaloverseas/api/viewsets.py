from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)

from .serializers import *
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'DentaloverseasClaimViewSet',
    'DentaloverseasClaimDraftViewSet'
    ]



class DentaloverseasClaimViewSet(viewsets.ModelViewSet):
    serializer_class = DentaloverseasClaimSerializer
    queryset = DentaloverseasClaim.objects.all()


class DentaloverseasClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = DentaloverseasClaimDraftSerializer
    queryset = DentaloverseasClaimDraft.objects.all()
