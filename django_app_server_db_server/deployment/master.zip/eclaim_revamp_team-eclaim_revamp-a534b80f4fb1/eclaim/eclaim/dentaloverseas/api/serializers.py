from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'DentaloverseasClaimSerializer',
    'DentaloverseasClaimDraftSerializer'
    ]


class DentaloverseasClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = DentaloverseasClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        draftList = obj.dentaloverseasclaimitem_set.all()
        return list(draftList.values())


class DentaloverseasClaimDraftSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = DentaloverseasClaimDraft
        fields = ('id', 'items')

    def get_items(self, obj):
        draftList = obj.dentaloverseasclaimitemdraft_set.all()
        return list(draftList.values())
