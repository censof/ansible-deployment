# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import DentaloverseasIndexView, DentaloverseasDetailView, DentaloverseasDraftView

urlpatterns = patterns('',
    url(r'^dentaloverseas/$', DentaloverseasIndexView.as_view(), name='dentaloverseas_index'),
    url(r'^dentaloverseas/detail/$', DentaloverseasDetailView.as_view(), name='dentaloverseas_detail'),
    url(r'^dentaloverseas/draft/(?P<draft_id>[0-9]+)/$', DentaloverseasDraftView.as_view(), name='dentaloverseas_draft')
)
