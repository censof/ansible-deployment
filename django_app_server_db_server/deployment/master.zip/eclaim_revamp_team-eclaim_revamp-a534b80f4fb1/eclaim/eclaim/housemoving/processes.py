import datetime
from decimal import *

from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.utils import save_claimant_history, save_document_list_item_draft, save_document_list_item
from eclaim.utils.common import generate_claim_no, get_claim_type_code, get_claim_type_prefix
from .models import HOUSE_MOVING_CLAIM_TYPE, HouseMovingClaim, HouseMovingClaimDraft


__ClaimType__ = get_claim_type_code(HOUSE_MOVING_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(HOUSE_MOVING_CLAIM_TYPE)


def house_moving_claim_process(btn_mode, form_data, created_by=None):
    draft_id = None
    claim_id = None

    if btn_mode in ['save_draft']:
        draft_id = save_draft(form_data, created_by)
    elif btn_mode in ['submit']:
        claim_id = submit_claim(form_data)

    return draft_id, claim_id


def save_draft(form_data, created_by=None):
    draft_id = form_data.get('draft_id')

    house_moving_claim_draft_id = None if (draft_id == '' or draft_id is None) else int(draft_id)
    status = 'D' if (draft_id == '' or draft_id is None) else None

    claim_draft = HouseMovingClaimDraft(id=house_moving_claim_draft_id)
    claim_draft.status = status
    claim_draft.moving_date = datetime.datetime.strptime(form_data.get('movingDateTxt'), "%Y-%m-%d")
    claim_draft.apply_date = datetime.date.today()
    claim_draft.created_by = created_by or None
    claim_draft.save()
    save_house_moving_claim('save', claim_draft, form_data)
    save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)

    if draft_id == '' or draft_id is None:
        return claim_draft.id
    else:
        return draft_id


def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')
    draft_id = form_data.get('draft_id')

    claim = HouseMovingClaim()
    claim.status = 'S'
    claim.moving_date = datetime.datetime.strptime(form_data.get('movingDateTxt'), "%Y-%m-%d")
    claim.apply_date = datetime.date.today()
    claim.save()

    claim.claim_no = generate_claim_no(__ClaimPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_house_moving_claim('submit', claim, form_data)
    save_document_list_item(claim.claim_no, __ClaimType__, form_data)

    if draft_id != '':
        claim_draft = HouseMovingClaimDraft(id=int(draft_id))
        delete_house_moving_claim_draft(claim_draft)

    return claim.id

def save_house_moving_claim(housemoving, form_data):
    saveObj = housemoving
    saveObj.contact_no = form_data.get('contactNo')
    saveObj.marital_status = form_data.get('maritalStatus')
    saveObj.government_loan = form_data.get('governmentLoan')
    saveObj.fund_type = FundType.objects.get(code=form_data['houseMovingFundType'].get('code'))
    saveObj.project_code = form_data.get('houseMovingProjectCode')
    saveObj.destination = form_data['destinationType'].get('code')
    saveObj.old_address_1 = form_data.get('oldAddress1')
    saveObj.old_address_2 = form_data.get('oldAddress2')
    saveObj.old_address_3 = form_data.get('oldAddress3')
    saveObj.old_address_4 = form_data.get('oldAddress4')
    saveObj.new_address_1 = form_data.get('newAddress1')
    saveObj.new_address_2 = form_data.get('newAddress2')
    saveObj.new_address_3 = form_data.get('newAddress3')
    saveObj.new_address_4 = form_data.get('newAddress4')
    saveObj.rate = Decimal(form_data.get('claimRate'))
    saveObj.grand_total = Decimal(form_data.get('grandTotal'))
    saveObj.endowment = Decimal(form_data.get('endowmentAmount'))
    saveObj.net_total = Decimal(form_data.get('netTotal'))
    saveObj.save()

def delete_house_moving_claim_draft(draft):
    deleteObj = draft
    deleteObj.delete()
