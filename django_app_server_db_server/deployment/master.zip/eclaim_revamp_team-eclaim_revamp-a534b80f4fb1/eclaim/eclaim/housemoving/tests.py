from eclaim.libs.tests import TestCase
from eclaim.housemoving.models import (HouseMovingClaim,
                                       HouseMovingClaimDraft)
from eclaim.housemoving.processes import (house_moving_claim_process,
                                          save_draft,
                                          submit_claim,
                                          delete_house_moving_claim_draft,
                                          save_house_moving_claim)
from mock import Mock, patch, call

class HouseMovingClaimsTests(TestCase):

    def setUp(self):

        self.hse_mv_claim = HouseMovingClaim()
        self.hse_mv_claim.moving_date = '2016-04-01'
        self.hse_mv_claim.apply_date = '2016-04-01'
        self.hse_mv_claim.old_address_1 = 'old_address_1'
        self.hse_mv_claim.old_address_2 = 'old_address_2'
        self.hse_mv_claim.old_address_3 = 'old_address_3'
        self.hse_mv_claim.old_address_4 = 'old_address_4'
        self.hse_mv_claim.save()

        self.hse_mv_claim_draft = HouseMovingClaimDraft()

    def testDown(self):

        self.hse_mv_claim.delete()

    def test_update_house_moving_claim(self):

        """Update data in moving house claim model"""

        self.assertEqual(self.hse_mv_claim.old_address_4,
                         'old_address_4')

        self.hse_mv_claim.old_address_4 = 'updated_old_address_4'
        self.hse_mv_claim.save()

        self.assertEqual(self.hse_mv_claim.old_address_4,
                         'updated_old_address_4')

    def test_house_moving_claim_draft_absolute_url(self):
        draft_url = self.hse_mv_claim_draft.get_absolute_url()
        assert(draft_url.__dict__['_proxy____args'][0] == 'housemoving_draft')


    @patch('eclaim.housemoving.processes.save_draft')
    @patch('eclaim.housemoving.processes.submit_claim')
    def test_house_moving_claim_process(self, mock_submit_claim, mock_save_draft):

        mock_save_draft.return_value = 1234
        result = house_moving_claim_process('save_draft', {'one': 1}, created_by='Author')
        self.assertEqual(mock_save_draft.call_args,
                         call({'one': 1}, 'Author'))
        self.assertEqual(result, (1234, None))
        mock_submit_claim.return_value = 1234
        result2 = house_moving_claim_process('submit', {'one': 1}, created_by='Author')
        self.assertEqual(mock_submit_claim.call_args,
                         call({'one': 1}))
        self.assertEqual(result2, (None, 1234))

    @patch('eclaim.housemoving.processes.datetime.date')
    @patch('eclaim.housemoving.processes.save_document_list_item_draft')
    @patch('eclaim.housemoving.processes.save_house_moving_claim')
    @patch('eclaim.housemoving.processes.HouseMovingClaimDraft')
    def test_save_draft(self, mock_HouseMovingClaimDraft,
                        mock_save_house_moving_claim, mock_save_document_list_item_draft, mock_date):

        mock_date.today.return_value = '2016-01-01'
        mock_form_data = {'movingDateTxt': '2014-01-01'}
        save_draft(mock_form_data)
        self.assertTrue(mock_HouseMovingClaimDraft.return_value.save.called)
        self.assertIn('save', mock_save_house_moving_claim.call_args[0])
        self.assertIn('save', mock_save_house_moving_claim.call_args[0])
        self.assertIn({'movingDateTxt': '2014-01-01'}, mock_save_house_moving_claim.call_args[0])
        self.assertIn({'movingDateTxt': '2014-01-01'}, mock_save_document_list_item_draft.call_args[0])
        self.assertIn(None, mock_save_document_list_item_draft.call_args[0])

        mock_form_data['draft_id'] = 1234
        result = save_draft(mock_form_data)
        self.assertEqual(result, 1234)
        for item in ('save', {'draft_id': 1234, 'movingDateTxt': '2014-01-01'}):
            self.assertIn(item, mock_save_house_moving_claim.call_args[0])
        for item in (None, {'draft_id': 1234, 'movingDateTxt': '2014-01-01'}):
            self.assertIn(item, mock_save_document_list_item_draft.call_args[0])

    @patch('eclaim.housemoving.processes.datetime.date')
    @patch('eclaim.housemoving.processes.save_document_list_item_draft')
    @patch('eclaim.housemoving.processes.save_house_moving_claim')
    @patch('eclaim.housemoving.processes.HouseMovingClaim')
    @patch('eclaim.housemoving.processes.HouseMovingClaimDraft')
    @patch('eclaim.housemoving.processes.save_claimant_history')
    @patch('eclaim.housemoving.processes.save_document_list_item')
    @patch('eclaim.housemoving.processes.delete_house_moving_claim_draft')
    def test_submit_claim(self, mock_delete_house_moving_claim_draft,
                          mock_save_document_list_item,
                          mock_save_claimant_history,
                          mock_HouseMovingClaimDraft,
                          mock_HouseMovingClaim,
                          mock_save_house_moving_claim,
                          mock_save_document_list_item_draft,
                          mock_date):

        mock_data = dict(claimant_no=1234, draft_id=1234, movingDateTxt='2014-01-01')
        mock_date.today.return_value = '2016-01-01'
        submit_claim(mock_data)
        for item in (None, {'draft_id': 1234, 'claimant_no': 1234, 'movingDateTxt': '2014-01-01'}):
            self.assertIn(item, mock_save_document_list_item.call_args[0])
        self.assertIn({'draft_id': 1234, 'claimant_no': 1234, 'movingDateTxt': '2014-01-01'},
                      mock_save_house_moving_claim.call_args[0])
        for item in (None, 1234):
            self.assertIn(item, mock_save_claimant_history.call_args[0])
        self.assertFalse(mock_save_document_list_item_draft.called)
        self.assertTrue(mock_HouseMovingClaim.return_value.save.called)
        self.assertTrue(mock_HouseMovingClaimDraft.called)
        self.assertTrue(mock_delete_house_moving_claim_draft.called)

    def test_delete_house_moving_claim_draft(self):
        del_obj = Mock()
        delete_house_moving_claim_draft(del_obj)
        self.assertTrue(del_obj.delete.called)

    @patch('eclaim.housemoving.processes.FundType')
    def test_save_house_moving_claim(self, mock_FundType):
        housemoving_obj = Mock()
        mock_FundType.object.get.return_value = 1234
        mock_form_data = dict(contactNo=1234,
                              maritalStatus='married',
                              governmentLoan='governmentLoan',
                              houseMovingFundType=dict(code=1234),
                              houseMovingProjectCode=1234,
                              destinationType=dict(code=1234),
                              oldAddress1='oldAddress1',
                              oldAddress2='oldAddress2',
                              oldAddress3='oldAddress3',
                              oldAddress4='oldAddress4',
                              newAddress1='newAddress1',
                              newAddress2='newAddress2',
                              newAddress3='newAddress3',
                              newAddress4='newAddress4',
                              claimRate=2,
                              grandTotal=100,
                              endowmentAmount=10,
                              netTotal=100)
        save_house_moving_claim(housemoving_obj, mock_form_data)
        for item in ('old_address_1', 'old_address_2', 'old_address_3', 'old_address_4'):
            data_split = item.split("_")
            self.assertEqual(getattr(housemoving_obj, item),
                             mock_form_data[data_split[0] + ''.join(str.capitalize() for str in data_split[1:])])

        for item in ('new_address_1', 'new_address_2', 'new_address_3', 'new_address_4'):
            data_split = item.split("_")
            self.assertEqual(getattr(housemoving_obj, item),
                             mock_form_data[data_split[0] + ''.join(str.capitalize() for str in data_split[1:])])
        self.assertTrue(housemoving_obj.save.called)
