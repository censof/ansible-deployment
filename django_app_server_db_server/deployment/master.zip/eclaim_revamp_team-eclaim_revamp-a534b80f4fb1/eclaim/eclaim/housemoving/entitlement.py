import json
import datetime
from decimal import Decimal

from django.db.models import Max

from eclaim.masterfiles.models.entitlement import MovingAllowanceEntitlement, HouseMovingAllowance

def get_house_moving_rate(salary_grade,basic_salary):
    rate = {}
    salary = Decimal(basic_salary)
    if str(salary_grade).isdigit():
        gradelevel = int(salary_grade)
    else:
        gradelevel = salary_grade
        
    entitlements = MovingAllowanceEntitlement.objects.filter(effective_date__lte=datetime.date.today()).annotate(Max('effective_date'))
    
    entitlement = None
    m = [i for i in entitlements if str(i.ssm_grade_from.code).isdigit() and str(i.ssm_grade_to.code).isdigit()]
    if m:
        n = [i for i in m if gradelevel >= int(i.ssm_grade_from.code) and gradelevel <= int(i.ssm_grade_to.code)]
    else:
        n = [i for i in m if gradelevel >= i.ssm_grade_from.code and gradelevel <= i.ssm_grade_to.code]
        
    max_salary = Decimal('0.00')
    if len(n) == 1:
        entitlement = n[0]
    else:
        for i in n:
            if i.ssm_salary_to > max_salary:
                max_salary = i.ssm_salary_to
            if i.ssm_salary_from != '0.00' and i.ssm_salary_to != '0.00':
                if salary >= i.ssm_salary_from and salary <= i.ssm_salary_to:
                    entitlement = i
            else:
                entitlement = i
    
    if entitlement == None:
        for i in n:
            if i.ssm_salary_to == max_salary:
                entitlement = i
                
    westmoving = HouseMovingAllowance.objects.filter(entitlement=entitlement,region='West')
    for i in westmoving:
        rate['west_single'] = str(i.single)
        rate['west_married'] = str(i.married)
        
    sabahsarawakmoving = HouseMovingAllowance.objects.filter(entitlement=entitlement,region='East')
    for i in sabahsarawakmoving:
        rate['east_single'] = str(i.single)
        rate['east_married'] = str(i.married)
    
    return json.dumps(rate)