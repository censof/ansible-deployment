from rest_framework import viewsets
from .serializers import (
    HouseMovingClaimSerializer, HouseMovingClaimDraftSerializer)
from ..models import HouseMovingClaim, HouseMovingClaimDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'HouseMovingClaimViewSet',
    'HouseMovingClaimDraftViewSet'
    ]


class HouseMovingClaimViewSet(viewsets.ModelViewSet):
    serializer_class = HouseMovingClaimSerializer
    queryset = HouseMovingClaim.objects.all()


class HouseMovingClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = HouseMovingClaimDraftSerializer
    queryset = HouseMovingClaimDraft.objects.all()
