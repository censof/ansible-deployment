from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import HouseMovingClaim, HouseMovingClaimDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'HouseMovingClaimSerializer',
    'HouseMovingClaimDraftSerializer'
    ]


class HouseMovingClaimSerializer(BaseClaimSerializer):
    class Meta:
        model = HouseMovingClaim


class HouseMovingClaimDraftSerializer(serializers.ModelSerializer):
    class Meta:
        model = HouseMovingClaimDraft
        fields = '__all__'
