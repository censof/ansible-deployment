from decimal import *
from django.db import models
from django.core.urlresolvers import reverse_lazy
from eclaim.claim.models import ClaimType
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import FundType, REGION_LIST
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.common import CLAIM_STATUS

#claim_type pk for House Moving Claim is 11
HOUSE_MOVING_CLAIM_TYPE = 11


class HouseMovingAbstract(BaseModel):
    status = models.CharField(max_length=CLAIM_STATUS.DEFAULT_LENGTH)
    contact_no = models.CharField(max_length=25, null=True)
    moving_date = models.DateField()
    marital_status = models.CharField(max_length=1, null=True)
    government_loan = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType, null=True, blank=True)
    project_code = models.CharField(max_length=10, null=True)
    destination = models.CharField(max_length=30, choices=REGION_LIST)
    old_address_1 = models.TextField()
    old_address_2 = models.TextField()
    old_address_3 = models.TextField()
    old_address_4 = models.TextField()
    new_address_1 = models.TextField()
    new_address_2 = models.TextField()
    new_address_3 = models.TextField()
    new_address_4 = models.TextField()
    rate = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    grand_total = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    endowment = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    net_total = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    apply_date = models.DateField()

    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=HOUSE_MOVING_CLAIM_TYPE)

    class Meta:
        app_label = 'housemoving'
        abstract = True


class HouseMovingClaim(HouseMovingAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    class Meta(HouseMovingAbstract.Meta):
        app_label = 'housemoving'
        verbose_name = 'House Moving Claim'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('housemoving_detail'), self.pk)


class HouseMovingClaimDraft(HouseMovingAbstract):

    class Meta(HouseMovingAbstract.Meta):
        app_label = 'housemoving'
        verbose_name = 'House Moving Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('housemoving_draft', args=[self.pk])
