from django.conf.urls import patterns, url

from .views import HouseMovingIndexView, HouseMovingDetailView, HouseMovingDraftView

urlpatterns = patterns('',
    url(r'^housemoving/$', HouseMovingIndexView.as_view(), name='housemoving_index'),
    url(r'^housemoving/detail/$', HouseMovingDetailView.as_view(), name='housemoving_detail'),
    url(r'^housemoving/draft/(?P<draft_id>[0-9]+)/$', HouseMovingDraftView.as_view(), name='housemoving_draft')
)