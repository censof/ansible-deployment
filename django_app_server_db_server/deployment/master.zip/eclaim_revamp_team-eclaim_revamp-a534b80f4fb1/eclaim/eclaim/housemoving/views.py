import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text
from django.contrib.contenttypes.models import ContentType

from eclaim.auth.authenticate import Authenticate
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import ClaimDetailView, ClaimIndexView
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.utils import get_document_list, get_document_list_item, \
                                     get_document_list_item_draft

from eclaim.utils.common import get_claim_type_code, get_claim_type_prefix, \
                                get_json_from_set_obj, get_json_from_list

from .models import (
    HOUSE_MOVING_CLAIM_TYPE, HouseMovingClaim, HouseMovingClaimDraft)
from .entitlement import get_house_moving_rate
from .processes import house_moving_claim_process

__ClaimType__ = get_claim_type_code(HOUSE_MOVING_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(HOUSE_MOVING_CLAIM_TYPE)


class HouseMovingIndexView(ClaimIndexView):
    """
    This is index page for House Moving Claims.
    """
    template_name = 'housemoving/house_moving_claim.html'
    claim_type = ClaimType.get_claim_type(11)
    validate_form_by_name = 'house_moving_claim_form'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(HouseMovingIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None
            rate_entitled = None

        if claimant:
            rate_entitled = get_house_moving_rate(claimant.grade_level_category.code, claimant.basic_salary)

        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['json_rate'] = rate_entitled
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = house_moving_claim_process(
            btn_mode, form_data, request.user)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, HouseMovingClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, HouseMovingClaim,
                                             claim_id, new_claim=True)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")

class HouseMovingDetailView(ClaimDetailView):
    """
    This is detail view for House Moving Claims.
    """
    model = HouseMovingClaim
    claim_type = ClaimType.get_claim_type(11)
    template_name = 'housemoving/house_moving_claim.html'
    submit_success_url = reverse_lazy('claim_list')
    validate_form_by_name = 'house_moving_claim_form'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(HouseMovingDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None
            rate_entitled = None

        if claimant:
            rate_entitled = get_house_moving_rate(claimant.grade_level_category.code, claimant.basic_salary)

        ctx['claimant'] = claimant
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['json_rate'] = rate_entitled
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)

        obj_pk = self.request.GET['pk']
        claim = HouseMovingClaim.objects.get(pk=obj_pk)
        doclist = get_document_list_item(claim.claim_no, __ClaimType__)
        document_list = get_json_from_set_obj(doclist)

        ctx['claim_no'] = claim.claim_no
        ctx['json_documentlist'] = document_list

        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = house_moving_claim_process(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, HouseMovingClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, HouseMovingClaim, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")

class HouseMovingDraftView(TemplateView):
    template_name = 'housemoving/house_moving_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(HouseMovingDraftView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        context = super(HouseMovingDraftView, self).get_context_data(**kwargs)
        draft_id = self.kwargs['draft_id']

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None
            rate_entitled = None

        if claimant:
            rate_entitled = get_house_moving_rate(claimant.grade_level_category.code, claimant.basic_salary)

        context['claimant'] = claimant
        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        context['json_rate'] = rate_entitled
        context['DOC_LIST'] = get_document_list(__ClaimType__)

        draft = HouseMovingClaimDraft.objects.get(id=int(draft_id))
        document_list = get_json_from_set_obj(get_document_list_item_draft(draft.id, __ClaimType__))

        context['draft_id'] = draft.id
        context['json_documentlist'] = document_list

        return context

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = house_moving_claim_process(
            btn_mode, form_data, request.user)

        response_data = {'errors': False, 'draft_id':draft_id, 'claim_id':claim_id, 'submit_success_url': force_text(self.submit_success_url)}
        return HttpResponse(json.dumps(response_data), content_type="application/json")
