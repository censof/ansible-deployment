/* Author : Hawa
   Date	: December 2015 */

console.log('House Moving Claim JS Loaded!!!');

uiBootstrapApp.controller('HouseMovingClaimCtrl', function ($scope, $sce, $http, $log, $filter, DataMain, DataEndowment, DataFundType) {

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;

    $scope.panel1 = {
        open: false
    };

    $scope.panel2 = {
        open: false
    };

    $scope.panel3 = {
        open: true
    };

    $scope.panel4 = {
        open: false
    };

    $scope.panel5 = {
        open: false
    };

    $scope.panel6 = {
        open: false
    };

	$scope.panel7 = {
        open: false
    };

	$scope.panel8 = {
        open: false
    };

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel1.open = true;
        $scope.panel2.open = true;
        $scope.panel3.open = true;
        $scope.panel4.open = true;
        $scope.panel5.open = true;
        $scope.panel6.open = true;
		$scope.panel7.open = true;
		$scope.panel8.open = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel1.open = false;
        $scope.panel2.open = false;
        $scope.panel3.open = false;
        $scope.panel4.open = false;
        $scope.panel5.open = false;
        $scope.panel6.open = false;
		$scope.panel7.open = false;
		$scope.panel8.open = false;
    };
    /*************** Accordion End ***************/

	/*************** Initial Variable Start ***************/
	$scope.error_validation = false;
	$scope.claimant_no = '';
	$scope.draft_id = '';
	$scope.claim_no = '';
	$scope.object_pk = PK;
    $scope.showLectureForm = true;
    $scope.url_query_pdf = '';
    $scope.expenses = [];
    $scope.claimAmountSummary = '0.00';
    $scope.fundTypeSummary = '';
    /*************** Initial Variable End ***************/

	$scope.initClaimantNo = function (claimant_no) {
		$scope.claimant_no = claimant_no;
		changeItemVal('claimant_no');
	};

	var changeItemVal = function(obj) {
		if (obj == 'claimant_no') {
            DataMain.setClaimantNo($scope.claimant_no);
        }
    };

    var claim_api_url = API_URL+'house-moving-claims/';

    if (PK) {  // detail view
        $http({
            url: claim_api_url+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, $sce, 11, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, $sce, 11, 1);
    }

    init_workflow($scope, $http, 'housemoving', 'HouseMovingClaim', PK, claim_api_url, WF_TEMPLATE);

    /* Summary */
    $http({
        url: API_URL+'expenses/',
        method: 'GET',
        params: {'claim_code': 'HM'}
    })
    .success(function (data, status, headers, config) {
        $scope.expenses = angular.copy(data.results);
    });

    $scope.$watch(function () { return DataEndowment.getClaimAmount(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.claimAmountSummary = get2Float(newValue);
        }
    });
    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.fundTypeSummary = newValue.description;
        }
    });
});

uiBootstrapApp.controller('HouseMovingFormCtrl', function($http, $scope, $filter, $q, DataFundType, DataLookup, DataRates, DataHouseMovingForm, DataEndowment){

	$scope.initHouseMovingFormCtrl = function (jsonDestinationList, marital_status, draftID) {
        $scope.destinationTypes = [];
		$scope.destinationType = {};
        $scope.regionList = [];

        if (draftID) {
            console.log('Load draft items for Draft [',draftID,']');
            $http({
                url: API_URL+'house-moving-claim-drafts/'+draftID+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $q.all(promises).then(function (resolutions) {
                    $scope.contactNo = data.contact_no;
                    changeItemVal('contactNo');
                    $scope.movingDate = data.moving_date;
                    DataHouseMovingForm.setMovingDate($scope.movingDate);
                    $scope.governmentLoan = data.government_loan;
                    changeItemVal('governmentLoan');
                    $scope.oldAddress1 = data.old_address_1;
                    changeItemVal('oldAddress1');
                    $scope.oldAddress2 = data.old_address_2;
                    changeItemVal('oldAddress2');
                    $scope.oldAddress3 = data.old_address_3;
                    changeItemVal('oldAddress3');
                    $scope.oldAddress4 = data.old_address_4;
                    changeItemVal('oldAddress4');
                    $scope.newAddress1 = data.new_address_1;
                    changeItemVal('newAddress1');
                    $scope.newAddress2 = data.new_address_2;
                    changeItemVal('newAddress2');
                    $scope.newAddress3 = data.new_address_3;
                    changeItemVal('newAddress3');
                    $scope.newAddress4 = data.new_address_4;
                    changeItemVal('newAddress4');
                    $scope.maritalStatus = { status: data.marital_status };
                    changeItemVal('maritalStatus');
                    $scope.destinationType = $scope.getRegionByCode(data.destination, resolutions.region.data);
                    DataFundType.setFundType(DataFundType.getFundTypeByCode(data.fund_type));
                    if (data.project_code) {
                        $scope.projectCode = data.project_code;
                        changeItemVal('houseMovingProjectCode');
                    }
                    DataEndowment.setEndowmentAmount(data.endowment);
                });
            });
        };

        // getAngularObjFromJson(jsonDestinationList).forEach(function (obj) {
        //     var val = obj['code'];
        //     var txt = obj['description'];
        //     $scope.destinationTypes.push({value:val, label:txt});
        // });

		if (marital_status == 'True') {
            $scope.maritalStatus = {
				status:'m'
			};
        }
		else {
			$scope.maritalStatus = {
				status:'s'
			};
		}
		changeItemVal('maritalStatus');

		$scope.claimRate = DataHouseMovingForm.getClaimRate();

        var promises = {
            region: $http({
                    url: '/eclaim/masterfiles/region-list/',
                    method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    $scope.regionList = data;
                }),
            fund_type: $http({
                    url: API_URL+'fund-type/',
                    method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    $scope.FundTypes = data.results;
                })
        }

        $scope.getRegionByCode = function (code, region_list) {
            var objSelect = $filter("filter")(region_list, { code: code });
            return objSelect[0];
        };

        if (PK) {  // detail view
            $http({
                url: API_URL+'house-moving-claims/'+PK+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $q.all(promises).then(function (resolutions) {
                    $scope.contactNo = data.contact_no;
                    changeItemVal('contactNo');
                    $scope.movingDate = data.moving_date;
                    DataHouseMovingForm.setMovingDate($scope.movingDate);
                    $scope.governmentLoan = data.government_loan;
                    changeItemVal('governmentLoan');
                    $scope.oldAddress1 = data.old_address_1;
                    changeItemVal('oldAddress1');
                    $scope.oldAddress2 = data.old_address_2;
                    changeItemVal('oldAddress2');
                    $scope.oldAddress3 = data.old_address_3;
                    changeItemVal('oldAddress3');
                    $scope.oldAddress4 = data.old_address_4;
                    changeItemVal('oldAddress4');
                    $scope.newAddress1 = data.new_address_1;
                    changeItemVal('newAddress1');
                    $scope.newAddress2 = data.new_address_2;
                    changeItemVal('newAddress2');
                    $scope.newAddress3 = data.new_address_3;
                    changeItemVal('newAddress3');
                    $scope.newAddress4 = data.new_address_4;
                    changeItemVal('newAddress4');
                    $scope.maritalStatus = { status: data.marital_status };
                    changeItemVal('maritalStatus');
                    $scope.destinationType = $scope.getRegionByCode(data.destination, resolutions.region.data);
                    DataFundType.setFundType(DataFundType.getFundTypeByCode(data.fund_type));
                    if (data.project_code) {
                        $scope.projectCode = data.project_code;
                        changeItemVal('houseMovingProjectCode');
                    }
                    DataEndowment.setEndowmentAmount(data.endowment);
                });
            });
        }
    };

	$scope.initOldAddress1 = function (address1) {
		$scope.oldAddress1 = address1;
		changeItemVal('oldAddress1');
	};

	$scope.initOldAddress2 = function (address2) {
		$scope.oldAddress2 = address2;
		changeItemVal('oldAddress2');
	};

	$scope.initOldAddress3 = function (address3) {
		$scope.oldAddress3 = address3;
		changeItemVal('oldAddress3');
	};

	$scope.initOldAddress4 = function (address4) {
		$scope.oldAddress4 = address4;
		changeItemVal('oldAddress4');
	};

	var changeItemVal = function(obj) {
		if (obj == 'contactNo') {
            DataHouseMovingForm.setContactNo($scope.contactNo);
        }
		else if (obj == 'movingDate') {
			$scope.movingDate = DataHouseMovingForm.getMovingDate();
			$scope.movingDateTxt = DataHouseMovingForm.getMovingDateTxt();
		}
		else if (obj == 'governmentLoan') {
            DataHouseMovingForm.setGovernmentLoan($scope.governmentLoan);
        }
		else if (obj == 'maritalStatus') {
            DataHouseMovingForm.setMaritalStatus($scope.maritalStatus);
        }
		else if (obj == 'houseMovingFundType') {
            DataHouseMovingForm.setHouseMovingFundType(DataFundType.getFundType());
        }
		else if (obj == 'houseMovingProjectCode') {
            DataHouseMovingForm.setHouseMovingProjectCode(DataLookup.getProjectCode());
        }
		else if (obj == 'destinationType') {
            DataHouseMovingForm.setDestinationType($scope.destinationType);
        }
		else if (obj == 'oldAddress1') {
            DataHouseMovingForm.setOldAddress1($scope.oldAddress1);
        }
		else if (obj == 'oldAddress2') {
            DataHouseMovingForm.setOldAddress2($scope.oldAddress2);
        }
		else if (obj == 'oldAddress3') {
            DataHouseMovingForm.setOldAddress3($scope.oldAddress3);
        }
		else if (obj == 'oldAddress4') {
            DataHouseMovingForm.setOldAddress4($scope.oldAddress4);
        }
		else if (obj == 'newAddress1') {
            DataHouseMovingForm.setNewAddress1($scope.newAddress1);
        }
		else if (obj == 'newAddress2') {
            DataHouseMovingForm.setNewAddress2($scope.newAddress2);
        }
		else if (obj == 'newAddress3') {
            DataHouseMovingForm.setNewAddress3($scope.newAddress3);
        }
		else if (obj == 'newAddress4') {
            DataHouseMovingForm.setNewAddress4($scope.newAddress4);
        }
		else if (obj == 'claimRate') {
            DataHouseMovingForm.setClaimRate($scope.claimRate);
			DataEndowment.setClaimAmount(DataHouseMovingForm.getClaimRate());
        }
		else if (obj == 'endowmentAmount') {
            DataHouseMovingForm.setEndowmentAmount(DataEndowment.getEndowmentAmount());
        }
		else if (obj == 'netTotal') {
            DataHouseMovingForm.setNetTotal(DataEndowment.getNetTotal());
        }
    };

	$scope.$watch('contactNo', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('contactNo');
			$scope.contactNo = DataHouseMovingForm.getContactNo();
		}
	});

    $scope.$watch(function () { return DataHouseMovingForm.getMovingDate(); }, function (newValue, oldValue) {
        changeItemVal('movingDate');
    });

	$scope.checkGovernmentLoan = function() {
        $scope.governmentLoan = !!$scope.governmentLoan;
        changeItemVal('governmentLoan');
    };

	$scope.changeMaritalStatus = function () {
		changeItemVal('maritalStatus');
		var houseMovingRate = 0;
		var status = $scope.maritalStatus.status;

		if (status == 'm' || status == 'o') {
			if ($scope.destinationType) {
				var destination = $scope.destinationType.code;
				if (destination=='West') {
					houseMovingRate = DataRates.getWestMarriedRate();
				}else if (destination=='East') {
					houseMovingRate = DataRates.getEastMarriedRate();
				}
			}
		}
		else
		{
			if ($scope.destinationType) {
				var destination = $scope.destinationType.code;
				if (destination=='West') {
					houseMovingRate = DataRates.getWestSingleRate();
				}else if (destination=='East') {
					houseMovingRate = DataRates.getEastSingleRate();
				}
			}
		}

		DataRates.setSelectedRate(get2Float(houseMovingRate));
		$scope.claimRate = DataRates.getSelectedRate();
		changeItemVal('claimRate');
    }

	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('houseMovingFundType');
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('houseMovingProjectCode');
    });

	$scope.$watch('destinationType', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('destinationType');
            var houseMovingRate = 0;
            if ($scope.destinationType) {
				var status = $scope.maritalStatus.status;
                var destination = $scope.destinationType.code;

				if (status == 'm' || status == 'o') {
                    if (destination=='West') {
						houseMovingRate = DataRates.getWestMarriedRate();
					}else if (destination=='East') {
						houseMovingRate = DataRates.getEastMarriedRate();
					}
                }
				else
				{
					if (destination=='West') {
						houseMovingRate = DataRates.getWestSingleRate();
					}else if (destination=='East') {
						houseMovingRate = DataRates.getEastSingleRate();
					}
				}

            }

            DataRates.setSelectedRate(get2Float(houseMovingRate));
			$scope.claimRate = DataRates.getSelectedRate();
			changeItemVal('claimRate');
        }
    });

	$scope.$watch('oldAddress1', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldAddress1');
			$scope.oldAddress1 = DataHouseMovingForm.getOldAddress1();
		}
	});

	$scope.$watch('oldAddress2', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldAddress2');
			$scope.oldAddress2 = DataHouseMovingForm.getOldAddress2();
		}
	});

	$scope.$watch('oldAddress3', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldAddress3');
			$scope.oldAddress3 = DataHouseMovingForm.getOldAddress3();
		}
	});

	$scope.$watch('oldAddress4', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldAddress4');
			$scope.oldAddress4 = DataHouseMovingForm.getOldAddress4();
		}
	});

	$scope.$watch('newAddress1', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newAddress1');
			$scope.newAddress1 = DataHouseMovingForm.getNewAddress1();
		}
	});

	$scope.$watch('newAddress2', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newAddress2');
			$scope.newAddress2 = DataHouseMovingForm.getNewAddress2();
		}
	});

	$scope.$watch('newAddress3', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newAddress3');
			$scope.newAddress3 = DataHouseMovingForm.getNewAddress3();
		}
	});

	$scope.$watch('newAddress4', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newAddress4');
			$scope.newAddress4 = DataHouseMovingForm.getNewAddress4();
		}
	});

	$scope.$watch('claimRate', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('claimRate');
			$scope.claimRate = DataHouseMovingForm.getClaimRate();
		}
	});

	$scope.$watch(function () { return DataEndowment.getEndowmentAmount(); }, function (newValue, oldValue) {
        changeItemVal('endowmentAmount');
    });

	$scope.$watch(function () { return DataEndowment.getNetTotal(); }, function (newValue, oldValue) {
        changeItemVal('netTotal');
    });

});

uiBootstrapApp.controller('RatesCtrl', function ($scope, $log, DataRates) {
	$scope.west_single = 0;
	$scope.west_married = 0;
	$scope.east_single = 0;
	$scope.east_married = 0;

	$scope.initRatesCtrl = function(json_rate){
		if (json_rate) {
			console.log('Load Init RatesCtrl (Django Obj)');
			var angular_rates = getAngularObjFromJson(json_rate);
			var west_single = angular_rates.west_single;
			var west_married = angular_rates.west_married;
			var east_single = angular_rates.east_single;
			var east_married = angular_rates.east_married;

			$scope.west_single = west_single;
			$scope.west_married = west_married;
			$scope.east_single = east_single;
			$scope.east_married = east_married;
			DataRates.setWestSingleRate(west_single);
			DataRates.setWestMarriedRate(west_married);
			DataRates.setEastSingleRate(east_single);
			DataRates.setEastMarriedRate(east_married);
		}
	};
});

uiBootstrapApp.controller('DateCtrl', function ($scope, $filter, DataHouseMovingForm) {

    /*************** DatePicker Start ***************/
    $scope.today = function() {
        $scope.movingDate = new Date();
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.setDate = function(year, month, day) {
        $scope.movingDate = new Date(year, month, day);
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.status = {
        opened: false
    };

    $scope.dateChanged = function(){
		DataHouseMovingForm.setMovingDate($scope.movingDate);
    };

	$scope.$watch(function () { return DataHouseMovingForm.getMovingDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.movingDate = newValue;
        }
    });

    /*************** DatePicker End ***************/
});


uiBootstrapApp.factory('DataMain', function ($filter) {
	var data = {
			error_validation:'',
			claimant_no:'',
			draft_id:'',
			claim_id:'',
            RegionDestinations: '',
		};
	return {
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (obj) {
            data.error_validation = obj;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        },
        setRegionDestinations: function(obj){
            data.RegionDestinations = obj;
        },
        getRegionDestinationByCode: function(code){
            var selected = {};
            data.RegionDestinations.forEach(function(obj){
                if (obj.code == code) {
                    selected = obj;
                }
            });
            return selected;
        }
	};
});

uiBootstrapApp.factory('DataRates', function (){
	var data = {
		WestSingleRate : 0,
		WestMarriedRate : 0,
		EastSingleRate : 0,
		EastMarriedRate : 0,
		SelectedRate : 0
	};

	return {
		getWestSingleRate : function(){
			return data.WestSingleRate;
		},
		setWestSingleRate : function(val){
			return data.WestSingleRate = val;
		},
		getWestMarriedRate : function(){
			return data.WestMarriedRate;
		},
		setWestMarriedRate : function(val){
			return data.WestMarriedRate = val;
		},
		getEastSingleRate : function(){
			return data.EastSingleRate;
		},
		setEastSingleRate : function(val){
			return data.EastSingleRate = val;
		},
		getEastMarriedRate : function(){
			return data.EastMarriedRate;
		},
		setEastMarriedRate : function(val){
			return data.EastMarriedRate = val;
		},
		getSelectedRate : function(){
			return data.SelectedRate;
		},
		setSelectedRate : function(val){
			return data.SelectedRate = val;
		}
	};
});

uiBootstrapApp.factory('DataHouseMovingForm', function ($filter) {
	var data = {
			contactNo:'',
			movingDate:'',
			movingDateTxt:'-',
			governmentLoan:false,
			maritalStatus:'',
			houseMovingFundType:'',
			houseMovingProjectCode:'',
			destinationType:'',
			oldAddress1:'',
			oldAddress2:'',
			oldAddress3:'',
			oldAddress4:'',
			newAddress1:'',
			newAddress2:'',
			newAddress3:'',
			newAddress4:'',
			claimRate:'0.00',
			endowmentAmount:'0.00',
			netTotal:'0.00'
		};
	return {
		getContactNo: function () {
            return data.contactNo;
        },
        setContactNo: function (obj) {
            data.contactNo = obj;
        },
		getMovingDate: function () {
            return data.movingDate;
        },
        setMovingDate: function (obj) {
            data.movingDate = obj;
        },
		getMovingDateTxt: function () {
            return data.movingDateTxt;
        },
        setMovingDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.movingDate = obj;
            data.movingDateTxt = minDate;
        },
		getGovernmentLoan: function () {
            return data.governmentLoan;
        },
        setGovernmentLoan: function (obj) {
            data.governmentLoan = obj;
        },
		getMaritalStatus: function () {
            return data.maritalStatus.status;
        },
        setMaritalStatus: function (obj) {
            data.maritalStatus = obj;
        },
		getHouseMovingFundType: function () {
            return data.houseMovingFundType;
        },
        setHouseMovingFundType: function (obj) {
            data.houseMovingFundType = obj;
        },
		getHouseMovingProjectCode: function () {
            return data.houseMovingProjectCode;
        },
        setHouseMovingProjectCode: function (obj) {
            data.houseMovingProjectCode = obj;
        },
		getDestinationType: function () {
            return data.destinationType;
        },
        setDestinationType: function (obj) {
            data.destinationType = obj;
        },
		getOldAddress1: function () {
            return data.oldAddress1;
        },
        setOldAddress1: function (obj) {
            data.oldAddress1 = obj;
        },
		getOldAddress2: function () {
            return data.oldAddress2;
        },
        setOldAddress2: function (obj) {
            data.oldAddress2 = obj;
        },
		getOldAddress3: function () {
            return data.oldAddress3;
        },
        setOldAddress3: function (obj) {
            data.oldAddress3 = obj;
        },
		getOldAddress4: function () {
            return data.oldAddress4;
        },
        setOldAddress4: function (obj) {
            data.oldAddress4 = obj;
        },
		getNewAddress1: function () {
            return data.newAddress1;
        },
        setNewAddress1: function (obj) {
            data.newAddress1 = obj;
        },
		getNewAddress2: function () {
            return data.newAddress2;
        },
        setNewAddress2: function (obj) {
            data.newAddress2 = obj;
        },
		getNewAddress3: function () {
            return data.newAddress3;
        },
        setNewAddress3: function (obj) {
            data.newAddress3 = obj;
        },
		getNewAddress4: function () {
            return data.newAddress4;
        },
        setNewAddress4: function (obj) {
            data.newAddress4 = obj;
        },
		getClaimRate: function () {
            return data.claimRate;
        },
        setClaimRate: function (obj) {
            data.claimRate = obj;
        },
		getEndowmentAmount: function () {
            return data.endowmentAmount;
        },
        setEndowmentAmount: function (obj) {
            data.endowmentAmount = obj;
        },
		getNetTotal: function () {
            return data.netTotal;
        },
        setNetTotal: function (obj) {
            data.netTotal = obj;
        }
	};
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataMain', 'DataHouseMovingForm', function ($scope, $uibModal, $http, $window, DataMain, DataHouseMovingForm) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);

		form_data = {
			btn_mode:btnMode,
			contactNo:DataHouseMovingForm.getContactNo(),
			movingDate:DataHouseMovingForm.getMovingDate(),
			movingDateTxt:DataHouseMovingForm.getMovingDateTxt(),
			governmentLoan:DataHouseMovingForm.getGovernmentLoan(),
			maritalStatus:DataHouseMovingForm.getMaritalStatus(),
			houseMovingFundType:DataHouseMovingForm.getHouseMovingFundType(),
			houseMovingProjectCode:DataHouseMovingForm.getHouseMovingProjectCode(),
			destinationType:DataHouseMovingForm.getDestinationType(),
			oldAddress1:DataHouseMovingForm.getOldAddress1(),
			oldAddress2:DataHouseMovingForm.getOldAddress2(),
			oldAddress3:DataHouseMovingForm.getOldAddress3(),
			oldAddress4:DataHouseMovingForm.getOldAddress4(),
			newAddress1:DataHouseMovingForm.getNewAddress1(),
			newAddress2:DataHouseMovingForm.getNewAddress2(),
			newAddress3:DataHouseMovingForm.getNewAddress3(),
			newAddress4:DataHouseMovingForm.getNewAddress4(),
            claimRate:get2Float(DataHouseMovingForm.getClaimRate()),
			grandTotal:get2Float(DataHouseMovingForm.getClaimRate()),
			endowmentAmount:get2Float(DataHouseMovingForm.getEndowmentAmount()),
			netTotal:get2Float(DataHouseMovingForm.getNetTotal()),
			claimant_no:DataMain.getClaimantNo(),
			draft_id:DataMain.getDraftID(),
			document_list:[]
		}

		if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

				if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                }
				else
				{
					$http({
						url: '',
						method: 'POST',
						data: form_data
					})
					.success(function (data, status, headers, config) {
                        enable_claim_controls();
						var submit_success_url = data.submit_success_url;

						if (btnMode == 'submit') {
							$window.location.href = submit_success_url;
						} else if (btnMode == 'save_draft') {
							$scope.initSubmitCtrl(data.draft_id);
							$uibModal.open({
								animation: $scope.animationsEnabled,
								templateUrl: 'SaveSuccess.html',
								controller: 'ModalInstanceInfoCtrl',
								size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
								resolve: {
								  data: function () {
									return data;
								  }
								}
							});
                            $window.location.href = submit_success_url;
						}
					}).error(function () {
                        enable_claim_controls();
                    });
				}
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id){
		$scope.draft_id = draft_id;
		DataMain.setDraftID(draft_id);
	};
}]);
