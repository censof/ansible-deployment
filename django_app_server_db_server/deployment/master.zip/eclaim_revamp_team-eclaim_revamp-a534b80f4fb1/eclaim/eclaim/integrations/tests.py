import json
from django.test import TestCase
from mock import call, patch
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.integrations.ajax import get_account_type_list
from eclaim.integrations.utils import (generate_gl,
                                       get_default_shape,
                                       process_gl_distribution,
                                       get_gl_shape)


class IntegrationUtilsTests(TestCase):
    fixtures = [
        'level_db2.json',
        'company_level_db2.json',
        'user.json',
        'claimant_db2.json'
    ]

    @patch('eclaim.integrations.utils.ClaimantHistory', autospec=True)
    @patch('eclaim.integrations.utils.Claimant', autospec=True)
    @patch('eclaim.integrations.utils.get_gl_shape')
    def test_generate_gl(self, mock_get_gl_shape, mock_Claimant, mock_ClaimantHistory):

        class MockDict(dict):
            def __init__(self, *args, **kwargs):
                super(MockDict, self).__init__(*args, **kwargs)
                self.__dict__ = self
        data = MockDict()
        data["staff_no"] = 1
        mock_ClaimantHistory.objects.get.return_value = data
        mock_Claimant.objects.get.return_value.company_levels.all.return_value = 'abc'
        result = generate_gl(1234, 1, 'type', 1234)
        self.assertEqual(mock_get_gl_shape.call_args,
                         call('abc', 'type', 1234))
        self.assertTrue(mock_get_gl_shape.called)
        self.assertTrue(1234 in mock_get_gl_shape.call_args[0])

    def test_get_default_shape(self):
        result = get_default_shape("ho", 5)
        self.assertEqual(result, "hohohohoho")

    @patch('eclaim.integrations.utils.GLTransaction', autospec=True)
    @patch('eclaim.integrations.utils.GLDistribution', autospec=True)
    @patch('eclaim.integrations.utils.GLDistributionDetail', autospec=True)
    @patch('eclaim.integrations.utils.generate_gl')
    def test_process_gl_distribution(self, mock_generate_gl, mock_GLDistributionDetail, mock_GLDistribution, mock_GLTransaction):
        process_gl_distribution(1234, 1, [{'account_code': 1234,
                                                 'amount': 100,
                                                 'groupedFundType': [{'code': 1234,
                                                                     'amount': 100}]}], 
                                {'header': None,
                                 'details': 'details'})
        self.assertEqual(mock_generate_gl.call_args, call(1234, 1, 1234, 1234))
        self.assertTrue(mock_GLDistributionDetail.return_value.save.called)
        self.assertTrue(mock_GLDistribution.return_value.save.called)
        self.assertTrue(mock_GLDistributionDetail.return_value.save.called)
        process_gl_distribution(1234, 1, [{'account_code': 1234,
                                                 'amount': 100,
                                                 'groupedFundType': [{'code': 1234,
                                                                     'amount': 100}]}], 
                                {'header': [{'expenses_code': 1234,
                                             'grand_total': 1000}],
                                 'details': [{'gl_account': 'gl_account',
                                              'amount': 100}]})
        self.assertEqual(mock_GLDistributionDetail.return_value.gl_account, 'gl_account')
        self.assertEqual(mock_GLDistributionDetail.return_value.amount, 100)
        self.assertTrue(mock_GLDistributionDetail.return_value.save.called)

    @patch('eclaim.integrations.utils.GLShape', autospec=True)
    def test_get_gl_shape(self, mock_GLShape):
        class MockDict(dict):
            def __init__(self, *args, **kwargs):
                super(MockDict, self).__init__(*args, **kwargs)
                self.__dict__ = self
        data = MockDict()
        data['source'] = 'FORM_TYPE'
        data['length'] = 10
        data['start_from_char'] = 5
        data['form_type'] = 'fund'
        data['settings_level_id'] = 1
        mock_GLShape.objects.all.return_value = [data]
        result = get_gl_shape(None, 'fund_type', 1234)
        self.assertEqual(result, 'X' * data['length'])

        data2 = MockDict()
        data2['source'] = 'COMPANY_LEVEL'
        data2['length'] = 10
        data2['start_from_char'] = 5
        data2['form_type'] = 'fund'
        data2['settings_level_id'] = 1
        mock_GLShape.objects.all.return_value = [data2]
        result = get_gl_shape(None, 'fund_type', 1234)
        self.assertEqual(result, 'X'*data2['length'])

        claimant = Claimant.objects.get(pk='A0007031')
        c_levels = claimant.company_levels.all()

        data3 = MockDict()
        data3['source'] = 'COMPANY_LEVEL'
        data3['length'] = 5
        data3['start_from_char'] = 5
        data3['form_type'] = ''
        data3['settings_level_id'] = 2
        mock_GLShape.objects.all.return_value = [data3]
        result = get_gl_shape(c_levels, '', 1234)
        self.assertEqual(result, 'D03')

        data3 = MockDict()
        data3['source'] = 'COMPANY_LEVEL'
        data3['length'] = 5
        data3['start_from_char'] = 5
        data3['form_type'] = ''
        data3['settings_level_id'] = 2
        mock_GLShape.objects.all.return_value = [data3, data, data3]
        result = get_gl_shape(c_levels, '', 1234)
        self.assertEqual(result, 'D03-XXXXXXXXXX-D03')


class IntegrationsAjaxTests(TestCase):

    def test_get_account_type_list(self):
        target_result = [
            {'code': 'GL', 'description': 'GL'},
            {'code': 'PC', 'description': 'PC'}
        ]
        result = get_account_type_list('')
        self.assertEqual(result.content, json.dumps(target_result))
