from rest_framework import viewsets

from eclaim.integrations.models import (GLTransaction, GLDistribution,
                                        GLDistributionDetail)
from .serializers import (GLTransactionSerializer, GLDistributionSerializer,
                          GLDistributionDetailSerializer)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'GLTransactionViewSet',
    'GLDistributionViewSet',
    'GLDistributionDetailViewSet'
    ]


class GLTransactionViewSet(viewsets.ModelViewSet):
    serializer_class = GLTransactionSerializer
    queryset = GLTransaction.objects.all()

    def get_queryset(self):
        qs = self.queryset
        claim_type = self.request.GET.get('claim_type')
        claim_id = self.request.GET.get('claim_id')

        if claim_type and claim_id:
            qs = qs.filter(claim_type=claim_type)
            if claim_id:
                qs = [qs.filter(claim_id=claim_id).latest()]
        return qs


class GLDistributionViewSet(viewsets.ModelViewSet):
    serializer_class = GLDistributionSerializer
    queryset = GLDistribution.objects.all()


class GLDistributionDetailViewSet(viewsets.ModelViewSet):
    serializer_class = GLDistributionDetailSerializer
    queryset = GLDistributionDetail.objects.all()
