from rest_framework import serializers

from ..models import GLTransaction, GLDistribution, GLDistributionDetail

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'GLTransactionSerializer',
    'GLDistributionSerializer',
    'GLDistributionDetailSerializer'
    ]


class GLTransactionSerializer(serializers.ModelSerializer):
    gl_distributions = serializers.SerializerMethodField()
    gl_distributions_detail = serializers.SerializerMethodField()

    class Meta:
        model = GLTransaction
        fields = ('id', 'claim_type', 'claim_id', 'gl_distributions',
                  'gl_distributions_detail')

    def get_gl_distributions(self, obj):
        gl_distributions = obj.gldistribution_set.all()
        return gl_distributions.values()

    def get_gl_distributions_detail(self, obj):
        gl_distributions = obj.gldistribution_set.all()
        gl_distributions_pk = gl_distributions.values_list('pk', flat=True)
        gl_distributions_detail = GLDistributionDetail.objects.filter(
                                                            gl_distribution__in=
                                                            gl_distributions_pk)
        return gl_distributions_detail.values()


class GLDistributionSerializer(serializers.ModelSerializer):
    class Meta:
        model = GLDistribution
        fields = ('id', 'gl_transaction', 'expenses_code', 'amount')


class GLDistributionDetailSerializer(serializers.ModelSerializer):
    class Meta:
        model = GLDistributionDetail
        fields = ('id', 'gl_distribution', 'gl_account', 'amount')
