uiBootstrapApp.controller('GLDistributionsCtrl', ['$scope', '$http', 'DataGLDistributions',
                                                  function($scope, $http, DataGLDistributions){
    /****************
    *   Accordion   *
    *****************/
    $scope.oneAtATime = false;
    
    $scope.glDistributions = [];
    $scope.glDistributionsDetails = [];
    $scope.account_type = [];
    
    $scope.initLoad = function(draftID, claimID){
        if (draftID || claimID) {
            $http({
                url: '/eclaim/integrations/account-type-list/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.accountTypes = data;
            });
        
            $http({
                url: API_URL+'gl-transactions/',
                method: 'GET',
                params: {'claim_type': 'LTC', 'claim_id': draftID}
            })
            .success(function (data, status, headers, config) {
                $scope.glDistributions = data.results[0].gl_distributions;
                $scope.glDistributions.forEach(function(obj){
                    angular.merge(obj, {grand_total: get2Float(0)})
                });
                $scope.glDistributionsDetails = data.results[0].gl_distributions_detail;
            });
        }
    };
    
    $scope.addItem = function(glDistID, glDistExpensesCode){
        $scope.glDistributionsDetails.push(
            {
                gl_distribution_id: glDistID,
                expenses_code: glDistExpensesCode,
                account_type: $scope.account_type[0],
                gl_account: 'xxx-xxx-xxx-x-' + glDistExpensesCode,
                amount: ''
            }
        );
    };
    
    $scope.deleteItem = function(obj){
        var items = $scope.glDistributionsDetails;
        var index = items.indexOf(obj);
        if (index != -1) {
            items.splice(index, 1);
        }
    };
    
    $scope.lookupGLDistributions = function(obj){
        return $http.get('/eclaim/integrations/lookup-gl-distributions/?glDist='+obj).then(function(data) {
            return data.data;
        });
    };
    
    $scope.onSelect = function($item, $model, $label){
        var bcac_monitorglac = $item.bcac_monitorglac;
        // Can do something later
    };
    
    $scope.$watch('glDistributionsDetails', function(newVal, oldVal){
        // Re-Calculate each gl_list grand_total 
        $scope.glDistributions.forEach(function(glDist){
            var grandTotal = 0;
            var glDistID = glDist.id;
            var glDistCode = glDist.expenses_code;
            
            newVal.forEach(function(detail){
                var parentID = detail.gl_distribution_id;
                var amount = detail.amount;
                
                if (amount && (parentID == glDistID)) {
                    grandTotal += parseFloat(amount);
                    /* To add expenses_code attribute to glDistributionsDetails
                     * use for table filtering */
                    angular.merge(detail, {expenses_code: glDistCode})
                }
            });
            angular.merge(glDist, {grand_total: grandTotal});
        });
        DataGLDistributions.setHeader($scope.glDistributions);
        DataGLDistributions.setDetails(newVal);
    }, true);
}]);

uiBootstrapApp.factory('DataGLDistributions', function(){
    var data = {
        Header: [],
        Details: []  
    };
    
    return {
        getHeader: function(){
            return data.Header;
        },
        setHeader: function(obj){
            data.Header = obj;
        },
        getDetails: function(){
            return data.Details;
        },
        setDetails: function(obj){
            data.Details = obj;
        }
    }
});