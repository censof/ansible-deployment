from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from .models import GLShape, GLTransaction, GLDistribution, GLDistributionDetail


def process_gl_distribution(claim_code, claim_id,
                            expenses_summary,
                            gl_distributions):

    gld_header = gl_distributions.get('header')
    gld_details = gl_distributions.get('details')

    # Create new transaction
    gl_transaction = GLTransaction()
    gl_transaction.claim_type = claim_code
    gl_transaction.claim_id = claim_id
    gl_transaction.save()

    if gld_header:
        # Create new distribution details
        for n_gldh in gld_header:
            gld_header = GLDistribution()
            gld_header.gl_transaction = gl_transaction
            gld_header.expenses_code = n_gldh['expenses_code']
            gld_header.amount = n_gldh['grand_total']
            gld_header.save()

            for n_gldd in gld_details:
                gld_detail = GLDistributionDetail()
                gld_detail.gl_distribution = gld_header
                gld_detail.gl_account = n_gldd['gl_account']
                gld_detail.amount = n_gldd['amount']
                gld_detail.save()
    else:
        for expenses in expenses_summary:
            expenses_code = expenses['account_code']
            amount = expenses['amount']
            grouped_fund_types = expenses['groupedFundType']

            gl_dist = GLDistribution()
            gl_dist.gl_transaction = gl_transaction
            gl_dist.expenses_code = expenses_code
            gl_dist.amount = amount
            gl_dist.save()

            for fund_type in grouped_fund_types:
                ft_code = fund_type['code']
                ft_amount = fund_type['amount']

                gl_dist_detail = GLDistributionDetail()
                gl_dist_detail.gl_distribution = gl_dist
                gl_dist_detail.gl_account = generate_gl(claim_code, claim_id,
                                                        ft_code, expenses_code)
                gl_dist_detail.amount = ft_amount
                gl_dist_detail.save()


def generate_gl(claim_code, claim_id, fund_type, expenses_code):
    try:
        claimant_history = ClaimantHistory.objects.get(claim_type=claim_code,
                                                       claim_id=claim_id)
        staff_no = claimant_history.staff_no
        claimant = Claimant.objects.get(staff_no=staff_no)
    except ClaimantHistory.DoesNotExist:
        claimant_history = None

    if claimant_history:
            c_levels = claimant.company_levels.all()
    else:
        c_levels = None
    return get_gl_shape(c_levels, fund_type, expenses_code)


def get_gl_shape(c_levels, fund_type, expenses_code):
    new_gl_shape = ""
    gl_shapes = GLShape.objects.all()
    for gl_shape in gl_shapes:
        length = gl_shape.length
        source = gl_shape.source
        form_type = gl_shape.form_type
        settings_level_id = gl_shape.settings_level_id

        s = get_default_shape('X', length)

        if source == 'FORM_TYPE':
            if form_type == 'FUND':
                s = fund_type[:length]
            elif form_type == 'EXPENSES_CODE':
                s = expenses_code[:length]

        elif source == 'COMPANY_LEVEL':
            if c_levels:
                level_id = c_levels.filter(level_id=settings_level_id)
                if level_id:
                    s = level_id[0].code[:length]
        new_gl_shape += s
        new_gl_shape += "-"
    return new_gl_shape.rstrip("-")


def get_default_shape(s, length):
    if isinstance(s, str) and isinstance(length, int):
        return s * length
