from django.db import models
from django.utils.translation import ugettext_lazy as _
from decimal import Decimal

from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.default_attribute import CLAIM_TYPE_MAX_LENGTH
from eclaim.settings.models import Level


ACCOUNT_TYPE_LIST = (
    ('GL', unicode(_(u'GL'))),
    ('PC', unicode(_(u'PC')))
)

GL_SHAPE_SOURCE_LEVEL = (
    ('FORM_TYPE', unicode(_(u'Form'))),
    ('COMPANY_LEVEL', unicode(_(u'Company Level'))),
)

GL_SHAPE_FORM_TYPE = (
    ('FUND', unicode(_(u'Fund'))),
    ('PROJECT', unicode(_(u'Project'))),
    ('EXPENSES_CODE', unicode(_(u'Expenses Code'))),
)


class GLShape(models.Model):
    start_from_char = models.IntegerField()
    length = models.IntegerField()
    description = models.CharField(max_length=20)
    source = models.CharField(max_length=20, choices=GL_SHAPE_SOURCE_LEVEL)
    form_type = models.CharField(max_length=20, blank=True,
                                 choices=GL_SHAPE_FORM_TYPE)
    settings_level = models.ForeignKey(Level, blank=True, null=True)

    class Meta:
        verbose_name = 'GL Shape'
        ordering = ['start_from_char']


class GLTransaction(BaseModel):
    claim_type = models.CharField(max_length=CLAIM_TYPE_MAX_LENGTH)
    claim_id = models.IntegerField()

    class Meta:
        verbose_name = 'GL Transaction'
        get_latest_by = 'created'


class GLDistribution(models.Model):
    gl_transaction = models.ForeignKey(GLTransaction)
    expenses_code = models.CharField(max_length=50)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        verbose_name = 'GL Distribution'


class GLDistributionDetail(models.Model):
    gl_distribution = models.ForeignKey(GLDistribution)
    gl_account = models.CharField(max_length=100)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        verbose_name = 'GL Distribution Detail'


class Budget(models.Model):
    bcac_account = models.CharField(max_length=100)
    bcac_monitorglac = models.CharField(max_length=100)
    bcac_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    bcac_status = models.CharField(max_length=1)
    bcac_warnflag = models.CharField(max_length=1)

    class Meta:
        verbose_name = 'Budget from SAGA'
