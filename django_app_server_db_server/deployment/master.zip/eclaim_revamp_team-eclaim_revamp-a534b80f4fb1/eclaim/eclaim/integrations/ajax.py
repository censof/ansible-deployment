from django.http import HttpResponse, JsonResponse

from eclaim.utils.common import get_json_from_list
from .models import ACCOUNT_TYPE_LIST, Budget


def get_account_type_list(request):
    return HttpResponse(get_json_from_list(ACCOUNT_TYPE_LIST))


def lookup_gl_distributions(request):
    result = []
    budgets = Budget.objects.filter(bcac_monitorglac__icontains=request.GET['glDist'])
    for budget in budgets:
        result.append({'bcac_monitorglac': budget.bcac_monitorglac})
    return JsonResponse(result, safe=False)