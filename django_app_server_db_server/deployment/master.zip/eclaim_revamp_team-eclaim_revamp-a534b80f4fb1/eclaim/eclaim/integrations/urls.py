from django.conf.urls import patterns, url

urlpatterns = patterns(
    'eclaim.integrations.ajax',

    url(r'^account-type-list/$', 'get_account_type_list',
        name='account_type_list'),
    url(r'^lookup-gl-distributions', 'lookup_gl_distributions',
        name='lookup_gl_distributions')
)
