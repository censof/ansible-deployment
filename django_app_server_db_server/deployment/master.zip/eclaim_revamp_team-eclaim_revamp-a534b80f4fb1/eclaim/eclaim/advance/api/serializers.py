from datetime import datetime
from django.contrib.humanize.templatetags.humanize import intcomma
from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from eclaim.settings.api.serializers import (
    CountrySerializer, CurrencySerializer, FundTypeSerializer)
from eclaim.advance.models import OpenAdvance
from ..models import MiscAdvance, MiscAdvanceDraft, MiscAdvanceItemDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MiscAdvanceSerializer',
    'MiscAdvanceDraftSerializer',
    'MiscAdvanceItemDraftSerializer',
    'OpenAdvanceSerializer'
    ]


class MiscAdvanceSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MiscAdvance
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        def _format_date(date_obj):
            return datetime.strftime(
                date_obj, '%Y-{}-%d'.format(date_obj.month))

        itemlist = []
        for item in obj.miscadvanceitem_set.all():
            _values = {
                'localMiscDateFrom': item.date_from,
                'localMiscDateFromTxt': _format_date(item.date_from),
                'localMiscDateTo': item.date_to,
                'localMiscDateToTxt': _format_date(item.date_to),
                'localMiscFundType': item.fund_type.code,
                'localMiscFundTypeTxt': item.fund_type.description,
                'miscProjectTxt': item.project_code,
                'localMiscPurpose': item.purpose,
                'localMiscReason': item.reason,
                'localMiscItem': item.item,
                'localMiscQuantity': intcomma(item.quantity),
                'localMiscPrice': intcomma(item.price)
                }
            itemlist.append(_values)
        return itemlist


class MiscAdvanceDraftSerializer(serializers.ModelSerializer):
    class Meta:
        model = MiscAdvanceDraft
        fields = ('id', 'status')


class MiscAdvanceItemDraftSerializer(serializers.ModelSerializer):
    fund_type = FundTypeSerializer()
    country = CountrySerializer()
    currency_type = CurrencySerializer()

    class Meta:
        model = MiscAdvanceItemDraft
        fields = ('misc_advance_draft', 'date_from', 'date_to', 'fund_type',
                  'purpose', 'reason', 'item', 'country', 'currency_type',
                  'currency_rate', 'quantity', 'price', 'total', 'grand_total')


class OpenAdvanceSerializer(serializers.ModelSerializer):
    class Meta:
        model = OpenAdvance
        fields = ('advance_id', 'reference_no', 'saga_type', 'advance_amount',
                  'balance_amount', 'allocated_amount', 'status')
