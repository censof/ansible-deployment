from rest_framework import viewsets
from eclaim.advance.models import OpenAdvance
from .serializers import (
    MiscAdvanceSerializer, MiscAdvanceDraftSerializer,
    MiscAdvanceItemDraftSerializer, OpenAdvanceSerializer)
from ..models import MiscAdvance, MiscAdvanceDraft, MiscAdvanceItemDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MiscAdvanceViewSet',
    'MiscAdvanceDraftViewSet',
    'MiscAdvanceItemDraftViewSet',
    'OpenAdvanceViewSet'
    ]


class MiscAdvanceViewSet(viewsets.ModelViewSet):
    serializer_class = MiscAdvanceSerializer
    queryset = MiscAdvance.objects.all()


class MiscAdvanceDraftViewSet(viewsets.ModelViewSet):
    serializer_class = MiscAdvanceDraftSerializer

    def get_queryset(self):
        qs = MiscAdvanceDraft.objects.all()
        draft_id = self.request.GET.get('draft_id')
        if draft_id:
            qs = qs.filter(pk=draft_id)
        return qs


class MiscAdvanceItemDraftViewSet(viewsets.ModelViewSet):
    serializer_class = MiscAdvanceItemDraftSerializer

    def get_queryset(self):
        draft_id = self.request.GET.get('draft_id')
        if draft_id:
            qs = MiscAdvanceItemDraft.objects.all()
            qs = qs.filter(misc_advance_draft__pk=draft_id)
        return qs


class OpenAdvanceViewSet(viewsets.ModelViewSet):
    serializer_class = OpenAdvanceSerializer

    def get_queryset(self):
        qs = OpenAdvance.objects.all()
        # claimant_no = self.request.GET.get('staffNo')
        # if claimant_no:
        #     qs = qs.filter()
        return qs
