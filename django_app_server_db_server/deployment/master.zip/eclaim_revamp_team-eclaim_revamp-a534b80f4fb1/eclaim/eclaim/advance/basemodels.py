from decimal import Decimal
from django.db import models
from django.utils.translation import ugettext_lazy as _
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.libs.models import BaseModel

__all__ = ['BaseMiscAdvance', 'BaseMiscAdvanceItem']


class BaseMiscAdvance(BaseModel):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)
    grand_total = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        abstract = True


class BaseMiscAdvanceItem(BaseModel):
    date_from = models.DateField(_("Date From"))
    date_to = models.DateField(_("Date To"))
    fund_type = models.ForeignKey('masterfiles.FundType', null=True, blank=True, verbose_name=_("Fund Type"))
    project_code = models.CharField(_("Project Code"), max_length=10, blank=True)
    purpose = models.TextField(_("Purpose"))
    reason = models.TextField(_("Reason"))
    item = models.TextField(_("Item"))
    country = models.ForeignKey('settings.Country', null=True, blank=True, verbose_name=_("Country"))
    currency_type = models.ForeignKey('settings.Currency', null=True, blank=True, verbose_name=_("Currency Type"))
    currency_rate = models.DecimalField(_("Currenty Rate"), max_digits=9, decimal_places=6, default=Decimal('0.00'))
    quantity = models.DecimalField(_("Quantity"), max_digits=9, decimal_places=1, default=Decimal('0.0'))
    price = models.DecimalField(_("Price"), max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        abstract = True

    def total(self):
        total = self.quantity * self.price
        if self.currency_type:
            total *= self.currency_rate
        return Decimal('%.2f' % total)
