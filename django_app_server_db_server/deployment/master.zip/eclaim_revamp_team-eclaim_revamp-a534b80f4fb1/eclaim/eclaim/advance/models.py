from decimal import Decimal
from django.db import models
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from .basemodels import BaseMiscAdvance, BaseMiscAdvanceItem


class MiscAdvance(BaseMiscAdvance):
    CLAIM_TYPE = 12

    class Meta:
        app_label = 'advance'
        verbose_name = _("Miscellaneous Advance")
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('miscadvance_detail'), self.pk)


class MiscAdvanceItem(BaseMiscAdvanceItem):
    misc_advance = models.ForeignKey(MiscAdvance, null=True, blank=True)

    class Meta:
        app_label = 'advance'
        verbose_name = _("Miscellaneous Advance Item")
        verbose_name_plural = _("Miscellaneous Advance Items")


class MiscAdvanceDraft(BaseMiscAdvance):
    CLAIM_TYPE = 12

    class Meta:
        app_label = 'advance'
        verbose_name = _("Miscellaneous Advance Draft")
        verbose_name_plural = _("Miscellaneous Advance Drafts")
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('miscadvance_draft', args=[self.pk])


class MiscAdvanceItemDraft(BaseMiscAdvanceItem):
    misc_advance_draft = models.ForeignKey(MiscAdvanceDraft)
    total = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    grand_total = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta:
        app_label = 'advance'
        verbose_name = _("Miscellaneous Advance Item Draft")
        verbose_name_plural = _("Miscellaneous Advance Item Drafts")
        ordering = ['id']


class OpenAdvance(models.Model):
    # SAGA_TYPE_LIST need to be exist in SAGA
    SAGA_TYPE_LIST = (
        ('M', _("Misc")),
        ('T', _("Travel")),
    )

    advance_type = models.CharField(max_length=10) # max_length must be >= than ClaimType.code max_length
    advance_id = models.IntegerField()
    reference_no = models.CharField(max_length=25, blank=True)
    saga_type = models.CharField(max_length=5, choices=SAGA_TYPE_LIST)
    advance_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    balance_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    allocated_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    status = models.CharField(max_length=10)
    # gl_account need to be added later

    class Meta:
        verbose_name = _("Open Advance")
        verbose_name_plural = _("Open Advances")
        ordering = ['-id']
