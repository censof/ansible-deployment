# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import EntAdvanceIndexView, MiscAdvanceIndexView, MiscAdvanceDraftView, MiscAdvanceDetailView

urlpatterns = patterns('',
    url(r'^entadvance/$', EntAdvanceIndexView.as_view(), name='entadvance_index'),
    url(r'^miscadvance/$', MiscAdvanceIndexView.as_view(), name='miscadvance_index'),
    url(r'^miscadvance/detail/$', MiscAdvanceDetailView.as_view(), name='miscadvance_detail'),
    url(r'^miscadvance/draft/(?P<draft_id>[0-9]+)/$', MiscAdvanceDraftView.as_view(), name='miscadvance_draft')
)
