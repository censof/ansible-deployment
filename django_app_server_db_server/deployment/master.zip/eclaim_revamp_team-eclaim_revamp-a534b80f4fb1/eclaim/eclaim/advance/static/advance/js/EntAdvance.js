/* Author 	: Hisham
 * Date	: December 2015 */

console.log('Entertainment Advance JS Loaded!!!');
	
uiBootstrapApp.controller('EntAdvanceCtrl', function ($scope, $log, $filter, DataDate) {
	
    /*************** Initial Variable Start ***************/
	$scope.error_validation = false;
	$scope.claimant_no = '';
	$scope.draft_id = '';
	$scope.advance_no = '';
    /*************** Initial Variable End ***************/
	
    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;
    
    $scope.panel1 = {
        open: false
    };
    
    $scope.panel2 = {
        open: false
    };
    
    $scope.panel3 = {
        open: true
    };
    
    $scope.panel4 = {
        open: false
    };
    
    $scope.panel5 = {
        open: false
    };
    
    $scope.panel6 = {
        open: false
    };
    
    $scope.panel7 = {
        open: false
    };
    
    
    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel1.open = true;
        $scope.panel2.open = true;
        $scope.panel3.open = true;
        $scope.panel4.open = true;
        $scope.panel5.open = true;
        $scope.panel6.open = true;
        $scope.panel7.open = true;
    };
    
    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel1.open = false;
        $scope.panel2.open = false;
        $scope.panel3.open = false;
        $scope.panel4.open = false;
        $scope.panel5.open = false;
        $scope.panel6.open = false;
        $scope.panel7.open = false;
    };
    /*************** Accordion End ***************/
    
    /*****Entertainment Advance Guest List Start*****/
    $scope.AdvanceDetailTab = [{
        id:1,
        active:true,
        ent_guest_name:'',
        ent_guest_company:'',
    }];
    
    $scope.counter = 1;
    
    $scope.addEntAdv = function(){
        $scope.counter++;
        $scope.AdvanceDetailTab.push({id:$scope.counter, active:true
                                     ,ent_guest_name:''
                                     ,ent_guest_company:'',});
        //$scope.selectedTab = $scope.AdvanceDetailTab.length - 1;       
    };
    
    $scope.deleteEntAdv = function(index){
        $scope.AdvanceDetailTab.splice(index,1);
        $scope.counter = $scope.AdvanceDetailTab.length;
    };
    
    /*****Entertainment Advance Guest List End*******/
    
    /*************** Fundtype dropdownlist Start ***************/
	$scope.onChangeFundType = function(){
        var fundType = $scope.ent_fundtype;
		//console.log($scope.tabs[index].lecture_fundtype);
	};
    /*************** Fundtype dropdownlist Start ***************/
    
    /*************** ProjectCode Search Start ***************/
	$scope.onChangeProjectCode = function(){
        var projectCode = $scope.ent_projectcode;
		//console.log($scope.tabs[index].lecture_fundtype);
	};
    /*************** Fundtype dropdownlist Start ***************/
    
    /*************** Watch Section : Start ***************/
    
    $scope.$watch(function () { return DataDate.getEntDateFrom(); }, function (newValue, oldValue) {
        if (newValue !== oldValue) {
			$scope.ent_date_from_str = newValue;
			console.log('Date From ='+$scope.ent_date_from_str);
		}
    });
    
    $scope.$watch(function () { return DataDate.getEntDateTo(); }, function (newValue, oldValue) {
        if (newValue !== oldValue) {
			$scope.ent_date_to_str = newValue;
			//console.log('Date To ='+$scope.ent_date_to_str);
		}
    });
});

uiBootstrapApp.controller('DateCtrl', function ($scope, $filter, DataDate) {
	
    /*************** DatePicker Start ***************/
	$scope.ent_date_from = '';
    $scope.ent_date_to = '';
	
    $scope.today = function() {
        $scope.ent_date_from = new Date();
        $scope.ent_date_to = new Date();
    };
    
	//$scope.today();
    
    $scope.open = function($event) {
        $scope.status.opened = true;
    };
    
    $scope.setDate = function(year, month, day) {
        $scope.ent_date_from = new Date(year, month, day);
        $scope.ent_date_to = new Date(year, month, day);
    };
    
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };
    
    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'dd-MM-yyyy'];
    $scope.format = $scope.formats[0];
    
    $scope.status = {
        opened: false
    };
    
	$scope.dateFromChanged = function(){
		var minDate = $filter('date')($scope.ent_date_from, 'yyyy-M-dd');
		DataDate.setEntDateFrom(minDate);
	};
	
	$scope.dateToChanged = function(){
        var maxDate = $filter('date')($scope.ent_date_to, 'yyyy-M-dd');
        DataDate.setEntDateTo(maxDate);
	};
	
    /*************** DatePicker End ***************/
});

uiBootstrapApp.factory('DataDate', function () {

    var data = {
		TabIndex: '',
		EntDateFrom: '',
        EntDateTo: '',
    };

    return {
        //getTabIndex: function () {
        //    return data.TabIndex;
        //},
        //setTabIndex: function (tabIndex) {
        //    data.TabIndex = tabIndex;
        //},
        getEntDateFrom: function () {
            return data.EntDateFrom;
        },
        setEntDateFrom: function (val) {
            data.EntDateFrom = val;
        },
        getEntDateTo: function () {
            return data.EntDateTo;
        },
        setEntDateTo: function (val) {
            data.EntDateTo = val;
        }
    };
});