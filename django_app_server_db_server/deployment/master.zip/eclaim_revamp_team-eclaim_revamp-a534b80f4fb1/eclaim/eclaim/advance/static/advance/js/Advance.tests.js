"use strict";

describe("Advance Tests", function() {

    // beforeEach(angular.mock.module('uiBootstrapApp'));
    // beforeEach(module('AdvanceLookupCtrl'));

    // var $scope;
    // var $http;
    
    var scope, $location, createController;

	beforeEach(inject(function($rootscope, $controller, _$location_){
		$location = _$location_;
		scope = $rootscope.new();

		createController = function() {
			return $controller('AdvanceLookupCtrl', {
				'$scope': $scope
			});
		};	
	 }));

	it("Place holder test", function() {
		// var controller = createController();
		expect(4444).toBe(4);
	});
});
