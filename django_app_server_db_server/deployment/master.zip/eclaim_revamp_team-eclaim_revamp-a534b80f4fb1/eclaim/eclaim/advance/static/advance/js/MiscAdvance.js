/* Author 	: Hisham
 * Date	: December 2015 */

console.log('Miscellaneous Advance JS Loaded!!!');

uiBootstrapApp.controller('MiscAdvanceCtrl', function ($scope, $sce, $http, DataSummary, DataLookup, DataMiscAdvForm, DataFundType, DataLocalMiscAdvForm) {

    /*************** Initial Variable Start ***************/
	$scope.error_validation = false;
	$scope.claimant_no = '';
	$scope.draft_id = '';
	$scope.claim_no = '';
    /*************** Initial Variable End ***************/

	$scope.initMiscAdvanceCtrl = function(){
		console.log('Load initMiscAdvanceCtrl (Default)');

		$scope.fundTypes = [];
		$scope.country_list = [];
		$scope.currency_list = [];
		$scope.currRate_list = [];

		$http({
			url: API_URL+'fund-type/',
			method: 'GET'
		})
		.success(function (data, status, headers, config) {
			$scope.fundTypes = data.results;
			DataFundType.setFundTypes($scope.fundTypes);
		});

		$http({
			url: API_URL+'countries/',
			method: 'GET'
		})
		.success(function (data, status, headers, config) {
			$scope.country_list = data.results;
			DataMiscAdvForm.setCountryLists($scope.country_list);
		});

		$http({
			url: API_URL+'currencies/',
			method: 'GET'
		})
		.success(function (data, status, headers, config) {
			$scope.currency_list = data.results;
			DataMiscAdvForm.setCurrencyTypeLists($scope.currency_list);
		});

		$http({
			url: API_URL+'currency-rates/',
			method: 'GET'
		})
		.success(function (data, status, headers, config) {
			$scope.currRate_list = data.results;
			DataMiscAdvForm.setCurrencyRates($scope.currRate_list);
		});
	};

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;

    $scope.panel1 = {
        open: false
    };

    $scope.panel2 = {
        open: true
    };

    $scope.panel3 = {
        open: false
    };

    $scope.panel4 = {
        open: false
    };

    $scope.panel5 = {
        open: false
    };

    $scope.panel6 = {
        open: false
    };

    $scope.panel7 = {
        open: false
    };

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel1.open = true;
        $scope.panel2.open = true;
        $scope.panel3.open = true;
        $scope.panel4.open = true;
        $scope.panel5.open = true;
        $scope.panel6.open = true;
        $scope.panel7.open = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel1.open = false;
        $scope.panel2.open = false;
        $scope.panel3.open = false;
        $scope.panel4.open = false;
        $scope.panel5.open = false;
        $scope.panel6.open = false;
        $scope.panel7.open = false;
    };
    /*************** Accordion End ***************/

    var claim_api_url = API_URL+'misc-advances/';

    if (PK) {  // detail view
        $http({
            url: claim_api_url+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, $sce, 12, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, $sce, 12, 1);
    }

    init_workflow($scope, $http, 'advance', 'MiscAdvance', PK, claim_api_url, WF_TEMPLATE);
});

uiBootstrapApp.controller('LocalMisAdvCtrl', ['$scope', '$http', '$filter', '$location', '$anchorScroll', '$validation', 'DataLookup', 'DataLocalMiscAdvForm', 'DataMiscAdvForm', 'DataFundType', function ($scope, $http, $filter, $location, $anchorScroll, $validation, DataLookup, DataLocalMiscAdvForm, DataMiscAdvForm, DataFundType) {

    $scope.initLocalMiscAdvCtrl = function(jsonFundTypeList){
        console.log('Load initLocalMiscAdvCtrl (Default)');

        $scope.localMiscFundType = {'label': '-'};

        /* Start : Global var might be used in Child controller */
        setEmptyTable();
        $scope.pageSize = 5;
        $scope.currentPage = 1;
        $scope.localMiscAdvItems = [];
        /* End : Global var might be used in Child controller */

        /* Start : Mileageform */
        $scope.showLocalMiscAdvForm = false;
        /* End : Mileageform */

        /* Start : Calculation variable */
        // $scope.localMiscQuantity = get1Float(0);
        // $scope.localMiscPrice = get2Float(0);
        $scope.localMiscAmount = get2Float(0);

        $scope.grandTotalLocalMiscAmount = get2Float(0);
        /* End : Calculation variable */
    };

	$scope.initLocalTable = function(draft_id){
		console.log('Load initLocalTable');
		if (draft_id != null && draft_id != '') {
            $scope.draft_item_list = [];
			$scope.localMiscAdvItems = [];
			$scope.fund_type = [];

			$http({
				url: API_URL+'miscdraftitem-advances/?draft_id='+draft_id,
				method: 'GET'
			})
			.success(function (data, status, headers, config) {
				$scope.draft_item_list = data.results;

				var draft_item_list = $scope.draft_item_list;
				for (var i=0; i < draft_item_list.length; i++){
					//console.log('Test');
					//console.log(draft_item_list[i].date_from);
					var id=i+1;
					var minDate = $filter('date')(draft_item_list[i].date_from, 'yyyy-M-dd');
					DataLocalMiscAdvForm.setLocalDateFrom(draft_item_list[i].date_from, minDate);
					var maxDate = $filter('date')(draft_item_list[i].date_to, 'yyyy-M-dd');
					DataLocalMiscAdvForm.setLocalDateTo(draft_item_list[i].date_to, maxDate);

					if (draft_item_list[i].country == null && draft_item_list[i].currency_type == null ) {
                        for (var j=0; j < $scope.fundTypes.length; j++){
							if ($scope.fundTypes[j].code == draft_item_list[i].fund_type.code) {
								$scope.fund_type = $scope.fundTypes[j];
                                DataFundType.setFundType($scope.fundTypes[j]);
							}
						}

						var setLocalMiscAdvItem = function(id){
							return {
								  id:id, active:true
								, localMiscDateFrom: DataLocalMiscAdvForm.getLocalDateFrom(), localMiscDateFromTxt: DataLocalMiscAdvForm.getLocalDateFromTxt()
								, localMiscDateTo: DataLocalMiscAdvForm.getLocalDateTo(), localMiscDateToTxt: DataLocalMiscAdvForm.getLocalDateToTxt()
								, localMiscFundType: DataFundType.getFundTypeCode(), localMiscFundTypeCode: DataFundType.getFundTypeCode()
								, localMiscFundTypeTxt: DataFundType.getFundType().description, miscProjectTxt: DataLookup.getProjectCode()
								, localMiscPurpose: draft_item_list[i].purpose, localMiscReason: draft_item_list[i].reason
								, localMiscItem: draft_item_list[i].item, localMiscQuantity: get1Float(draft_item_list[i].quantity)
								, localMiscPrice: get2Float(draft_item_list[i].price), localMiscAmount: get2Float(draft_item_list[i].total)
							};
						};

						$scope.localMiscAdvItems.push(setLocalMiscAdvItem(id));
						$scope.localMiscAdvCounter = id+1;
						calculateAllSummary();
						$scope.isEmptyTable = false;
					}
				}

			});
        }
	};

    var setEmptyTable = function(){
        $scope.currIndex = '';
        $scope.localMiscAdvCounter = 1;
        $scope.isEmptyTable = true;
        $scope.isEditMode = false;
        $scope.directIndex = 0;
        $scope.grandTotalLocalMiscAmount = get2Float(0);
    };

    $scope.localMiscAdvTableHeader = [
        {label:''}, {label:'Activity Date From'}, {label:'Activity Date To'}
        , {label:'Fund Type'}, {label:'Project Code'}, {label:'Purpose of Activity'}
        , {label:'Reason not using Purchase Requisition'},  {label:'Item'}
        , {label:'Quantity'}, {label:'Price (RM)'}, {label:'Total (RM)'}
        , {label:''}
    ];

    var setLocalMisAdvRow = function(id){
        return {
            id:id, active:true
            , localMiscDateFrom: DataLocalMiscAdvForm.getLocalDateFrom(), localMiscDateFromTxt: DataLocalMiscAdvForm.getLocalDateFromTxt()
            , localMiscDateTo: DataLocalMiscAdvForm.getLocalDateTo(), localMiscDateToTxt: DataLocalMiscAdvForm.getLocalDateToTxt()
            , localMiscFundType: $scope.localMiscFundType.description, localMiscFundTypeCode: $scope.localMiscFundType.code
			, localMiscFundTypeTxt: $scope.localMiscFundType.description, miscProjectTxt: DataLookup.getProjectCode()
            , localMiscPurpose: $scope.localMiscPurpose, localMiscReason: $scope.localMiscReason
            , localMiscItem: $scope.localMiscItem, localMiscQuantity: get1Float($scope.localMiscQuantity)
            , localMiscPrice: get2Float($scope.localMiscPrice), localMiscAmount: get2Float($scope.localMiscAmount)
        };
    };

    $scope.addLocalMiscAdvItem = function(form){
        var dateFrom = DataLocalMiscAdvForm.getLocalDateFrom(),
            dateTo   = DataLocalMiscAdvForm.getLocalDateTo();

        if (dateFrom <= dateTo) {  // dateFrom must not be after dateTo
            $scope.addButtonActive = false;
            $scope.localMiscAdvItems.push(setLocalMisAdvRow($scope.localMiscAdvCounter));
            $scope.localMiscAdvCounter++;
            $scope.isEmptyTable = false;
            $scope.resetForm();
            calculateAllSummary();
            $('[name="localMiscDateFrom"]').removeClass('ng-invalid');
            $('[name="localMiscDateTo"]').removeClass('ng-invalid');
        } else {
            $('[name="localMiscDateFrom"]').addClass('ng-invalid');
            $('[name="localMiscDateTo"]').addClass('ng-invalid');
        }
    };

    $scope.deleteLocalMiscAdvItem = function(tabIndex){
        var index = tabIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.localMiscAdvItems.splice(index, 1); //remove the object from the array based on index
        $scope.localMiscAdvCounter = $scope.localMiscAdvItems.length;
        if ($scope.localMiscAdvItems.length == 0) {
            setEmptyTable();
        }
    };

    $scope.editLocalMiscAdvItem = function(tabIndex){
        $scope.isEditMode = true;
        var index = tabIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        var currTab = $scope.localMiscAdvItems[index];
        setLocalMiscAdvScope(currTab);
        $scope.openModal(false);
    };

    var setLocalMiscAdvScope = function(currTab){
        console.log(currTab);
        DataLocalMiscAdvForm.setLocalDateFrom(currTab.localMiscDateFrom);
        DataLocalMiscAdvForm.setLocalDateTo(currTab.localMiscDateTo);
        DataFundType.setFundType(DataFundType.getFundTypeByCode(currTab.localMiscFundType));
        $scope.localMiscFundType = DataFundType.getFundType();
        DataLookup.setProjectCode(currTab.miscProjectTxt);
        $scope.localMiscPurpose = currTab.localMiscPurpose;
        $scope.localMiscReason = currTab.localMiscReason;
        $scope.localMiscItem = currTab.localMiscItem;
        $scope.localMiscQuantity = currTab.localMiscQuantity;
        $scope.localMiscPrice = currTab.localMiscPrice;
        $scope.localMiscAmount = currTab.localMiscAmount;
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currTab = '';
        if ($scope.localMiscAdvItems.length > 0) {
            if ($scope.directIndex == $scope.localMiscAdvItems.length) {
                $scope.directIndex = $scope.localMiscAdvItems.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                currTab = $scope.localMiscAdvItems[$scope.directIndex];
                setLocalMiscAdvScope(currTab);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= $scope.localMiscAdvItems.length-1)) {
                $scope.directIndex++;
                currTab = $scope.localMiscAdvItems[$scope.directIndex];
                setLocalMiscAdvScope(currTab);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };

    $scope.openModal = function (reset) {
        if (reset)
            $scope.resetForm();
        $('#localMiscAdvModalForm').modal('show');
    };

    $scope.resetForm = function(){
        DataLocalMiscAdvForm.reset();
        DataLookup.setProjectCode('');
        DataFundType.setFundType({});
        $scope.localMiscDateFrom = '';
        $scope.localMiscDateTo = '';
        $scope.localMiscPurpose = '';
        $scope.localMiscReason = '';
        $scope.localMiscItem = '';
        $scope.localMiscQuantity = get1Float(0);
        $scope.localMiscPrice = get2Float(0);
        $scope.localMiscAmount = get2Float(0);
        $scope.isEditMode = false;
    };

	$scope.$watch('localMiscAdvItems',function() {
		//console.log($scope.localMiscAdvItems);
		return DataLocalMiscAdvForm.setLocalMiscAdvItems($scope.localMiscAdvItems)
		}, true);

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if ($scope.isEditMode){
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            if (newValue != oldValue) {
                var currTab = $scope.localMiscAdvItems[$scope.currIndex];
                currTab.miscProjectTxt = newValue;
            }
        }
    });

    $scope.$watch('localMiscFundType', function (newValue, oldValue) {
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            if ($scope.localMiscFundType) {
                DataFundType.setFundType(DataFundType.getFundTypeByCode($scope.localMiscFundType.code));
                currTab.localMiscFundType = DataFundType.getFundTypeCode();
                currTab.localMiscFundTypeTxt = $scope.localMiscFundType.description;
            }else{
                currTab.localMiscFundTypeTxt = '';
            }
        }
    });

    $scope.$watch('localMiscPurpose',function() {
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            currTab.localMiscPurpose = $scope.localMiscPurpose;
        }
    });

	$scope.$watch('localMiscReason',function() {
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            currTab.localMiscReason = $scope.localMiscReason;
        }
    });

    $scope.$watch('localMiscItem',function() {
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            currTab.localMiscItem = $scope.localMiscItem;
        }
    });

    $scope.$watch('localMiscQuantity', function() {
        var quantity = $scope.localMiscQuantity;
        var localMiscAmount = parseFloat($scope.localMiscPrice) * parseFloat(quantity);
        $scope.localMiscAmount = get2Float(localMiscAmount);
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            currTab.localMiscQuantity = get1Float(quantity);
            currTab.localMiscAmount = get2Float(localMiscAmount)
            calculateAllSummary();
        }
    });

    $scope.$watch('localMiscPrice', function() {
        var price = $scope.localMiscPrice;
        var localMiscAmount = parseFloat($scope.localMiscQuantity) * parseFloat(price);
        $scope.localMiscAmount = get2Float(localMiscAmount);
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            currTab.localMiscPrice = get2Float(price);
            currTab.localMiscAmount = get2Float(localMiscAmount)
            calculateAllSummary();
        }
    });

    $scope.$watch('localMiscAmount', function() {
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            currTab.localMiscAmount = get2Float($scope.localMiscAmount);
        }
    });

    var calculateAllSummary = function () {
        var totalSummaryLocalMiscAmount = 0;
        angular.forEach($scope.localMiscAdvItems, function(obj){
            totalSummaryLocalMiscAmount = totalSummaryLocalMiscAmount + parseFloat(obj.localMiscAmount);
        });
        $scope.grandTotalLocalMiscAmount = get2Float(totalSummaryLocalMiscAmount);
		DataLocalMiscAdvForm.setLocalGrandTotal($scope.grandTotalLocalMiscAmount);
    };

    if (PK) {  // detail view
        $http({
            url: API_URL+'misc-advances/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.localMiscAdvItems = data.items;
            $scope.isEmptyTable = false;
            angular.forEach($scope.localMiscAdvItems, function (obj) {
                obj.localMiscAmount = get2Float(parseFloat(obj.localMiscPrice) * parseFloat(obj.localMiscQuantity));
            });
            calculateAllSummary();
        });
    }
}]);

uiBootstrapApp.controller('MiscAdvDateFromCtrl', function($scope, $filter, DataLocalMiscAdvForm, DataOverseaMiscAdvForm){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.localMiscDateFrom = '';
		$scope.overseaMiscDateFrom = '';
        //$scope.dateChanged();
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initActivityDateFrom = function(){
        console.log('Load initActivityDateFrom (Default)');
        $scope.resetDate();
    };

	$scope.localDateChanged = function(){
        var minDate = $filter('date')($scope.localMiscDateFrom, 'yyyy-M-dd');
        DataLocalMiscAdvForm.setLocalDateFrom($scope.localMiscDateFrom, minDate);

        if ($scope.isEditMode){
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            if (minDate != '') {
                currTab.localMiscDateFromTxt = minDate;
            }else{
                currTab.localMiscDateFromTxt = '-';
            }
            currTab.localMiscDateFrom = $scope.localMiscDateFrom;
        }
	};

    $scope.$watch(function () { return DataLocalMiscAdvForm.getLocalDateFrom(); }, function (newValue, oldValue) {
        if (newValue == 'reset') {
            $scope.resetDate();
        } else if (newValue != '') {
            $scope.localMiscDateFrom = newValue;
        }
    });

	$scope.overseaDateChanged = function(){
        var minDate = $filter('date')($scope.overseaMiscDateFrom, 'yyyy-M-dd');
        DataOverseaMiscAdvForm.setOverseaDateFrom($scope.overseaMiscDateFrom, minDate);

        if ($scope.isEditMode){
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            if (minDate != '') {
                currTab.overseaMiscDateFromTxt = minDate;
            }else{
                currTab.overseaMiscDateFromTxt = '-';
            }
            currTab.overseaMiscDateFrom = $scope.overseaMiscDateFrom;
        }
	};

	$scope.$watch(function () { return DataOverseaMiscAdvForm.getOverseaDateFrom(); }, function (newValue, oldValue) {
        if (newValue == 'reset') {
            $scope.resetDate();
        }else if (newValue != '') {
            $scope.overseaMiscDateFrom = newValue;
        }
    });
});

uiBootstrapApp.controller('SummaryCtrl', function ($scope, $http, DataLocalMiscAdvForm) {
    $scope.fund_types = [];
    $scope.grandTotalAmount = get2Float(0);
    $scope.expense_type = {};

    $scope.$watch(function () { return DataLocalMiscAdvForm.getLocalGrandTotal(); }, function(newValue, oldValue) {
        $scope.grandTotalAmount = newValue;
        $http({
            url: API_URL+'expenses/',
            method: 'GET',
            params: { claim_code: 'LMADV' }
        })
        .success(function (data, status, headers, config) {
            $scope.expense_type = data.results[0];
        });
    });

    $scope.$watchCollection(function () { return DataLocalMiscAdvForm.getLocalMiscAdvItems(); }, function (newValue, oldValue) {
        var items           = DataLocalMiscAdvForm.getLocalMiscAdvItems(),
            fund_type_data  = {};

        // Get list of fund types collected from added table rows
        angular.forEach(items, function (obj) {
            var _in_array = false;
            $.each(fund_type_data, function (ftcode, ftobj) {
                if (ftcode == obj.localMiscFundType)
                    _in_array = true;
            });
            if (_in_array) {
                var _amount = parseFloat(obj.localMiscPrice) * parseFloat(obj.localMiscQuantity);
                fund_type_data[obj.localMiscFundType].amount = get2Float(parseFloat(fund_type_data[obj.localMiscFundType].amount)+_amount);
            } else {
                fund_type_data[obj.localMiscFundType] = {
                    label:  obj.localMiscFundTypeTxt,
                    amount: get2Float(parseFloat(obj.localMiscPrice)*parseFloat(obj.localMiscQuantity))
                };
            }
        });
        $scope.fund_type_data = fund_type_data;
    });
});

uiBootstrapApp.controller('MiscAdvDateToCtrl', function($scope, $filter, DataLocalMiscAdvForm, DataOverseaMiscAdvForm){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.localMiscDateTo = '';
		$scope.overseaMiscDateTo = '';
        //$scope.dateChanged();
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initActivityDateTo = function(){
        console.log('Load initActivityDateTo (Default)');
		 $scope.resetDate();
    };

	$scope.localDateChanged = function(){
        var minDate = $filter('date')($scope.localMiscDateTo, 'yyyy-M-dd');
        DataLocalMiscAdvForm.setLocalDateTo($scope.localMiscDateTo, minDate);
        if ($scope.isEditMode) {
            var currTab = $scope.localMiscAdvItems[$scope.currIndex];
            if (minDate != '') {
                currTab.localMiscDateToTxt = minDate;
            }else{
                currTab.localMiscDateToTxt = '-';
            }
            currTab.localMiscDateTo = $scope.localMiscDateTo;
        }
	};

    $scope.$watch(function () { return DataLocalMiscAdvForm.getLocalDateTo(); }, function (newValue, oldValue) {
        if (newValue == 'reset') {
            $scope.resetDate();
        }else if (newValue != '') {
            $scope.localMiscDateTo = newValue;
        }
    });

	$scope.overseaDateChanged = function(){
        var minDate = $filter('date')($scope.overseaMiscDateTo, 'yyyy-M-dd');
        DataOverseaMiscAdvForm.setOverseaDateTo($scope.overseaMiscDateTo, minDate);
        if ($scope.isEditMode) {
            var currTab = $scope.overseaMiscAdvItems[$scope.currIndex];
            if (minDate != '') {
                currTab.overseaMiscDateToTxt = minDate;
            }else{
                currTab.overseaMiscDateToTxt = '-';
            }
            currTab.overseaMiscDateTo = $scope.overseaMiscDateTo;
        }
	};

    $scope.$watch(function () { return DataOverseaMiscAdvForm.getOverseaDateTo(); }, function (newValue, oldValue) {
        if (newValue == 'reset') {
            $scope.resetDate();
        }else if (newValue != '') {
            $scope.overseaMiscDateTo = newValue;
        }
    });
});

uiBootstrapApp.factory('DataLocalMiscAdvForm', function ($filter) {

    var data = {
        localMiscAdvItems : [],
		LocalDateFrom : '',
		LocalDateFromTxt : '-',
        LocalDateTo : '',
        LocalDateToTxt : '-',
        ProjectCode : '',
		localGrandTotal: get2Float(0)
    };

    return {
        getLocalMiscAdvItems: function () {
            return data.localMiscAdvItems;
        },
        setLocalMiscAdvItems: function (obj) {
            data.localMiscAdvItems = obj;
        },
        reset: function (){
            data.LocalDateFrom = 'reset';
            data.LocalDateFromTxt = '-';
            data.LocalDateTo = 'reset';
            data.LocalDateToTxt = '-';
        },
        getLocalDateFrom: function () {
            return data.LocalDateFrom;
        },
        getLocalDateFromTxt: function () {
            return data.LocalDateFromTxt;
        },
        setLocalDateFrom: function (obj, objStr) {
            data.LocalDateFrom = obj;
            data.LocalDateFromTxt = objStr;
        },
        getLocalDateTo: function () {
            return data.LocalDateTo;
        },
        getLocalDateToTxt: function () {
            return data.LocalDateToTxt;
        },
        setLocalDateTo: function (obj, objStr) {
            data.LocalDateTo = obj;
            data.LocalDateToTxt = objStr;
        },
        getProjectCode: function () {
            return data.ProjectCode;
        },
        setProjectCode: function (obj) {
            data.ProjectCode = obj;
        },
		getLocalGrandTotal: function () {
			return data.localGrandTotal;
		},
		setLocalGrandTotal: function (obj) {
			data.localGrandTotal = obj;
		}
    };
});

uiBootstrapApp.factory('DataOverseaMiscAdvForm', function ($filter) {

    var data = {
        overseaMiscAdvItems : [],
		OverseaDateFrom : '',
		OverseaDateFromTxt : '-',
        OverseaDateTo : '',
        OverseaDateToTxt : '-',
        ProjectCode : '',
		overseaGrandTotal: get2Float(0)
    };

    return {
        getOverseaMiscAdvItems: function () {
            return data.overseaMiscAdvItems;
        },
        setOverseaMiscAdvItems: function (obj) {
            data.overseaMiscAdvItems = obj;
        },
        reset: function (){
            data.OverseaDateFrom = 'reset';
            data.OverseaDateFromTxt = '-';
            data.OverseaDateTo = 'reset';
            data.OverseaDateToTxt = '-';
        },
        getOverseaDateFrom: function () {
            return data.OverseaDateFrom;
        },
        getOverseaDateFromTxt: function () {
            return data.OverseaDateFromTxt;
        },
        setOverseaDateFrom: function (obj, objStr) {
            data.OverseaDateFrom = obj;
            data.OverseaDateFromTxt = objStr;
        },
        getOverseaDateTo: function () {
            return data.OverseaDateTo;
        },
        getOverseaDateToTxt: function () {
            return data.OverseaDateToTxt;
        },
        setOverseaDateTo: function (obj, objStr) {
            data.OverseaDateTo = obj;
            data.OverseaDateToTxt = objStr;
        },
        getProjectCode: function () {
            return data.ProjectCode;
        },
        setProjectCode: function (obj) {
            data.ProjectCode = obj;
        },
		getOverseaGrandTotal: function () {
			return data.overseaGrandTotal;
		},
		setOverseaGrandTotal: function (obj) {
			data.overseaGrandTotal = obj;
		}
    };
});

uiBootstrapApp.factory('DataMiscAdvForm', function ($filter) {

    var data = {
		fundTypesList:[],
		countryLists:[],
		currencTypeLists:[],
		currencyRateList:[],
		error_validation:'',
		claimant_no:'',
		draft_id:'',
		claim_id:'',
    };

    return {
		getFundTypes: function () {
            return data.fundTypesList;
        },
        setFundTypes: function (obj) {
            data.fundTypesList = obj;
        },
		getCountryLists: function () {
            return data.countryLists;
        },
        setCountryLists: function (obj) {
            data.countryLists = obj;
        },
		getCurrencyTypeLists: function () {
            return data.currencTypeLists;
        },
        setCurrencyTypeLists: function (obj) {
            data.currencTypeLists = obj;
        },
		getCurrencyRates: function () {
            return data.currencyRateList;
        },
        setCurrencyRates: function (obj) {
            data.currencyRateList = obj;
        },
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (obj) {
            data.error_validation = obj;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        }
    };
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataLookup', 'DataLocalMiscAdvForm', 'DataOverseaMiscAdvForm', 'DataMiscAdvForm', function ($scope, $uibModal, $http, $window, DataLookup, DataLocalMiscAdvForm, DataOverseaMiscAdvForm, DataMiscAdvForm) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);
		//console.log(DataLookup.getPTJCharged());
		//console.log(DataLectureClaim.getTabs());
		//console.log(DataLectureClaim.getErrorValidation());
		//console.log(DataLectureClaim.getClaimantNo());
		//console.log(DataDocumentList.getDocumentList())

		form_data = {
			btn_mode:btnMode,
			claimant_no:DataMiscAdvForm.getClaimantNo(),
			draft_id:DataMiscAdvForm.getDraftID(),
			localTabs:DataLocalMiscAdvForm.getLocalMiscAdvItems(),
			localGrandTotal:DataLocalMiscAdvForm.getLocalGrandTotal()
		}
        if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                } else {
    				$http({
    					url: '',
    					method: 'POST',
    					data: form_data
    				})
    				.success(function (data, status, headers, config) {
    					//console.log(data.tabs);
    					//window.location.reload();
                        enable_claim_controls();
                        var submit_success_url = data.submit_success_url;

    					if (btnMode == 'submit') {
    						$window.location.href = submit_success_url;
    					} else if (btnMode == 'save_draft') {
    						$scope.initSubmitCtrl(data.draft_id);
    						$uibModal.open({
    							animation: $scope.animationsEnabled,
    							templateUrl: 'SaveSuccess.html',
    							controller: 'ModalInstanceInfoCtrl',
    							size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
    							resolve: {
    							  data: function () {
    								return data;
    							  }
    							}
    						});
                            $window.location.href = submit_success_url;
    					}
    				}).error(function () {
                        enable_claim_controls();
                    });
                }
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id){
		$scope.draft_id = draft_id;
		DataMiscAdvForm.setDraftID(draft_id);
	};
}]);

uiBootstrapApp.controller('ModalInstanceSaveCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

	$scope.ok = function () {
		$uibModalInstance.close();
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};
}]);

uiBootstrapApp.controller('ModalInstanceSubmitCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

	$scope.ok = function () {
		$uibModalInstance.close();
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};
}]);

uiBootstrapApp.controller('ModalInstanceInfoCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

	$scope.ok = function () {
		$uibModalInstance.close();
	};
}]);
