/* Author 	: Danial
 * Date	    : Feb 2016 */
console.log('Advance JS Loaded!!!');

uiBootstrapApp.controller('AdvanceLookupCtrl', function ($scope, $http, DataClaimant, DataAdvance) {
    $scope.advanceNo = '';
    $scope.advanceAmount = '';
    $scope.advanceItems = [];
    $scope.openAdvances = [];
    $scope.advanceTotalAmount = get2Float(0);
    $scope.claimGrandTotal = get2Float(0);
    $scope.claimNettTotal = get2Float(0);
    
    /* Start : General Config for Table */
            $scope.pageSize = 5;
            $scope.currentPage = 1;
    /* End : General Config for Table */
        
    $http({
        url: API_URL+'open-advances/',
        method: 'GET',
        params: {'staffNo':DataClaimant.getStaffNo()}
	})
    .success(function (data, status, headers, config) {
        $scope.openAdvances = data.results;
    });
    
    /* if using $http
    $scope.getOpenAdvance = function (obj) {
        return $http.get('/eclaim/lookup-advance/?advanceNo='+obj).then(function(data) {
            return data.data;
        });
    };*/
    
    var getItems = function (index){
        var obj = $scope.advanceItems;
        
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    var setEmptyTable = function(){
        $scope.isEmptyTable = true;
        $scope.directIndex = 0;
    };
    
    /* Start : Calculation */
    var calculateAll = function(){
        var totalAdvance = getListTotalAmount($scope.advanceItems, 'advanceAmount');
        var claimGrandTotal = DataAdvance.getClaimGrandTotal();
        var claimNettTotal = 0;
        
        $scope.advanceTotalAmount = get2Float(totalAdvance);
        claimNettTotal = parseFloat(claimGrandTotal) - parseFloat(totalAdvance);
        $scope.claimNettTotal = get2Float(claimNettTotal);
        
        DataAdvance.setAdvanceGrandTotal(totalAdvance);
        DataAdvance.setClaimNettTotal(claimNettTotal);
    };
    /* End : Calculation */
    
    $scope.onSelect = function($item, $model, $label){
        var reference_no = $item.reference_no;
            amount = $item.balance_amount;
        
        $scope.advanceItems.forEach(function(obj){
            if (obj.objAdvance.reference_no == reference_no) {
                obj.advanceAmount = amount;
            };
        });
        calculateAll();
    };
    
    $scope.addItem = function(){
        var items = getItems();
        items.push({});
        $scope.isEmptyTable = false;
    };
    
    $scope.deleteItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
            items = getItems();
            
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };
    
    $scope.$watch('advanceItems', function(newValue, oldValue){
        if (newValue != oldValue) {
            DataAdvance.setAdvanceItems($scope.advanceItems);
        }
    }, true);
    
    $scope.$watch(function () { return DataAdvance.getClaimGrandTotal(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.claimGrandTotal = get2Float(newValue);
            calculateAll();
        }
    });
    
    setEmptyTable();
});

uiBootstrapApp.factory('DataAdvance', function(){
    data = {
        AdvanceItems: [],
        AdvanceGrandTotal: get2Float(0),
        ClaimGrandTotal: get2Float(0),
        ClaimNettTotal: get2Float(0)
    };
    
    return {
        getAdvanceItems: function(){
            return data.AdvanceItems;
        },
        setAdvanceItems: function(obj){
            data.AdvanceItems = obj;
        },
        getAdvanceGrandTotal: function(){
            return data.AdvanceGrandTotal;
        },
        setAdvanceGrandTotal: function(val){
            data.AdvanceGrandTotal = val;
        },
        getClaimGrandTotal: function(){
            return data.ClaimGrandTotal;
        },
        setClaimGrandTotal: function(val){
            data.ClaimGrandTotal = val;
        },
        getClaimNettTotal: function(){
            return data.ClaimNettTotal;
        },
        setClaimNettTotal: function(val){
            data.ClaimNettTotal = val;
        }
    };
});