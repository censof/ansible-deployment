import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text

from eclaim.claim.models import ClaimType
from eclaim.libs.views import AngularUpdateAndDetailView, ClaimIndexView
from eclaim.auth.authenticate import Authenticate
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.utils import get_document_list, get_document_list_item_draft
from eclaim.masterfiles.common import CLAIM_TYPE, SUMMARY
from eclaim.utils.common import get_json_from_set_obj

from .models import (
    MiscAdvance, MiscAdvanceDraft, MiscAdvanceItemDraft)
from .processes import process_controller

__ClaimType__ = CLAIM_TYPE.MADV


class EntAdvanceIndexView(TemplateView):
    """
    This is index page for Ent Advance.
    """
    template_name = 'advance/entadvance.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(EntAdvanceIndexView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(EntAdvanceIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        context['claimant'] = claimant
        context['FUND_TYPE_LIST'] = FundType.objects.all()

        return context

    # def post(self, request, **kwargs):
    #     form_data = json.loads(request.body)
    #     btn_mode = form_data.get('btn_mode')
    #
    #     draft_id, claim_id = process_controller(btn_mode, form_data)
    #
    #     response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
    #     return HttpResponse(json.dumps(response_data), content_type="application/json")

class MiscAdvanceIndexView(ClaimIndexView):
    """
    This is index page for Misc Advance.
    """
    template_name = 'advance/miscadvance.html'
    claim_type = ClaimType.get_claim_type(12)
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(MiscAdvanceIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        context['claimant'] = claimant
        return context

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(
            btn_mode, form_data, request.user)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscAdvance, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class MiscAdvanceDetailView(AngularUpdateAndDetailView):
    model = MiscAdvance
    template_name = 'advance/miscadvance.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(MiscAdvanceDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        context['claimant'] = claimant
        return context

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscAdvance, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class MiscAdvanceDraftView(TemplateView):
    template_name = 'advance/miscadvance.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(MiscAdvanceDraftView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        context = super(MiscAdvanceDraftView, self).get_context_data(**kwargs)
        draft_id = self.kwargs['draft_id']

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        context['claimant'] = claimant
        context['DOC_LIST'] = get_document_list('MADV')
        context['SUMMARY'] = SUMMARY().get_summary('MADV')

        draft = MiscAdvanceDraft.objects.get(id=int(draft_id))
        # draft_item = MiscAdvanceItemDraft.objects.filter(misc_advance_draft=draft)
        # local = False
        # oversea = False
        # for i in draft_item:
        #     if i.country and i.currency_type and i.currency_rate:
        #         oversea_items = get_json_from_set_obj(draft.miscadvanceitemdraft_set.all())
        #         oversea = True
        #     else:
        #         local_items = get_json_from_set_obj(draft.miscadvanceitemdraft_set.all())
        #         local = True
        document_list = get_json_from_set_obj(get_document_list_item_draft(draft.id, __ClaimType__))

        # context['draft_id'] = draft.id
        # if local:
        #     context['json_local_items'] = local_items
        # if oversea:
        #     context['json_oversea_items'] = oversea_items
        context['json_documentlist'] = document_list
        return context

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')
        draft_id, claim_id = process_controller(
            btn_mode, form_data, request.user)

        if btn_mode == 'submit':
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscAdvance, claim_id)

        response_data = {'errors': False, 'draft_id':draft_id, 'claim_id':claim_id, 'submit_success_url': force_text(self.submit_success_url)}
        return HttpResponse(json.dumps(response_data), content_type="application/json")
