import datetime
from decimal import *

from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.common import CLAIM_TYPE
from eclaim.masterfiles.utils import save_claimant_history
from eclaim.utils.common import generate_claim_no
from .models import (
    MiscAdvanceDraft, MiscAdvanceItemDraft, MiscAdvance, MiscAdvanceItem)

__ClaimType__ = CLAIM_TYPE.MADV
__ClaimNoPrefix__ = CLAIM_TYPE.LocalMiscAdvanceNoPrefix


def process_controller(btn_mode, form_data, created_by=None):
    draft_id = None
    claim_id = None

    if btn_mode in ['save_draft']:
        draft_id = save_draft(form_data, created_by)
        print 'Save Draft Completed!!!'
    elif btn_mode in ['submit']:
        claim_id = submit_claim(form_data)
        print 'Submit Claim Completed!!!'

    return draft_id, claim_id


def save_draft(form_data, created_by=None):
    draft_id = form_data.get('draft_id')

    if not draft_id:
        claim_draft = MiscAdvanceDraft()
        if created_by is not None:
            claim_draft.created_by = created_by
        claim_draft.save()
        save_misc_advance_item('save_draft', claim_draft, form_data)
        return claim_draft.id
    else:
        claim_draft = MiscAdvanceDraft(id=draft_id)
        if created_by is not None:
            claim_draft.created_by = created_by
        delete_misc_advance_draft_item(claim_draft)
        save_misc_advance_item('save_draft', claim_draft, form_data)
        return draft_id


def submit_claim(form_data):
    claim = MiscAdvance()
    claim.grand_total = form_data.get('localGrandTotal')
    claim.save()
    claim.claim_no = generate_claim_no(__ClaimNoPrefix__, claim.id)
    claim.save()
    claimant_no = form_data.get('claimant_no')
    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_misc_advance_item('submit_claim', claim, form_data)
    return claim.id


def save_misc_advance_item(mode, parent, form_data):
    if form_data.get('localTabs'):
        for i in form_data.get('localTabs'):
            miscadv_datefrom = i['localMiscDateFromTxt']
            miscadv_dateto = i['localMiscDateToTxt']
            miscadv_fundtype = i['localMiscFundTypeCode']
            miscadv_purpose = i['localMiscPurpose']
            miscadv_reason = i['localMiscReason']
            miscadv_item = i['localMiscItem']
            miscadv_quantity = i['localMiscQuantity']
            miscadv_price = i['localMiscPrice']
            miscadv_amount = i['localMiscAmount']

            if mode in ['save_draft']:
                saveObj = MiscAdvanceItemDraft()
                saveObj.misc_advance_draft = parent
                saveObj.total = Decimal(miscadv_amount)
                saveObj.grand_total = Decimal(form_data.get('localGrandTotal'))
            elif mode in ['submit_claim']:
                saveObj = MiscAdvanceItem()
                saveObj.misc_advance = parent

            saveObj.date_from = datetime.datetime.strptime(miscadv_datefrom, "%Y-%m-%d")
            saveObj.date_to = datetime.datetime.strptime(miscadv_dateto, "%Y-%m-%d")
            saveObj.fund_type = FundType.objects.get(code=miscadv_fundtype)
            saveObj.purpose = miscadv_purpose
            saveObj.reason = miscadv_reason
            saveObj.item = miscadv_item
            saveObj.quantity = miscadv_quantity
            saveObj.price = miscadv_price
            saveObj.save()


def delete_misc_advance_draft_item(parent):
    delObj = MiscAdvanceItemDraft.objects.filter(misc_advance_draft=parent)
    delObj.delete()
