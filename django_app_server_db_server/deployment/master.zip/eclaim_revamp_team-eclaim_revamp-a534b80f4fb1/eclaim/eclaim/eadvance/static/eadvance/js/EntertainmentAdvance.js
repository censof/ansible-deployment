/* Author : Hawa
   Date	: January 2016 */

console.log('Local Entertainment Advance JS Loaded!!!');

uiBootstrapApp.controller('LocalEntertainmentAdvanceCtrl', function ($scope, $http, DataMain, DataAdvanceForm) {

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;

    $scope.panel1 = {
        open: false
    };

    $scope.panel2 = {
        open: true
    };

    $scope.panel3 = {
        open: false
    };

    $scope.panel4 = {
        open: false
    };

    $scope.panel5 = {
        open: false
    };

    $scope.panel6 = {
        open: false
    };

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel1.open = true;
        $scope.panel2.open = true;
        $scope.panel3.open = true;
        $scope.panel4.open = true;
        $scope.panel5.open = true;
        $scope.panel6.open = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel1.open = false;
        $scope.panel2.open = false;
        $scope.panel3.open = false;
        $scope.panel4.open = false;
        $scope.panel5.open = false;
        $scope.panel6.open = false;
    };
    /*************** Accordion End ***************/

    /*************** Initial Variable Start ***************/
	$scope.error_validation = false;
	$scope.claimant_no = '';
	$scope.draft_id = '';
	$scope.claim_no = '';
	$scope.claim = {};
	$scope.object_pk = PK;
    /*************** Initial Variable End ***************/

    $scope.initClaimantNo = function (claimant_no) {
        $scope.claimant_no = claimant_no;
        changeItemVal('claimant_no');
    };

    var changeItemVal = function(obj) {
	if (obj == 'claimant_no') {
            DataMain.setClaimantNo($scope.claimant_no);
        }
	else if (obj == 'showLocal') {
	    $scope.showLocal = DataAdvanceForm.getShowLocal();
	}
	else if (obj == 'showOversea') {
	    $scope.showOversea = DataAdvanceForm.getShowOversea();
	}
    };

    $scope.$watch(function () { return DataAdvanceForm.getShowLocal(); }, function (newValue, oldValue) {
	if (oldValue != newValue) {
            changeItemVal('showLocal');
        }
    });

    $scope.$watch(function () { return DataAdvanceForm.getShowOversea(); }, function (newValue, oldValue) {
        changeItemVal('showOversea');
    });

    /**
     * Render workflow query types
     */
    $http({
        url: API_URL+'workflow-query-types/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.querytype_list = data.results;
    });

    /**
     * Render workflow reasons
     */
    $http({
        url: API_URL+'workflow-reasons/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.reason_list = data.results;
    });

    /**
     * Claim button controls
     */
    $scope.controls = {};

    /**
     * Detail view
     */
    if (PK) {
        // Initialize variables.
        $scope.controls.has_basic_perm = false;
        $scope.controls.has_ext_perm = false;

        $http({
            url: API_URL+'lecture-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.claim = data;

            $http({
                url: API_URL+'claimants/'+STAFF_NO+'/',
                method: 'GET'
            })
            .success(function (claimant_data, status, headers, config) {
                // Check whether user is just a claimant or a privileged user.
                if (!$scope.claim.query) {
                    var _assignee   = $scope.claim.current_assignee,
                        _group      = $scope.claim.current_assigned_group;

                    if (_assignee) {
                        $scope.controls.has_ext_perm = _assignee == STAFF_NO;
                    } else if (claimant_data.assignee) {
                        var _in_group = $.inArray(_group, claimant_data.assignee.groups) != -1;
                        $scope.controls.has_ext_perm = claimant_data.assignee && _in_group;
                    } else {
                        $scope.controls.has_ext_perm = false;
                    }

                    $scope.controls.has_basic_perm = false;
                } else {
                    $scope.controls.has_basic_perm = $scope.claim.claimant_staff_no == STAFF_NO;
                    $scope.controls.has_ext_perm = false;
                }

                console.log('has_basic_perm:', $scope.controls.has_basic_perm);
                console.log('has_ext_perm:', $scope.controls.has_ext_perm);
            });
        });
    } else {
        // New claim.
        $scope.controls.has_basic_perm = true;
        $scope.controls.has_ext_perm = false;
    }

    // Assignee from a selection filtering.
    $scope.filtering = {};
    $scope.filtering.claimant_list = [];

    if ($scope.showLocal == true) {
        var params = {
	    has_filtering: true,
	    claim_app: 'eadvance',
	    claim_model: 'LocalEntertainmentAdvance'
	};
    }

    if ($scope.showOversea == true) {
        var params = {
	    has_filtering: true,
	    claim_app: 'eadvance',
	    claim_model: 'OverseaEntertainmentAdvance'
	};
    }

    if (PK)
        params.claim = PK;

    $http({
        url: API_URL+'claimants/',
        method: 'GET',
        params: params
    })
    .success(function (data, status, headers, config) {
        $scope.filtering.claimant_list = data.results;
    });

    // Control button actions.
    $scope.approve_claim = function (claim_no, claim_ctype_id) {
        $http({
            url: URL_AJAX_APPROVE_CLAIM,
            method: 'POST',
            data: {
                claim_no: claim_no,
                claim_ctype: claim_ctype_id
            }
        })
        .success(function (data, status, headers, config) {
            if (data.success)
                window.location.href = URL_HOMEPAGE;
        });
    };

    $scope.reject_claim = function (claim_no, claim_ctype_id) {
        $http({
            url: URL_AJAX_DECLINE_CLAIM,
            method: 'POST',
            data: {
                claim_no: claim_no,
                claim_ctype: claim_ctype_id
            }
        })
        .success(function (data, status, headers, config) {
            if (data.success)
                window.location.href = URL_HOMEPAGE;
        });
    };

    $scope.query = function (claim_no, claim_ctype_id, query_type, notes) {
        $http({
            url: URL_AJAX_QUERY,
            method: 'POST',
            data: {
                claim_no: claim_no,
                claim_ctype: claim_ctype_id,
                query_type: query_type,
                notes: notes
            }
        })
        .success(function (data, status, headers, config) {
            if (data.success)
                window.location.href = URL_HOMEPAGE;
        });
    };
});

uiBootstrapApp.controller('DateCtrl', function ($scope, $filter, DataAdvanceForm) {

    /*************** DatePicker Start ***************/
    $scope.dateFromToday = function() {
        $scope.dateFrom = new Date();
    };

    $scope.dateToToday = function() {
        $scope.dateTo = new Date();
    };

    $scope.dateFromOpen = function($event) {
        $scope.dateFromStatus.opened = true;
    };

    $scope.dateToOpen = function($event) {
        $scope.dateToStatus.opened = true;
    };

    $scope.setDateFrom = function(year, month, day) {
        $scope.dateFrom = new Date(year, month, day);
    };

    $scope.setDateTo = function(year, month, day) {
	$scope.dateTo = new Date(year, month, day);
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.dateFromStatus = {
        opened: false
    };

    $scope.dateToStatus = {
        opened: false
    };

    $scope.dateFromChanged = function(){
	DataAdvanceForm.setDateFrom($scope.dateFrom);
    };

    $scope.dateToChanged = function(){
	DataAdvanceForm.setDateTo($scope.dateTo);
    };

    $scope.$watch(function () { return DataAdvanceForm.getDateFrom(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.dateFrom = newValue;
        }
    });

    $scope.$watch(function () { return DataAdvanceForm.getDateTo(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.dateTo = newValue;
        }
    });

    /*************** DatePicker End ***************/
});

uiBootstrapApp.controller('AdvanceFormCtrl', function($scope, $http, DataMain, DataFundType, DataLookup, DataAdvanceForm, DataAmountRequired){
    $scope.initAdvanceFormCtrl = function (adv_type, jsonCountryList, jsonCurrencyList) {
	console.log('init Advance Form Ctrl');

	$scope.countryList = [];
	$scope.country = {};
	$scope.currencyList = [];
	$scope.currency = {};

	if (adv_type == 'Oversea') {
	    getAngularObjFromJson(jsonCountryList).forEach(function (obj) {
		var val = obj['pk'];
		var txt = obj['code'] + ' - ' + obj['name'];
		$scope.countryList.push({value:val, label:txt});
	    });

	    getAngularObjFromJson(jsonCurrencyList).forEach(function (obj) {
		var val = obj['pk'];
		var txt = obj['code'] + ' - ' + obj['name'];
		$scope.currencyList.push({value:val, label:txt});
	    });
	}

	if (adv_type == 'Local') {
            $scope.showLocal = true;
	    $scope.showOversea = false;
        }
	else
	{
	    $scope.showLocal = false;
	    $scope.showOversea = true;
	}

	DataAdvanceForm.setShowLocal($scope.showLocal);
	changeItemVal('showLocal');
	DataAdvanceForm.setShowOversea($scope.showOversea);
	changeItemVal('showOversea');
    };

    var changeItemVal = function(obj) {
	if (obj == 'showLocal') {
	    $scope.showLocal = DataAdvanceForm.getShowLocal();
	    DataMain.setShowLocal($scope.showLocal);
	}
	else if (obj == 'showOversea') {
	    $scope.showOversea = DataAdvanceForm.getShowOversea();
	    DataMain.setShowOversea($scope.showOversea);
	}
	else if (obj == 'contactNo') {
            DataAdvanceForm.setContactNo($scope.contactNo);
        }
	else if (obj == 'dateFrom') {
	    $scope.dateFrom = DataAdvanceForm.getDateFrom();
	    $scope.dateFromTxt = DataAdvanceForm.getDateFromTxt();
	}
	else if (obj == 'dateTo') {
	    $scope.dateTo = DataAdvanceForm.getDateTo();
	    $scope.dateToTxt = DataAdvanceForm.getDateToTxt();
	}
	else if (obj == 'advFundType') {
            DataAdvanceForm.setAdvFundType(DataFundType.getFundType());
        }
	else if (obj == 'advProjectCode') {
            DataAdvanceForm.setAdvProjectCode(DataLookup.getProjectCode());
        }
	else if (obj == 'activityPurpose') {
            DataAdvanceForm.setActivityPurpose($scope.activityPurpose);
        }
	else if (obj == 'country') {
            DataAdvanceForm.setCountry($scope.country);
        }
	else if (obj == 'currency') {
            DataAdvanceForm.setCurrency($scope.currency);
        }
	else if (obj == 'currencyRateID') {
            DataAdvanceForm.setCurrencyRateID($scope.currencyRateID);
        }
	else if (obj == 'currencyRate') {
            DataAdvanceForm.setCurrencyRate($scope.currencyRate);
        }
    };

    $scope.$watch('contactNo', function(newValue, oldValue){
        if (newValue != oldValue) {
	    changeItemVal('contactNo');
	}
    });

    $scope.$watch(function () { return DataAdvanceForm.getDateFrom(); }, function (newValue, oldValue) {
        changeItemVal('dateFrom');
    });

    $scope.$watch(function () { return DataAdvanceForm.getDateTo(); }, function (newValue, oldValue) {
        changeItemVal('dateTo');
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('advFundType');
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('advProjectCode');
    });

    $scope.$watch('activityPurpose', function(newValue, oldValue){
	if (newValue != oldValue) {
	    changeItemVal('activityPurpose');
	}
    });

    $scope.$watch('country', function(newValue, oldValue){
        if (newValue != oldValue) {
	    changeItemVal('country');
        }
    });

    $scope.$watch('currency', function(newValue, oldValue){
        if (newValue != oldValue) {
	    changeItemVal('currency');
	    var selectDate = DataAdvanceForm.getDateFromTxt();
	    var selectCurrency = $scope.currency.value;
	    //console.log(selectDate + ' ' + selectCurrency);

	    $http({
		url: GET_CURRENCY_URL+ '?selectCurrency=' +selectCurrency+ '&selectDate=' +selectDate,
		method: 'GET'
	    })
	    .success(function (data, status, headers, config) {
		getAngularObjFromJson(data).forEach(function (obj) {
		    var pk = obj['pk'];
		    var rate = obj['rate'];
		    $scope.currencyRateID = pk;
		    $scope.currencyRate = rate;
		});
		changeItemVal('currencyRateID');
		changeItemVal('currencyRate');
	    });
        }
    });
});

uiBootstrapApp.controller('GuestListCtrl', function($scope, $location, $anchorScroll, DataMain, DataGuestList){
    $scope.initGuestListCtrl = function (jsonGuestItems) {
        $scope.guestItems = [];

	/* Start : General Config for Smart Table */
	$scope.pageSize = 5;
	$scope.currentPage = 1;
        /* End : General Config for Smart Table */

        setEmptyTable();
        $scope.isDBMode = false;
        if (jsonGuestItems) {
            $scope.isDBMode = true;
            getAngularObjFromJson(jsonGuestItems).forEach(function (obj) {
                $scope.addItemDB(obj);
            });
        }
    };

    var setEmptyTable = function() {
        $scope.currIndex = '';
        $scope.isEmptyTable = true;
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    var setEditMode = function(itemIndex){
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };

    var setRow = function() {
        return {
            guestName: $scope.guestName,
	    companyName: $scope.companyName
        };
    };

    var setRowDB = function(obj) {
        var i = obj['fields'];
        var guest_name = i['guest_name'];
	var company_name = i['company_name'];

        return {
            guestName: guest_name,
            companyName: company_name
        };
    };

    var setForm = function(currItem) {
        $scope.guestName = currItem.guestName;
	$scope.companyName = currItem.companyName;
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode && !$scope.isDBMode) {
            var currItem = getItems($scope.currIndex);
            if (obj == 'guestName') {
                currItem.guestName = $scope.guestName;
            }
	    else if (obj == 'companyName') {
                currItem.companyName = $scope.companyName;
            }
        }
    };

    var getItems = function(itemIndex){
        var obj = [];
        if (itemIndex == undefined) {
            obj = $scope.guestItems;
        }else{
            obj = $scope.guestItems[itemIndex];
        }
        return obj;
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

    $scope.addItem = function(){
        getItems().push(setRow());
        $scope.isEmptyTable = false;
    };

    $scope.addItemDB = function(obj){
        $scope.isEmptyTable = false;
        getItems().push(setRowDB(obj));
    };

    $scope.deleteItem = function(itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
    };

    $scope.editItem = function(itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        var currItem = $scope.guestItems[index];
        setForm(currItem);
        $scope.isEditMode = true;
        $scope.openModal();
    };

    $scope.openModal = function(){
        $('#guestModalForm').modal('show');
    };

    $scope.$watch('guestName', function(newValue, oldValue){
        changeItemVal('guestName');
    });

    $scope.$watch('companyName', function(newValue, oldValue){
        changeItemVal('companyName');
    });

    $scope.$watch('guestItems', function() {
        DataMain.setGuestItems($scope.guestItems);
    }, true);

});

uiBootstrapApp.controller('AmountRequiredCtrl', function($scope, DataMain, DataAdvanceForm, DataAmountRequired){
    var changeItemVal = function(obj) {
	if (obj == 'amountRequired') {
	    DataAmountRequired.setAmountRequired($scope.amountRequired);
	}
	else if (obj == 'foreignAmount') {
	    DataAmountRequired.setForeignAmount($scope.foreignAmount);
	}
    };

    $scope.$watch('amountRequired', function(newValue, oldValue){
	if (newValue != oldValue) {
	    changeItemVal('amountRequired');
	    var getOversea = DataMain.getShowOversea();
	    if (getOversea == true) {
                calculateForeignAmount();
            }
	}
    });

    $scope.$watch(function () { return DataAdvanceForm.getCurrencyRate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
	    var getOversea = DataMain.getShowOversea();
	    if (getOversea == true) {
                calculateForeignAmount();
            }
	}
    });

    var calculateForeignAmount = function () {
	var rate = DataAdvanceForm.getCurrencyRate();
	var amount = $scope.amountRequired;

	var foreignRate = get2Float(amount) * parseFloat(rate);
	$scope.foreignAmount = get2Float(foreignRate);
	changeItemVal('foreignAmount');

    };
});

uiBootstrapApp.factory('DataMain', function () {
    var data = {
		    showLocal:false,
		    showOversea:false,
		    guestItems:[],
                    error_validation:'',
                    claimant_no:'',
                    draft_id:'',
                    claim_id:''
            };
    return {
	getShowLocal: function () {
            return data.showLocal;
        },
        setShowLocal: function (obj) {
            data.showLocal = obj;
        },
	getShowOversea: function () {
            return data.showOversea;
        },
        setShowOversea: function (obj) {
            data.showOversea = obj;
        },
	getGuestItems: function () {
            return data.guestItems;
        },
        setGuestItems: function (obj) {
            data.guestItems = obj;
        },
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (obj) {
            data.error_validation = obj;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        }
    };
});

uiBootstrapApp.factory('DataAdvanceForm', function ($filter) {
    var data = {
	showLocal:false,
	showOversea:false,
	contactNo:'',
	dateFrom:'',
	dateFromTxt:'-',
	dateTo:'',
	dateToTxt:'-',
	advFundType:'',
	advProjectCode:'',
	activityPurpose:'',
	country:'',
	currency:'',
	currencyRateID:'',
	currencyRate:''
    };
    return {
	getShowLocal: function () {
            return data.showLocal;
        },
        setShowLocal: function (obj) {
            data.showLocal = obj;
        },
	getShowOversea: function () {
            return data.showOversea;
        },
        setShowOversea: function (obj) {
            data.showOversea = obj;
        },
	getContactNo: function () {
            return data.contactNo;
        },
        setContactNo: function (obj) {
            data.contactNo = obj;
        },
	getDateFrom: function () {
	    return data.dateFrom;
	},
	getDateFromTxt: function () {
	    return data.dateFromTxt;
	},
	setDateFrom: function (obj) {
	    var minDate = $filter('date')(obj, 'yyyy-M-dd');
	    data.dateFrom = obj;
	    data.dateFromTxt = minDate;
	},
	getDateTo: function () {
	    return data.dateTo;
	},
	getDateToTxt: function () {
	    return data.dateToTxt;
	},
	setDateTo: function (obj) {
	    var minDate = $filter('date')(obj, 'yyyy-M-dd');
	    data.dateTo = obj;
	    data.dateToTxt = minDate;
	},
	getAdvFundType: function () {
	    return data.advFundType;
	},
	setAdvFundType: function (obj) {
	    data.advFundType = obj;
	},
	getAdvProjectCode: function () {
	    return data.advProjectCode;
	},
	setAdvProjectCode: function (obj) {
	    data.advProjectCode = obj;
	},
	getActivityPurpose: function () {
	    return data.activityPurpose;
	},
	setActivityPurpose: function (obj) {
	    data.activityPurpose = obj;
	},
	getCountry: function () {
	    return data.country;
	},
	setCountry: function (obj) {
	    data.country = obj;
	},
	getCurrency: function () {
	    return data.currency;
	},
	setCurrency: function (obj) {
	    data.currency = obj;
	},
	getCurrencyRateID: function () {
	    return data.currencyRateID;
	},
	setCurrencyRateID: function (obj) {
	    data.currencyRateID = obj;
	},
	getCurrencyRate: function () {
	    return data.currencyRate;
	},
	setCurrencyRate: function (obj) {
	    data.currencyRate = obj;
	}
    };
});

uiBootstrapApp.factory('DataGuestList', function () {

    var data = {
        guestItems : []
    };

    return {
        getGuestItems: function () {
            return data.guestItems;
        },
        setGuestItems: function (obj) {
            data.guestItems = obj;
        }
    };
});

uiBootstrapApp.factory('DataAmountRequired', function () {

    var data = {
        amountRequired : '0.00',
	foreignAmount : '0.00'
    };

    return {
        getAmountRequired: function () {
            return data.amountRequired;
        },
        setAmountRequired: function (obj) {
            data.amountRequired = obj;
        },
	getForeignAmount: function () {
            return data.foreignAmount;
        },
        setForeignAmount: function (obj) {
            data.foreignAmount = obj;
        }
    };
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataMain', 'DataAdvanceForm', 'DataAmountRequired','DataDocumentList', function ($scope, $uibModal, $http, $window, DataMain, DataAdvanceForm, DataAmountRequired, DataDocumentList) {

    $scope.animationsEnabled = true;

    $scope.submit = function(btnMode) {
	console.log(btnMode);

	form_data = {
	    btn_mode:btnMode,
	    contactNo:DataAdvanceForm.getContactNo(),
	    dateFrom:DataAdvanceForm.getDateFrom(),
	    dateFromTxt:DataAdvanceForm.getDateFromTxt(),
	    dateTo:DataAdvanceForm.getDateTo(),
	    dateToTxt:DataAdvanceForm.getDateToTxt(),
	    advFundType:DataAdvanceForm.getAdvFundType(),
	    advProjectCode:DataAdvanceForm.getAdvProjectCode(),
	    activityPurpose:DataAdvanceForm.getActivityPurpose(),
	    amountRequired:get2Float(DataAmountRequired.getAmountRequired()),
	    country:DataAdvanceForm.getCountry(),
	    currency:DataAdvanceForm.getCurrency(),
	    currencyRateID:DataAdvanceForm.getCurrencyRateID(),
	    currencyRate:DataAdvanceForm.getCurrencyRate(),
	    foreignAmount:get2Float(DataAmountRequired.getForeignAmount()),
	    guestItems:DataMain.getGuestItems(),
	    claimant_no:DataMain.getClaimantNo(),
	    draft_id:DataMain.getDraftID(),
	    document_list:DataDocumentList.getDocumentList()
	}

	if ($scope.filtering.assignee)
	    form_data.assignee = $scope.filtering.assignee.staff_no;

	var instance_controller = '';

	if (btnMode == 'save_draft') {
	    instance_controller = 'ModalInstanceSaveCtrl';
	    ng_template = 'SaveConformation.html';
	}else if (btnMode == 'submit'){
	    instance_controller = 'ModalInstanceSubmitCtrl';
	    ng_template = 'SubmitConformation.html';
	}

	var modalInstance = $uibModal.open({
	    animation: $scope.animationsEnabled,
	    templateUrl: ng_template,
	    controller: instance_controller,
	    size: 'sm',
	    resolve: {
		data: function () {
		    return form_data;
		}
	    }
	});

	modalInstance.result.then(
	    function () {
		console.log('OK, conformation box closed');

		if (PK && $scope.claim.query) {  // Re-submission
		    var params = {
			claim_no: $scope.claim.claim_no,
			claim_ctype: $scope.claim.claim_ctype_id
		    };

		    $http({
			url: URL_AJAX_RESUBMIT_TO,
			method: 'POST',
			data: params
		    })
		    .success(function (data, status, headers, config) {
			$window.location.href = URL_HOMEPAGE;
		    });
		}
		else
		{
		    $http({
			url: '',
			method: 'POST',
			data: form_data
		    })
		    .success(function (data, status, headers, config) {
			console.log(data);
			var submit_success_url = data.submit_success_url;

			if (btnMode == 'submit') {
			    $window.location.href = submit_success_url;
			}
			else if (btnMode == 'save_draft') {
			    $scope.initSubmitCtrl(data.draft_id);
			    $uibModal.open({
				animation: $scope.animationsEnabled,
				templateUrl: 'SaveSuccess.html',
				controller: 'ModalInstanceInfoCtrl',
				size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
				resolve: {
				    data: function () {
					return data;
				  }
				}
			    });
			}
		    });
		}
	    },
	    function () {
		console.log('Cancel, conformation box closed');
	    }
	);
    };

    $scope.initSubmitCtrl = function(draft_id){
	$scope.draft_id = draft_id;
	DataMain.setDraftID(draft_id);
    };
}]);
