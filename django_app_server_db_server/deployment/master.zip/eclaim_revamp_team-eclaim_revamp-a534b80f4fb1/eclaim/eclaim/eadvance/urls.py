from django.conf.urls import patterns, url

from .views import LocalEntertainmentAdvanceIndexView, LocalEntertainmentAdvanceDetailView, \
                   OverseaEntertainmentAdvanceIndexView, OverseaEntertainmentAdvanceDetailView, \
                   get_currency_rate

urlpatterns = patterns('',
    url(r'^eadvance/local/$', LocalEntertainmentAdvanceIndexView.as_view(), name='localentertainment_index'),
    url(r'^eadvance/local/detail/$', LocalEntertainmentAdvanceDetailView.as_view(), name='localentertainment_detail'),
    url(r'^eadvance/oversea/$', OverseaEntertainmentAdvanceIndexView.as_view(), name='overseaentertainment_index'),
    url(r'^eadvance/oversea/detail/$', OverseaEntertainmentAdvanceDetailView.as_view(), name='overseaentertainment_detail'),
    url(r'^eadvance/oversea/get_currency_rate/$',get_currency_rate,name='get_currency_rate')
)