import json
import datetime

from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text
from django.contrib.contenttypes.models import ContentType

from moneyed import get_currency, CurrencyDoesNotExist

from eclaim.auth.authenticate import Authenticate
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import AngularUpdateAndDetailView
from eclaim.settings.models import Country, Currency, CurrencyRate
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.utils import get_document_list

from eclaim.utils.common import get_claim_type_code, get_claim_type_prefix, \
                                get_json_from_set_obj, get_json_from_list

from .models import LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE, OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE, \
                    LocalEntertainmentAdvance, LocalEntertainmentGuestList, \
                    OverseaEntertainmentAdvance, OverseaEntertainmentGuestList

from .processes import entertainment_advance_process


__LocalClaimType__ = get_claim_type_code(LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE)
__LocalClaimPrefix__ = get_claim_type_prefix(LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE)
__OverseaClaimType__ = get_claim_type_code(OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE)
__OverseaClaimPrefix__ = get_claim_type_prefix(OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE)


class LocalEntertainmentAdvanceIndexView(TemplateView):
    """
    This is index page for Local Entertainment Advance.
    """
    template_name = 'eadvance/entertainment_advance.html'
    
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(LocalEntertainmentAdvanceIndexView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')
        
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(LocalEntertainmentAdvanceIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None
            
        rate_entitled = None
        adv_type = 'Local'
            
        context['claimant'] = claimant
        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        context['json_rate'] = rate_entitled
        context['adv_type'] = adv_type
        context['DOC_LIST'] = get_document_list(__LocalClaimType__)
        return context
    
    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        print form_data
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = entertainment_advance_process(btn_mode, 'local', form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, LocalEntertainmentAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, LocalEntertainmentAdvance, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")
    
class LocalEntertainmentAdvanceDetailView(AngularUpdateAndDetailView):
    """
    This is detail view for Local Entertainment Advances.
    """
    model = LocalEntertainmentAdvance
    template_name = 'eadvance/entertainment_advance.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(LocalEntertainmentAdvanceDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None
        
        rate_entitled = None
        adv_type = 'Local'

        context['claimant'] = claimant
        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        context['json_rate'] = rate_entitled
        context['adv_type'] = adv_type
        context['DOC_LIST'] = get_document_list(__LocalClaimType__)
        
        obj_pk = self.request.GET['pk']
        advance = LocalEntertainmentAdvance.objects.get(pk=obj_pk)
        doclist = get_document_list_item(advance.claim_no, __LocalClaimType__)
        document_list = get_json_from_set_obj(doclist)

        context['claim_no'] = advance.claim_no
        context['json_documentlist'] = document_list

        return context
    
def get_name(obj):
    try:
        return get_currency(obj.currency).name
    except CurrencyDoesNotExist:
        return obj.currency
    
class OverseaEntertainmentAdvanceIndexView(TemplateView):
    """
    This is index page for Oversea Entertainment Advance.
    """
    template_name = 'eadvance/entertainment_advance.html'
    
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(OverseaEntertainmentAdvanceIndexView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')
        
    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(OverseaEntertainmentAdvanceIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None
            
        rate_entitled = None
        adv_type = 'Oversea'
            
        context['claimant'] = claimant
        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        
        country_list = []
        for country in Country.objects.all().order_by('country'):
            data = {
                'pk': country.pk,
                'code': country.country.code,
                'name': unicode(country)
            }
            country_list.append(data)
        
        context['jsonCountryList'] = json.dumps(country_list)
        
        currency_list = []
        for currency in Currency.objects.all().order_by('currency'):
            data = {
                'pk': currency.pk,
                'code': currency.currency,
                'name': get_name(currency)
            }
            currency_list.append(data)
            
        context['jsonCurrencyList'] = json.dumps(currency_list)
        
        context['json_rate'] = rate_entitled
        context['adv_type'] = adv_type
        context['DOC_LIST'] = get_document_list(__OverseaClaimType__)
        return context
    
    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        print form_data
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = entertainment_advance_process(btn_mode, 'oversea', form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, OverseaEntertainmentAdvance, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaEntertainmentAdvance, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")
    
class OverseaEntertainmentAdvanceDetailView(AngularUpdateAndDetailView):
    """
    This is detail view for Oversea Entertainment Advances.
    """
    model = OverseaEntertainmentAdvance
    template_name = 'eadvance/entertainment_advance.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(OverseaEntertainmentAdvanceDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None
        
        rate_entitled = None
        adv_type = 'Oversea'

        context['claimant'] = claimant
        context['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        context['json_rate'] = rate_entitled
        context['adv_type'] = adv_type
        context['DOC_LIST'] = get_document_list(__OverseaClaimType__)
        
        obj_pk = self.request.GET['pk']
        advance = OverseaEntertainmentAdvance.objects.get(pk=obj_pk)
        doclist = get_document_list_item(advance.claim_no, __OverseaClaimType__)
        document_list = get_json_from_set_obj(doclist)

        context['claim_no'] = advance.claim_no
        context['json_documentlist'] = document_list

        return context
    
def get_currency_rate(request):
    if request.method == 'POST':
        form_data = request.POST
    else:
        form_data = request.GET
        
    selectDate = None
    selectCurrency = None
    currency_rate = []
    if (form_data['selectCurrency'] != ''):
        selectCurrency = Currency.objects.get(pk=form_data['selectCurrency'])
        if (form_data['selectDate'] != '' and form_data['selectDate'] != '-'):
            selectDate = datetime.datetime.strptime(form_data['selectDate'], "%Y-%m-%d")
        else:
            selectDate = datetime.date.today()
            
        for rate in CurrencyRate.objects.filter(date__lte=selectDate,currency=selectCurrency).order_by('-date')[:1]:
            data = {
                'pk': rate.pk,
                'rate': str(rate.value)
            }
            currency_rate.append(data)
            
    return HttpResponse(json.dumps(currency_rate))