from decimal import *
from django.db import models
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.common import CLAIM_STATUS
from eclaim.settings.models import Country, Currency, CurrencyRate

#claim_type pk for Local Entertainment Advance is 14
LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE=14
#claim_type pk for Oversea Entertainment Advance is 18
OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE=18

class EntertainmentAdvanceAbstract(models.Model):
    status = models.CharField(max_length=CLAIM_STATUS.DEFAULT_LENGTH)
    contact_no = models.CharField(max_length=25, null=True)
    date_from = models.DateField()
    date_to = models.DateField()
    fund_type = models.ForeignKey(FundType, null=True, blank=True)
    project_code = models.CharField(max_length=10, null=True)
    purpose = models.TextField(null=True, blank=True)
    amount_required = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    apply_date = models.DateField()

    class Meta:
        app_label = 'eadvance'
        abstract = True
        
class GuestListAbstract(models.Model):
    guest_name = models.TextField()
    guest_company = models.TextField()
    
    class Meta:
        app_label = 'eadvance'
        abstract = True
        
class LocalEntertainmentAdvance(EntertainmentAdvanceAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)
    
    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE)

    class Meta(EntertainmentAdvanceAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Local Entertainment Advance'
        verbose_name_plural = verbose_name
        ordering = ['id']
        
    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('localentertainment_detail'), self.pk)
        
class LocalEntertainmentGuestList(GuestListAbstract):
    advance = models.ForeignKey(LocalEntertainmentAdvance, null=True, blank=True)

    class Meta(GuestListAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Local Entertainment Advance Guest List'
        verbose_name_plural = verbose_name
        
class LocalEntertainmentAdvanceDraft(EntertainmentAdvanceAbstract):

    class Meta(EntertainmentAdvanceAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Local Entertainment Advance Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
        
class LocalEntertainmentGuestListDraft(GuestListAbstract):
    advance_draft = models.ForeignKey(LocalEntertainmentAdvanceDraft, null=True, blank=True)

    class Meta(GuestListAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Local Entertainment Advance Guest List Draft'
        verbose_name_plural = verbose_name
        
        
class OverseaEntertainmentAdvance(EntertainmentAdvanceAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)
    country = models.ForeignKey(Country, null=True, blank=True)
    currency_type = models.ForeignKey(Currency, null=True, blank=True)
    currency_rate = models.ForeignKey(CurrencyRate, null=True, blank=True)
    rate = models.DecimalField(max_digits=9, decimal_places=6, default=Decimal('0.00'))
    foreign_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    
    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE)

    class Meta(EntertainmentAdvanceAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Oversea Entertainment Advance'
        verbose_name_plural = verbose_name
        ordering = ['id']
        
    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('overseaentertainment_detail'), self.pk)
        
class OverseaEntertainmentGuestList(GuestListAbstract):
    advance = models.ForeignKey(OverseaEntertainmentAdvance, null=True, blank=True)

    class Meta(GuestListAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Oversea Entertainment Advance Guest List'
        verbose_name_plural = verbose_name
    
class OverseaEntertainmentAdvanceDraft(EntertainmentAdvanceAbstract):
    country = models.ForeignKey(Country, null=True, blank=True)
    currency_type = models.ForeignKey(Currency, null=True, blank=True)
    currency_rate = models.ForeignKey(CurrencyRate, null=True, blank=True)
    rate = models.DecimalField(max_digits=9, decimal_places=6, default=Decimal('0.00'))
    foreign_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))

    class Meta(EntertainmentAdvanceAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Oversea Entertainment Advance Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
        
class OverseaEntertainmentGuestListDraft(GuestListAbstract):
    advance_draft = models.ForeignKey(OverseaEntertainmentAdvanceDraft, null=True, blank=True)

    class Meta(GuestListAbstract.Meta):
        app_label = 'eadvance'
        verbose_name = 'Oversea Entertainment Advance Guest List Draft'
        verbose_name_plural = verbose_name