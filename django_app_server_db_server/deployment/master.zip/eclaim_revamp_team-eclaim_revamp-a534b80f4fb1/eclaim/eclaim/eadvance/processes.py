import datetime
from decimal import *

from eclaim.settings.models import Country, Currency, CurrencyRate
from eclaim.masterfiles.models.misc import FundType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.utils import save_claimant_history, save_document_list_item_draft, save_document_list_item
from eclaim.utils.common import generate_claim_no, get_claim_type_code, get_claim_type_prefix

from .models import LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE, OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE, \
                    LocalEntertainmentAdvance, LocalEntertainmentGuestList, \
                    LocalEntertainmentAdvanceDraft, LocalEntertainmentGuestListDraft, \
                    OverseaEntertainmentAdvance, OverseaEntertainmentGuestList, \
                    OverseaEntertainmentAdvanceDraft, OverseaEntertainmentGuestListDraft
                    
__LocalClaimType__ = get_claim_type_code(LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE)
__LocalClaimPrefix__ = get_claim_type_prefix(LOCAL_ENTERTAINMENT_ADV_CLAIM_TYPE)
__OverseaClaimType__ = get_claim_type_code(OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE)
__OverseaClaimPrefix__ = get_claim_type_prefix(OVERSEA_ENTERTAINMENT_ADV_CLAIM_TYPE)

def entertainment_advance_process(btn_mode, adv_type, form_data):
    draft_id = None
    claim_id = None

    if btn_mode in ['save_draft']:
        draft_id = save_draft(adv_type, form_data)
        print 'Save Draft Completed!!!'
    elif btn_mode in ['submit']:
        claim_id = submit_advance(adv_type, form_data)
        print 'Submit Claim Completed!!!'

    return draft_id, claim_id

def save_draft(adv_type, form_data):
    draft_id = form_data.get('draft_id')

    if draft_id == '' or draft_id == None:
        if adv_type == 'local':
            adv_draft = LocalEntertainmentAdvanceDraft()
        else:
            adv_draft = OverseaEntertainmentAdvanceDraft()
        adv_draft.status = 'D'
        adv_draft.date_from = datetime.datetime.strptime(form_data.get('dateFromTxt'), "%Y-%m-%d")
        adv_draft.date_to = datetime.datetime.strptime(form_data.get('dateToTxt'), "%Y-%m-%d")
        adv_draft.apply_date = datetime.date.today()
        adv_draft.save()
        
        save_ent_advance_data('save', adv_draft, adv_type, form_data)
        save_guest_list('save', adv_draft, adv_type, form_data)
        if adv_type == 'local':
            save_document_list_item_draft(adv_draft.id, __LocalClaimType__, form_data)
        else:
            save_document_list_item_draft(adv_draft.id, __OverseaClaimType__, form_data)
        return adv_draft.id
    
    else:
        if adv_type == 'local':
            adv_draft = LocalEntertainmentAdvanceDraft(id=int(draft_id))
        else:
            adv_draft = OverseaEntertainmentAdvanceDraft(id=int(draft_id))
        adv_draft.date_from = datetime.datetime.strptime(form_data.get('dateFromTxt'), "%Y-%m-%d")
        adv_draft.date_to = datetime.datetime.strptime(form_data.get('dateToTxt'), "%Y-%m-%d")
        adv_draft.apply_date = datetime.date.today()
        adv_draft.save()
        
        save_ent_advance_data('save', adv_draft, adv_type, form_data)
        save_guest_list('save', adv_draft, adv_type, form_data)
        if adv_type == 'local':
            save_document_list_item_draft(adv_draft.id, __LocalClaimType__, form_data)
        else:
            save_document_list_item_draft(adv_draft.id, __OverseaClaimType__, form_data)
        return draft_id
    
def submit_advance(adv_type, form_data):
    claimant_no = form_data.get('claimant_no')
    
    if adv_type == 'local':
        advance = LocalEntertainmentAdvance()
    else:
        advance = OverseaEntertainmentAdvance()
    advance.status = 'S'
    advance.date_from = datetime.datetime.strptime(form_data.get('dateFromTxt'), "%Y-%m-%d")
    advance.date_to = datetime.datetime.strptime(form_data.get('dateToTxt'), "%Y-%m-%d")
    advance.apply_date = datetime.date.today()
    advance.save()
    
    if adv_type == 'local':
        advance.claim_no = generate_claim_no(__LocalClaimPrefix__, advance.id)
    else:
        advance.claim_no = generate_claim_no(__OverseaClaimPrefix__, advance.id)
    advance.save()
    
    save_ent_advance_data('submit', advance, adv_type, form_data)
    save_guest_list('submit', advance, adv_type, form_data)
    if adv_type == 'local':
        save_claimant_history(claimant_no, advance.id, __LocalClaimType__)
        save_document_list_item(advance.claim_no, __LocalClaimType__, form_data)
    else:
        save_claimant_history(claimant_no, advance.id, __OverseaClaimType__)
        save_document_list_item(advance.claim_no, __OverseaClaimType__, form_data)
    return advance.id
    
def save_ent_advance_data(mode, advance, adv_type, form_data):
    saveObj = advance
    saveObj.contact_no = form_data.get('contactNo')
    saveObj.fund_type = FundType.objects.get(code=form_data['advFundType'].get('code'))
    saveObj.project_code = form_data.get('advProjectCode')
    saveObj.purpose = form_data.get('activityPurpose')
    saveObj.amount_required = Decimal(form_data.get('amountRequired'))
    
    if adv_type == 'oversea':
        saveObj.country = Country.objects.get(pk=form_data['country'].get('value'))
        saveObj.currency_type = Currency.objects.get(pk=form_data['currency'].get('value'))
        saveObj.currency_rate = CurrencyRate.objects.get(pk=form_data.get('currencyRateID'))
        saveObj.rate = Decimal(form_data.get('currencyRate'))
        saveObj.foreign_amount = Decimal(form_data.get('foreignAmount'))
    saveObj.save()
    
def save_guest_list(mode, parent, adv_type, form_data):

    for i in form_data.get('guestItems'):
        print '>>>', i
        guest_name = i['guestName']
        guest_company = i['companyName']

        if mode in ['save']:
            if adv_type == 'local':
                saveObj = LocalEntertainmentGuestListDraft()
            else:
                saveObj = OverseaEntertainmentGuestListDraft()
            saveObj.advance_draft = parent
            
        elif mode in ['submit']:
            if adv_type == 'local':
                saveObj = LocalEntertainmentGuestList()
            else:
                saveObj = OverseaEntertainmentGuestList()
            saveObj.advance = parent

        saveObj.guest_name = guest_name
        saveObj.guest_company = guest_company
        saveObj.save()