from django.conf import settings
from eclaim.libs.permissions import (
    get_user_permissions, is_implementer, is_admin, is_in_workflow_group)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'user_roles',
    'permissions'
    ]


def user_roles(request):
    user = request.user
    roles = {
        'IS_IMPLEMENTER': is_implementer(user),
        'IS_ADMIN': is_admin(user),
        'IS_IN_WORKFLOW_GROUP': is_in_workflow_group(user)
        }
    if settings.DEBUG:
        print ">>> User Roles:", roles
    return roles


def permissions(request):
    perms = get_user_permissions(request.user)
    if settings.DEBUG:
        print ">>> User Permissions:", perms
    return perms
