from django.utils.translation import ugettext_lazy as _
from .models.company import ExpensesType
from .models.default_attribute import (
    CLAIM_TYPE_MAX_LENGTH, CLAIM_STATUS_MAX_LENGTH)

__all__ = ['CLAIM_STATUS', 'CLAIM_TYPE', 'SUMMARY']


class CLAIM_STATUS(object):
    DEFAULT_LENGTH = CLAIM_STATUS_MAX_LENGTH

    DRAFT = 'D'
    NEW = 'N'
    PENDING = 'P'
    REVIEWED = 'W'
    VERIFIED = 'V'
    APPROVED = 'A'
    CANCELLED = 'F'
    RETURNED = 'B'
    READY = 'R'
    HELD = 'H'
    QUERY = 'Q'
    SUBMITTED = 'S'
    CLOSED = 'C'
    REJECTED = 'J'

    CHOICES = (
        (DRAFT, _(u'DRAFT')),
        (NEW, _(u'NEW')),
        (PENDING, _(u'PENDING')),
        (REVIEWED, _(u'REVIEWED')),
        (VERIFIED, _(u'VERIFIED')),
        (APPROVED, _(u'APPROVED')),
        (CANCELLED, _(u'CANCELLED')),
        (RETURNED, _(u'AMEND')),
        (READY, _(u'READY')),
        (HELD, _(u'HELD')),
        (QUERY, _(u'QUERY')),
        (SUBMITTED, _(u'SUBMITTED')),
        (CLOSED, _(u'CLOSED')),
        (REJECTED, _(u'REJECTED'))
    )


class CLAIM_TYPE(object):
    DEFAULT_LENGTH = CLAIM_TYPE_MAX_LENGTH

    MADV='MADV'
    LTC='LTC'
    OTC='OTC'
    LMISC='LMISC'
    LFC='LFC'
    TOC='TOC'
    PTL='PTL'
    HM='HM'
    LC='LC'
    LMED='LMED'
    LDEN= 'LDEN'
    OMISC= 'OMISC'
    ODEN= 'ODEN'
    OMED = 'OMED'

    LectureClaimNoPrefix = 'S'
    LocalMiscAdvanceNoPrefix = 'B'
    OverseaMiscAdvanceNoPrefix = 'Z'
    LocalTransferClaimNoPrefix = 'K'
    MiscellaneousNoPrefix = 'O'
    MedicalNoPrefix = 'M'
    MedicaloverseasNoPrefix = 'T'
    DentalNoPrefix = 'N'
    MiscoverseasNoPrefix = 'V'
    DentaloverseasNoPrefix = 'U'

    CHOICES = (
        (MADV, _(u'Local Miscellaneous Advance')),
        (OMISC, _(u'Oversea Miscellaneous Advance')),
        (LTC, _(u'Local Travelling Claim')),
        (OTC, _(u'Oversea Travelling Claim')),
        (LMISC, _(u'Miscellaneous Claim')),
        (LFC, _(u'Local Transfer Claim')),
        (TOC, _(u'Transfer Oversea Claim')),
        (PTL, _(u'Parttime Lecturer Claim')),
        (HM, _(u'House Moving Claim')),
        (LC, _(u'Lecturer Claim')),
        (LMED, _(u'Local Medical Claim')),
        (LDEN, _(u'Local Dental Claim')),
        (ODEN, _(u'Dental overseas claim')),
        (OMED, _(u'Medical Overseas Claim')),
    )


class SUMMARY(object):
    def __init__(self):
        self.LECTURE_CLAIM = [{'seq': 1,'id': 'summary_parttime_lecturer', 'expense_map': 'HONORARIUM01', 'expense_code': '', 'desc': _(u'Total Parttime Lecturer Claim')}
                            , {'seq': 2,'id': 'summary_parttime_fasilitator', 'expense_map': 'HONORARIUM01', 'expense_code': '', 'desc': _(u'Total Parttime Facilitator Claim')}
                            , {'seq': 3,'id': 'summary_corporate_lecturer', 'expense_map': 'HONORARIUM02', 'expense_code': '', 'desc': _(u'Total Corporate Lecturer Claim')}]

        self.LOCAL_TRANSFER_CLAIM = [{'seq': 1,'id': 'summary_transfer_allowance', 'expense_map': 'LocalTransferClaim01', 'expense_code': '', 'desc': _(u'Grand Total Transfer Allowance')}
                                   , {'seq': 2,'id': 'summary_meal_allowance', 'expense_map': 'LocalTransferClaim02', 'expense_code': '', 'desc': _(u'Grand Meal Allowance')}
                                   , {'seq': 3,'id': 'summary_hotel_and_lodging', 'expense_map': 'LocalTransferClaim03', 'expense_code': '', 'desc': _(u'Grand Total Hotel and Lodging')}
                                   , {'seq': 4,'id': 'summary_public_transport', 'expense_map': 'LocalTransferClaim04', 'expense_code': '', 'desc': _(u'Grand Total Public Transport')}
                                   , {'seq': 5,'id': 'summary_mileage', 'expense_map': 'LocalTransferClaim05', 'expense_code': '', 'desc': _(u'Grand Total Mileage')}
                                   , {'seq': 6,'id': 'summary_goods_transportation_fare_land', 'expense_map': 'LocalTransferClaim06', 'expense_code': '', 'desc': _(u'Grand Total Goods Transportation Fare (Land)')}
                                   , {'seq': 7,'id': 'summary_goods_transportation_fare_sea', 'expense_map': 'LocalTransferClaim07', 'expense_code': '', 'desc': _(u'Grand Total Goods Transportation Fare (Sea)')}
                                   , {'seq': 8,'id': 'summary_gst', 'expense_map': 'LocalTransferClaim08', 'expense_code': '', 'desc': _(u'Grand Total GST')}
                                   , {'seq': 9,'id': 'summary_misc_expenses', 'expense_map': 'LocalTransferClaim09', 'expense_code': '', 'desc': _(u'Grand Total Other Miscellaneous Expenses/Miscellaneous Expenses')}]

    def get_summary(self, claim_type):
        summary_list = []
        if claim_type == 'LC':
            self.update_expensecode(self.LECTURE_CLAIM)
            summary_list = self.LECTURE_CLAIM
        elif claim_type == 'LFC':
            self.update_expensecode(self.LOCAL_TRANSFER_CLAIM)
            summary_list = self.LOCAL_TRANSFER_CLAIM
        return summary_list

    def update_expensecode(self, summary_list):
        for i in summary_list:
            code_map = i.get('expense_map')
            try:
                expenses_type = ExpensesType.objects.get(code=code_map)
                if expenses_type:
                    i.update({'expense_code':expenses_type.expense_code})
            except ExpensesType.DoesNotExist:
                print 'mapping '+code_map +' does not exist in table ExpensesType'
