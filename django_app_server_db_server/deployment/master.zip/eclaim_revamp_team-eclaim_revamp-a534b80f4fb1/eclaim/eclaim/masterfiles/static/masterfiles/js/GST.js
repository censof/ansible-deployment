console.log('GST JS Loaded!!!');

uiBootstrapApp.controller('GSTCtrl', function ($scope, $http, DataGST) {


    $scope.initGSTCtrl = function(){
        console.log('Load initGSTCtrl (Default)');
        $scope.GSTType = {};
        $scope.gstTypes = [];

        $http({
            url: API_URL+'gst-tax/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            data.results.forEach(function(obj) {
                $scope.gstTypes = data.results;
                DataGST.setGSTTypes(data.results);
            });
        });
    };

    $scope.$watch('GSTType', function(newValue, oldValue) {
        if (newValue != oldValue && newValue != null) {
            DataGST.setGSTType($scope.GSTType);
            $scope.GSTPercentage = $scope.GSTType.rate;
        }else{
            $scope.GSTPercentage = 0;
            DataGST.setGSTType('');
        }
    });

    $scope.$watch(function () { return DataGST.getGSTType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.GSTType = newValue;
        }
    });
    
    $scope.initGSTCtrl();
});

uiBootstrapApp.factory('DataGST', function () {
    var data = {
        GSTTypes: [],
		GSTType: {}, /* etc SR, ZR */
    };

    return {
        getGSTTypeByCode: function(code){
            /**
             *      To use this function, follow below step:
             *      1) Make sure <div ng-controller="GSTCtrl"></div> is put in your main template.
             */
            var selected = {};
            data.GSTTypes.forEach(function(obj){
                if (code == obj.code){
                    selected = obj;
                }
            });
            return selected;
        },
        setGSTTypes: function(obj){
            data.GSTTypes = obj;
        },
        getGSTType: function () {
            return data.GSTType;
        },
        setGSTType: function (val) {
            data.GSTType = val;
        },
        getGSTFloat: function () {
            return getNumber(data.GSTType.rate) / 100;
        }
    };
});
