console.log('UploadDoc JS Loaded!!!');

uiBootstrapApp.controller('UploadDocCtrl', function($scope, $http, DataFormDoc) {
    $scope.initUploadDocCtrl = function () {
        setEmptyTable();

		$scope.docItems = [];
		//$scope.loadList();
		$scope.$watch(function () { return DataFormDoc.getDBItems(); }, function (newValue, oldValue) {
			if (newValue != oldValue){
				if (newValue.length > 0) {
					newValue.forEach(function(obj){
					  $scope.addItem(obj);
					});
				}
			};
		});
    };

    var setEmptyTable = function() {
        $scope.isEmptyTable = true;
    };

    var getItems = function(index) {
        var obj = [];
        obj = $scope.docItems;
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    $scope.addItem = function(objDB) {
        var items = getItems();
        if (objDB) {
            items.push({doc:DataFormDoc.getDocByID(objDB.document_list_id)});
        }else{
            items.push({});
        }
        $scope.isEmptyTable = false;
    };

    $scope.deleteItem = function(itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
    };
});

uiBootstrapApp.factory('DataFormDoc', function() {
    var data = {
        DocItems: [],
        DocList: [],
        DBItems: [],
    }

    return {
        getDocItems: function() {
            return data.DocItems;
        },
        setDocItems: function(obj) {
            data.DocItems = obj;
        },
        setDocList: function(obj){
            data.DocList = obj;
        },
		getDocByID: function(id){
            var list = [];
            var selected = {};
			list = data.DocList;
            list.forEach(function(obj){
                if (obj.id==id) {
                    selected = obj;
                }
            });
            return selected;
        },
        getDBItems: function(){
            return data.DBItems;
        },
        setDBItems: function(obj){
            data.DBItems = obj;
        },
    }
});