console.log('Claimant JS Loaded!!!');

uiBootstrapApp.controller('ClaimantCtrl', function ($scope, DataClaimant) {
    $scope.initClaimantCtrl = function (staffNo, salaryGrade) {
        DataClaimant.setStaffNo(staffNo);
		DataClaimant.setSalaryGrade(salaryGrade);
    };
});

uiBootstrapApp.factory('DataClaimant', function () {
    var data = {
		StaffNo: '',
		SalaryGrade: ''
    };

    return {
        getStaffNo: function () {
            return data.StaffNo;
        },
        setStaffNo: function (val) {
            data.StaffNo = val;
        },
		getSalaryGrade: function () {
            return data.SalaryGrade;
        },
        setSalaryGrade: function (val) {
            data.SalaryGrade = val;
        }
    };
});