console.log('FundType JS Loaded!!!');

uiBootstrapApp.controller('FundTypeCtrl', function ($scope, $http, DataFundType, DataLookup) {
    
    $scope.initFundTypeCtrl = function(){
        console.log('Load initFundTypeCtrl (Default)');

        $scope.fundType = {};
        $scope.fundTypes = [];

        $http({
			url: API_URL+'fund-type/',
			method: 'GET'
		})
		.success(function (data, status, headers, config) {
            data.results.forEach(function(obj) {
                $scope.fundTypes = data.results;
                DataFundType.setFundTypes(data.results);
            });
		});
    };
    
    $scope.$watch('fundType', function(newValue, oldValue){
        if (newValue != oldValue && $scope.fundType) {
            var is_project = $scope.fundType.is_project;
            DataFundType.setFundType(newValue);
            if (is_project) {
                DataLookup.setDisabled(false);
            }else{
                DataLookup.setDisabled(true);
            }
        }
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.fundType = newValue;
        }
    });
    
    $scope.initFundTypeCtrl();
});

uiBootstrapApp.factory('DataFundType', function () {
    var data = {
        FundTypes: [],
		FundType: {}
    };

    return {
        getFundTypeByCode: function(code){
            /**
             *      To use this function, follow below step:
             *      1) Make sure <div ng-controller="FundTypeCtrl"></div> is put in your main template.
             */
            var fundType = {};
            data.FundTypes.forEach(function(obj){
                if (code == obj.code){
                    fundType = obj;
                }
            });
            return fundType;
        },
        setFundTypes: function(obj){
            data.FundTypes = obj;
        },
        getFundType: function(){
            return data.FundType;
        },
        getFundTypeCode: function(){
            return data.FundType.code;
        },
        setFundType: function(obj){
            data.FundType = obj;
        }
    };
});
