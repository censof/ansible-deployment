console.log('Summary JS Loaded!!!');

uiBootstrapApp.controller('SummaryCtrl', function ($scope, DataSummary) {
    $scope.summary_parttime_lecturer = 0;
    $scope.summary_parttime_fasilitator = 0;
    $scope.summary_corporate_lecturer = 0;
    
	$scope.$watch(function () { return DataSummary.getTotalParttimeLecturer(); }, function (newValue, oldValue) {
		$scope.summary_parttime_lecturer = parseFloat(newValue).toFixed(2);
    });
	$scope.$watch(function () { return DataSummary.getTotalParttimeFacilitator(); }, function (newValue, oldValue) {
		$scope.summary_parttime_fasilitator = parseFloat(newValue).toFixed(2);
    });
	$scope.$watch(function () { return DataSummary.getTotalCorporateLecturer(); }, function (newValue, oldValue) {
		$scope.summary_corporate_lecturer = parseFloat(newValue).toFixed(2);
    });
});

uiBootstrapApp.factory('DataSummary', function () {
    var data = {
		TotalParttimeLecturer: 0,
		TotalParttimeFacilitator: 0,
		TotalCorporateLecturer: 0
    };

    return {
        getTotalParttimeLecturer: function () {
            return data.TotalParttimeLecturer;
        },
        setTotalParttimeLecturer: function (val) {
            data.TotalParttimeLecturer = val;
        },
        getTotalParttimeFacilitator: function () {
            return data.TotalParttimeFacilitator;
        },
        setTotalParttimeFacilitator: function (val) {
            data.TotalParttimeFacilitator = val;
        },
        getTotalCorporateLecturer: function () {
            return data.TotalCorporateLecturer;
        },
        setTotalCorporateLecturer: function (val) {
            data.TotalCorporateLecturer = val;
        }
    };
});