console.log('Endowment JS Loaded!!!');

uiBootstrapApp.controller('EndowmentCtrl', function ($scope, DataEndowment) {

    $scope.$watch(function () { return DataEndowment.getClaimAmount(); }, function (newValue, oldValue) {
    	if (newValue != oldValue) {
    	    $scope.claimAmount = newValue;
    	}
    	calculateTotal();
    });

    $scope.$watch('endowmentAmount', function(newValue, oldValue){
        if (newValue != oldValue) {
    	    changeItemVal('endowmentAmount');
    	    $scope.endowmentAmount = DataEndowment.getEndowmentAmount();
    	    calculateTotal();
    	}
    });

    $scope.$watch(function () { return DataEndowment.getEndowmentAmount(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.endowmentAmount = newValue;
        }
        calculateTotal();
    });

    var changeItemVal = function(obj) {
    	if (obj == 'claimAmount') {
                DataEndowment.setClaimAmount($scope.claimAmount);
            }
    	else if (obj == 'endowmentAmount') {
                DataEndowment.setEndowmentAmount($scope.endowmentAmount);
            }
    	else if (obj == 'netTotal') {
                DataEndowment.setNetTotal($scope.netTotal);
            }
    };

    var calculateTotal = function () {
	var total = 0;
	var claim_amount = parseFloat(DataEndowment.getClaimAmount());
	var endowment = parseFloat(DataEndowment.getEndowmentAmount());
	$scope.claimAmount = get2Float(claim_amount);
	$scope.endowmentAmount = get2Float(endowment);

	total = get2Float(parseFloat(claim_amount) - parseFloat(endowment));
	$scope.netTotal = get2Float(total);

	changeItemVal('claimAmount');
	changeItemVal('endowmentAmount');
	changeItemVal('netTotal');
    };

});

uiBootstrapApp.factory('DataEndowment', function () {
    var data = {
		claimAmount: 0.00,
        endowmentAmount: 0.00,
        netTotal: 0.00
    };

    return {
        getClaimAmount: function () {
            return data.claimAmount;
        },
        setClaimAmount: function (obj) {
            data.claimAmount = obj;
        },
        getEndowmentAmount: function () {
            return data.endowmentAmount;
        },
        setEndowmentAmount: function (obj) {
            data.endowmentAmount = obj;
        },
        getNetTotal: function () {
            return data.netTotal;
        },
        setNetTotal: function (obj) {
            data.netTotal = obj;
        }
    };
});
