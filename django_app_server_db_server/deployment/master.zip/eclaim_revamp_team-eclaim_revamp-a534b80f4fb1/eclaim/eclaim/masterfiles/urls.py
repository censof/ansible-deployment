# from Django
from django.conf.urls import patterns, url

urlpatterns = patterns(
    'eclaim.masterfiles.ajax',

    url(r'^public-transport-list/$', 'get_public_transport_list', name='public_transport_list'),
    url(r'^misc-expenses-list/$', 'get_misc_expenses_list', name='misc_expenses_list'),
    url(r'^region-list/$', 'get_region_list', name='region_list'),
    url(r'^course-location-list/$', 'get_course_location_list', name='course_location_list'),
    url(r'^mileage-trip-type/$', 'get_mileage_trip_type', name='mileage_trip_type'),
    url(r'^destination-type/$', 'get_destination_type', name='destination_type'),
    url(r'^transit-type/$', 'get_transit_type', name='transit_type'),
    url(r'^accommodation-type/$', 'get_accommodation_type', name='accommodation_type'),
    url(r'^fare-replacement-type/$', 'get_fare_replacement_type', name='fare_replacement_type'),
    url(r'^flight-class-type/$', 'get_flight_class_type', name='flight_class_type')
)