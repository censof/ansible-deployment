import datetime

from django.db import models
from django.utils.translation import ugettext as _

from .company import SalaryGroup, GradeLevelCategory
from .misc import REGION_LIST, COURSE_LOCATION_LIST


class Entitlement(models.Model):
    """
    Base abstract model for all 'Entitlement' models.
    """

    GRADE = GradeLevelCategory.GRADE

    effective_date = models.DateField(default=datetime.datetime.today)

    # SSM

    ssm_salary_group = models.ForeignKey(SalaryGroup, verbose_name='SSM Salary Group'
                                         , related_name='%(class)s_ssm_salary_group')
    ssm_grade_from = models.ForeignKey(GradeLevelCategory, limit_choices_to={'code_type':GRADE}
                                       , verbose_name='SSM Grade From', related_name='%(class)s_ssm_grade_from')
    ssm_grade_to = models.ForeignKey(GradeLevelCategory, limit_choices_to={'code_type':GRADE}
                                     , verbose_name='SSM Grade To', related_name='%(class)s_ssm_grade_to')
    ssm_salary_from = models.DecimalField(max_digits=17, decimal_places=2, verbose_name='SSM Salary From'
                                          , blank=True, null=True, default=0)
    ssm_salary_to = models.DecimalField(max_digits=17, decimal_places=2, verbose_name='SSM Salary To'
                                        , blank=True, null=True, default=0)

    def __unicode__(self):
        date = format(self.effective_date, '%Y-%m-%d')
        return u'%s (%s)' % (self.__class__.__name__, date)

    class Meta:
        abstract = True
        app_label = 'masterfiles'
        unique_together = (
            'effective_date',
            'ssm_salary_group', 'ssm_grade_from', 'ssm_grade_to'
        )


class MaritalBasedAllowance(models.Model):
    single = models.DecimalField('moving allowance (single)',
                                 blank=True, null=True, default=0,
                                 max_digits=17, decimal_places=2)

    married = models.DecimalField('moving allowance (married)',
                                  blank=True, null=True, default=0,
                                  max_digits=17, decimal_places=2)

    def save(self, *args, **kwargs):
        for f in ['single', 'married']:
            if getattr(self, f) is None:
                setattr(self, f, 0)
        super(MaritalBasedAllowance, self).save(*args, **kwargs)

    class Meta:
        abstract = True
        app_label = 'masterfiles'


class TripAllowance(models.Model):
    meal = models.DecimalField(_('Meal Rate'), blank=True, null=True, default=0, max_digits=17, decimal_places=2)
    hotel = models.DecimalField(_(u'Hotel Rate'), blank=True, null=True, default=0, max_digits=17, decimal_places=2)
    lodging = models.DecimalField(_(u'Lodging Rate'), blank=True, null=True, default=0, max_digits=17, decimal_places=2)

    def save(self, *args, **kwargs):
        for f in ['meal', 'hotel', 'lodging']:
            if getattr(self, f) is None:
                setattr(self, f, 0)
        super(TripAllowance, self).save(*args, **kwargs)

    class Meta:
        abstract = True
        app_label = 'masterfiles'


class TransferAllowance(MaritalBasedAllowance):
    meal_replacement = models.DecimalField(_(u'Meal Replacement'),blank=True, null=True, default=0, max_digits=17, decimal_places=2)
    miscellaneous = models.DecimalField(_(u'Miscellaneous Exp. (%)'),blank=True, null=True, default=0, max_digits=17, decimal_places=2)

    def save(self, *args, **kwargs):
        for f in ['meal_replacement', 'miscellaneous']:
            if getattr(self, f) is None:
                setattr(self, f, 0)
        super(TransferAllowance, self).save(*args, **kwargs)

    class Meta:
        abstract = True
        app_label = 'masterfiles'


class LectureClaimEntitlement(Entitlement):
    lecture_rate = models.DecimalField(max_digits=17, decimal_places=2, blank=True, null=True, default=0)
    facilitator_rate = models.DecimalField(max_digits=17, decimal_places=2, blank=True, null=True, default=0)
    monthly_claim_limit_bysalary = models.DecimalField(max_digits=17, decimal_places=2, blank=True, null=True, default=0)
    
    def __unicode__(self):
        return u'lecture_rate=%s , facilitator_rate=%s, monthly_claim_limit_bysalary=%s' % (str(self.lecture_rate), str(self.facilitator_rate), str(self.monthly_claim_limit_bysalary))
    
    class Meta(Entitlement.Meta):
        app_label = 'masterfiles'
        verbose_name = 'Lecture Claim Entitlement'
        verbose_name_plural = verbose_name


class MovingAllowanceEntitlement(Entitlement):
    class Meta(Entitlement.Meta):
        app_label = 'masterfiles'
        verbose_name = 'House Moving Entitlement'
        verbose_name_plural = verbose_name


class HouseMovingAllowance(MaritalBasedAllowance):
    entitlement = models.ForeignKey(MovingAllowanceEntitlement)
    region = models.CharField(max_length=10, choices=REGION_LIST)

    class Meta(MaritalBasedAllowance.Meta):
        verbose_name = 'House Moving Allowance for West & East Malaysia'
        verbose_name_plural = verbose_name


# Implementations for "Official Trips / Courses in Malaysia" #################

class InMalaysiaEntitlement(Entitlement):
    class Meta(Entitlement.Meta):
        verbose_name = _('Entitlement for West & East of Malaysia')
        verbose_name_plural = _('Entitlements for West & East of Malaysia')
        ordering = ['id']


class OfficialTripAllowance(TripAllowance):
    entitlement = models.ForeignKey(InMalaysiaEntitlement)
    region = models.CharField(max_length=10, choices=REGION_LIST)

    class Meta(TripAllowance.Meta):
        verbose_name = _('Official Trip Allowance Rate for West & East Malaysia')
        verbose_name_plural = _('Official Trip Allowances Rate for West & East Malaysia')
        ordering = ['entitlement', '-region']


class CourseTripAllowance(TripAllowance):
    entitlement = models.ForeignKey(InMalaysiaEntitlement)
    region = models.CharField(max_length=10, choices=REGION_LIST)

    class Meta(TripAllowance.Meta):
        verbose_name = _('Course Trip Allowance Rate for West & East Malaysia')
        verbose_name_plural = _('Course Trip Allowances Rate for West & East Malaysia')
        ordering = ['entitlement', '-region']


class CourseDailyAllowance(models.Model):
    entitlement = models.ForeignKey(InMalaysiaEntitlement)
    long_term = models.DecimalField(_('Long Term'), default=0, max_digits=17, decimal_places=2)
    short_term = models.DecimalField(_('Short Term'), default=0, max_digits=17, decimal_places=2)
    part_time = models.DecimalField(_('Part Time'), default=0, max_digits=17, decimal_places=2)
    meal_aid = models.DecimalField(_('Meal Aid'), default=0, max_digits=17, decimal_places=2)
    transport_aid = models.DecimalField(_('Transport Aid'), default=0, max_digits=17, decimal_places=2)
    course_location = models.CharField(max_length=10, choices=COURSE_LOCATION_LIST)
    
    class Meta:
        verbose_name = _('Course Daily Allowance Rate')
        verbose_name_plural = _('Course Daily Allowances Rate')
        ordering = ['entitlement', 'course_location']


# Implementations for "Official Trips / Courses in Malaysia" #################

class OverseaEntitlement(Entitlement):
    country_category = models.ForeignKey('settings.CountryCategory', null=True, blank=True)
    
    class Meta(Entitlement.Meta):
        verbose_name = _('Entitlement for Oversea')
        verbose_name_plural = _('Entitlements for Oversea')
        ordering = ['id']
        

class OfficialTripOverseaAllowance(TripAllowance):
    entitlement = models.ForeignKey(OverseaEntitlement)
    
    class Meta(TripAllowance.Meta):
        verbose_name = _('Official Trip Allowance Rate for Oversea')
        verbose_name_plural = _('Official Trip Allowances Rate for Oversea')
        ordering = ['entitlement']


class CourseTripOverseaAllowance(TripAllowance):
    entitlement = models.ForeignKey(OverseaEntitlement)
    
    class Meta(TripAllowance.Meta):
        verbose_name = _('Course Trip Allowance Rate for Oversea')
        verbose_name_plural = _('Course Trip Allowances Rate for Oversea')
        ordering = ['entitlement']


# Implementation for "Transfers within the Same State" #######################

class TransferWithinStateEntitlement(Entitlement):
    class Meta(Entitlement.Meta):
        verbose_name = 'Transfer Local Claim Entitlement within State'
        verbose_name_plural = verbose_name


class WestMalaysiaTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferWithinStateEntitlement)

    class Meta(TransferAllowance.Meta):
        verbose_name = 'Transfer Local Claim Entitlement for Peninsular Malaysia'
        verbose_name_plural = verbose_name


class SarawakTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferWithinStateEntitlement)

    class Meta(TransferAllowance.Meta):
        verbose_name = 'Transfer Local Claim Entitlement for Sarawak'
        verbose_name_plural = verbose_name


class SabahTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferWithinStateEntitlement)

    class Meta(TransferAllowance.Meta):
        verbose_name = 'Transfer Local Claim Entitlement for Sabah'
        verbose_name_plural = verbose_name


# Implementation for "Transfers between P. Malaysia and Sabah/Sarawak" #######

# this is exactly the same as above TransferWithinStateEntitlement, only difference is semantics:
# each related TransferAllowance here refers to where the claimant is moving FROM

class TransferBetweenStateEntitlement(Entitlement):
    class Meta(Entitlement.Meta):
        verbose_name = 'Transfer Local Claim Entitlement between States'
        verbose_name_plural = verbose_name


class FromWestMalaysiaTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferBetweenStateEntitlement)

    class Meta(WestMalaysiaTransferAllowance.Meta):
        verbose_name = 'Transfer Local Claim Entitlement from Peninsular Malaysia'
        verbose_name_plural = verbose_name


class FromSarawakTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferBetweenStateEntitlement)

    class Meta(SarawakTransferAllowance.Meta):
        verbose_name = 'Transfer Local Claim Entitlement from Sarawak'
        verbose_name_plural = verbose_name


class FromSabahTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferBetweenStateEntitlement)

    class Meta(SabahTransferAllowance.Meta):
        verbose_name = 'Transfer Local Claim Entitlement from Sabah'
        verbose_name_plural = verbose_name


class BetweenSabahSarawakTransferAllowance(TransferAllowance):
    entitlement = models.ForeignKey(TransferBetweenStateEntitlement)

    class Meta:
        verbose_name = 'Transfer Local Claim Entitlement between Sabah and Sarawak'
        verbose_name_plural = verbose_name