import datetime

from django.db import models
from django.utils.translation import ugettext_lazy as _

from .default_attribute import (CODE_MAX_LENGTH, DESC_MAX_LENGTH, EXPENSES_CODE_MAX_LENGTH
                                , CLAIM_TYPE_MAX_LENGTH)


# Start : Temporary Only
GST_LIST = (
    ('SR', unicode(_(u'SR')), '6'),
    ('ZR', unicode(_(u'ZR')), '0')
)

# Used in app : localtravel
PUBLIC_TRANSPORT_LIST = (
    ('Taxi', unicode(_(u'Taxi'))),
    ('Bus', unicode(_(u'Bus'))),
    ('Train', unicode(_(u'Train'))),
    ('Ferry', unicode(_(u'Ferry'))),
    ('Airplane', unicode(_(u'Airplane'))),
    ('Others', unicode(_(u'Others'))),
    ('TrainReplacementFee', unicode(_(u'Train Replacement Fee'))),
    ('AirplaneReplacementFee', unicode(_(u'Airplane Replacement Fee')))
)

# Used in app : localtravel
MISC_EXPENSES_LIST = (
    ('Toll', unicode(_(u'Toll'))),
    ('Parking', unicode(_(u'Parking'))),
    ('Postage', unicode(_(u'Postage'))),
    ('Telephone', unicode(_(u'Telephone'))),
    ('Fax', unicode(_(u'Fax'))),
    ('AirportTax', unicode(_(u'Airport Tax'))),
    ('Baggage', unicode(_(u'Baggage'))),
    ('Others', unicode(_(u'Others')))
)

# Used in app : localtravel, masterfiles
REGION_LIST = (
    ('West', unicode(_(u'Semenanjung'))),
    ('East', unicode(_(u'Sabah & Sarawak')))
)

# Used in app : localtravel, masterfiles
COURSE_LOCATION_LIST = (
    ('In', unicode(_('Dalam Kawasan'))),
    ('Out', unicode(_('Luar Kawasan')))
)

# Used in app : localtravel
LOCAL_ACTIVITY_LIST = (
    ('OD', unicode(_('Official Duty'))),
    ('LT', unicode(_('Long Term Course'))),
    ('ST', unicode(_('Short Term Course'))),
    ('PT', unicode(_('Part Time Course')))    
)

# Used in app : overseatravel
MILEAGE_TRIP_TYPE = (
    ('HousetoAirport', unicode(_('House to Airport'))),
    ('AirporttoAccommodation', unicode(_('Airport to Accommodation'))),
    ('CourseSession', unicode(_('Course Session')))
)

# Used in app : overseatravel
DESTINATION_TYPE = (
    ('Local', unicode(_('Local'))),
    ('Oversea', unicode(_('Oversea')))
)

# Used in app : overseatravel
TRANSIT_TYPE = (
    ('Transit', unicode(_('Transit > 6 hours'))),
    ('Flight', unicode(_('Flight > 12 hours'))),
    ('Stranded', unicode(_('Stranded')))
)

# Used in app : overseatravel
ACCOMMODATION_TYPE = (
    ('Hotel', unicode(_('Hotel'))),
    ('Lodging', unicode(_('Lodging')))
)

# Used in app : overseatravel
FARE_REPLACEMENT_TYPE = (
    ('FareReplacement', unicode(_('Fare Replacement'))),
    ('Flight', unicode(_('Flight')))
)

# Used in app : overseatravel
FLIGHT_CLASS_TYPE = (
    ('FirstClass', unicode(_('First Class'))),
    ('BusinessClass', unicode(_('Business Class'))),
    ('EconomyClass', unicode(_('Economy Class')))
)

# Used in app : localtransfer
TRANSFER_DESTINATION_LIST = (
    ('WithinPeninsular',unicode(_(u'Within Peninsular Malaysia'))),
    ('WithinSabah',unicode(_(u'Within Sabah (including Labuan)'))),
    ('WithinSarawak',unicode(_(u'Within Sarawak'))),
    ('FromPeninsulartoSabahSarawak',unicode(_(u'From Peninsular to Sabah (including Labuan)/Sarawak'))),
    ('FromSabahtoPeninsular',unicode(_(u'From Sabah (including Labuan) to Peninsular'))),
    ('FromSarawaktoPeninsular',unicode(_(u'From Sarawak to Peninsular'))),
    ('BetweenSabahandSarawak',unicode(_(u'Between Sabah and Sarawak'))),
)

# Used in app : localtransfer
TYPE_OF_MOVER_LIST = (
    ('MoverProvidedByOrganization',unicode(_(u'Mover is provided by the organization'))),
    ('MoverUnderClaimantsCost',unicode(_(u'Mover is under Claimants cost'))),
    ('HousemovingWithoutMover',unicode(_(u'House moving without using mover'))),
    ('TransferWithoutFamily',unicode(_(u'Transfer without family members'))),
    ('TransferOutsideNoHouseMoving',unicode(_(u'Transfer outside station but no house moving'))),
)

DESTINATION_TYPE = (
    ('Local', unicode(_('Local'))),
    ('Oversea', unicode(_('Oversea')))
)

OVERSEA_TRANSFER_DESTINATION_LIST = (
    ('MalaysiaToOversea',unicode(_(u'Malaysia to Oversea'))),
    ('OverseaToMalaysia',unicode(_(u'Oversea to Malaysia'))),
    ('OverseaToOversea',unicode(_(u'Oversea to Oversea'))),
)

TYPE_OF_ADVANCE = (
    ('OfficialDuty', unicode(_('Official Duty'))),
    ('Course', unicode(_('Course'))),
)

TYPE_OF_EXPENSES = (
    ('MealHotel',unicode(_(u'Elaun Makan & Elaun Hotel'))),
    ('MealLodging',unicode(_(u'Elaun Makan & Elaun Lodging'))),
    ('MealOnly',unicode(_(u'Elaun Makan Sahaja'))),
    ('HotelOnly',unicode(_(u'Elaun Hotel Sahaja'))),
    ('LodgingOnly',unicode(_(u'Elaun Lodging Sahaja'))),
)
# End : Temporary Only

CONFIG_SECTION = (
    ('FORM', 'FORM'),
    ('WORKFLOW', 'WORKFLOW'),
)

class ConfigSet(models.Model):

    section     = models.CharField(max_length=200, choices=CONFIG_SECTION)
    section_detail = models.CharField(max_length=200, blank=True)
    key         = models.CharField(unique=True, max_length=200)
    value       = models.CharField(max_length=50)
    description = models.TextField()

    def __unicode__(self):
        return '(%s, %s)' % (self.key, self.value)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Config Setup'
        verbose_name_plural = verbose_name


class FundType(models.Model):
    """
    Fund Types

    Integration Notes:
        code field must be synchronized with the financial system.
    """

    code = models.CharField(primary_key=True, max_length=3)
    description = models.CharField(max_length=DESC_MAX_LENGTH)
    is_project = models.BooleanField(default=False)
    sequence = models.IntegerField(unique=True)
    policy = models.CharField(max_length=21, null=True)

    def __unicode__(self):
        return '%s (%s)' % (self.code, self.description)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Fund Type'
        verbose_name_plural = verbose_name
        ordering = ['sequence']


class MiscellaneousType(models.Model):

    MED  = 'MED'
    DEN  = 'DEN'
    Misc = 'Misc'

    DEFAULT_TYPE = (
        (MED, _(u'Medical')),
        (DEN, _(u'Dental')),
        (Misc, _(u'Misc')),
    )

    code = models.CharField(max_length=15, unique=True)
    claim_type = models.CharField(max_length=10,choices=DEFAULT_TYPE)
    description = models.TextField()
    rate = models.DecimalField(max_digits=9, decimal_places=2,default=0.00)
    limit_claim = models.IntegerField(default=0)
    exp_code = models.TextField(max_length=15, null=True)
    active = models.BooleanField(default=True)

    def __unicode__(self):
        return self.description

    def treatment_type(self):
        if self.claim_type == 'MED':
            return _(u'Medical')
        elif self.claim_type == 'DEN':
            return _(u'Dental')
        elif self.claim_type == 'Misc':
            return _(u'Misc')
        else:
            return ''

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Miscellaneous Item Type')
        verbose_name_plural = verbose_name


class PetrolType(models.Model):
    name = models.CharField(max_length=15)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Petrol Type')
        verbose_name_plural = verbose_name
        ordering = ['name']


class PetrolRate(models.Model):
    petrol_type = models.ForeignKey(PetrolType)
    date = models.DateField()
    rate =  models.DecimalField(max_digits=11, decimal_places=2, default=0)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Petrol Rate')
        verbose_name_plural = verbose_name
        ordering = ['date', 'petrol_type']

class VehicleType(models.Model):
    name = models.CharField(max_length=15)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Vehicle Type')
        verbose_name_plural = verbose_name
        ordering = ['name']


class VehicleRate(models.Model):
    vehicle_type = models.ForeignKey(VehicleType)
    date = models.DateField()
    rate =  models.DecimalField(max_digits=11, decimal_places=2, default=0)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Vehicle Rate')
        verbose_name_plural = verbose_name
        ordering = ['date', 'vehicle_type']


VEHICLE_CC_LIST = (
    ('1400,5000', unicode(_(u'1400 and above'))),
    ('1000,1399', unicode(_(u'1000 - 1399'))),
    ('650,999'  , unicode(_(u'650 - 999'))),
    ('175,649'  , unicode(_(u'175 - 649'))),
    ('1,174'    , unicode(_(u'below 175')))
)

class MileageClaimClassName(models.Model):
    mclass = models.CharField(max_length=1, primary_key=True )

    class Meta:
        verbose_name = _(u'mileage claim class name')
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return self.mclass

class MileageClaimClass(models.Model):
    mileage_class_name = models.ForeignKey(MileageClaimClassName, verbose_name=_("ClassName"))
    salary_from = models.DecimalField(max_digits=17, decimal_places=2)
    salary_to = models.DecimalField(max_digits=17, decimal_places=2)
    cc_from = models.DecimalField(max_digits=17, decimal_places=2)
    cc_to = models.DecimalField(max_digits=17, decimal_places=2)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'mileage claim class')
        verbose_name_plural = verbose_name
        unique_together = (
            ('salary_from', 'salary_to'),
            ('cc_from', 'cc_to'),
        )
        ordering = ['salary_from']

    def __unicode__(self):
        return self.mileage_class_name.mclass

class MileageClaimRange(models.Model):
    distance_min = models.IntegerField()
    distance_max = models.IntegerField()

    def __unicode__(self):
        return u"{} - {}".format(self.distance_min, self.distance_max)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'mileage claim range')
        verbose_name_plural = verbose_name
        unique_together = ('distance_min', 'distance_max')
        ordering = ['distance_min']

class MileageClaimRate(models.Model):
    mileage_claim_range = models.ForeignKey(MileageClaimRange, null=True, verbose_name=_(u'range'))
    mileage_claim_class = models.ForeignKey(MileageClaimClass, null=True, verbose_name=_(u'class'))
    rate = models.DecimalField(default=0, max_digits=17, decimal_places=2)

    def __unicode__(self):
        return unicode(self.mileage_claim_class)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'mileage claim rate')
        verbose_name_plural = verbose_name
        ordering = ['mileage_claim_class']
        unique_together = ('mileage_claim_range', 'mileage_claim_class')


class Bank(models.Model):
    name = models.CharField(max_length=100)
    code = models.CharField(max_length=50, unique=True)
    ihrms_code = models.CharField(max_length=10, null=True)
    saga_code = models.CharField(max_length=10, null=True)

    def __unicode__(self):
        return '%s' % (self.name)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Bank'
        verbose_name_plural = verbose_name


class GSTTax(models.Model):
    code = models.CharField(max_length=21,  primary_key=True)
    rate = models.DecimalField(default=0, max_digits=17, decimal_places=2)
    description = models.CharField(max_length=225)

    def __unicode__(self):
        return '%s - %s' % (self.code, self.description)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'GST Tax'
        verbose_name_plural = verbose_name


class Budget(models.Model):
    bcac_account = models.CharField(max_length=125)
    bcac_amount =  models.DecimalField(max_digits=11, decimal_places=2, default=0.00)
    bcac_monitorglac = models.CharField(max_length=125)
    bcac_status = models.CharField(max_length=1)
    bcac_warnflag = models.CharField(max_length=1)

    def __unicode__(self):
        return '%s' % (self.bcac_account)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Budget'
        verbose_name_plural = verbose_name

class TransportationFare(models.Model):
    # malaysia is 329750 sq km, so we use this value as the maximum limit
    INFINITY = 329750

    date = models.DateField(_(u'date'), default=datetime.date.today)
    distance_min = models.IntegerField(_(u'distance from (km)'))
    distance_max = models.IntegerField(_(u'distance to (km)'))
    west_single = models.DecimalField(_(u'single (west Malaysia)'), max_digits=17, decimal_places=2)
    west_married = models.DecimalField(_(u'married (west Malaysia)'), max_digits=17, decimal_places=2)
    east_single = models.DecimalField(_(u'single (east Malaysia)'), max_digits=17, decimal_places=2)
    east_married = models.DecimalField(_(u'married (east Malaysia)'), max_digits=17, decimal_places=2)

    def __unicode__(self):
        return self.distance_range()

    def distance_range(self):
        if self.distance_max >= TransportationFare.INFINITY:
            return u'> %.2f' % self.distance_min
        else:
            return u"%.2f - %.2f" % (self.distance_min, self.distance_max)
    distance_range.short_description = _(u'distance (km)')
    distance_range.admin_order_field = 'distance_min'

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Transportation Fare'
        verbose_name_plural = verbose_name