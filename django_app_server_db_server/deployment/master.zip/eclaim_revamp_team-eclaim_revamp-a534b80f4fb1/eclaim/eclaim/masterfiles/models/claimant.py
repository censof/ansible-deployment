from decimal import *
from django.db import models
from django.contrib.auth.models import User
from django.utils.translation import ugettext_lazy as _
from .company import (
    SalaryGroup, SalaryScheme, GradeLevelCategory, Position, CompanyLevel)
from ..common import CLAIM_TYPE


WORK_STATUS = (
    ('Employed', _('Employed')),
    ('Unemployed', _('Unemployed')),
    ('Student', _('Student'))
)

class ClaimantBankInfo(models.Model):
    bank_code = models.CharField(primary_key=True, max_length=50, verbose_name='Bank Code')
    bank_name = models.CharField(max_length=100, verbose_name='Bank Name')
    ihrms_code = models.CharField(max_length=10, blank=True, verbose_name='IHRMS Code')
    saga_code = models.CharField(max_length=10, blank=True, verbose_name='Saga Code')

    def __unicode__(self):
        return '%s' % (self.bank_name)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Claimant Bank Info'
        verbose_name_plural = verbose_name
        ordering = ['bank_code']

class ClaimantAbstract(models.Model):
    name = models.CharField(max_length=70, verbose_name='Name')
    ic = models.CharField(max_length=14, verbose_name='IC/Passport')
    married = models.BooleanField(default=False, verbose_name='Married')
    address1 = models.CharField(max_length=100, blank=True, verbose_name='Address 1')
    address2 = models.CharField(max_length=100, blank=True, verbose_name='Address 2')
    address3 = models.CharField(max_length=100, blank=True, verbose_name='Address 3')
    address4 = models.CharField(max_length=100, blank=True, verbose_name='Address 4')
    email = models.EmailField(blank=True, verbose_name='Email')
    resigned = models.BooleanField(default=False, verbose_name='Resigned')
    basic_salary = models.DecimalField(max_digits=17, decimal_places=2, verbose_name='Basic Salary')
    bank_info = models.ForeignKey(ClaimantBankInfo, null=True, blank=True, verbose_name='Claimant Bank Info')
    salary_scheme = models.ForeignKey(SalaryScheme, null=True,blank=True, verbose_name='Salary Scheme')
    salary_group = models.ForeignKey(SalaryGroup, null=True, blank=True, verbose_name='Salary Group')
    grade_prefix = models.CharField(max_length=10, blank=True, verbose_name='Grade Prefix')
    grade_level_category = models.ForeignKey(
                                GradeLevelCategory, null=True, blank=True,
                                limit_choices_to={'code_type':GradeLevelCategory.GRADE}, verbose_name='Grade / Level / Category'
                            )
    position = models.ForeignKey(Position, null=True, blank=True, verbose_name='Position')
    company_levels = models.ManyToManyField(CompanyLevel, verbose_name=_("Company Levels"), blank=True)

    class Meta:
        abstract = True
        app_label = 'masterfiles'
        ordering = ['staff_no']

    def save(self, *args, **kwargs):
        self.name = self.name.title()
        super(ClaimantAbstract, self).save(*args, **kwargs)

class Claimant(ClaimantAbstract):
    user = models.OneToOneField(User)
    staff_no = models.CharField(primary_key=True, max_length=10, verbose_name='Staff No.')
    is_admin = models.BooleanField(_("Is Administrator"), default=False)

    def __unicode__(self):
        return unicode(self.staff_no)

    class Meta(ClaimantAbstract.Meta):
        app_label = 'masterfiles'
        verbose_name = 'Claimant'
        verbose_name_plural = verbose_name

    def save(self, *args, **kwargs):
        user = self.user
        if self.email != user.email:
            user.email = self.email
            user.save()
        super(Claimant, self).save(*args, **kwargs)

class ClaimantHistory(ClaimantAbstract):
    staff_no = models.CharField(max_length=10, verbose_name='Staff No.', blank=True)
    claim_id = models.IntegerField()
    claim_type = models.CharField(max_length=CLAIM_TYPE.DEFAULT_LENGTH, blank=True, choices=CLAIM_TYPE.CHOICES)

    class Meta(ClaimantAbstract.Meta):
        app_label = 'masterfiles'
        verbose_name = 'Claimant History'
        verbose_name_plural = verbose_name

class Spouse(models.Model):
    staff = models.ForeignKey(Claimant)
    name = models.CharField(_(u'Name'), max_length=255)
    ic = models.CharField(_(u'IC / Passport No.'), max_length=14)
    grade = models.CharField(_(u'Grade'), max_length=50, null=True)
    position = models.CharField(_(u'Position'), max_length=50, null=True)
    basic_salary = models.DecimalField(_(u'Basic Salary'), max_digits=17, decimal_places=2, default=Decimal('0.00'))
    employer_name = models.TextField(null=True)
    address1 = models.TextField(null=True)
    address2 = models.TextField(null=True)
    address3 = models.TextField(null=True)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Claimant\'s Spouse')
        verbose_name_plural = _(u'Claimant\'s Spouses')
        ordering = ['staff', 'name']

class Children(models.Model):
    staff = models.ForeignKey(Claimant)
    name = models.CharField(_(u'Name'), max_length=255)
    ic = models.CharField(_(u'IC / Passport No'), max_length=14)
    age = models.IntegerField(_(u'Age'), null=True)
    work_status = models.CharField(_(u'Work Status'), max_length=25, choices=WORK_STATUS, null=True)
    oku_status = models.BooleanField(_(u'OKU Status'), default=False)
    parent = models.ForeignKey(Spouse, null=True)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _(u'Claimant\'s Child')
        verbose_name_plural = _(u'Claimant\'s Children')
        ordering = ['staff', 'name']
