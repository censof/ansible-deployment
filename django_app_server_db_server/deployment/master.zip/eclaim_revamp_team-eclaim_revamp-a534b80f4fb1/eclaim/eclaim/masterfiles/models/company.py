from django.db import models
from django.utils.translation import ugettext_lazy as _
from eclaim.libs.models import BaseModel
from .default_attribute import (
    CODE_MAX_LENGTH, DESC_MAX_LENGTH, EXPENSES_CODE_MAX_LENGTH,
    CLAIM_TYPE_MAX_LENGTH)


class Company(models.Model):

    code = models.CharField(db_column='ecco_code', max_length=15, primary_key=True)
    name = models.CharField(db_column='ecco_name', max_length=200)
    reg_no = models.CharField(db_column='ecco_regno', max_length=50)
    addr_1 = models.CharField(db_column='ecco_addr1', max_length=100, null=True, blank=True)
    addr_2 = models.CharField(db_column='ecco_addr2', max_length=100, null=True, blank=True)
    addr_3 = models.CharField(db_column='ecco_addr3', max_length=100, null=True, blank=True)
    addr_4 = models.CharField(db_column='ecco_addr4', max_length=100, null=True, blank=True)
    tel_no = models.CharField(db_column='ecco_telno', max_length=30, null=True, blank=True)
    fax_no = models.CharField(db_column='ecco_faxno', max_length=30, null=True, blank=True)
    email = models.CharField(db_column='ecco_email', max_length=50, null=True, blank=True)
    logo = models.CharField(db_column='ecco_logo', max_length=100, null=True, blank=True)
    website = models.CharField(db_column='ecco_website',max_length=300, null=True, blank=True)
    form_template = models.CharField(db_column='ecco_formtemplate', max_length=50)
    currency_code = models.CharField(db_column='ecco_currcode', max_length=10)
    is_active = models.BooleanField(db_column='ecco_isactive')
    saga_company_code = models.CharField(db_column='ecco_sagacompanycode', max_length=15, blank=True)

    class Meta:
        app_label = 'masterfiles'
        db_table = 'ec_company'
        verbose_name = 'Company'
        verbose_name_plural = verbose_name
        ordering = ['code']


class CompanyBankInfo(models.Model):

    code = models.CharField(db_column='eccbi_bankcode', max_length=15)
    desc = models.CharField(db_column='eccbi_bankdesc', max_length=50)
    gl_code = models.CharField(db_column='eccbi_glcode', max_length=30)
    company = models.ForeignKey(Company, db_column='eccbi_company')

    class Meta:
        app_label = 'masterfiles'
        db_table = 'ec_companybankinfo'
        verbose_name = 'Company Bank Info'
        verbose_name_plural = verbose_name
        ordering = ['code']


DB_TYPE = (
    ('I', 'Informix'),
    ('O', 'Oracle'),
    ('P', 'Postgresql'),
)


class IntegrationDBSettings(models.Model):

    db_type = models.CharField(db_column='ecids_dbtype', max_length=1, choices=DB_TYPE)
    db_name = models.CharField(db_column='ecids_dbname', max_length=50)
    db_host = models.CharField(db_column='ecids_dbhost', max_length=50)
    db_user = models.CharField(db_column='ecids_dbuser', max_length=50)
    db_pass = models.CharField(db_column='ecids_dbpass', max_length=50)
    company = models.ForeignKey(Company, db_column='ecids_company')

    class Meta:
        app_label = 'masterfiles'
        db_table = 'ec_integrationdbsettings'
        verbose_name = 'Integration DB Settings'
        verbose_name_plural = verbose_name
        ordering = ['company']


class SalaryScheme(models.Model):

    code = models.CharField(primary_key=True, max_length=CODE_MAX_LENGTH, verbose_name='Salary Scheme Code')
    description = models.CharField(max_length=DESC_MAX_LENGTH, blank=True, verbose_name='Salary Scheme Description')

    def __unicode__(self):
        return u'%s (%s)' % (self.code, self.description)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Salary Scheme'
        verbose_name_plural = verbose_name
        ordering = ['code']


class SalaryGroup(models.Model):

    code = models.CharField(primary_key=True, max_length=CODE_MAX_LENGTH, verbose_name='Salary Group Code')
    description = models.CharField(max_length=DESC_MAX_LENGTH, blank=True, verbose_name='Salary Group Description')

    def __unicode__(self):
        return u'%s (%s)' % (self.code, self.description)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Salary Group'
        verbose_name_plural = verbose_name
        ordering = ['code']


class Position(models.Model):

    code = models.CharField(primary_key=True, max_length=10, verbose_name='Position Code')
    description = models.CharField(max_length=DESC_MAX_LENGTH, blank=True, verbose_name='Position Description')

    def __unicode__(self):
        return u'%s (%s)' % (self.code, self.description)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Position'
        verbose_name_plural = verbose_name


class GradeLevelCategory(models.Model):

    GRADE = 'G'
    LEVEL = 'L'
    CATEGORY = 'C'
    CODE_TYPES = (
        (GRADE, _(u'Grade')),
        (LEVEL, _(u'Level')),
        (CATEGORY, _(u'Category')),
    )

    code = models.CharField(primary_key=True, max_length=CODE_MAX_LENGTH, verbose_name='Grade/Level/Category Code')
    description = models.CharField(max_length=DESC_MAX_LENGTH, blank=True, verbose_name='Grade/Level/Category Description')
    code_type = models.CharField(max_length=1, choices=CODE_TYPES, default=CATEGORY, verbose_name='Grade/Level/Category Code Type')
    ordering = models.PositiveIntegerField(_("Ordering"), blank=True, null=True)

    def __unicode__(self):
        return u'%s (%s)' % (self.code, self.description)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Grade/Level/Category'
        verbose_name_plural = verbose_name
        unique_together = ('code', 'code_type')
        ordering = ['ordering', 'code_type', 'code']
        get_latest_by = 'ordering'

    def save(self, *args, **kwargs):
        if self.ordering is None and self.code.isdigit():
            self.ordering = int(self.code)
        super(GradeLevelCategory, self).save(*args, **kwargs)


class ExpensesType(models.Model):

    code = models.CharField(primary_key=True, max_length=CODE_MAX_LENGTH, verbose_name='Expense Type Code')
    description = models.CharField(max_length=DESC_MAX_LENGTH, verbose_name='Expense Type Description')
    expense_code = models.CharField(max_length=EXPENSES_CODE_MAX_LENGTH, verbose_name='Expense Code')
    #claim_type = models.CharField(db_column='ecexpt_claimtype', max_length=CLAIM_TYPE_MAX_LENGTH, verbose_name='Claim Type')
    #sequence = models.IntegerField(db_column='ecexpt_sequence', null=True, blank=True)

    def __unicode__(self):
        return '%s (%s) - %s' % (self.code, self.description, self.expense_code)

    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Expenses Type'
        verbose_name_plural = verbose_name


class CompanyLevel(models.Model):
    code = models.CharField(primary_key=True, max_length=CODE_MAX_LENGTH, verbose_name=_("Code"))
    title = models.CharField(_("Name"), max_length=255)
    parent = models.ForeignKey('self', blank=True, null=True)
    level = models.ForeignKey('settings.Level', verbose_name=_("Level"))

    class Meta:
        app_label = 'masterfiles'
        verbose_name = _("Company Level")
        verbose_name_plural = _("Company Levels")
        ordering = ['level']

    def __unicode__(self):
        return unicode(self.title)


class CompanyLevelInfo(BaseModel):
    company_level = models.OneToOneField(CompanyLevel)
    reg_no = models.CharField(_("Registration No."), max_length=255, blank=True)
    addr_1 = models.CharField(_("Address 1"), max_length=255, blank=True)
    addr_2 = models.CharField(_("Address 2"), max_length=255, blank=True)
    addr_3 = models.CharField(_("Address 3"), max_length=255, blank=True)
    addr_4 = models.CharField(_("Address 4"), max_length=255, blank=True)
    tel_no = models.CharField(_("Phone No."), max_length=100, blank=True)
    fax_no = models.CharField(_("Fax No."), max_length=100, blank=True)
    email = models.EmailField(_("E-mail"), blank=True)
    website = models.URLField(_("Website URL"), blank=True)
    bank_code = models.CharField(max_length=50, blank=True)
    bank_desc = models.CharField(max_length=255, blank=True)
    bank_gl_code = models.CharField(max_length=50, blank=True)

    class Meta:
        verbose_name = _("Company Level Information")
        verbose_name_plural = _("Company Level Information")

    def __unicode__(self):
        return unicode(self.company_level)
