from django.db import models

from .default_attribute import DESC_MAX_LENGTH, CLAIM_TYPE_MAX_LENGTH, CLAIM_NO_MAX_LENGTH
from ..common import CLAIM_TYPE


class DocumentList(models.Model):
    description = models.CharField(max_length=DESC_MAX_LENGTH)
    claim_type = models.CharField(max_length=CLAIM_TYPE_MAX_LENGTH, choices=CLAIM_TYPE.CHOICES)
    sequence = models.IntegerField(null=True, blank=True)
    document_group = models.CharField(max_length=15, blank=True)
    
    def __unicode__(self):
        return '%s (%s)' % (self.description, self.claim_type)
    
    class Meta:
        app_label = 'masterfiles'
        verbose_name = 'Document List'
        verbose_name_plural = verbose_name
        
class DocumentListItemAbstract(models.Model):
    claim_type = models.CharField(max_length=CLAIM_TYPE_MAX_LENGTH, choices=CLAIM_TYPE.CHOICES)
    document_list = models.ForeignKey(DocumentList)
    sub_group_id = models.IntegerField(null=True, blank=True)
    
    class Meta:
        app_label = 'masterfiles'
        abstract = True
        
class DocumentListItem(DocumentListItemAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH)
    
    class Meta(DocumentListItemAbstract.Meta):
        app_label = 'masterfiles'
        verbose_name = 'Document List Item'
        verbose_name_plural = verbose_name

class DocumentListItemDraft(DocumentListItemAbstract):
    draft_id = models.CharField(max_length=CLAIM_NO_MAX_LENGTH)  
    
    class Meta(DocumentListItemAbstract.Meta):
        app_label = 'masterfiles'
        verbose_name = 'Document List Item Draft'
        verbose_name_plural = verbose_name
