from eclaim.libs.tests import TestCase
from eclaim.integrations.ajax import get_account_type_list
from eclaim.masterfiles.utils import (get_document_list_item,
                                      get_document_list_item_draft,
                                      save_document_list_item,
                                      save_document_list_item_draft)
from mock import patch, MagicMock, Mock, call


class ClaimantTestCase(TestCase):
    def test_save_user_email(self):
        user = self.claimant.user
        user.email = ''
        user.save()
        email = 'abc@test.zzz'
        self.assertEquals(self.claimant.email, 'mohdshukor@hasil.gov.my')
        self.claimant.email = email
        self.claimant.save()
        self.assertEquals(user.email, email)


class MasterfilesUtilsTests(TestCase):

    @patch('eclaim.masterfiles.utils.DocumentListItem')
    def test_get_document_list_item(self, mock_DocumentListItem):
        def side_effect_function(**kwargs):
            return [1,2,3,4]
        mock_DocumentListItem.objects.filter.return_value = Mock(side_effect=[1,2,3,4])
        mock_DocumentListItem.objects.filter.return_value.filter.side_effect = side_effect_function
        result = get_document_list_item(123, 'type')
        self.assertEqual(result, [1, 2, 3, 4])
        self.assertEqual(mock_DocumentListItem.objects.filter.return_value.filter.call_args,
                         call(sub_group_id__in=[]))

    @patch('eclaim.masterfiles.utils.DocumentListItemDraft')
    def test_get_document_list_item_draft(self, mock_DocumentListItemDraft):
        def side_effect_function(**kwargs):
            return [1,2,3,4]
        mock_DocumentListItemDraft.objects.filter.return_value = Mock(side_effect=[1,2,3,4])
        mock_DocumentListItemDraft.objects.filter.return_value.filter.side_effect = side_effect_function
        result = get_document_list_item_draft(123, 'type')
        self.assertEqual(result, [1, 2, 3, 4]) 
        self.assertEqual(mock_DocumentListItemDraft.objects.filter.return_value.filter.call_args,
                         call(sub_group_id__in=[]))

    @patch("eclaim.masterfiles.utils.DocumentListItem", autospec=True)
    @patch("eclaim.masterfiles.utils.DocumentList", autospec=True)
    def test_save_document_list_item(self, mock_DocumentList, mock_DocumentListItem):
        class MockDict(dict):
            def __init__(self, *args, **kwargs):
                super(MockDict, self).__init__(*args, **kwargs)
                self.__dict__ = self
        stupid = MockDict()
        stupid["id"] = 1
        mock_DocumentListItem.objects.filter.return_value = [stupid]
        mock_DocumentList.objects.get.return_value = [1, 2, 3, 4]
        save_document_list_item(1234, 'type', {'document_list': [{'selected_item': 1234}]})
        self.assertEqual(mock_DocumentListItem.return_value.claim_no, 1234)
        self.assertEqual(mock_DocumentListItem.return_value.claim_type, 'type')
        self.assertEqual(mock_DocumentListItem.return_value.document_list, [1, 2, 3, 4])
        self.assertEqual(mock_DocumentListItem.return_value.save.call_args, call())

    @patch("eclaim.masterfiles.utils.DocumentListItemDraft", autospec=True)
    @patch("eclaim.masterfiles.utils.DocumentList", autospec=True)
    def test_save_document_list_item_draft(self, mock_DocumentList, mock_DocumentListItemDraft):
        class MockDict(dict):
            def __init__(self, *args, **kwargs):
                super(MockDict, self).__init__(*args, **kwargs)
                self.__dict__ = self
        mock_dict = MockDict()
        mock_dict["id"] = 1
        mock_DocumentListItemDraft.objects.filter.return_value = [mock_dict]
        mock_DocumentList.objects.get.return_value = [1, 2, 3, 4]
        save_document_list_item_draft(1234, 'type', {'document_list': [{'selected_item': 1234}]})
        self.assertEqual(mock_DocumentListItemDraft.return_value.draft_id, 1234)
        self.assertEqual(mock_DocumentListItemDraft.return_value.claim_type, 'type')
        self.assertEqual(mock_DocumentListItemDraft.return_value.document_list, [1, 2, 3, 4])
        self.assertEqual(mock_DocumentListItemDraft.return_value.save.call_args, call())

