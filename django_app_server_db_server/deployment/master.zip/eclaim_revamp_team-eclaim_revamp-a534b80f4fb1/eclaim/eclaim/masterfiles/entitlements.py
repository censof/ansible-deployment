from django.db.models import Max, Count

from .models.entitlement import InMalaysiaEntitlement, OfficialTripAllowance, CourseTripAllowance
from eclaim.utils.common import get_json_from_set_obj


def get_json_inmalaysia_trip_ent(salary_grade):
    
    entitlement = InMalaysiaEntitlement.objects.filter(ssm_grade_from__code__lte=salary_grade
                                                , ssm_grade_to__code__gte=salary_grade).annotate(Max('effective_date'))
    official_trip_ent = OfficialTripAllowance.objects.filter(entitlement=entitlement)
    course_trip_ent = CourseTripAllowance.objects.filter(entitlement=entitlement)
    
    return get_json_from_set_obj(official_trip_ent), get_json_from_set_obj(course_trip_ent)