from django.contrib.auth.models import User
from django.contrib.contenttypes.models import ContentType
from django.db.models import Q, Max, get_model
from rest_framework import viewsets
from eclaim.settings.models import (
    WorkflowTemplateLevel, WorkflowState, SelectionFiltering)
from eclaim.claim.models import ClaimType
from .serializers import (
    SalarySchemeSerializer, SalaryGroupSerializer, ClaimantSerializer,
    GradeLevelCategorySerializer, PositionSerializer, CompanyLevelSerializer, BudgetSerializer,
    VehicleTypeSerializer, DocumentListSerializer,
    MovingAllowanceEntitlementSerializer, HouseMovingAllowanceSerializer,
    InMalaysiaEntitlementSerializer, OfficialTripAllowanceSerializer, CourseTripAllowanceSerializer, CourseDailyAllowanceSerializer,
    OverseaEntitlementSerializer, OfficialTripOverseaAllowanceSerializer, CourseTripOverseaAllowanceSerializer,
    TransferWithinStateEntitlementSerializer, WestMalaysiaTransferAllowanceSerializer, SarawakTransferAllowanceSerializer, SabahTransferAllowanceSerializer,
    TransferBetweenStateEntitlementSerializer, FromWestMalaysiaTransferAllowanceSerializer, FromSarawakTransferAllowanceSerializer,
    FromSabahTransferAllowanceSerializer, BetweenSabahSarawakTransferAllowanceSerializer,
    SpouseSerializer, ChildrenSerializer, CompanyLevelInfoSerializer)
from ..models.company import (
    SalaryScheme, SalaryGroup, GradeLevelCategory, Position, CompanyLevel,
    CompanyLevelInfo)
from ..models.misc import Budget, VehicleType, REGION_LIST
from ..models.document import DocumentList
from ..models.claimant import Claimant, Spouse, Children
from ..models.entitlement import (MovingAllowanceEntitlement, HouseMovingAllowance,
    InMalaysiaEntitlement, OfficialTripAllowance, CourseDailyAllowance, CourseTripAllowance,
    OverseaEntitlement, OfficialTripOverseaAllowance, CourseTripOverseaAllowance,
    TransferWithinStateEntitlement, TransferBetweenStateEntitlement, WestMalaysiaTransferAllowance,
    SarawakTransferAllowance, SabahTransferAllowance, FromWestMalaysiaTransferAllowance,
    FromSarawakTransferAllowance, FromSabahTransferAllowance, BetweenSabahSarawakTransferAllowance)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'SalarySchemeViewSet',
    'SalaryGroupViewSet',
    'GradeLevelCategoryViewSet',
    'PositionViewSet',
    'ClaimantViewSet',
    'SpouseViewSet',
    'ChildrenViewSet',
    'CompanyLevelViewSet',
    'CompanyLevelInfoViewSet',
    'BudgetViewSet',
    'VehicleTypeViewSet',
    'DocumentListViewSet',
    'MovingAllowanceEntitlementViewSet',
    'HouseMovingAllowanceViewSet',
    'InMalaysiaEntitlementViewSet',
    'OfficialTripAllowanceViewSet',
    'CourseTripAllowanceViewSet',
    'CourseDailyAllowanceViewSet',
    'OverseaEntitlementViewSet',
    'OfficialTripOverseaAllowanceViewSet',
    'CourseTripOverseaAllowanceViewSet',
    'TransferWithinStateEntitlementViewSet',
    'WestMalaysiaTransferAllowanceViewSet',
    'SarawakTransferAllowanceViewSet',
    'SabahTransferAllowanceViewSet',
    'TransferBetweenStateEntitlementViewSet',
    'FromWestMalaysiaTransferAllowanceViewSet',
    'FromSarawakTransferAllowanceViewSet',
    'FromSabahTransferAllowanceViewSet',
    'BetweenSabahSarawakTransferAllowanceViewSet'
    ]


class CompanyLevelViewSet(viewsets.ModelViewSet):
    serializer_class = CompanyLevelSerializer

    def get_queryset(self):
        qs = CompanyLevel.objects.all()
        upper = self.request.GET.get('upper')
        level = self.request.GET.get('level')
        if level and int(level) > 0 and upper:
            lookup_level = int(level) - 1
            qs = qs.filter(level__ordering=lookup_level)

        if level and upper is None:
            qs = qs.filter(level__ordering=level)

        parent = self.request.GET.get('parent')
        if parent:
            qs = qs.filter(parent__pk=parent)
        return qs.distinct()


class CompanyLevelInfoViewSet(viewsets.ModelViewSet):
    serializer_class = CompanyLevelInfoSerializer
    queryset = CompanyLevelInfo.objects.all()


class SalarySchemeViewSet(viewsets.ModelViewSet):
    serializer_class = SalarySchemeSerializer
    queryset = SalaryScheme.objects.all()


class SalaryGroupViewSet(viewsets.ModelViewSet):
    serializer_class = SalaryGroupSerializer
    queryset = SalaryGroup.objects.all()


class GradeLevelCategoryViewSet(viewsets.ModelViewSet):
    serializer_class = GradeLevelCategorySerializer
    queryset = GradeLevelCategory.objects.all()
    page_size = 100
    page_size_query_param = 'page_size'
    max_page_size = 1000


class PositionViewSet(viewsets.ModelViewSet):
    serializer_class = PositionSerializer
    queryset = Position.objects.all()


class ClaimantViewSet(viewsets.ModelViewSet):
    serializer_class = ClaimantSerializer

    def perform_create(self, serializer):
        data = serializer.initial_data
        try:
            user = User.objects.get(username=data['staff_no'])
        except User.DoesNotExist:
            user = User.objects.create_user(
                username=data['staff_no'],
                password=data['ic']
                )
        serializer.save(user=user)

    def get_queryset(self):
        def _filter_by_selection(queryset, current_level):
            if not hasattr(current_level, 'selectionfiltering'):
                return queryset

            # Check whether a claimant is in the same company/dept/etc.
            try:
                sf = SelectionFiltering.objects.get(
                    level__template=current_level.template,
                    level__group=current_level.group
                    )
            except SelectionFiltering.DoesNotExist:
                sf = None

            if sf is not None:
                claimant = self.request.user.claimant
                try:
                    cl_complevel = claimant.company_levels.get(
                        level=sf.company_level
                        )
                except CompanyLevel.DoesNotExist:
                    return queryset.none()  # TODO: notify user about an error

                return queryset.filter(
                    company_levels__code__exact=cl_complevel.code
                    )
            return queryset

        qs = Claimant.objects.all()
        query = self.request.GET.get('q')
        group_id = self.request.GET.get('group')
        exc_group_id = self.request.GET.get('exclude_group')
        if query:
            qs = qs.filter(
                Q(staff_no__icontains=query) | Q(name__icontains=query) |
                Q(user__username__icontains=query)
                )
        if group_id:
            qs = qs.filter(assignee__groups__pk=group_id)
        if exc_group_id:
            qs = qs.exclude(assignee__groups__pk=exc_group_id)

        # Selection filtering.
        if 'has_filtering' in self.request.GET:
            _app = self.request.GET['claim_app']
            _model = self.request.GET['claim_model']
            _claim_id = self.request.GET.get('claim')

            claim_model = get_model(_app, _model)
            try:
                claim_type = claim_model.get_claim_type()  # legacy
            except AttributeError:
                claim_type = ClaimType.get_claim_type(claim_model.CLAIM_TYPE)

            content_type = ContentType.objects.get_for_model(claim_model)

            # If a claim already exists, then retrieve data from its state.
            # Or else retrieve from a corresponding workflow level.
            if _claim_id:
                state = WorkflowState.objects.filter(
                    content_type=content_type,
                    object_id=_claim_id
                    ).latest()
                level = state.level
            else:
                try:
                    level = WorkflowTemplateLevel.objects.get(
                        template=claim_type.template,
                        ordering=1
                        )
                except WorkflowTemplateLevel.DoesNotExist:
                    return qs.none()

            # Filter according to a user group.
            try:
                next_level = WorkflowTemplateLevel.objects.get(
                    template=level.template,
                    ordering=level.ordering+1
                    )
            except WorkflowTemplateLevel.DoesNotExist:
                return qs.none()

            qs = qs.filter(assignee__groups__id__exact=next_level.group.id)

            # A queryset shall be filtered out according to selection
            # filtering setup in settings. In case when such setup is
            # missing, then simply do not filter.
            if level.selection_filtering:
                qs = _filter_by_selection(qs, level)

        return qs


class SpouseViewSet(viewsets.ModelViewSet):
    serializer_class = SpouseSerializer

    def get_queryset(self):
        qs = Spouse.objects.all()
        claimant = self.request.GET.get('claimant')
        if claimant:
            qs = qs.filter(staff__pk=claimant)
        return qs


class ChildrenViewSet(viewsets.ModelViewSet):
    serializer_class = ChildrenSerializer

    def get_queryset(self):
        qs = Children.objects.all()
        claimant = self.request.GET.get('claimant')
        if claimant:
            qs = qs.filter(staff__pk=claimant)
        return qs


class BudgetViewSet(viewsets.ModelViewSet):
    serializer_class = BudgetSerializer
    queryset = Budget.objects.all()


class VehicleTypeViewSet(viewsets.ModelViewSet):
    serializer_class = VehicleTypeSerializer
    queryset = VehicleType.objects.all()


class DocumentListViewSet(viewsets.ModelViewSet):
    serializer_class = DocumentListSerializer
    queryset = DocumentList.objects.all().order_by('document_group', 'sequence')

    def get_queryset(self):
        qs = self.queryset
        claim_type = self.request.GET.get('claim_type')
        document_group = self.request.GET.get('document_group')
        if claim_type:
            qs = qs.filter(claim_type=claim_type)
        if document_group:
            qs = qs.filter(document_group=document_group)
        return qs


class MovingAllowanceEntitlementViewSet(viewsets.ModelViewSet):
    serializer_class = MovingAllowanceEntitlementSerializer
    queryset = MovingAllowanceEntitlement.objects.all()


class HouseMovingAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = HouseMovingAllowanceSerializer
    queryset = HouseMovingAllowance.objects.all()


class InMalaysiaEntitlementViewSet(viewsets.ModelViewSet):
    serializer_class = InMalaysiaEntitlementSerializer
    queryset = InMalaysiaEntitlement.objects.all()


class OfficialTripAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = OfficialTripAllowanceSerializer
    queryset = OfficialTripAllowance.objects.all()

    def get_queryset(self):
        qs = self.queryset
        staff_no = self.request.GET.get('staffNo')
        salary_grade = self.request.GET.get('salaryGrade')
        if staff_no or salary_grade:
            if staff_no:
                claimant = Claimant.objects.get(staff_no=staff_no)
                grade_code = claimant.grade_level_category.code
            else:
                grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = InMalaysiaEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class CourseTripAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = CourseTripAllowanceSerializer
    queryset = CourseTripAllowance.objects.all()

    def get_queryset(self):
        qs = self.queryset
        staff_no = self.request.GET.get('staffNo')
        if staff_no:
            claimant = Claimant.objects.get(staff_no=staff_no)
            grade_code = claimant.grade_level_category.code
            entitlement = InMalaysiaEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class CourseDailyAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = CourseDailyAllowanceSerializer
    queryset = CourseDailyAllowance.objects.all()

    def get_queryset(self):
        qs = self.queryset
        staff_no = self.request.GET.get('staffNo')
        if staff_no:
            claimant = Claimant.objects.get(staff_no=staff_no)
            grade_code = claimant.grade_level_category.code
            entitlement = InMalaysiaEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class OverseaEntitlementViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaEntitlementSerializer
    queryset = OverseaEntitlement.objects.all()


class OfficialTripOverseaAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = OfficialTripOverseaAllowanceSerializer
    queryset = OfficialTripOverseaAllowance.objects.all()

    def get_queryset(self):
        qs = self.queryset
        staff_no = self.request.GET.get('staffNo')
        salary_grade = self.request.GET.get('salaryGrade')
        if staff_no or salary_grade:
            if staff_no:
                claimant = Claimant.objects.get(staff_no=staff_no)
                grade_code = claimant.grade_level_category.code
            else:
                grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = OverseaEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class CourseTripOverseaAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = CourseTripOverseaAllowanceSerializer
    queryset = CourseTripOverseaAllowance.objects.all()

    def get_queryset(self):
        qs = self.queryset
        staff_no = self.request.GET.get('staffNo')
        if staff_no:
            claimant = Claimant.objects.get(staff_no=staff_no)
            grade_code = claimant.grade_level_category.code
            entitlement = OverseaEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class TransferWithinStateEntitlementViewSet(viewsets.ModelViewSet):
    serializer_class = TransferWithinStateEntitlementSerializer
    queryset = TransferWithinStateEntitlement.objects.all()


class WestMalaysiaTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = WestMalaysiaTransferAllowanceSerializer
    queryset = WestMalaysiaTransferAllowance.objects.all()

    def get_queryset(self):
        qs = WestMalaysiaTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferWithinStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class SarawakTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = SarawakTransferAllowanceSerializer
    queryset = SarawakTransferAllowance.objects.all()

    def get_queryset(self):
        qs = SarawakTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferWithinStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class SabahTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = SabahTransferAllowanceSerializer
    queryset = SabahTransferAllowance.objects.all()

    def get_queryset(self):
        qs = SabahTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferWithinStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class TransferBetweenStateEntitlementViewSet(viewsets.ModelViewSet):
    serializer_class = TransferBetweenStateEntitlementSerializer
    queryset = TransferBetweenStateEntitlement.objects.all()


class FromWestMalaysiaTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = FromWestMalaysiaTransferAllowanceSerializer
    queryset = FromWestMalaysiaTransferAllowance.objects.all()

    def get_queryset(self):
        qs = FromWestMalaysiaTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferBetweenStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class FromSarawakTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = FromSarawakTransferAllowanceSerializer
    queryset = FromSarawakTransferAllowance.objects.all()

    def get_queryset(self):
        qs = FromSarawakTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferBetweenStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class FromSabahTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = FromSabahTransferAllowanceSerializer
    queryset = FromSabahTransferAllowance.objects.all()

    def get_queryset(self):
        qs = FromSabahTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferBetweenStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs


class BetweenSabahSarawakTransferAllowanceViewSet(viewsets.ModelViewSet):
    serializer_class = BetweenSabahSarawakTransferAllowanceSerializer
    queryset = BetweenSabahSarawakTransferAllowance.objects.all()

    def get_queryset(self):
        qs = BetweenSabahSarawakTransferAllowance.objects.all()
        salary_grade = self.request.GET.get('salaryGrade')
        if salary_grade:
            grade_code = GradeLevelCategory.objects.get(code=salary_grade).code
            entitlement = TransferBetweenStateEntitlement.objects.filter(ssm_grade_from__code__lte=grade_code
                        , ssm_grade_to__code__gte=grade_code).annotate(Max('effective_date'))
            qs = qs.filter(entitlement=entitlement)
        return qs
