from django.contrib.auth.models import User
from django.core.urlresolvers import reverse_lazy
from rest_framework import serializers
from eclaim.settings.api.serializers import AssigneeSerializer
from eclaim.masterfiles.models.misc import REGION_LIST
from ..models.company import (
    SalaryScheme, SalaryGroup, GradeLevelCategory, Position, CompanyLevel,
    CompanyLevelInfo)
from ..models.claimant import Claimant
from ..models.misc import Budget, COURSE_LOCATION_LIST, VehicleType
from ..models.claimant import Claimant, Spouse, Children
from ..models.misc import Budget
from ..models.document import DocumentList
from ..models.entitlement import (MovingAllowanceEntitlement, HouseMovingAllowance,
    InMalaysiaEntitlement, OfficialTripAllowance, CourseTripAllowance, CourseDailyAllowance,
    OverseaEntitlement, OfficialTripOverseaAllowance, CourseTripOverseaAllowance,
    TransferWithinStateEntitlement, WestMalaysiaTransferAllowance, SarawakTransferAllowance, SabahTransferAllowance,
    TransferBetweenStateEntitlement, FromWestMalaysiaTransferAllowance, FromSarawakTransferAllowance,
    FromSabahTransferAllowance, BetweenSabahSarawakTransferAllowance)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'SalarySchemeSerializer',
    'SalaryGroupSerializer',
    'GradeLevelCategorySerializer',
    'PositionSerializer',
    'ClaimantSerializer',
    'SpouseSerializer',
    'ChildrenSerializer',
    'CompanyLevelSerializer',
    'CompanyLevelInfoSerializer',
    'BudgetSerializer',
    'VehicleTypeSerializer',
    'InMalaysiaEntitlementSerializer',
    'OverseaEntitlementSerializer',
    'MovingAllowanceEntitlementSerializer',
    'HouseMovingAllowanceSerializer',
    'TransferWithinStateEntitlementSerializer',
    'TransferBetweenStateEntitlementSerializer'
    ]


class CompanyLevelSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyLevel
        depth = 1
        fields = ('code', 'title', 'parent', 'level', 'companylevelinfo')


class CompanyLevelInfoSerializer(serializers.ModelSerializer):
    class Meta:
        model = CompanyLevelInfo
        fields = ('id', 'company_level', 'reg_no', 'addr_1', 'addr_2',
                  'addr_3', 'addr_4', 'tel_no', 'fax_no', 'email', 'website',
                  'bank_code', 'bank_desc', 'bank_gl_code')


class SalarySchemeSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryScheme
        fields = ('code', 'description')


class SalaryGroupSerializer(serializers.ModelSerializer):
    class Meta:
        model = SalaryGroup
        fields = ('code', 'description')


class GradeLevelCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = GradeLevelCategory
        fields = ('code', 'description', 'code_type')


class PositionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Position
        fields = ('code', 'description')


class ClaimantSerializer(serializers.ModelSerializer):
    user = serializers.PrimaryKeyRelatedField(
        queryset=User.objects.all(), required=False)
    company_levels = serializers.PrimaryKeyRelatedField(
        many=True, queryset=CompanyLevel.objects.all())
    company_levels_data = serializers.SerializerMethodField(read_only=True)
    position_label = serializers.SerializerMethodField()
    groups = serializers.SerializerMethodField()
    detail_url = serializers.SerializerMethodField()
    assignee = AssigneeSerializer(required=False)

    class Meta:
        model = Claimant
        fields = ('user', 'address1', 'address2', 'address3', 'address4',
                  'bank_info', 'basic_salary', 'company_levels',
                  'company_levels_data', 'email', 'grade_level_category',
                  'grade_prefix', 'ic', 'married', 'name', 'position',
                  'resigned', 'salary_group', 'salary_scheme', 'staff_no',
                  'user', 'position_label', 'groups', 'is_admin', 'detail_url',
                  'assignee')

    def get_company_levels_data(self, obj):
        qs = obj.company_levels.all()
        return [{'code': lvl.code, 'level': lvl.level.title,
                 'title': unicode(lvl)} for lvl in qs]

    def get_position_label(self, obj):
        if obj.position is not None:
            return obj.position.description

    def get_groups(self, obj):
        if hasattr(obj, 'assignee'):
            return u", ".join(unicode(gr) for gr in obj.assignee.groups.all())

    def get_detail_url(self, obj):
        baseurl = reverse_lazy('settings_claimant_detail')
        return "{}?pk={}".format(baseurl, obj.pk)


class SpouseSerializer(serializers.ModelSerializer):
    class Meta:
        model = Spouse
        fields = ('id', 'staff', 'name', 'ic', 'grade', 'position',
                  'basic_salary', 'employer_name', 'address1', 'address2',
                  'address3')


class ChildrenSerializer(serializers.ModelSerializer):
    parent = serializers.PrimaryKeyRelatedField(queryset=Spouse.objects.all())
    parent_name = serializers.SerializerMethodField()

    class Meta:
        model = Children
        fields = ('id', 'staff', 'name', 'ic', 'age', 'work_status',
                  'oku_status', 'parent', 'parent_name')

    def get_parent_name(self, obj):
        return obj.parent.name


class BudgetSerializer(serializers.ModelSerializer):
    class Meta:
        model = Budget
        depth = 1
        fields = ('id', 'bcac_account', 'bcac_amount', 'bcac_monitorglac', 'bcac_status', 'bcac_warnflag')


class VehicleTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = VehicleType
        fields = ('id', 'name')


class DocumentListSerializer(serializers.ModelSerializer):
    class Meta:
        model = DocumentList
        fields = ('id', 'description', 'claim_type', 'document_group', 'sequence')


class MovingAllowanceEntitlementSerializer(serializers.ModelSerializer):
    ssm_salary_group = serializers.PrimaryKeyRelatedField(queryset=SalaryGroup.objects.all())
    ssm_grade_from = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    ssm_grade_to = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    title = serializers.SerializerMethodField()
    effective_date = serializers.DateField(input_formats=['%d-%m-%Y'])

    class Meta:
        model = MovingAllowanceEntitlement
        fields = ('id', 'effective_date', 'ssm_salary_group', 'ssm_grade_from', 'ssm_grade_to', 'ssm_salary_from', 'ssm_salary_to', 'title')

    def get_title(self, obj):
        return u"({}) {} - {}".format(obj.ssm_salary_group.code, obj.ssm_grade_from.description, obj.ssm_grade_to.description)


class HouseMovingAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=MovingAllowanceEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()
    region_description = serializers.SerializerMethodField()

    class Meta:
        model = HouseMovingAllowance
        fields = ('id', 'entitlement', 'single', 'married', 'region', 'region_description', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)

    def get_region_description(self, obj):
        for code, label in REGION_LIST:
            if obj.region == code:
                return label


class InMalaysiaEntitlementSerializer(serializers.ModelSerializer):
    ssm_salary_group = serializers.PrimaryKeyRelatedField(queryset=SalaryGroup.objects.all())
    ssm_grade_from = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    ssm_grade_to = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    title = serializers.SerializerMethodField()
    effective_date = serializers.DateField(input_formats=['%d-%m-%Y'])

    class Meta:
        model = InMalaysiaEntitlement
        fields = ('id', 'effective_date', 'ssm_salary_group', 'ssm_grade_from', 'ssm_grade_to', 'ssm_salary_from', 'ssm_salary_to', 'title')

    def get_title(self, obj):
        return u"({}) {} - {}".format(obj.ssm_salary_group.code, obj.ssm_grade_from.description, obj.ssm_grade_to.description)


class OfficialTripAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=InMalaysiaEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = OfficialTripAllowance
        fields = ('id', 'entitlement', 'meal', 'hotel', 'lodging', 'region', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class CourseTripAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=InMalaysiaEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = CourseTripAllowance
        fields = ('id', 'entitlement', 'entitlement_title', 'meal', 'hotel', 'lodging', 'region')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class CourseDailyAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=InMalaysiaEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = CourseDailyAllowance
        fields = ('id', 'entitlement', 'entitlement_title', 'long_term', 'short_term', 'part_time', 'meal_aid', 'transport_aid', 'course_location')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class OverseaEntitlementSerializer(serializers.ModelSerializer):
    ssm_salary_group = serializers.PrimaryKeyRelatedField(queryset=SalaryGroup.objects.all())
    ssm_grade_from = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    ssm_grade_to = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    title = serializers.SerializerMethodField()
    effective_date = serializers.DateField(input_formats=['%d-%m-%Y'])

    class Meta:
        model = OverseaEntitlement
        fields = ('id', 'effective_date', 'ssm_salary_group', 'ssm_grade_from', 'ssm_grade_to', 'ssm_salary_from', 'ssm_salary_to', 'title', 'country_category')

    def get_title(self, obj):
        return u"({}) {} - {}".format(obj.ssm_salary_group.code, obj.ssm_grade_from.description, obj.ssm_grade_to.description)


class OfficialTripOverseaAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=OverseaEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = OfficialTripOverseaAllowance
        fields = ('id', 'entitlement', 'entitlement_title', 'meal', 'hotel', 'lodging')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class CourseTripOverseaAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=OverseaEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = CourseTripOverseaAllowance
        fields = ('id', 'entitlement', 'entitlement_title', 'meal', 'hotel', 'lodging')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class TransferWithinStateEntitlementSerializer(serializers.ModelSerializer):
    ssm_salary_group = serializers.PrimaryKeyRelatedField(queryset=SalaryGroup.objects.all())
    ssm_grade_from = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    ssm_grade_to = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    title = serializers.SerializerMethodField()
    effective_date = serializers.DateField(input_formats=['%d-%m-%Y'])

    class Meta:
        model = TransferWithinStateEntitlement
        fields = ('id', 'effective_date', 'ssm_salary_group', 'ssm_grade_from', 'ssm_grade_to', 'ssm_salary_from', 'ssm_salary_to', 'title')

    def get_title(self, obj):
        return u"({}) {} - {}".format(obj.ssm_salary_group.code, obj.ssm_grade_from.description, obj.ssm_grade_to.description)


class WestMalaysiaTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferWithinStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = WestMalaysiaTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class SarawakTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferWithinStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = SarawakTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class SabahTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferWithinStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = SabahTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class TransferBetweenStateEntitlementSerializer(serializers.ModelSerializer):
    ssm_salary_group = serializers.PrimaryKeyRelatedField(queryset=SalaryGroup.objects.all())
    ssm_grade_from = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    ssm_grade_to = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all())
    title = serializers.SerializerMethodField()
    effective_date = serializers.DateField(input_formats=['%d-%m-%Y'])

    class Meta:
        model = TransferBetweenStateEntitlement
        fields = ('id', 'effective_date', 'ssm_salary_group', 'ssm_grade_from', 'ssm_grade_to', 'ssm_salary_from', 'ssm_salary_to', 'title')

    def get_title(self, obj):
        return u"({}) {} - {}".format(obj.ssm_salary_group.code, obj.ssm_grade_from.description, obj.ssm_grade_to.description)


class FromWestMalaysiaTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferBetweenStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = FromWestMalaysiaTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class FromSarawakTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferBetweenStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = FromSarawakTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class FromSabahTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferBetweenStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = FromSabahTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)


class BetweenSabahSarawakTransferAllowanceSerializer(serializers.ModelSerializer):
    entitlement = serializers.PrimaryKeyRelatedField(queryset=TransferBetweenStateEntitlement.objects.all())
    entitlement_title = serializers.SerializerMethodField()

    class Meta:
        model = BetweenSabahSarawakTransferAllowance
        fields = ('id', 'single', 'married', 'meal_replacement', 'miscellaneous', 'entitlement', 'entitlement_title')

    def get_entitlement_title(self, obj):
        return u"({}) {} - {}".format(obj.entitlement.ssm_salary_group.code, obj.entitlement.ssm_grade_from.description, obj.entitlement.ssm_grade_to.description)
