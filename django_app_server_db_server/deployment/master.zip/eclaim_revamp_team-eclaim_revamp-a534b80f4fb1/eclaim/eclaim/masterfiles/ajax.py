from django.http import HttpResponse

from eclaim.utils.common import get_json_from_list

from .models.misc import (PUBLIC_TRANSPORT_LIST, MISC_EXPENSES_LIST, REGION_LIST,
                          COURSE_LOCATION_LIST, MILEAGE_TRIP_TYPE, DESTINATION_TYPE,
                          TRANSIT_TYPE, ACCOMMODATION_TYPE, FARE_REPLACEMENT_TYPE,
                          FLIGHT_CLASS_TYPE)


def get_public_transport_list(request):
    return HttpResponse(get_json_from_list(PUBLIC_TRANSPORT_LIST))

def get_misc_expenses_list(request):
    return HttpResponse(get_json_from_list(MISC_EXPENSES_LIST))

def get_region_list(request):
    return HttpResponse(get_json_from_list(REGION_LIST))

def get_course_location_list(request):
    return HttpResponse(get_json_from_list(COURSE_LOCATION_LIST))

def get_mileage_trip_type(request):
    return HttpResponse(get_json_from_list(MILEAGE_TRIP_TYPE))

def get_destination_type(request):
    return HttpResponse(get_json_from_list(DESTINATION_TYPE))

def get_transit_type(request):
    return HttpResponse(get_json_from_list(TRANSIT_TYPE))

def get_accommodation_type(request):
    return HttpResponse(get_json_from_list(ACCOMMODATION_TYPE))

def get_fare_replacement_type(request):
    return HttpResponse(get_json_from_list(FARE_REPLACEMENT_TYPE))

def get_flight_class_type(request):
    return HttpResponse(get_json_from_list(FLIGHT_CLASS_TYPE))
