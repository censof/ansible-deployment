from .models.claimant import Claimant, ClaimantHistory
from .models.document import DocumentList, DocumentListItem, DocumentListItemDraft


def save_claimant_history(staff_no, claim_no, claim_type):
    claimant = Claimant.objects.get(staff_no=staff_no)
    try:
        claimant_history = ClaimantHistory.objects.get(staff_no=staff_no,
                                                       claim_id=claim_no,
                                                       claim_type=claim_type)
    except ClaimantHistory.DoesNotExist:
        claimant_history = ClaimantHistory()
        claimant_history.claim_id = claim_no
        claimant_history.claim_type = claim_type
        claimant_history.staff_no = claimant.staff_no

    claimant_history.name = claimant.name
    claimant_history.ic = claimant.ic
    claimant_history.resigned = claimant.resigned
    claimant_history.basic_salary = claimant.basic_salary
    claimant_history.bank_info = claimant.bank_info
    claimant_history.salary_scheme = claimant.salary_scheme
    claimant_history.salary_group = claimant.salary_group
    claimant_history.grade_prefix = claimant.grade_prefix
    claimant_history.grade_level_category = claimant.grade_level_category
    claimant_history.position = claimant.position
    claimant_history.save()
    return claimant_history

def get_document_list(claim_type):
    list = None
    try:
        list = DocumentList.objects.filter(claim_type=claim_type)
    except DocumentList.DoesNotExist:
        pass
    return list

def get_document_list_item(claim_no, claim_type, sub_group_id=[]):
    # doclist = DocumentListItem.objects.filter(
    #     claim_no=claim_no,
    #     claim_type=claim_type
    #     )
    # return doclist
    list = None
    try:
        list = DocumentListItem.objects.filter(claim_no=claim_no, claim_type=claim_type)
        list = list.filter(sub_group_id__in=sub_group_id)
    except DocumentList.DoesNotExist:
        pass
    return list

def get_document_list_item_draft(draft_id, claim_type, sub_group_id=[]):
    list = None
    try:
        list = DocumentListItemDraft.objects.filter(draft_id=draft_id, claim_type=claim_type)
        list = list.filter(sub_group_id__in=sub_group_id)
    except DocumentList.DoesNotExist:
        pass
    return list

def save_document_list_item_draft(draft_id, claim_type, form_data):
    delete_list = []
    saved_list = DocumentListItemDraft.objects.filter(draft_id=draft_id, claim_type=claim_type)

    for i in saved_list:
        delete_list.append({'id':i.id})

    for i in form_data.get('document_list'):
        document_list = DocumentList.objects.get(id=int(i['selected_item']))
        saveObj = DocumentListItemDraft()
        saveObj.draft_id = draft_id
        saveObj.claim_type = claim_type
        saveObj.document_list = document_list
        saveObj.save()

    for i in delete_list:
        delObj = DocumentListItemDraft.objects.get(id=i['id'])
        delObj.delete()

def save_document_list_item(claim_no, claim_type, form_data):
    delete_list = []
    saved_list = DocumentListItem.objects.filter(claim_no=claim_no, claim_type=claim_type)

    for i in saved_list:
        delete_list.append({'id':i.id})

    for i in form_data.get('document_list'):
        document_list = DocumentList.objects.get(id=int(i['selected_item']))
        saveObj = DocumentListItem()
        saveObj.claim_no = claim_no
        saveObj.claim_type = claim_type
        saveObj.document_list = document_list
        saveObj.save()

    for i in delete_list:
        delObj = DocumentListItem.objects.get(id=i['id'])
        delObj.delete()
