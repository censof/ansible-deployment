from django.conf import settings

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'base_settings',
    'pagination'
    ]


def base_settings(request):
    return {'HOST_URL': settings.HOST_URL}


def pagination(request):
    return {'PAGE_SIZE': settings.REST_FRAMEWORK['PAGE_SIZE']}
