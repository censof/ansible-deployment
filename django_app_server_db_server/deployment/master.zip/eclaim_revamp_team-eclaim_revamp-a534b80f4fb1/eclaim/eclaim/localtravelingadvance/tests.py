from eclaim.localtravelingadvance.processes import local_traveling_advance_process
from unittest import TestCase
from mock import call, patch


class LocalTravelingAdvanceTests(TestCase):

    @patch('eclaim.localtravelingadvance.processes.save_draft')
    def test_local_traveling_advance_process(self, mock_save_draft):

        """Test local_traveling_advance_process when btn_mode 'save_draft'"""
        local_traveling_advance_process('save_draft', {'a': 'a', 'b': 'b'},
                              created_by='mock_user')
        self.assertEqual(mock_save_draft.call_args,
                         call({'a': 'a', 'b': 'b'}, 'mock_user'))


    @patch('eclaim.localtravelingadvance.processes.submit_claim')
    def test_local_traveling_advance_process_submit(self, mock_submit_claim):

        """Test for local_traveling_advance_process when btn_mode 'submit'"""
        local_traveling_advance_process('submit', {'a': 'a', 'b': 'b'},
                              created_by='mock_user')
        self.assertEqual(mock_submit_claim.call_args,
                         call({'a': 'a', 'b': 'b'}))
