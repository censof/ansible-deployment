from django.conf.urls import patterns, url

from .views import LocalTravelingAdvanceIndexView, LocalTravelingAdvanceDetailView, LocalTravelingAdvanceDraftView

urlpatterns = patterns('',
    url(r'^$', LocalTravelingAdvanceIndexView.as_view(), name='localtravelingadvance_index'),
    url(r'^detail/$', LocalTravelingAdvanceDetailView.as_view(), name='localtravelingadvance_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', LocalTravelingAdvanceDraftView.as_view(), name='localtravelingadvance_draft')
)
