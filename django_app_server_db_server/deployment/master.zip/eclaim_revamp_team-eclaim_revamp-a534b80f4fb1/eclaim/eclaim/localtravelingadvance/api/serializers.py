from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTravelingAdvanceSerializer',
    'LocalTravelingAdvanceDraftSerializer'
    ]


class LocalTravelingAdvanceSerializer(BaseClaimSerializer):
    advance_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTravelingAdvance
        fields = BaseClaimSerializer.Meta.fields + ('advance_details',)

    def get_advance_details(self, obj):
        advance_details = obj.localtravelingadvanceparentitem_set.all()
        advance_details_pk = advance_details.values_list('pk', flat=True)
        child_items = LocalTravelingAdvanceChildItem.objects.filter(local_traveling_advance__in=advance_details_pk)
        return {'advance_details': advance_details.values()
                ,'child_items': child_items.values()
        }


class LocalTravelingAdvanceDraftSerializer(serializers.ModelSerializer):
    advance_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTravelingAdvanceDraft
        fields = '__all__'

    def get_advance_details(self, obj):
        advance_details = obj.localtravelingadvanceparentitemdraft_set.all()
        advance_details_pk = advance_details.values_list('pk', flat=True)
        child_items = LocalTravelingAdvanceChildItemDraft.objects.filter(local_traveling_advance_draft__in=advance_details_pk)
        return {'advance_details': advance_details.values()
                ,'child_items': child_items.values()
        }
