from rest_framework import viewsets
from .serializers import LocalTravelingAdvanceSerializer, LocalTravelingAdvanceDraftSerializer
from ..models import LocalTravelingAdvance, LocalTravelingAdvanceDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTravelingAdvanceViewSet',
    'LocalTravelingAdvanceDraftViewSet'
    ]


class LocalTravelingAdvanceViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTravelingAdvanceSerializer
    queryset = LocalTravelingAdvance.objects.all()


class LocalTravelingAdvanceDraftViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTravelingAdvanceDraftSerializer
    queryset = LocalTravelingAdvanceDraft.objects.all()
