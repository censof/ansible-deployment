from datetime import datetime
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text
from rest_framework import serializers
from eclaim.settings.models import WorkflowStateLog, UserGroup
from ..models import ClaimType

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = ['ClaimTypeSerializer',
           'WorkflowStateLogSerializer',
           'DraftSerializer']


class ClaimTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = ClaimType
        depth = 1
        fields = ('id', 'title', 'is_enabled', 'description')


class WorkflowStateLogSerializer(serializers.Serializer):
    """Serializer for WorkflowStateLog objects to render on dashboard."""
    pk = serializers.SerializerMethodField()
    claim_no = serializers.SerializerMethodField()
    status = serializers.SerializerMethodField()
    claimant = serializers.SerializerMethodField()
    claimant_staff_no = serializers.SerializerMethodField()
    created = serializers.DateTimeField()
    completed = serializers.DateTimeField()
    elapsed_days = serializers.SerializerMethodField()
    action_taken = serializers.SerializerMethodField()
    claim_type = serializers.SerializerMethodField()
    claim_ctype_id = serializers.SerializerMethodField()
    is_finally_approved = serializers.SerializerMethodField()
    is_finally_rejected = serializers.SerializerMethodField()
    is_approved = serializers.SerializerMethodField()
    query = serializers.SerializerMethodField()
    queried_by = serializers.SerializerMethodField()
    is_latest = serializers.SerializerMethodField()
    is_latest_for_state = serializers.SerializerMethodField()
    has_query_label = serializers.SerializerMethodField()
    approved_by = serializers.SerializerMethodField()
    detail_url = serializers.SerializerMethodField()
    current_assignee = serializers.SerializerMethodField()
    approver_detail_url = serializers.SerializerMethodField()
    is_cancelled = serializers.SerializerMethodField()
    cancelled_by = serializers.SerializerMethodField()
    assignee_list = serializers.SerializerMethodField()
    action_date_list = serializers.SerializerMethodField()

    class Meta:
        fields = (
            'pk',
            'claim_no',
            'status',
            'claimant',
            'created',
            'elapsed_days',
            'action_taken',
            'claim_type',
            'claim_ctype_id',
            'is_finally_approved',
            'is_finally_rejected',
            'is_approved',
            'query',
            'queried_by',
            'is_latest',
            'is_latest_for_state',
            'has_query_label',
            'approved_by',
            'detail_url',
            'notes',
            'current_assignee',
            'approver_detail_url',
            'is_cancelled',
            'cancelled_by',
            'assignee_list',
            'action_date_list'
        )

    def get_pk(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.object_id
        return obj.object_id

    def get_claim_no(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.content_object.claim_no

    def get_status(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.get_latest_state().get_status()

    def get_claimant(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.claimant.name
        return obj.claimant.name

    def get_claimant_staff_no(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.claimant.staff_no
        return obj.claimant.staff_no

    def get_elapsed_days(self, obj):
        created = obj.created
        action_taken = self.get_action_taken(obj)
        if created and action_taken is not None:
            return (action_taken - created).days
        return 0

    def get_action_taken(self, obj):
        state = obj.get_state()
        if state is not None:
            logs = WorkflowStateLog.objects.filter(
                content_type=state.content_type,
                object_id=state.object_id,
                completed__isnull=False)
            if logs.exists():
                return logs.latest().completed

    def get_claim_type(self, obj):
        state = obj.get_state()
        if state is not None:
            return force_text(state.content_type)
        return force_text(obj.content_type)

    def get_claim_ctype_id(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.content_type.pk
        return obj.content_type.pk

    def get_query(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.has_active_query

    def get_queried_by(self, obj):
        state = obj.get_state()
        if state is not None and state.has_active_query:
            query_states = state.get_latest_state().query_states.all()
            if query_states.exists():
                return force_text(query_states.latest().queried_by)

    def get_is_finally_approved(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.is_finally_approved
        return False

    def get_is_finally_rejected(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.is_finally_rejected
        return False

    def get_is_approved(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.is_approved
        return obj.is_approved

    def get_is_latest(self, obj):
        return obj.is_latest()

    def get_is_latest_for_state(self, obj):
        return obj.is_latest_for_state()

    def get_has_query_label(self, obj):
        return obj.query

    def get_approved_by(self, obj):
        if obj.approved_by is not None:
            return obj.approved_by.name

    def get_approver_detail_url(self, obj):
        if obj.approved_by is not None:
            baseurl = reverse_lazy('settings_claimant_detail')
            return "{}?pk={}".format(baseurl, obj.approved_by.claimant.pk)

    def get_detail_url(self, obj):
        return obj.content_object.get_absolute_url()

    def get_current_assignee(self, obj):
        return obj.current_assignee

    def get_assignee_list(self, obj):
        state = obj.get_state()
        if state is not None:
            assigned = state.get_assigned_entity()
            if assigned is not None:
                if isinstance(assigned, UserGroup):
                    return [force_text(o) for o in assigned.assignee_set.all()]

    def get_is_cancelled(self, obj):
        state = obj.get_state()
        if state is not None:
            return state.is_finally_cancelled
        return False

    def get_cancelled_by(self, obj):
        if obj.cancelled_by is not None:
            return obj.cancelled_by.name

    def get_action_date_list(self, obj):
        dates = []
        state = obj.get_state()
        if state is not None:
            log_list = WorkflowStateLog.objects.filter(
                content_type=state.content_type,
                object_id=state.object_id,
                completed__isnull=False)
            for log in log_list:
                completed = datetime.strftime(log.completed, '%d-%M-%Y')
                dates.append("{} - {}".format(completed, force_text(log)))
        return dates


class DraftSerializer(serializers.Serializer):
    pk = serializers.SerializerMethodField()
    model = serializers.SerializerMethodField()
    app = serializers.SerializerMethodField()
    detail_url = serializers.SerializerMethodField()
    claim_type = serializers.SerializerMethodField()
    created = serializers.SerializerMethodField()
    modified = serializers.SerializerMethodField()

    class Meta:
        fields = ('pk', 'model', 'app', 'detail_url', 'claim_type', 'created',
                  'modified')

    def get_created(self, obj):
        return obj.created

    def get_modified(self, obj):
        return obj.modified

    def get_pk(self, obj):
        return obj.pk

    def get_detail_url(self, obj):
        return obj.get_absolute_url()

    def get_claim_type(self, obj):
        try:
            claim_type = obj.get_claim_type()  # legacy
        except AttributeError:
            claim_type = ClaimType.get_claim_type(obj.CLAIM_TYPE)
        return force_text(claim_type)

    def get_model(self, obj):
        return obj.__class__.__name__

    def get_app(self, obj):
        return obj._meta.app_label
