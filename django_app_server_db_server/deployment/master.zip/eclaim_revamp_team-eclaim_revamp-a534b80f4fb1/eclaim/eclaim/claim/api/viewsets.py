from django.db.models import Q
from django.conf import settings
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404
from django.utils.decorators import method_decorator
from rest_framework import viewsets, mixins, permissions
from eclaim.localtransfer.models import LocalTransferClaimDraft
from eclaim.advance.models import MiscAdvanceDraft
from eclaim.overseaadvance.models import OverseaMiscAdvanceDraft
from eclaim.settings.models import (
    WorkflowState, WorkflowStateLog, SelectedAssignee)
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.company import CompanyLevel
from eclaim.lecture.models import LectureClaimDraft
from eclaim.dental.models import DentalClaimDraft
from eclaim.housemoving.models import HouseMovingClaimDraft
from eclaim.medical.models import MedicalClaimDraft
from eclaim.miscellaneous.models import MiscellaneousClaimDraft
from eclaim.localtravel.models import LocalTravelClaimDraft
from eclaim.libs.permissions import get_user_permissions
from .serializers import (
    WorkflowStateLogSerializer, ClaimTypeSerializer, DraftSerializer)
from ..models import ClaimType

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'ClaimTypeViewSet',
    'ClaimViewSet',
    'SubmittedClaimViewSet',
    'QueriedClaimViewSet',
    'CompletedClaimViewSet',
    'PendingClaimViewSet',
    'ApprovedClaimViewSet',
    'RejectedClaimViewSet',
    'DraftViewSet',
    'CancelledClaimViewSet',
    'AdminCompletedViewSet',
    'AdminPendingViewSet'
    ]

DRAFT_MODELS = [
    LectureClaimDraft,
    MiscAdvanceDraft,
    OverseaMiscAdvanceDraft,
    DentalClaimDraft,
    HouseMovingClaimDraft,
    LocalTransferClaimDraft,
    MedicalClaimDraft,
    MiscellaneousClaimDraft,
    LocalTravelClaimDraft
    ]


class ClaimTypeViewSet(viewsets.ModelViewSet):
    serializer_class = ClaimTypeSerializer
    paginate_by = 30

    def get_queryset(self):
        if 'is_enabled' in self.request.GET:
            qs = ClaimType.enabled_objects.all()
        else:
            qs = ClaimType.objects.all()

        if 'has_template' in self.request.GET:
            has_template = bool(self.request.GET.get('has_template', False))
            qs = qs.filter(template__isnull=has_template)

        return qs


class ClaimViewSet(mixins.RetrieveModelMixin, mixins.ListModelMixin,
                   viewsets.GenericViewSet):
    serializer_class = WorkflowStateLogSerializer

    def get_queryset(self):
        """List view."""
        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        status_id = self.request.GET.get('status')

        if status_id and claimant is not None and hasattr(claimant, 'workflowtemplatedetails'):
            wf_details = claimant.workflowtemplatedetails
            cl_companylevels = claimant.company_levels.all()
            wf_companylevels = wf_details.levels.all()
            has_perm = True

            # Check whether a claimant is in the suitable company.
            for i, level in enumerate(wf_companylevels):
                if cl_companylevels.count() >= i+1:
                    has_perm = cl_companylevels[i] == wf_companylevels[i]
                    if not has_perm:
                        break

            if has_perm:
                # Check if the claimant grade falls within the corresponding
                # grade range.
                if wf_details.grade_from.ordering < claimant.grade_level_category.ordering < wf_details.grade_to.ordering:
                    wf_states = WorkflowState.objects.filter(
                        level__group__status__pk=status_id,
                        level__workflowtemplatedetails__levels__in=cl_companylevels
                        ).distinct()
                    return wf_states
        return []

    def get_object(self):
        """Detail view."""
        state = get_object_or_404(WorkflowState, pk=self.kwargs['pk'])
        return state.workflowstatelog_set.latest()


class _BaseClaimsViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """Base class for the dashboard."""
    serializer_class = WorkflowStateLogSerializer

    class Meta:
        abstract = True

    @method_decorator(login_required)
    def dispatch(self, request, *args, **kwargs):
        return super(_BaseClaimsViewSet, self
                     ).dispatch(request, *args, **kwargs)

    def get_queryset(self):
        qs = WorkflowStateLog.objects.all()

        # Allow claim list lookup by a reference number.
        query = self.request.GET.get('query')
        if query:
            qs = qs.filter(claim_no__icontains=query)

        # Apply various filters set by the user.
        claim_type = self.request.GET.get('claim_type')
        verif = self.request.GET.get('verification')
        if claim_type or verif:
            for obj in qs:
                exclude_obj = False
                if claim_type:
                    claim = obj.content_object
                    try:
                        _claim_type = claim.get_claim_type()  # legacy
                    except AttributeError:
                        _claim_type = ClaimType.get_claim_type(
                            claim.CLAIM_TYPE)
                    if _claim_type.pk != int(claim_type):
                        exclude_obj = True
                if verif:
                    state = obj.get_state()
                    if verif == 'approved' and not state.is_finally_approved:
                        exclude_obj = True
                    elif verif == 'rejected' and not state.is_finally_rejected:
                        exclude_obj = True
                if exclude_obj:
                    qs = qs.exclude(pk=obj.pk)

        return qs


class _MyTaskPermission(permissions.BasePermission):
    def has_permission(self, request, view):
        perms = get_user_permissions(request.user)
        return perms['CAN_ACCESS_MY_TASKS']


class _MyTaskViewSet(_BaseClaimsViewSet):
    """Base class for the tasks belonging to the currently logged in user."""
    permission_classes = (_MyTaskPermission,)

    class Meta:
        abstract = True

    def get_queryset(self):
        def _has_view_perm(claimant, company_levels, grade_from, grade_to):
            """Perform checks to ensure that an assignee is able to view
            a claim.

            Firstly check whether a claimant's grade falls into the
            corresponding grade range. Then check if a claimant is in the
            suitable company.
            """
            cl_companylevels = claimant.company_levels.all()
            grade = claimant.grade_level_category.ordering
            if grade_from.ordering < grade < grade_to.ordering:
                orderings = company_levels.values_list(
                    'level__ordering', flat=True
                    ).distinct()
                for i in orderings:
                    try:
                        cl_complevel = cl_companylevels.get(level__ordering=i)
                    except CompanyLevel.DoesNotExist:
                        return False
                    complevels = company_levels.filter(level__ordering=i)
                    if cl_complevel not in complevels:
                        return False
                return True
            return False

        qs = super(_MyTaskViewSet, self).get_queryset()
        qs = qs.filter(is_cancelled=False)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        pk_list = []

        # Magic. Do not touch.
        if claimant is not None and hasattr(claimant, 'assignee'):
            assignee = claimant.assignee
            groups = assignee.groups.all()
            _innerqs = qs.exclude(state__claimant=claimant,
                                  query_state__state__claimant=claimant)
            wf_detail_list = assignee.workflowtemplatedetails_set.all()

            for log in _innerqs:
                # If ticked in settings, exclude his own claims.
                if (not settings.ALLOW_MANAGING_OWN_CLAIMS and
                        log.claimant == claimant):
                    continue

                state = log.get_state()
                if state is not None:
                    assigned = state.get_assigned_entity()
                    if isinstance(assigned, SelectedAssignee):
                        # Add an object to object list if an assignee was
                        # selected manually in a claim form.
                        if assigned.assignee == assignee:
                            pk_list.append(log.pk)
                    elif wf_detail_list.exists() and log.level.group in groups:
                        for wf_details in wf_detail_list:
                            wf_complevels = wf_details.levels.all()
                            if _has_view_perm(state.claimant, wf_complevels,
                                              wf_details.grade_from,
                                              wf_details.grade_to):
                                pk_list.append(log.pk)

            return qs.filter(pk__in=pk_list).order_by('-created')
        return qs.none()


class CompletedClaimViewSet(_MyTaskViewSet):
    """Approved, rejected and queried claims."""
    def get_queryset(self):
        qs = super(CompletedClaimViewSet, self).get_queryset()
        qs = qs.filter(approved_by__claimant__user=self.request.user)
        object_list = []
        for obj in qs:
            state = obj.get_state()
            if state is None or (state.is_approved is not None or
                                 state.has_active_query):
                object_list.append(obj)
        return object_list


class PendingClaimViewSet(_MyTaskViewSet):
    """Claims which are neither approved nor rejected."""
    def get_queryset(self):
        qs = super(PendingClaimViewSet, self).get_queryset()
        object_list = []
        for obj in qs:
            state = obj.get_state()
            if state is not None and obj.is_latest_for_state() and \
                    not state.has_active_query and state.is_approved is None:
                object_list.append(obj)
        return object_list


class _MyClaimPermission(permissions.BasePermission):
    def has_permission(self, request, view):
        perms = get_user_permissions(request.user)
        return perms['CAN_ACCESS_MY_CLAIMS']


class _MyClaimViewSet(_BaseClaimsViewSet):
    """Base class for the claims which belong to the currently logged in
    user.
    """
    permission_classes = (_MyClaimPermission,)

    class Meta:
        abstract = True

    def get_queryset(self):
        qs = super(_MyClaimViewSet, self).get_queryset()
        user = self.request.user
        qs = qs.filter(Q(state__claimant__user=user) |
                       Q(query_state__state__claimant__user=user))
        return qs.distinct().order_by('-created')


class _NonCancelledClaimMixin(object):
    """Claims which are not cancelled."""
    class Meta:
        abstract = True

    def get_queryset(self):
        qs = super(_NonCancelledClaimMixin, self).get_queryset()
        pk_list = []
        for obj in qs:
            state = obj.get_state()
            if not state.is_finally_cancelled:
                pk_list.append(obj.pk)
        return qs.filter(pk__in=pk_list)


class SubmittedClaimViewSet(_NonCancelledClaimMixin, _MyClaimViewSet):
    """Claims which are neither approved nor rejected."""
    def get_queryset(self):
        qs = super(SubmittedClaimViewSet, self).get_queryset()
        object_list = []
        for obj in qs:
            state = obj.get_state()
            if (obj.is_latest() and state.is_approved is None and
                    not state.has_active_query):
                object_list.append(obj)
        return object_list


class QueriedClaimViewSet(_NonCancelledClaimMixin, _MyClaimViewSet):
    """Claims which are query."""
    def get_queryset(self):
        qs = super(QueriedClaimViewSet, self).get_queryset()
        object_list = []
        for obj in qs:
            state = obj.get_state()
            if state.has_active_query and obj.query and \
                    not obj.query_state.is_resubmitted:
                object_list.append(obj)
        return object_list


class ApprovedClaimViewSet(_MyClaimViewSet):
    """Approved claims."""
    def get_queryset(self):
        qs = super(ApprovedClaimViewSet, self).get_queryset()
        object_list = []
        for obj in qs:
            if obj.is_latest() and obj.get_state().is_finally_approved:
                object_list.append(obj)
        return object_list


class RejectedClaimViewSet(_MyClaimViewSet):
    """Rejected claims."""
    def get_queryset(self):
        qs = super(RejectedClaimViewSet, self).get_queryset()
        object_list = []
        for obj in qs:
            if obj.is_latest() and obj.get_state().is_finally_rejected:
                object_list.append(obj)
        return object_list


class DraftViewSet(mixins.ListModelMixin, viewsets.GenericViewSet):
    """Claim drafts. One view to rule them all."""
    serializer_class = DraftSerializer

    @method_decorator(login_required)
    def dispatch(self, request, *args, **kwargs):
        return super(DraftViewSet, self).dispatch(request, *args, **kwargs)

    def get_queryset(self):
        result = []
        user = self.request.user
        for model in DRAFT_MODELS:
            qs = model.objects.filter(created_by=user)
            result.extend(qs)
        return sorted(result, key=lambda x: x.created, reverse=True)


class CancelledClaimViewSet(_MyClaimViewSet):
    """Cancelled claims."""
    def get_queryset(self):
        qs = super(CancelledClaimViewSet, self).get_queryset()
        return list(qs.filter(is_cancelled=True))


class AdminCompletedViewSet(_BaseClaimsViewSet):
    """Admin / Completed claims."""
    def get_queryset(self):
        qs = super(AdminCompletedViewSet, self).get_queryset()
        object_list = []
        for obj in qs.order_by('-created'):
            if obj.is_latest():
                state = obj.get_state()
                approved = state.is_finally_approved
                rejected = state.is_finally_rejected
                cancelled = state.is_cancelled
                if approved or rejected or cancelled:
                    object_list.append(obj)
        return object_list


class AdminPendingViewSet(_BaseClaimsViewSet):
    """Admin / Pending claims."""
    def get_queryset(self):
        qs = super(AdminPendingViewSet, self).get_queryset()
        object_list = []
        for obj in qs.order_by('-created'):
            if obj.is_latest():
                state = obj.get_state()
                approved = state.is_finally_approved
                rejected = state.is_finally_rejected
                cancelled = state.is_finally_cancelled
                if not approved and not rejected and not cancelled:
                    object_list.append(obj)
        return object_list
