from django.contrib.contenttypes.models import ContentType
from django.core.urlresolvers import reverse
from eclaim.libs.tests import TestCase
from eclaim.miscellaneous.models import MiscellaneousClaim


class CancelClaimTestCase(TestCase):
    def test_login_required(self):
        self.logout()
        response = self.client.get(reverse('claim_ajax_cancel'))
        self.assertRedirects(response, '/eclaim/login/')

    def test_get_method(self):
        response = self.client.get(reverse('claim_ajax_cancel'))
        self.assertEquals(response.status_code, 405)

    def test_post_method(self):
        ctype = ContentType.objects.get_for_model(MiscellaneousClaim)
        claim = MiscellaneousClaim.objects.latest('pk')
        data = {
            'claim_no': str(claim.claim_no),
            'claim_ctype': ctype.pk,
            'reason': "The claimant duplicated this claim"
            }
        response = self.client.post(reverse('claim_ajax_cancel'), data,
                                    'application/json;charset=UTF-8')
        self.assertEquals(response.status_code, 200)
        self.assertIsInstance(response.content, str)
