/**
 * Claim App Controller
 */
var claimApp = angular
    .module('claimApp', ['angularUtils.directives.dirPagination'])
    .config(httpInterceptor)
    .config(function ($interpolateProvider) {
        $interpolateProvider.startSymbol('[[');
        $interpolateProvider.endSymbol(']]');
    });

claimApp.directive('onEnter', function () {
    return function (scope, element, attrs) {
        element.bind('keydown keypress', function (event) {
            if (event.which === 13) {
                scope.$apply(function () {
                    scope.$eval(attrs.onEnter);
                });
                event.preventDefault();
            }
        });
    };
});

claimApp.controller('claimController', function ($scope, $http, $location, $q) {
    /**
     * Initial values
     */
    $scope.is_loading = true;
    $scope.badges_loading = true;
    $scope.claims_count = {};
    $scope.query = QUERY;
    $scope.claim_list = [];
    $scope.total_claims = 0;
    $scope.is_loading = false;

    var urls = {};

    if (CAN_ACCESS_MY_TASKS) {
        urls.completed = API_URL + 'completed-claims/';
        urls.pending = API_URL + 'pending-claims/';
    }
    if (CAN_ACCESS_MY_CLAIMS) {
        urls.submitted = API_URL + 'submitted-claims/';
        urls.query = API_URL + 'queried-claims/';
        urls.approved = API_URL + 'approved-claims/';
        urls.rejected = API_URL + 'rejected-claims/';
        urls.drafts = API_URL + 'drafts/';
        urls.cancelled = API_URL + 'cancelled-claims/';
    }
    if (IS_ADMIN) {
        urls.admin_completed = API_URL + 'admin/completed-claims/';
        urls.admin_pending = API_URL + 'admin/pending-claims/';
    }

    /**
     * Show badges of total items next to claim labels in the sidebar
     */
    var promises = {};
    for (var key in urls) {
        promises[key] = $http({
            url: urls[key],
            method: 'GET'
        });
    }
    $q.all(promises).then(function (resolutions) {
        if (CAN_ACCESS_MY_TASKS) {
            $scope.claims_count.completed = resolutions.completed.data.count || '';
            $scope.claims_count.pending = resolutions.pending.data.count || '';
        }
        if (CAN_ACCESS_MY_CLAIMS) {
            $scope.claims_count.submitted = resolutions.submitted.data.count || '';
            $scope.claims_count.query = resolutions.query.data.count || '';
            $scope.claims_count.approved = resolutions.approved.data.count || '';
            $scope.claims_count.rejected = resolutions.rejected.data.count || '';
            $scope.claims_count.drafts = resolutions.drafts.data.count || '';
            $scope.claims_count.cancelled = resolutions.cancelled.data.count || '';
        }
        if (IS_ADMIN) {
            $scope.claims_count.admin_completed = resolutions.admin_completed.data.count || '';
            $scope.claims_count.admin_pending = resolutions.admin_pending.data.count || '';
        }
        $scope.badges_loading = false;
    });

    /**
     * Fetch objects via API
     */
    var api_url = '';
    if (CAN_ACCESS_MY_TASKS) {
        if (STATUS == 2) {
            api_url = urls.pending;
        } else if (STATUS == 3) {
            api_url = urls.completed;
        }
    }
    if (CAN_ACCESS_MY_CLAIMS) {
        if (STATUS == 1) {
            api_url = urls.submitted;
        } else if (STATUS == 4) {
            api_url = urls.rejected;
        } else if (STATUS == 5) {
            api_url = urls.approved;
        } else if (STATUS == 6) {
            api_url = urls.drafts;
        } else if (STATUS == 7) {
            api_url = urls.query;
        } else if (STATUS == 8) {
            api_url = urls.cancelled;
        }
    }
    if (IS_ADMIN) {
        if (STATUS == 9) {
            api_url = urls.admin_completed;
        } else if (STATUS == 10) {
            api_url = urls.admin_pending;
        }
    }

    $scope.search_query = function (search_type, claim_no, status, fields) {
        if (search_type == 'claim') {
            /**
             * Search claims by reference number
             */
            var search_url = URL_HOMEPAGE+"?status="+status+"&fields="+fields+"&query="+claim_no;
            window.location.href = search_url;
        }
    };

    $scope.open_cancel_claim_popup = function (claim_no, claim_ctype_id) {
        $scope.cancellation_reason = '';
        $scope.cancelling_claim_no = claim_no;
        $scope.cancelling_claim_ctype_id = claim_ctype_id;
        $('#cancellation-modal').modal('show');
    };

    $scope.cancel_claim = function () {
        var action_data = {
            claim_no: $scope.cancelling_claim_no,
            claim_ctype: $scope.cancelling_claim_ctype_id,
            reason: $scope.cancellation_reason
        };
        $http({
            url: URL_AJAX_CANCEL_CLAIM,
            method: 'POST',
            data: action_data
        })
        .success(function (data, status, headers, config) {
            if (data.success) {
                window.location.reload();
            } else {
                show_error_message(data.message);
            }
        });
    };

    /**
     * The AJAX Call to fetch objects
     */
    function fetch_objects(page_number) {
        if (api_url.length) {
            var _url = api_url;

            $scope.claim_list = [];
            $scope.is_loading = true;
            _url = api_url + '?page=' + page_number;

            if (QUERY.length)
                _url += "&query=" + QUERY;

            $http({
                url: _url,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.claim_list = data.results;
                for (var i in $scope.claim_list) {
                    var trunc_len = 30;
                    var claimant = $scope.claim_list[i].claimant;
                    var cancelled_by = $scope.claim_list[i].cancelled_by;
                    var queried_by = $scope.claim_list[i].queried_by;
                    var current_assignee = $scope.claim_list[i].current_assignee;
                    if (!!claimant)
                        $scope.claim_list[i].claimant = truncate(claimant, trunc_len);
                    if (!!cancelled_by)
                        $scope.claim_list[i].cancelled_by = truncate(cancelled_by, trunc_len);
                    if (!!queried_by)
                        $scope.claim_list[i].queried_by = truncate(queried_by, trunc_len);
                    if (!!current_assignee)
                        $scope.claim_list[i].current_assignee = truncate(current_assignee, trunc_len);
                }
                $scope.total_claims = data.count;
                $scope.is_loading = false;
            });
        }
    }
    fetch_objects(1);

    $scope.page_changed = function (newPage) {
        fetch_objects(newPage);
    };

    $scope.open_assignee_modal = function (assignee_list) {
        $scope.modal_assignee_list = assignee_list;
        $('#assignee-modal').modal('show');
    };

    $scope.open_action_date_modal = function (action_date_list) {
        $scope.modal_action_date_list = action_date_list;
        $('#action-date-modal').modal('show');
    };
});

claimApp.controller('ListFilterController', function ($scope, $http) {
    /**
     * Load options: Claim types
     */
    $http({
        url: API_URL+'claim-types/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.claim_type_list = data.results;
    });

    /**
     * Apply filters
     */
    $scope.apply = function () {
        var api_url = '';
        if (CAN_ACCESS_MY_TASKS) {
            if (STATUS == 2) {
                api_url = API_URL+'pending-claims/';
            } else if (STATUS == 3) {
                api_url = API_URL+'completed-claims/';
            }
        }
        if (CAN_ACCESS_MY_CLAIMS) {
            if (STATUS == 1) {
                api_url = API_URL+'submitted-claims/';
            } else if (STATUS == 4) {
                api_url = API_URL+'rejected-claims/';
            } else if (STATUS == 5) {
                api_url = API_URL+'approved-claims/';
            } else if (STATUS == 6) {
                api_url = API_URL+'drafts/';
            } else if (STATUS == 7) {
                api_url = API_URL+'queried-claims/';
            } else if (STATUS == 8) {
                api_url = API_URL+'cancelled-claims/';
            }
        }

        if (api_url.length) {
            var params = {};
            if ($scope.claim_type)
                params.claim_type = $scope.claim_type.id;
            if ($scope.verification)
                params.verification = $scope.verification;
            $scope.$parent.claim_list = [];
            $scope.$parent.is_loading = true;

            $http({
                url: api_url,
                method: 'GET',
                params: params
            })
            .success(function (data, status, headers, config) {
                $scope.$parent.claim_list = data.results;
                $scope.$parent.is_loading = false;
            });
        }
    }
});
