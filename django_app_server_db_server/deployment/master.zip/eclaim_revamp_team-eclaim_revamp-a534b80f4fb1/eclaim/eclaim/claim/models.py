from django.db import models
from django.utils.translation import ugettext as _

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'ClaimType',
    'Claim'
    ]


class _EnabledClaimTypeManager(models.Manager):
    """Returns only enabled claim types."""
    def get_queryset(self):
        qs = super(_EnabledClaimTypeManager, self).get_queryset()
        return qs.filter(is_enabled=True)


class ClaimType(models.Model):
    code = models.CharField(max_length=5, unique=True, null=True)
    prefix = models.CharField(max_length=1, unique=True, null=True)
    title = models.CharField(_("Title"), max_length=255)
    is_enabled = models.BooleanField(default=True)
    is_advance = models.BooleanField(default=False)
    description = models.TextField(blank=True)
    template = models.ForeignKey('settings.WorkflowTemplate', verbose_name=_("Template"), blank=True, null=True,
                                 on_delete=models.SET_NULL)

    objects = models.Manager()
    enabled_objects = _EnabledClaimTypeManager()

    class Meta:
        verbose_name = _("Claim Type")
        verbose_name_plural = _("Claim Types")

    def __unicode__(self):
        return unicode(self.title)

    def save(self, *args, **kwargs):
        self.title = self.title.title()
        super(ClaimType, self).save(*args, **kwargs)

    @staticmethod
    def get_claim_type(key):
        return ClaimType.objects.get(pk=key)


class Claim(models.Model):
    """ ** DELETE THIS MODEL ** """
    SUBMITTED = 1
    PENDING = 2
    COMPLETED = 3
    REJECTED = 4
    APPROVED = 5
    DRAFT = 6
    STATUS_LIST = (
        (PENDING, _("Pending Tasks")),
        (SUBMITTED, _("Submitted Claims")),
        (COMPLETED, _("Completed Tasks")),
        (REJECTED, _("Rejected Claims")),
        (APPROVED, _("Approved Claims")),
        (DRAFT, _("Drafts")),
        )

    number = models.PositiveIntegerField(_("Claim No."), unique=True, db_index=True)
    claim_type = models.ForeignKey(ClaimType, related_name=_("Type"), null=True, blank=True)
    status = models.IntegerField(_("Status"), choices=STATUS_LIST, default=PENDING)
    is_verified = models.BooleanField(_("Verified"), default=False)
    elapsed_days = models.IntegerField(_("Elapsed Days"), blank=True, null=True)
    created_by = models.ForeignKey('auth.User', verbose_name=_("Submission Date"), editable=False, related_name='my_claims')
    created = models.DateTimeField(_("Submission Date"), auto_now_add=True)
    assigned_by = models.ForeignKey('auth.User', verbose_name=_("Assigned By"), blank=True, null=True)
    assigned_to = models.ForeignKey('auth.User', verbose_name=_("Assigned To"), blank=True, null=True, related_name='assignedto_claims')
    form_received_date = models.DateField(_("Form Received Date"), blank=True, null=True)

    class Meta:
        verbose_name = _("Claim")
        verbose_name_plural = _("Claims")
        ordering = ['-created']
        get_latest_by = 'created'
