from .models import ClaimType

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = ['claim_types']

LOCAL_CLAIMS = (1, 3, 8, 6, 7, 11, 5, 10, 9)
OVERSEA_CLAIMS = (2, 4, 22, 20, 21)
LOCAL_ADVANCE = (15, 13, 12, 14)
OVERSEA_ADVANCE = (19, 17, 16, 18)


def claim_types(request):
    qs = ClaimType.enabled_objects.all()
    local_claims = list(qs.filter(pk__in=LOCAL_CLAIMS))
    local_claims.sort(key=lambda x: LOCAL_CLAIMS.index(x.pk))
    oversea_claims = list(qs.filter(pk__in=OVERSEA_CLAIMS))
    oversea_claims.sort(key=lambda x: OVERSEA_CLAIMS.index(x.pk))
    local_advance = list(qs.filter(pk__in=LOCAL_ADVANCE))
    local_advance.sort(key=lambda x: LOCAL_ADVANCE.index(x.pk))
    oversea_advance = list(qs.filter(pk__in=OVERSEA_ADVANCE))
    oversea_advance.sort(key=lambda x: OVERSEA_ADVANCE.index(x.pk))
    return {
        'ENABLED_CLAIM_TYPES': qs,
        'LOCAL_CLAIM_TYPES': local_claims,
        'OVERSEA_CLAIM_TYPES': oversea_claims,
        'LOCAL_ADVANCE': local_advance,
        'OVERSEA_ADVANCE': oversea_advance
        }
