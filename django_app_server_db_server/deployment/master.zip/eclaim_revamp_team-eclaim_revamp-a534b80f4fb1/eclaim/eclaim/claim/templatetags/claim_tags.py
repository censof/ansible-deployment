from django import template
from django.core.urlresolvers import reverse_lazy

__all__ = ['get_claim_form_url']

register = template.Library()


@register.filter
def get_claim_form_url(claim_type):
    if claim_type.pk == 10:
        return reverse_lazy('lecture_index')
    elif claim_type.pk == 11:
        return reverse_lazy('housemoving_index')
    elif claim_type.pk == 1:
        return reverse_lazy('localtravel_index')
    elif claim_type.pk == 2:
        return reverse_lazy('overseatravel_index')
    elif claim_type.pk == 3:
        return reverse_lazy('localtransfer_index')
    elif claim_type.pk == 4:
        return reverse_lazy('overseatransfer_index')
    elif claim_type.pk == 8:
        return reverse_lazy('miscellaneous_index')
    elif claim_type.pk == 12:
        return reverse_lazy('miscadvance_index')
    elif claim_type.pk == 14:
        return reverse_lazy('localentertainment_index')
    elif claim_type.pk == 18:
        return reverse_lazy('overseaentertainment_index')
    elif claim_type.pk == 6:
        return reverse_lazy('medical_index')
    elif claim_type.pk == 22:
        return reverse_lazy('miscoverseas_index')
    elif claim_type.pk == 7:
        return reverse_lazy('dental_index')
    elif claim_type.pk == 20:
        return reverse_lazy('medicaloverseas_index')
    elif claim_type.pk == 21:
        return reverse_lazy('dentaloverseas_index')
    elif claim_type.pk == 19:
        return reverse_lazy('overseatravelingadvance_index')
    elif claim_type.pk == 16:
        return reverse_lazy('overseamiscadvance_index')
    elif claim_type.pk == 15:
        return reverse_lazy('localtravelingadvance_index')
    elif claim_type.pk == 20:
        return reverse_lazy('medicaloverseas_index')
    elif claim_type.pk == 21:
        return reverse_lazy('dentaloverseas_index')
    elif claim_type.pk == 13:
        return reverse_lazy('localtransferadvance_index')
    return ''
