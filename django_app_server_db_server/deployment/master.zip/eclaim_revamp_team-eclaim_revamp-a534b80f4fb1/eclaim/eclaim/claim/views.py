import urllib

from django.contrib.auth.decorators import login_required
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.utils import timezone
from django.utils.decorators import method_decorator
from django.utils.translation import ugettext_lazy as _
from easy_pdf.views import PDFTemplateView
from eclaim.settings.models import WorkflowQueryState, WorkflowState
from eclaim.libs.permissions import get_user_permissions
from .models import Claim

__all__ = ['ClaimListView',
           'QueryPDFView']


class ClaimListView(TemplateView):
    template_name = 'claim/claim_list.html'

    @method_decorator(login_required)
    def dispatch(self, request, *args, **kwargs):
        fields = request.GET.get('fields')
        status = request.GET.get('status')
        if not fields and status != '6':
            # Redirect to the default URL.
            perms = get_user_permissions(request.user)
            if perms['CAN_ACCESS_MY_TASKS']:
                fields = "number,created_by,type,is_verified,created,"\
                         "status_label,completed,elapsed_days"
                _paramdict = {
                    'fields': fields,
                    'status': 3
                }
            else:
                fields = "number,type,created,status_label,assignee"
                _paramdict = {
                    'fields': fields,
                    'status': 1
                }
            if 'query' in request.GET:
                _paramdict['query'] = request.GET['query']
            params = urllib.urlencode(_paramdict)
            url = "{}?{}".format(reverse_lazy('claim_list'), params)
            return redirect(url)
        return super(ClaimListView, self).dispatch(request, *args, **kwargs)

    def get_context_data(self, **kwargs):
        ctx = super(ClaimListView, self).get_context_data(**kwargs)
        fields = self.request.GET.get('fields')
        if fields:
            ctx['fields'] = fields.split(',')
        status = self.request.GET.get('status')
        if status:
            for k, v in Claim.STATUS_LIST:
                if k == int(status):
                    ctx['page_title'] = v
        else:
            ctx['page_title'] = _("My Claims")
        return ctx


class QueryPDFView(PDFTemplateView):
    template_name = 'claim/query_pdf.html'

    def get_context_data(self, **kwargs):
        ctx = super(QueryPDFView, self).get_context_data(**kwargs)
        claim_pk = self.request.GET['pk']
        ctype_id = self.request.GET['ctype_id']
        ctx['state'] = WorkflowState.objects.filter(
            object_id=claim_pk,
            content_type=ctype_id).latest()
        ctx['claim'] = ctx['state'].content_object
        ctx['query_list'] = WorkflowQueryState.objects.filter(
            state__object_id=claim_pk,
            state__content_type=ctype_id)
        ctx['today'] = timezone.now().date()
        return ctx
