from django.conf.urls import patterns, url
from .views import *


urlpatterns = patterns(
    'eclaim.claim.ajax',

    url(r'^claim/ajax/approve/$',
        'approve_claim',
        name='claim_ajax_approve'),

    url(r'^claim/ajax/decline/$',
        'decline_claim',
        name='claim_ajax_decline'),

    url(r'^claim/ajax/query/$',
        'query',
        name='claim_ajax_query'),

    url(r'^claim/ajax/resubmit-to/$',
        'resubmit_to',
        name='claim_ajax_resubmit_to'),

    url(r'^claim/ajax/cancel/$',
        'cancel_claim',
        name='claim_ajax_cancel'),

    url(r'^claim/ajax/get-assigned-for-level/(?P<template_pk>[0-9]+)/$',
        'get_assigned_for_level',
        name='claim_ajax_get_assigned_for_level'),
)

urlpatterns += patterns(
    '',

    url(r'^$', ClaimListView.as_view(), name='claim_list'),
    url(r'^query-pdf/$', QueryPDFView.as_view(), name='query_pdf'),
)
