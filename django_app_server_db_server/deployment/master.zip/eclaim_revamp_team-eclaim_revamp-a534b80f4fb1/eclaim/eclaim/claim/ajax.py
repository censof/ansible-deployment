import json

from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.contrib.contenttypes.models import ContentType
from django.shortcuts import get_object_or_404
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST, require_GET
from django.utils import timezone
from django.utils.encoding import force_text
from django.utils.translation import ugettext as _
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.settings.models import (
    WorkflowState, WorkflowTemplateLevel, WorkflowQuery, WorkflowQueryType,
    WorkflowQueryState, WorkflowStateLog, SelectedAssignee, WorkflowTemplate,
    WorkflowReason)
from eclaim.settings.utils import (
    notify_users_via_email, create_selected_assignee)

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'approve_claim',
    'decline_claim',
    'cancel_claim',
    'query',
    'resubmit_to',
    'get_assigned_for_level'
    ]


@require_POST
@csrf_exempt
def approve_claim(request):
    data = json.loads(request.body)
    claim_no = data['claim_no']
    ctype_id = data['claim_ctype']
    ctype = get_object_or_404(ContentType, pk=ctype_id)
    claim = ctype.get_object_for_this_type(claim_no=claim_no)
    assignee = request.user.claimant.assignee

    state = WorkflowState.objects.filter(
        content_type=ctype,
        object_id=claim.pk
        ).latest()
    state.is_approved = True
    state.approved_by = assignee
    state.save()

    log = WorkflowStateLog.objects.filter(state=state).latest()
    log.is_approved = True
    log.approved_by = assignee
    log.completed = timezone.now()
    log.save()

    try:
        claim_type = claim.get_claim_type()  # legacy
    except AttributeError:
        claim_type = ClaimType.get_claim_type(claim.CLAIM_TYPE)

    try:
        next_level = WorkflowTemplateLevel.objects.get(
            template__claimtype=claim_type,
            ordering=state.level.ordering+1
            )
    except WorkflowTemplateLevel.DoesNotExist:
        next_level = None  # completed going through workflow

    if next_level is not None:
        state = WorkflowState.objects.create(
            content_type=ctype,
            object_id=claim.pk,
            level=next_level,
            claimant=state.claimant
            )
        WorkflowStateLog.objects.create(state=state)

        # Assign a selected claimant as a next level approver. We use
        # an selected assignee's staff number to identify a claimant.
        sa_staffno = data.get('assignee')
        if sa_staffno:
            assigned = Claimant.objects.get(pk=sa_staffno)
            create_selected_assignee(assigned, claim.__class__, claim.pk,
                                     new_claim=False)

        # Send email notification if preferred.
        if next_level.email_notif:
            entity = state.get_assigned_entity()
            if isinstance(entity, SelectedAssignee):
                emails = [entity.assignee.claimant.email]
            else:  # UserGroup
                assignees = entity.assignee_set.all()
                emails = assignees.values_list('claimant__email', flat=True)

            if emails:
                notify_users_via_email(state, emails, is_claimant=False)

    return JsonResponse({'success': True})


@require_POST
@csrf_exempt
def decline_claim(request):
    data = json.loads(request.body)
    claim_no = data['claim_no']
    ctype_id = data['claim_ctype']
    reason_code = data['reason']
    notes = data['notes']
    reason = get_object_or_404(WorkflowReason, code=reason_code)
    ctype = get_object_or_404(ContentType, pk=ctype_id)
    claim = ctype.get_object_for_this_type(claim_no=claim_no)
    assignee = request.user.claimant.assignee

    state = WorkflowState.objects.filter(
        content_type=ctype,
        object_id=claim.pk
        ).latest()
    state.is_approved = False
    state.approved_by = assignee
    state.rejection_reason = reason
    state.notes = notes
    state.save()

    log = WorkflowStateLog.objects.filter(state=state).latest()
    log.is_approved = False
    log.approved_by = assignee
    log.completed = timezone.now()
    log.save()

    # Send email notification if preferred.
    email = state.claimant.email
    if state.level.email_notif and email:
        notify_users_via_email(state, [email], is_claimant=True, notes=notes)

    return JsonResponse({'success': True})


@login_required(redirect_field_name=None)
@require_POST
@csrf_exempt
def cancel_claim(request):
    body = request.body
    try:
        data = json.loads(body)
    except ValueError:  # occurs while running tests
        data = json.loads(body.replace("\'", '"'))
    claim_no = data['claim_no']
    ctype_id = data['claim_ctype']
    reason = data['reason']
    success = True
    try:
        ctype = ContentType.objects.get(pk=ctype_id)
    except ContentType.DoesNotExist:
        ctype = None
        success = False

    if ctype is not None:
        claim = ctype.get_object_for_this_type(claim_no=claim_no)
        claimant = request.user.claimant
        if hasattr(claimant, 'assignee'):
            assignee = claimant.assignee
            state = WorkflowState.objects.filter(
                content_type=ctype,
                object_id=claim.pk
                ).latest()
            state.is_cancelled = True
            state.cancelled_by = assignee
            state.notes = reason
            state.save()

            log = WorkflowStateLog.objects.filter(state=state).latest()
            log.is_cancelled = True
            log.cancelled_by = assignee
            log.completed = timezone.now()
            log.save()
        else:
            success = False

    return JsonResponse({'success': success})


@require_POST
@csrf_exempt
def query(request):
    data = json.loads(request.body)
    claim_no = data['claim_no']
    ctype_id = data['claim_ctype']
    query_type_id = data['query_type']
    reason_code = data['reason']
    notes = data['notes']
    reason = get_object_or_404(WorkflowReason, code=reason_code)
    ctype = get_object_or_404(ContentType, pk=ctype_id)
    query_type = get_object_or_404(WorkflowQueryType, pk=query_type_id)
    claim = ctype.get_object_for_this_type(claim_no=claim_no)
    state = WorkflowState.objects.filter(
        content_type=ctype,
        object_id=claim.pk).latest()
    log = state.workflowstatelog_set.latest()
    log.completed = timezone.now()
    log.save()

    if not state.level.query:
        _msg = _("Query not allowed on this level.")
        return JsonResponse({'success': False, 'message': _msg})

    try:
        query = WorkflowQuery.objects.get(level=state.level,
                                          query_type=query_type)
    except WorkflowQuery.DoesNotExist:
        _msg = _("No query templates found.")
        return JsonResponse({'success': False, 'message': _msg})

    assignee = request.user.claimant.assignee
    qstate = WorkflowQueryState.objects.create(state=state,
                                               query=query,
                                               reason=reason,
                                               notes=notes,
                                               queried_by=assignee)
    WorkflowStateLog.objects.create(query_state=qstate, query=True)

    # Send email notification if preferred.
    email = state.claimant.email
    if state.level.email_notif and email:
        notify_users_via_email(state, [email], is_claimant=True, notes=notes)

    return JsonResponse({'success': True})


@require_POST
@csrf_exempt
def resubmit_to(request):
    """Triggers when a claimant re-submits query back to an assignee
    or a group.
    """
    data = json.loads(request.body)
    claimant = request.user.claimant
    claim_no = data['claim_no']
    ctype_id = data['claim_ctype']
    ctype = get_object_or_404(ContentType, pk=ctype_id)
    claim = ctype.get_object_for_this_type(claim_no=claim_no)
    state = WorkflowState.objects.filter(
        claimant=claimant,
        content_type=ctype,
        object_id=claim.pk).latest()

    log = state.workflowstatelog_set.latest()
    log.completed = timezone.now()
    log.save()

    query_state = state.query_states.latest()
    query_state.is_resubmitted = True
    query_state.save()

    next_level = query_state.query.resubmit_to

    # Do not allow re-submitting a query to a level which is higher than
    # it was queried from.
    if next_level.ordering > state.level.ordering:
        return JsonResponse({'success': False})

    # Delete any states made on the levels above the level which a claimant
    # has re-submitted to.
    all_next_levels = next_level.template.workflowtemplatelevel_set.filter(
        ordering__gt=next_level.ordering
        )
    WorkflowState.objects.filter(
        level__in=all_next_levels,
        claimant=claimant,
        content_type=ctype,
        object_id=claim.pk
        ).delete()

    # Create a new state for the level, which the query is re-submitted to.
    next_state, new = WorkflowState.objects.get_or_create(
        level=next_level,
        claimant=claimant,
        content_type=ctype,
        object_id=claim.pk
        )
    next_state.is_approved = None
    next_state.save()
    WorkflowStateLog.objects.create(state=next_state)
    return JsonResponse({'success': True})


@require_GET
def get_assigned_for_level(request, template_pk):
    ordering = int(request.GET.get('level_ordering', 1))
    claim_no = request.GET.get('claim_no')
    ctype_id = request.GET.get('content_type')

    try:
        template = WorkflowTemplate.objects.get(pk=template_pk)
    except WorkflowTemplate.DoesNotExist:
        return JsonResponse({'error': "Workflow template not found."})

    try:
        level = WorkflowTemplateLevel.objects.get(template=template,
                                                  ordering=ordering)
    except WorkflowTemplateLevel.DoesNotExist:
        return JsonResponse({'error': "Workflow level not found."})

    if level.selection_filtering:
        try:
            next_level = WorkflowTemplateLevel.objects.get(template=template,
                                                           ordering=ordering+1)
        except WorkflowTemplateLevel.DoesNotExist:
            return JsonResponse({'error': "Next workflow level not found."})

        if claim_no and ctype_id:
            state_qs = WorkflowState.objects.filter(object_id=claim_no,
                                                    content_type__pk=ctype_id)
            state = state_qs.latest()
            assigned = state.get_assigned_entity()
            result = {
                'name': force_text(assigned)
                }
            if isinstance(assigned, SelectedAssignee):
                result['assignee'] = assigned.assignee.claimant.pk
            else:
                result['group'] = assigned.pk
        else:
            group = next_level.group
            result = {
                'group': group.pk,
                'name': force_text(group)
                }
    else:
        result = {'error': "Selection filtering is disabled on this level."}

    return JsonResponse(result)
