from decimal import Decimal
from django.db import models
from django.core.urlresolvers import reverse_lazy

from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.default_attribute import (
    CLAIM_NO_MAX_LENGTH, CLAIM_STATUS_MAX_LENGTH, PROJECT_CODE_MAX_LENGTH,
    COURSE_LOCATION_MAX_LENGTH, RECEIPT_NO_MAX_LENGTH, REGION_MAX_LENGTH
)
from eclaim.masterfiles.models.misc import (
    LOCAL_ACTIVITY_LIST, REGION_LIST, MISC_EXPENSES_LIST, COURSE_LOCATION_LIST,
    FundType, GSTTax
)
from eclaim.claim.models import ClaimType


class LocalTravelClaimBase(BaseModel):
    status = models.CharField(max_length=CLAIM_STATUS_MAX_LENGTH)
    claim_month = models.DateField()
    travel_date_from = models.DateField()
    travel_date_to = models.DateField()

    class Meta:
        abstract = True

    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=1)


class LocalTravelClaimDetailsBase(models.Model):
    activitiy_type = models.CharField(max_length=10, choices=LOCAL_ACTIVITY_LIST)
    travel_date_from = models.DateField()
    travel_date_to = models.DateField()

    class Meta:
        abstract = True


class MileageItemsBase(models.Model):
    depart_date = models.DateField()
    depart_time = models.TimeField()
    return_date = models.DateField()
    return_time = models.TimeField()
    destination_from = models.CharField(max_length=200, blank=True)
    destination_to = models.CharField(max_length=200, blank=True)
    travelling_info = models.TextField(blank=True)
    vehicle_type = models.CharField(max_length=200, blank=True)
    vehicle_cc = models.CharField(max_length=200, blank=True)
    vehicle_reg_no = models.CharField(max_length=200, blank=True)
    mileage = models.DecimalField(max_digits=9, decimal_places=1, default=Decimal('0.0'))
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class PublicTransportItemsBase(models.Model):
    depart_date = models.DateField()
    depart_time = models.TimeField()
    return_date = models.DateField()
    return_time = models.TimeField()
    destination_from = models.CharField(max_length=100, blank=True)
    destination_to = models.CharField(max_length=100, blank=True)
    travelling_info = models.TextField(blank=True)
    type = models.CharField(max_length=50, blank=True)
    receipt_no = models.CharField(max_length=RECEIPT_NO_MAX_LENGTH, blank=True)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    gst_tax = models.ForeignKey(GSTTax)
    gst_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    nett_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class MealItemsBase(models.Model):
    depart_date = models.DateField()
    depart_time = models.TimeField()
    return_date = models.DateField()
    return_time = models.TimeField()
    region_destination = models.CharField(max_length=REGION_MAX_LENGTH, choices=REGION_LIST)
    travelling_info = models.TextField(blank=True)
    chk_meal_distribution = models.BooleanField(default=False)
    int_meal_allowance = models.IntegerField(default=0)
    int_daily_allowance = models.IntegerField(default=0)
    meal_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    daily_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class MealDistributionsBase(models.Model):
    date = models.DateField()
    breakfast = models.BooleanField(default=False)
    lunch = models.BooleanField(default=False)
    dinner = models.BooleanField(default=False)

    class Meta:
        abstract = True


class HotelItemsBase(models.Model):
    check_in_date = models.DateField()
    check_out_date = models.DateField()
    region_destination = models.CharField(max_length=REGION_MAX_LENGTH, choices=REGION_LIST)
    travelling_info = models.TextField(blank=True)
    receipt_no = models.CharField(max_length=RECEIPT_NO_MAX_LENGTH)
    room_price = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    service_charge = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    perday_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    int_days = models.IntegerField(default=0)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    gst_tax = models.ForeignKey(GSTTax)
    gst_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    nett_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class LodgingItemsBase(models.Model):
    check_in_date = models.DateField()
    check_out_date = models.DateField()
    region_destination = models.CharField(max_length=REGION_MAX_LENGTH, choices=REGION_LIST)
    travelling_info = models.TextField(blank=True)
    address = models.TextField(blank=True)
    int_days = models.IntegerField(default=0)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class SubsistenceItemsBase(models.Model):
    depart_date = models.DateField()
    return_date = models.DateField()
    course_location = models.CharField(max_length=COURSE_LOCATION_MAX_LENGTH, choices=COURSE_LOCATION_LIST)
    travelling_info = models.TextField(blank=True)
    chk_substitution = models.BooleanField(default=False)
    chk_meal = models.BooleanField(default=False)
    chk_hotel = models.BooleanField(default=False)
    chk_lodging = models.BooleanField(default=False)
    int_days = models.IntegerField(default=0)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    meal_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    accommodation_amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class SubsistenceDistributionsBase(models.Model):
    date = models.DateField()
    chk_meal = models.BooleanField(default=False)
    chk_accommodation = models.BooleanField(default=False)

    class Meta:
        abstract = True


class MiscellaneousItemsBase(models.Model):
    date = models.DateField()
    type = models.CharField(max_length=100, choices=MISC_EXPENSES_LIST)
    receipt_no = models.CharField(max_length=RECEIPT_NO_MAX_LENGTH)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class MealAidItemsBase(models.Model):
    depart_date = models.DateField()
    return_date = models.DateField()
    course_location = models.CharField(max_length=COURSE_LOCATION_MAX_LENGTH, choices=COURSE_LOCATION_LIST)
    travelling_info = models.TextField(blank=True)
    chk_meal_distribution = models.BooleanField(default=False)
    int_days = models.IntegerField(default=0)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class MealAidDistributionsBase(models.Model):
    date = models.DateField()
    meal_aid = models.BooleanField(default=True)

    class Meta:
        abstract = True


class TransportAidItemsBase(models.Model):
    depart_date = models.DateField()
    return_date = models.DateField()
    course_location = models.CharField(max_length=COURSE_LOCATION_MAX_LENGTH, choices=COURSE_LOCATION_LIST)
    travelling_info = models.TextField(blank=True)
    chk_transport_distribution = models.BooleanField(default=False)
    int_days = models.IntegerField(default=0)
    amount = models.DecimalField(max_digits=9, decimal_places=2, default=Decimal('0.00'))
    corporate_card = models.BooleanField(default=False)
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=PROJECT_CODE_MAX_LENGTH)

    class Meta:
        abstract = True


class TransportAidDistributionsBase(models.Model):
    date = models.DateField()
    transport_aid = models.BooleanField(default=True)

    class Meta:
        abstract = True


class LocalTravelClaimDraft(LocalTravelClaimBase):

    class Meta(LocalTravelClaimBase.Meta):
        verbose_name = 'Local Travel Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['-id']

    def get_absolute_url(self):
        return reverse_lazy('localtravel_draft', args=[self.pk])


class LocalTravelClaim(LocalTravelClaimBase):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    class Meta(LocalTravelClaimBase.Meta):
        verbose_name = 'Local Travel Claim'
        verbose_name_plural = verbose_name
        ordering = ['-id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('localtravel_detail'), self.pk)


class LocalTravelClaimDetailsDraft(LocalTravelClaimDetailsBase):
    claim_draft = models.ForeignKey(LocalTravelClaimDraft)

    class Meta(LocalTravelClaimDetailsBase.Meta):
        verbose_name = 'Local Travel Claim Details Draft'
        verbose_name_plural = verbose_name
        ordering = ['-id']


class LocalTravelClaimDetails(LocalTravelClaimDetailsBase):
    claim = models.ForeignKey(LocalTravelClaim)

    class Meta(LocalTravelClaimDetailsBase.Meta):
        verbose_name = 'Local Travel Claim Details'
        verbose_name_plural = verbose_name
        ordering = ['-id']


class MileageItemsDraft(MileageItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(MileageItemsBase.Meta):
        verbose_name = 'Mileage Items Draft'
        ordering = ['claim_detail', 'id']


class MileageItems(MileageItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(MileageItemsBase.Meta):
        verbose_name = 'Mileage Items'
        ordering = ['claim_detail', 'id']


class PublicTransportItemsDraft(PublicTransportItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(PublicTransportItemsBase.Meta):
        verbose_name = 'Public Transport Items Draft'
        ordering = ['claim_detail', 'id']


class PublicTransportItems(PublicTransportItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(PublicTransportItemsBase.Meta):
        verbose_name = 'Public Transport Items'
        ordering = ['claim_detail', 'id']


class MealItemsDraft(MealItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(MealItemsBase.Meta):
        verbose_name = 'Meal Items Draft'
        ordering = ['claim_detail', 'id']


class MealItems(MealItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(MealItemsBase.Meta):
        verbose_name = 'Meal Items'
        ordering = ['claim_detail', 'id']


class MealDistributionsDraft(MealDistributionsBase):
    meal_item = models.ForeignKey(MealItemsDraft)

    class Meta(MealDistributionsBase.Meta):
        verbose_name = 'Meal Distributions Draft'
        ordering = ['meal_item', 'id']


class MealDistributions(MealDistributionsBase):
    meal_item = models.ForeignKey(MealItems)

    class Meta(MealDistributionsBase.Meta):
        verbose_name = 'Meal Distributions'
        ordering = ['meal_item', 'id']


class HotelItemsDraft(HotelItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(HotelItemsBase.Meta):
        verbose_name = 'Hotel Items Draft'
        ordering = ['claim_detail', 'id']


class HotelItems(HotelItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(HotelItemsBase.Meta):
        verbose_name = 'Hotel Items'
        ordering = ['claim_detail', 'id']


class LodgingItemsDraft(LodgingItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(LodgingItemsBase.Meta):
        verbose_name = 'Lodging Items Draft'
        ordering = ['claim_detail', 'id']


class LodgingItems(LodgingItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(LodgingItemsBase.Meta):
        verbose_name = 'Lodging Items'
        ordering = ['claim_detail', 'id']


class SubsistenceItemsDraft(SubsistenceItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(SubsistenceItemsBase.Meta):
        verbose_name = 'Subsistence Items Draft'
        ordering = ['claim_detail', 'id']


class SubsistenceItems(SubsistenceItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(SubsistenceItemsBase.Meta):
        verbose_name = 'Subsistence Items'
        ordering = ['claim_detail', 'id']


class SubsistenceDistributionsDraft(SubsistenceDistributionsBase):
    subsistence_item = models.ForeignKey(SubsistenceItemsDraft)

    class Meta(SubsistenceDistributionsBase.Meta):
        verbose_name = 'Subsistence Distributions Draft'
        ordering = ['subsistence_item', 'id']


class SubsistenceDistributions(SubsistenceDistributionsBase):
    subsistence_item = models.ForeignKey(SubsistenceItems)

    class Meta(SubsistenceDistributionsBase.Meta):
        verbose_name = 'Subsistence Distributions'
        ordering = ['subsistence_item', 'id']


class MiscellaneousItemsDraft(MiscellaneousItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(MiscellaneousItemsBase.Meta):
        verbose_name = 'Miscellaneous Items Draft'
        ordering = ['claim_detail', 'id']


class MiscellaneousItems(MiscellaneousItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(MiscellaneousItemsBase.Meta):
        verbose_name = 'Miscellaneous Items'
        ordering = ['claim_detail', 'id']


class MealAidItemsDraft(MealAidItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(MealAidItemsBase.Meta):
        verbose_name = 'Meal Aid Items Draft'
        ordering = ['claim_detail', 'id']


class MealAidItems(MealAidItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(MealAidItemsBase.Meta):
        verbose_name = 'Meal Aid Items'
        ordering = ['claim_detail', 'id']


class MealAidDistributionsDraft(MealAidDistributionsBase):
    meal_aid_item = models.ForeignKey(MealAidItemsDraft)

    class Meta(MealAidDistributionsBase.Meta):
        verbose_name = 'Meal Aid Distributions Draft'
        ordering = ['meal_aid_item', 'id']


class MealAidDistributions(MealAidDistributionsBase):
    meal_aid_item = models.ForeignKey(MealAidItems)

    class Meta(MealAidDistributionsBase.Meta):
        verbose_name = 'Meal Aid Distributions'
        ordering = ['meal_aid_item', 'id']


class TransportAidItemsDraft(TransportAidItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetailsDraft)

    class Meta(TransportAidItemsBase.Meta):
        verbose_name = 'Transport Aid Items Draft'
        ordering = ['claim_detail', 'id']


class TransportAidItems(TransportAidItemsBase):
    claim_detail = models.ForeignKey(LocalTravelClaimDetails)

    class Meta(TransportAidItemsBase.Meta):
        verbose_name = 'Transport Aid Items'
        ordering = ['claim_detail', 'id']


class TransportAidDistributionsDraft(TransportAidDistributionsBase):
    transport_aid_item = models.ForeignKey(TransportAidItemsDraft)

    class Meta(TransportAidDistributionsBase.Meta):
        verbose_name = 'Transport Aid Distributions Draft'
        ordering = ['transport_aid_item', 'id']


class TransportAidDistributions(TransportAidDistributionsBase):
    transport_aid_item = models.ForeignKey(TransportAidItems)

    class Meta(TransportAidDistributionsBase.Meta):
        verbose_name = 'Transport Aid Distributions'
        ordering = ['transport_aid_item', 'id']
