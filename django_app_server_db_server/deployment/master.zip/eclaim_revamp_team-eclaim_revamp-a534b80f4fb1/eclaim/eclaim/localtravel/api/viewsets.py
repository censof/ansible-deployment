from rest_framework import viewsets

from .serializers import LocalTravelClaimDraftSerializer, LocalTravelClaimSerializer
from ..models import LocalTravelClaimDraft, LocalTravelClaim


# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTravelClaimDraftViewSet',
    'LocalTravelClaimViewSet'
    ]


class LocalTravelClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTravelClaimDraftSerializer
    queryset = LocalTravelClaimDraft.objects.all()


class LocalTravelClaimViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTravelClaimSerializer
    queryset = LocalTravelClaim.objects.all()