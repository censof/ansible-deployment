from rest_framework import serializers

from eclaim.masterfiles.utils import (get_document_list,
                                      get_document_list_item_draft,
                                      get_document_list_item)
from eclaim.masterfiles.models.document import (DocumentListItemDraft,
                                                DocumentListItem)
from ..models import (LocalTravelClaimDraft, LocalTravelClaimDetailsDraft,
                      MileageItemsDraft, PublicTransportItemsDraft,
                      MealItemsDraft, HotelItemsDraft, LodgingItemsDraft,
                      MiscellaneousItemsDraft, SubsistenceItemsDraft,
                      MealAidItemsDraft, TransportAidItemsDraft,
                      MealDistributionsDraft, MealAidDistributionsDraft,
                      TransportAidDistributionsDraft,
                      SubsistenceDistributionsDraft,
                      LocalTravelClaim, LocalTravelClaimDetails, MileageItems,
                      PublicTransportItems, MealItems, HotelItems, LodgingItems,
                      MiscellaneousItems, SubsistenceItems, MealAidItems,
                      TransportAidItems, MealDistributions, MealAidDistributions,
                      TransportAidDistributions, SubsistenceDistributions)


# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTravelClaimDraftSerializer',
    'LocalTravelClaimSerializer'
    ]


class LocalTravelClaimDraftSerializer(serializers.ModelSerializer):
    journey_details = serializers.SerializerMethodField()
    od_claim_details = serializers.SerializerMethodField()
    lt_claim_details = serializers.SerializerMethodField()
    st_claim_details = serializers.SerializerMethodField()
    pt_claim_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTravelClaimDraft
        fields = ('id', 'journey_details', 'od_claim_details', 'lt_claim_details',
                  'st_claim_details', 'pt_claim_details')

    def get_journey_details(self, obj):
        claim_month = obj.claim_month
        travel_date_from = obj.travel_date_from
        travel_date_to = obj.travel_date_to
        return {
            'claim_month': claim_month,
            'travel_date_from': travel_date_from,
            'travel_date_to': travel_date_to
        }

    def get_od_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetailsdraft_set.all()
        claim_details = claim_details.filter(activitiy_type='OD')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        mileage_items = MileageItemsDraft.objects.filter(claim_detail__in=
                                                         claim_details_pk)
        public_transport_items = PublicTransportItemsDraft.objects.filter(
                                                            claim_detail__in=
                                                            claim_details_pk)
        meal_items = MealItemsDraft.objects.filter(claim_detail__in=
                                                   claim_details_pk)
        meal_items_pk = meal_items.values_list('pk', flat=True)
        meal_distributions = MealDistributionsDraft.objects.filter(
                                                            meal_item__in=
                                                            meal_items_pk)
        hotel_items = HotelItemsDraft.objects.filter(claim_detail__in=
                                                     claim_details_pk)
        lodging_items = LodgingItemsDraft.objects.filter(claim_detail__in=
                                                         claim_details_pk)
        misc_items = MiscellaneousItemsDraft.objects.filter(claim_detail__in=
                                                            claim_details_pk)
        doc_items = get_document_list_item_draft(obj.id, 'LTC',
                                                 claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'mileage_items': mileage_items.values()
                , 'public_transport_items': public_transport_items.values()
                , 'meal_items': meal_items.values()
                , 'meal_distributions': meal_distributions.values()
                , 'hotel_items': hotel_items.values()
                , 'lodging_items': lodging_items.values()
                , 'misc_items': misc_items.values()
                , 'doc_items': doc_items.values()
                }

    def get_lt_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetailsdraft_set.all()
        claim_details = claim_details.filter(activitiy_type='LT')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        subsistence_items = SubsistenceItemsDraft.objects.filter(
            claim_detail__in=claim_details_pk)
        subsistence_items_pk = subsistence_items.values_list('pk', flat=True)
        subsistence_distributions = SubsistenceDistributionsDraft.objects.filter(
                                                        subsistence_item__in=
                                                        subsistence_items_pk)
        meal_items = MealItemsDraft.objects.filter(claim_detail__in=
                                                   claim_details_pk)
        hotel_items = HotelItemsDraft.objects.filter(claim_detail__in=
                                                     claim_details_pk)
        lodging_items = LodgingItemsDraft.objects.filter(claim_detail__in=
                                                         claim_details_pk)
        misc_items = MiscellaneousItemsDraft.objects.filter(claim_detail__in=
                                                            claim_details_pk)
        doc_items = get_document_list_item_draft(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'subsistence_items': subsistence_items.values()
                , 'subsistence_distributions': subsistence_distributions.values()
                , 'meal_items': meal_items.values()
                , 'hotel_items': hotel_items.values()
                , 'lodging_items': lodging_items.values()
                , 'misc_items': misc_items.values()
                , 'doc_items': doc_items.values()
                }

    def get_st_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetailsdraft_set.all()
        claim_details = claim_details.filter(activitiy_type='ST')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        mileage_items = MileageItemsDraft.objects.filter(claim_detail__in=
                                                         claim_details_pk)
        public_transport_items = PublicTransportItemsDraft.objects.filter(
                                                            claim_detail__in=
                                                            claim_details_pk)
        meal_items = MealItemsDraft.objects.filter(claim_detail__in=
                                                   claim_details_pk)
        meal_items_pk = meal_items.values_list('pk', flat=True)
        meal_distributions = MealDistributionsDraft.objects.filter(
                                                            meal_item__in=
                                                            meal_items_pk)
        hotel_items = HotelItemsDraft.objects.filter(claim_detail__in=
                                                     claim_details_pk)
        lodging_items = LodgingItemsDraft.objects.filter(claim_detail__in=
                                                         claim_details_pk)
        subsistence_items = SubsistenceItemsDraft.objects.filter(
                                                            claim_detail__in=
                                                            claim_details_pk)
        subsistence_items_pk = subsistence_items.values_list('pk', flat=True)
        subsistence_distributions = SubsistenceDistributionsDraft.objects.filter(
                                                        subsistence_item__in=
                                                        subsistence_items_pk)
        misc_items = MiscellaneousItemsDraft.objects.filter(claim_detail__in=
                                                            claim_details_pk)
        doc_items = get_document_list_item_draft(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'mileage_items': mileage_items.values()
                , 'public_transport_items': public_transport_items.values()
                , 'meal_items': meal_items.values()
                , 'meal_distributions': meal_distributions.values()
                , 'hotel_items': hotel_items.values()
                , 'lodging_items': lodging_items.values()
                , 'subsistence_items': subsistence_items.values()
                , 'subsistence_distributions': subsistence_distributions.values()
                , 'misc_items': misc_items.values()
                , 'doc_items': doc_items.values()
                }

    def get_pt_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetailsdraft_set.all()
        claim_details = claim_details.filter(activitiy_type='PT')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        meal_aid_items = MealAidItemsDraft.objects.filter(claim_detail__in=
                                                          claim_details_pk)
        meal_aid_items_pk = meal_aid_items.values_list('pk', flat=True)
        meal_aid_distributions = MealAidDistributionsDraft.objects.filter(
                                                            meal_aid_item__in=
                                                            meal_aid_items_pk)
        transport_aid_items = TransportAidItemsDraft.objects.filter(
                                                            claim_detail__in=
                                                            claim_details_pk)
        transport_aid_items_pk = transport_aid_items.values_list('pk', flat=True)
        transport_aid_distributions = TransportAidDistributionsDraft.objects.filter(
                                                        transport_aid_item__in=
                                                        transport_aid_items_pk)
        doc_items = get_document_list_item_draft(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'meal_aid_items': meal_aid_items.values()
                , 'meal_aid_distributions': meal_aid_distributions.values()
                , 'transport_aid_items': transport_aid_items.values()
                , 'transport_aid_distributions': transport_aid_distributions.values()
                , 'doc_items': doc_items.values()
                }


class LocalTravelClaimSerializer(serializers.ModelSerializer):
    od_claim_details = serializers.SerializerMethodField()
    lt_claim_details = serializers.SerializerMethodField()
    st_claim_details = serializers.SerializerMethodField()
    pt_claim_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTravelClaimDraft
        fields = ('id', 'od_claim_details', 'lt_claim_details',
                  'st_claim_details', 'pt_claim_details')

    def get_od_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetails_set.all()
        claim_details = claim_details.filter(activitiy_type='OD')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        mileage_items = MileageItems.objects.filter(claim_detail__in=
                                                    claim_details_pk)
        public_transport_items = PublicTransportItems.objects.filter(
                                                        claim_detail__in=
                                                        claim_details_pk)
        meal_items = MealItems.objects.filter(claim_detail__in=claim_details_pk)
        meal_items_pk = meal_items.values_list('pk', flat=True)
        meal_distributions = MealDistributions.objects.filter(meal_item__in=
                                                              meal_items_pk)
        hotel_items = HotelItems.objects.filter(claim_detail__in=
                                                claim_details_pk)
        lodging_items = LodgingItems.objects.filter(claim_detail__in=
                                                    claim_details_pk)
        misc_items = MiscellaneousItems.objects.filter(claim_detail__in=
                                                       claim_details_pk)
        doc_items = get_document_list_item(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'mileage_items': mileage_items.values()
                , 'public_transport_items': public_transport_items.values()
                , 'meal_items': meal_items.values()
                , 'meal_distributions': meal_distributions.values()
                , 'hotel_items': hotel_items.values()
                , 'lodging_items': lodging_items.values()
                , 'misc_items': misc_items.values()
                , 'doc_items': doc_items.values()
                }

    def get_lt_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetails_set.all()
        claim_details = claim_details.filter(activitiy_type='LT')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        subsistence_items = SubsistenceItems.objects.filter(claim_detail__in=
                                                            claim_details_pk)
        subsistence_items_pk = subsistence_items.values_list('pk', flat=True)
        subsistence_distributions = SubsistenceDistributions.objects.filter(
                                                        subsistence_item__in=
                                                        subsistence_items_pk)
        meal_items = MealItems.objects.filter(claim_detail__in=claim_details_pk)
        hotel_items = HotelItems.objects.filter(claim_detail__in=
                                                claim_details_pk)
        lodging_items = LodgingItems.objects.filter(claim_detail__in=
                                                    claim_details_pk)
        misc_items = MiscellaneousItems.objects.filter(claim_detail__in=
                                                       claim_details_pk)
        doc_items = get_document_list_item(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'subsistence_items': subsistence_items.values()
                , 'subsistence_distributions': subsistence_distributions.values()
                , 'meal_items': meal_items.values()
                , 'hotel_items': hotel_items.values()
                , 'lodging_items': lodging_items.values()
                , 'misc_items': misc_items.values()
                , 'doc_items': doc_items.values()
                }

    def get_st_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetails_set.all()
        claim_details = claim_details.filter(activitiy_type='ST')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        mileage_items = MileageItems.objects.filter(claim_detail__in=
                                                    claim_details_pk)
        public_transport_items = PublicTransportItems.objects.filter(
                                                            claim_detail__in=
                                                            claim_details_pk)
        meal_items = MealItems.objects.filter(claim_detail__in=claim_details_pk)
        meal_items_pk = meal_items.values_list('pk', flat=True)
        meal_distributions = MealDistributions.objects.filter(meal_item__in=
                                                              meal_items_pk)
        hotel_items = HotelItems.objects.filter(claim_detail__in=
                                                claim_details_pk)
        lodging_items = LodgingItems.objects.filter(claim_detail__in=
                                                    claim_details_pk)
        subsistence_items = SubsistenceItems.objects.filter(claim_detail__in=
                                                            claim_details_pk)
        subsistence_items_pk = subsistence_items.values_list('pk', flat=True)
        subsistence_distributions = SubsistenceDistributions.objects.filter(
                                                        subsistence_item__in=
                                                        subsistence_items_pk)
        misc_items = MiscellaneousItems.objects.filter(claim_detail__in=
                                                       claim_details_pk)
        doc_items = get_document_list_item(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'mileage_items': mileage_items.values()
                , 'public_transport_items': public_transport_items.values()
                , 'meal_items': meal_items.values()
                , 'meal_distributions': meal_distributions.values()
                , 'hotel_items': hotel_items.values()
                , 'lodging_items': lodging_items.values()
                , 'subsistence_items': subsistence_items.values()
                , 'subsistence_distributions': subsistence_distributions.values()
                , 'misc_items': misc_items.values()
                , 'doc_items': doc_items.values()
                }

    def get_pt_claim_details(self, obj):
        claim_details = obj.localtravelclaimdetails_set.all()
        claim_details = claim_details.filter(activitiy_type='PT')
        claim_details_pk = claim_details.values_list('pk', flat=True)
        meal_aid_items = MealAidItems.objects.filter(claim_detail__in=
                                                     claim_details_pk)
        meal_aid_items_pk = meal_aid_items.values_list('pk', flat=True)
        meal_aid_distributions = MealAidDistributions.objects.filter(
                                                            meal_aid_item__in=
                                                            meal_aid_items_pk)
        transport_aid_items = TransportAidItems.objects.filter(claim_detail__in=
                                                               claim_details_pk)
        transport_aid_items_pk = transport_aid_items.values_list('pk', flat=True)
        transport_aid_distributions = TransportAidDistributions.objects.filter(
                                                        transport_aid_item__in=
                                                        transport_aid_items_pk)
        doc_items = get_document_list_item(obj.id, 'LTC', claim_details_pk)

        return {'claim_details': claim_details.values()
                , 'meal_aid_items': meal_aid_items.values()
                , 'meal_aid_distributions': meal_aid_distributions.values()
                , 'transport_aid_items': transport_aid_items.values()
                , 'transport_aid_distributions': transport_aid_distributions.values()
                , 'doc_items': doc_items.values()
                }