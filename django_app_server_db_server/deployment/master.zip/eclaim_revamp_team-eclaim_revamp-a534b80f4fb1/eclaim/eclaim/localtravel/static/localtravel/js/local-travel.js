/********************************************
 *      CREATED BY  :   DANIAL DARWIN       *
 *      DATE        :   DECEMBER 2015       *
 *******************************************/

uiBootstrapApp.controller('MainCtrl'
                        , function ($scope, $filter, $http, DataClaimant, DataFundType, DataFormMileage,
                                    DataFormPublicTransport, DataFormLodging, DataFormHotel, DataFormMeal,
                                    DataFormMisc, DataFormSubsis, DataFormMealAid, DataFormTransportAid,
                                    DataFormDoc, DataAdvance, DataFormMain) {
    /****************
    *   Accordion   *
    *****************/
    $scope.oneAtATime = false;

    $scope.panels = [
        {name: 'claimantDetails', open: false},
        {name: 'rateEntitlements', open: false},
        {name: 'masterJourneyDetails', open: false},
        {name: 'claimDetailsOD', open: false},
        {name: 'claimDetailsLT', open: false},
        {name: 'claimDetailsST', open: false},
        {name: 'claimDetailsPT', open: false},
        {name: 'masterSummary', open: false},
        {name: 'glDistributions', open: true}
    ];

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** Accordion */
    
    /**********************
     * Global Date Config *
     **********************/
    $scope.dateFormats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MM-yyyy'];
    
    $scope.monthDateOptions = {
        datepickerMode: "'month'",
    	minMode: 'month'
    };
    
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };
    
    $scope.monthFormat = $scope.dateFormats[4];
    $scope.dateFormat = $scope.dateFormats[0];
    /** Global Date Config */
    
    /**********************
     * Global Time Config *
     **********************/
    $scope.hstep = 1;
	$scope.mstep = 1;

	$scope.options = {
	  hstep: [1, 2, 3],
	  mstep: [1, 5, 10, 15, 25, 30]
	};

	$scope.ismeridian = false;
    
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.forceValidTime = function (objForm, objName) {
        var objDate = objForm[objName];
        
        if (!angular.isDate(objDate)) {
            objForm[objName] = initTime;
        }
    };
    /** Global Time Config */
    
    /******************************
     *  Load Rate & Entitlements  *
     ******************************/
    $scope.offDutyTripEntitlements = [];
    $scope.courseTripEntitlements = [];
    $scope.courseDailyEntitlements = [];
    
    $scope.initEntitlements = function(){
        $http({
			url: API_URL+'offduty-trip-allowance/',
			method: 'GET',
            params: {'staffNo':DataClaimant.getStaffNo()}
		})
		.success(function (data, status, headers, config) {
            $scope.offDutyTripEntitlements = data.results;
		});

        $http({
			url: API_URL+'course-trip-allowance/',
			method: 'GET',
            params: {'staffNo':DataClaimant.getStaffNo()}
		})
		.success(function (data, status, headers, config) {
            $scope.courseTripEntitlements = data.results;
		});

        $http({
			url: API_URL+'course-daily-allowance/',
			method: 'GET',
            params: {'staffNo':DataClaimant.getStaffNo()}
		})
		.success(function (data, status, headers, config) {
            $scope.courseDailyEntitlements = data.results;
		});
    };
    
    $scope.getRate = function(activity_type, filterby, objType){
        var rate = 0;
        var entitlements = [];
        
        if (activity_type == 'offduty_trip') {
            entitlements = $scope.offDutyTripEntitlements;
        }else if (activity_type == 'course_trip') {
            entitlements = $scope.courseTripEntitlements;
        }else if (activity_type == 'course_daily') {
            entitlements = $scope.courseDailyEntitlements;
        }
        
        if (activity_type == 'offduty_trip' || activity_type == 'course_trip') {
            entitlements.forEach(function(ent){
                if (ent.region == filterby) {
                    rate = ent[objType];
                }
            });
        }else if (activity_type == 'course_daily') {
            entitlements.forEach(function(ent){
                if (ent.course_location == filterby) {
                    rate = ent[objType];
                }
            });
        }
        /*console.log('Selected rate >>> Activity=',activity_type,' | filterby=',filterby
                    ,' | Type='+objType+' | Rate='+rate);*/
        return rate;
    };
    /** Load Rate & Entitlements */
    
    /************************************
    *   Load Vehicle CC, Types & Rate   *
    *************************************/
    $scope.initVehicleCCs = function(jsonVehicleCCList){
        $scope.vehicleCCs = getAngularObjFromJson(jsonVehicleCCList);
    };
    
    $http({
        url: API_URL+'vehicle-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.vehicleTypes = data.results;
    });
    
    $http({
        url: API_URL+'vehicle-rate/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.vehicleTypeRates = data.results;
    });
    
    $scope.getVehicleRateByTypeID = function(typeID){
        var rate = 0;
        var objType = $filter("filter")($scope.vehicleTypes, {id: typeID});
        var objRate = $filter("filter")($scope.vehicleTypeRates, {vehicle_type: typeID});
        
        if (typeID && objType) {
            rate = objRate[0].rate;
        }
        //console.log('Selected vehicle >>> Type=',objType[0].name,' | Rate='+rate);
        return rate;
    };
    
    $scope.getVehicleTypeByID = function(typeID){
        var rate = 0;
        var objType = $filter("filter")($scope.vehicleTypes, {id: typeID});
        return objType[0];
    };
    
    $scope.getVehicleCCByCode = function(code){
        var rate = 0;
        var objType = $filter("filter")($scope.vehicleCCs, {code: code});
        return objType[0];
    };
    /** Load Vehicle Types & Rate */
    
    /*******************************
    *  Load Public Transport Type  *
    ********************************/
    $scope.publicTransportTypes = [];
    
    $http({
        url: '/eclaim/masterfiles/public-transport-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.publicTransportTypes = data;
    });
    
    $scope.getTransportTypeByCode = function(code){
        var objSelect = $filter("filter")($scope.publicTransportTypes, {code:code});
        //console.log('Selected trip type >>> Code='+objSelect.code+' | Description='+ objSelect.description);
        return objSelect[0];
    };
    /** Load Public Transport Type */
    
    /**********************************
    *  Load Region & Course Location  *
    ***********************************/
    $http({
        url: '/eclaim/masterfiles/region-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.regions = data;
    });

    $http({
        url: '/eclaim/masterfiles/course-location-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.courseLocations = data;
    });
    
    $scope.getRegionByCode = function(code){
        var objSelect = $filter("filter")($scope.regions, {code:code});
        return objSelect[0];
    };
    
    $scope.getCourseLocationByCode = function(code){
        var objSelect = $filter("filter")($scope.courseLocations, {code:code});
        return objSelect[0];
    };
    /**  Load Region & Course Location  */
    
    /********************************
    *  Load Miscellaneous Expenses  *
    *********************************/
    $http({
        url: '/eclaim/masterfiles/misc-expenses-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.miscExpenses = data;
    });
    
    $scope.getMiscExpensesByCode = function(code){
        var objSelect = $filter('filter')($scope.miscExpenses, {code: code})
        return objSelect[0];
    };
    /**  Load Miscellaneous Expenses  */
    
    /******************************
    *  Load Supporting Documents  *
    *******************************/
    $http({
        url: API_URL+'document-list/',
        method: 'GET',
        params: {'claim_type': 'LTC'
            ,'document_group': 'OD'
        }
    })
    .success(function (data, status, headers, config) {
        $scope.docsOD = data.results;
    });

    $http({
        url: API_URL+'document-list/',
        method: 'GET',
        params: {'claim_type': 'LTC'
            ,'document_group': 'LT'
        }
    })
    .success(function (data, status, headers, config) {
        $scope.docsLT = data.results;
    });

    $http({
        url: API_URL+'document-list/',
        method: 'GET',
        params: {'claim_type': 'LTC'
            ,'document_group': 'ST'
        }
    })
    .success(function (data, status, headers, config) {
        $scope.docsST = data.results;
    });

    $http({
        url: API_URL+'document-list/',
        method: 'GET',
        params: {'claim_type': 'LTC'
            ,'document_group': 'PT'
        }
    })
    .success(function (data, status, headers, config) {
        $scope.docsPT = data.results;
    });
    
    $scope.getSupportingDocumentByID = function(section, id){
        var documentList = [];
        var objSelect = {};
        
        if (section == 'OD') {
            documentList = $scope.docsOD;
        }
        else if (section == 'LT') {
            documentList = $scope.docsLT;
        }
        else if (section == 'ST') {
            documentList = $scope.docsST;
        }
        else if (section == 'PT') {
            documentList = $scope.docsPT;
        }
        
        objSelect = $filter('filter')(documentList, {id: id});
        return objSelect[0];
    };
    /**  Load Supporting Documents  */
    
    /*****************
     * Others Config *
     *****************/
    // Global table pagination
    $scope.pageSize = 10;
    $scope.currentPage = 1;
    
    /** Others Config */
    
    /********************
    *   Trip Options    *
    *********************/
    var setAttribute = function(){
        return {
            active: true,
            fromDate: '', toDate: '',
            fromDateTxt: '', toDateTxt: '',
            mileage: {}, mileageItems:[],
            publicTransport: {}, publicTransportItems: [],
            meal: {}, mealItems: [],
            hotel: {}, hotelItems:[],
            lodging: {}, lodgingItems:[],
            miscellaneous: {}, miscellaneousItems: [],
            subsis: {}, subsisItems: [],
            supportingDocuments: [],
            expensesSummary: [],
            gstSummary: [],
            expensesGrandTotal: 0,
            gstGrandTotal: 0
        }
    };
    
    $scope.mileageForm = {};
    $scope.publicTransportForm = {};
    $scope.mealForm = {};
    $scope.hotelForm = {};
    $scope.lodgingForm = {};
    $scope.miscellaneousForm = {};
    $scope.subsisForm = {};
    
    $scope.masterDetails = {
        claimMonth: '',
        ltcFromDate: '',
        ltcToDate: '',
        claimMonthTxt: '',
        ltcFromDateTxt: '',
        ltcToDateTxt: ''
    };
    
    $scope.ODTrip = [setAttribute()];
    $scope.LTTrip = [setAttribute()];
    $scope.STTrip = [setAttribute()];
    $scope.PTTrip = [setAttribute()];
    $scope.masterExpensesSummary = [];
    $scope.masterGSTSummary = [];
    
    $scope.tripSelector = function(section){
        var trip = [];
        
        if (section == 'OD') {
            trip = $scope.ODTrip;
        }
        else if (section == 'LT') {
            trip = $scope.LTTrip;
        }
        else if (section == 'ST') {
            trip = $scope.STTrip;
        }
        else if (section == 'PT') {
            trip = $scope.PTTrip;
        }
        return trip;
    };
    
    $scope.getActiveTrip = function(section){
        // Return entire object only for active trip
        var trip = $scope.tripSelector(section);
        return $filter("filter")(trip, {active: true})[0]
    };
    
    $scope.getTrip = function(section, objName){
        var trip = $scope.getActiveTrip(section);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    };
    /** Trip Options */
    
    $scope.initLoad = function(config, draftID, claimID){
        $scope.draftID = draftID;
        $scope.isConfVEHICLETYPE = false;
        config = getAngularObjFromJson(config);
        if (config.VEHICLETYPE == 'YES'){
            $scope.isConfVEHICLETYPE = true;
        }

        $http({
			url: API_URL+'expenses/',
			method: 'GET',
            params: {'claim_code':'LTC'}
		})
		.success(function (data, status, headers, config) {
            $scope.expensesOD = angular.copy(data.results);
            $scope.expensesLT = angular.copy(data.results);
            $scope.expensesST = angular.copy(data.results);
            $scope.expensesPT = angular.copy(data.results);
		});

        if (draftID || claimID) {
            if (draftID) {
                $http({
                    url: API_URL+'local-travel-claim-drafts/'+draftID+'/',
                    method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    // Journey Details
                    $scope.masterDetails.claimMonth = getDateFromStr(data.journey_details.claim_month);
                    $scope.masterDetails.ltcFromDate = getDateFromStr(data.journey_details.travel_date_from);
                    $scope.masterDetails.ltcToDate = getDateFromStr(data.journey_details.travel_date_to);
                    
                    // Official Duty
                    trip = $scope.ODTrip;
                    if (data.od_claim_details.claim_details[0]) {
                        var claimDetails = data.od_claim_details.claim_details[0];
                        trip[0].fromDate = getDateFromStr(claimDetails.travel_date_from);
                        trip[0].toDate = getDateFromStr(claimDetails.travel_date_to);
                    }
                    DataFormMileage.setODDBItems(data.od_claim_details.mileage_items);
                    DataFormPublicTransport.setODDBItems(data.od_claim_details.public_transport_items);
                    DataFormMeal.setODDBItems(data.od_claim_details.meal_items);
                    DataFormMeal.setODDBDistributions(data.od_claim_details.meal_distributions);
                    DataFormHotel.setODDBItems(data.od_claim_details.hotel_items);
                    DataFormLodging.setODDBItems(data.od_claim_details.lodging_items);
                    DataFormMisc.setODDBItems(data.od_claim_details.misc_items);
                    DataFormDoc.setODDBItems(data.od_claim_details.doc_items);

                    // Long Term
                    trip = $scope.LTTrip;
                    if (data.lt_claim_details.claim_details[0]) {
                        var claimDetails = data.lt_claim_details.claim_details[0];
                        trip[0].fromDate = getDateFromStr(claimDetails.travel_date_from);
                        trip[0].toDate = getDateFromStr(claimDetails.travel_date_to);
                    }
                    DataFormSubsis.setLTDBItems(data.lt_claim_details.subsistence_items);
                    DataFormSubsis.setLTDBDistributions(data.lt_claim_details.subsistence_distributions);
                    DataFormMisc.setLTDBItems(data.lt_claim_details.misc_items);
                    DataFormDoc.setLTDBItems(data.lt_claim_details.doc_items);

                    // Short Term
                    trip = $scope.STTrip;
                    if (data.st_claim_details.claim_details[0]) {
                        var claimDetails = data.st_claim_details.claim_details[0];
                        trip[0].fromDate = getDateFromStr(claimDetails.travel_date_from);
                        trip[0].toDate = getDateFromStr(claimDetails.travel_date_to);
                    }
                    DataFormMileage.setSTDBItems(data.st_claim_details.mileage_items);
                    DataFormPublicTransport.setSTDBItems(data.st_claim_details.public_transport_items);
                    DataFormMeal.setSTDBItems(data.st_claim_details.meal_items);
                    DataFormMeal.setSTDBDistributions(data.st_claim_details.meal_distributions);
                    DataFormHotel.setSTDBItems(data.st_claim_details.hotel_items);
                    DataFormLodging.setSTDBItems(data.st_claim_details.lodging_items);
                    DataFormSubsis.setSTDBItems(data.st_claim_details.subsistence_items);
                    DataFormSubsis.setSTDBDistributions(data.st_claim_details.subsistence_distributions);
                    DataFormMisc.setSTDBItems(data.st_claim_details.misc_items);
                    DataFormDoc.setSTDBItems(data.st_claim_details.doc_items);

                    // Part Time
                    if (data.pt_claim_details.claim_details[0]) {
                        DataFormMain.setPTDateFrom(getDateFromStr(data.pt_claim_details.claim_details[0].travel_date_from));
                        DataFormMain.setPTDateTo(getDateFromStr(data.pt_claim_details.claim_details[0].travel_date_to));
                    }
                    DataFormMealAid.setPTDBItems(data.pt_claim_details.meal_aid_items);
                    DataFormMealAid.setPTDBDistributions(data.pt_claim_details.meal_aid_distributions);
                    DataFormTransportAid.setPTDBItems(data.pt_claim_details.transport_aid_items);
                    DataFormTransportAid.setPTDBDistributions(data.pt_claim_details.transport_aid_distributions);
                    DataFormDoc.setPTDBItems(data.pt_claim_details.doc_items);
                });
            }
            else if (claimID) {
                $http({
                    url: API_URL+'local-travel-claims/'+claimID+'/',
                    method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    /**
                     * Official Duty
                     */
                    if (data.od_claim_details.claim_details[0]) {
                        DataFormMain.setODDateFrom(getDateFromStr(data.od_claim_details.claim_details[0].travel_date_from));
                        DataFormMain.setODDateTo(getDateFromStr(data.od_claim_details.claim_details[0].travel_date_to));
                    }
                    DataFormMileage.setODDBItems(data.od_claim_details.mileage_items);
                    DataFormPublicTransport.setODDBItems(data.od_claim_details.public_transport_items);
                    DataFormMeal.setODDBItems(data.od_claim_details.meal_items);
                    DataFormMeal.setODDBDistributions(data.od_claim_details.meal_distributions);
                    DataFormHotel.setODDBItems(data.od_claim_details.hotel_items);
                    DataFormLodging.setODDBItems(data.od_claim_details.lodging_items);
                    DataFormMisc.setODDBItems(data.od_claim_details.misc_items);
                    DataFormDoc.setODDBItems(data.od_claim_details.doc_items);

                    /**
                     * Long Term
                     */
                    if (data.lt_claim_details.claim_details[0]) {
                        DataFormMain.setLTDateFrom(getDateFromStr(data.lt_claim_details.claim_details[0].travel_date_from));
                        DataFormMain.setLTDateTo(getDateFromStr(data.lt_claim_details.claim_details[0].travel_date_to));
                    }
                    DataFormSubsis.setLTDBItems(data.lt_claim_details.subsistence_items);
                    DataFormSubsis.setLTDBDistributions(data.lt_claim_details.subsistence_distributions);
                    DataFormMisc.setLTDBItems(data.lt_claim_details.misc_items);
                    DataFormDoc.setLTDBItems(data.lt_claim_details.doc_items);

                    /**
                     * Short Term
                     */
                    if (data.st_claim_details.claim_details[0]) {
                        DataFormMain.setSTDateFrom(getDateFromStr(data.st_claim_details.claim_details[0].travel_date_from));
                        DataFormMain.setSTDateTo(getDateFromStr(data.st_claim_details.claim_details[0].travel_date_to));
                    }
                    DataFormMileage.setSTDBItems(data.st_claim_details.mileage_items);
                    DataFormPublicTransport.setSTDBItems(data.st_claim_details.public_transport_items);
                    DataFormMeal.setSTDBItems(data.st_claim_details.meal_items);
                    DataFormMeal.setSTDBDistributions(data.st_claim_details.meal_distributions);
                    DataFormHotel.setSTDBItems(data.st_claim_details.hotel_items);
                    DataFormLodging.setSTDBItems(data.st_claim_details.lodging_items);
                    DataFormSubsis.setSTDBItems(data.st_claim_details.subsistence_items);
                    DataFormSubsis.setSTDBDistributions(data.st_claim_details.subsistence_distributions);
                    DataFormMisc.setSTDBItems(data.st_claim_details.misc_items);
                    DataFormDoc.setSTDBItems(data.st_claim_details.doc_items);

                    /**
                     * Part Time
                     */
                    if (data.pt_claim_details.claim_details[0]) {
                        DataFormMain.setPTDateFrom(getDateFromStr(data.pt_claim_details.claim_details[0].travel_date_from));
                        DataFormMain.setPTDateTo(getDateFromStr(data.pt_claim_details.claim_details[0].travel_date_to));
                    }
                    DataFormMealAid.setPTDBItems(data.pt_claim_details.meal_aid_items);
                    DataFormMealAid.setPTDBDistributions(data.pt_claim_details.meal_aid_distributions);
                    DataFormTransportAid.setPTDBItems(data.pt_claim_details.transport_aid_items);
                    DataFormTransportAid.setPTDBDistributions(data.pt_claim_details.transport_aid_distributions);
                    DataFormDoc.setPTDBItems(data.pt_claim_details.doc_items);
                });
            }
        }
    };

    $scope.onClickSummaryPanel = function(section){
        var trip = $scope.getTrip(section);
        trip.expensesGrandTotal = getListTotalAmount(trip.expensesSummary, 'amount');
        trip.gstGrandTotal = getListTotalAmount(trip.gstSummary, 'amount');
    };
    
    /*******************
     *     WORKFLOW    *
     *******************/
    
    // Render workflow query types
    $http({
        url: API_URL+'workflow-query-types/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.querytype_list = data.results;
    });

    // Form declaration
    function render_form_declaration (claim_type_id, level_ordering) {
       $http({
           url: API_URL+'form-declaration/',
           method: 'GET',
           params: {
               claim_type: claim_type_id,
               level_ordering: level_ordering
           }
       })
       .success(function (data, status, headers, config) {
           if (data.results.length) {
               var _el = data.results[0];

               if (LANGUAGE_CODE == 'ms-my') {
                   $scope.form_declaration = _el.content_my;
               } else {
                   $scope.form_declaration = _el.content_en;
               }
           }
       });
   }

    // Render workflow reasons
    if (WF_TEMPLATE) {
        var reason_params = { template: WF_TEMPLATE };
    } else {
        var reason_params = {};
    }
    $http({
        url: API_URL+'workflow-reasons/',
        method: 'GET',
        params: reason_params
    })
    .success(function (data, status, headers, config) {
        $scope.reason_list = data.results;
    });

    // Claim button controls
    $scope.controls = {};

    // Detail view
    if (PK) {
        // Initialize variables.
        $scope.controls.has_basic_perm = false;
        $scope.controls.has_ext_perm = false;

        $http({
            url: API_URL+'localtravel-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.claim = data;
            $scope.claim.query_notes = data.notes;

            $http({
                url: API_URL+'claimants/'+STAFF_NO+'/',
                method: 'GET'
            })
            .success(function (claimant_data, status, headers, config) {
                // Check whether user is just a claimant or a privileged user.
                if (!$scope.claim.query) {
                    var _assignee   = $scope.claim.current_assignee,
                        _group      = $scope.claim.current_assigned_group;

                    if (_assignee) {
                        $scope.controls.has_ext_perm = _assignee == STAFF_NO;
                    } else if (claimant_data.assignee) {
                        var _in_group = $.inArray(_group, claimant_data.assignee.groups) != -1;
                        $scope.controls.has_ext_perm = claimant_data.assignee && _in_group;
                    } else {
                        $scope.controls.has_ext_perm = false;
                    }

                    $scope.controls.has_basic_perm = false;
                } else {
                    $scope.controls.has_basic_perm = $scope.claim.claimant_staff_no == STAFF_NO;
                    $scope.controls.has_ext_perm = false;
                }

                console.log('has_basic_perm:', $scope.controls.has_basic_perm);
                console.log('has_ext_perm:', $scope.controls.has_ext_perm);
            });

            // Render a form declaration.
            render_form_declaration(1, data.current_level_ordering);
        });
    } else {
        // New claim.
        $scope.controls.has_basic_perm = true;
        $scope.controls.has_ext_perm = false;

        // Render a form declaration.
        render_form_declaration(1, 1);
    }

    // Assignee from a selection filtering.
    $scope.filtering = {};
    $scope.filtering.claimant_list = [];

    var params = {
        has_filtering: true,
        claim_app: 'localtravel',
        claim_model: 'LocalTravelClaim'
    };
    if (PK)
        params.claim = PK;

    $http({
        url: API_URL+'claimants/',
        method: 'GET',
        params: params
    })
    .success(function (data, status, headers, config) {
        $scope.filtering.claimant_list = data.results;
    });

    // Control button actions.
    $scope.approve_claim = function (claim_no, claim_ctype_id) {
        $http({
            url: URL_AJAX_APPROVE_CLAIM,
            method: 'POST',
            data: {
                claim_no: claim_no,
                claim_ctype: claim_ctype_id
            }
        })
        .success(function (data, status, headers, config) {
            if (data.success)
                window.location.href = URL_HOMEPAGE;
        });
    };

    $scope.reject_claim = function (claim_no, claim_ctype_id, notes) {
        $http({
            url: URL_AJAX_DECLINE_CLAIM,
            method: 'POST',
            data: {
                claim_no: claim_no,
                claim_ctype: claim_ctype_id,
                notes: notes
            }
        })
        .success(function (data, status, headers, config) {
            if (data.success)
                window.location.href = URL_HOMEPAGE;
        });
    };

    $scope.query = function (claim_no, claim_ctype_id, query_type, notes) {
        $http({
            url: URL_AJAX_QUERY,
            method: 'POST',
            data: {
                claim_no: claim_no,
                claim_ctype: claim_ctype_id,
                query_type: query_type,
                notes: notes
            }
        })
        .success(function (data, status, headers, config) {
            if (data.success)
                window.location.href = URL_HOMEPAGE;
        });
    };
    /** WORKFLOW */
});

uiBootstrapApp.controller('JourneyDetailsCtrl', function ($scope, $filter, DataFormMain) {
    
	$scope.initLoad = function(section){
        var toWatchItems = [];
        var trip = [];
        
        if (section == 'Master') {
            $scope.masterDetails.claimMonth = new Date();
            $scope.masterDetails.ltcFromDate = new Date();
            $scope.masterDetails.ltcToDate = new Date();
            $scope.masterDetails.claimMonthTxt = getDateStr($filter, new Date());
            $scope.masterDetails.ltcFromDateTxt = getDateStr($filter, new Date());
            $scope.masterDetails.ltcToDateTxt = getDateStr($filter, new Date());
            
            toWatchItems = ['claimMonth', 'ltcFromDate', 'ltcToDate'];
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('masterDetails.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        if (objToWatch == 'claimMonth') {
                            $scope.masterDetails.claimMonthTxt = getDateStr($filter, newVal);
                        }else if (objToWatch == 'ltcFromDate') {
                            $scope.masterDetails.ltcFromDateTxt = getDateStr($filter, newVal);
                        }else if (objToWatch == 'ltcToDate') {
                            $scope.masterDetails.ltcToDateTxt = getDateStr($filter, newVal);
                        }
                    }
                });
            });
        }
        else if (section == 'OD' || section == 'LT' || section == 'ST' || section == 'PT') {
            toWatchItems = ['fromDate', 'toDate'];
            trip = $scope.tripSelector(section);
            trip[0].activityType = section;
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch(function() {
                    return trip.map(function(obj) {
                        return obj[objToWatch];
                    });
                }, function (newVal, oldVal) {
                    if (newVal != oldVal) {
                        if (objToWatch == 'fromDate') {
                            trip[0].fromDateTxt = getDateStr($filter, newVal[0]);
                        }else if (objToWatch == 'toDate') {
                            trip[0].toDateTxt = getDateStr($filter, newVal[0]);
                        }
                    }
                }, true);
            });
        }
    };

    $scope.openClaimMonth = function($event) {
        $scope.statusClaimMonth.opened = true;
    };
    $scope.openFromDate = function($event) {
        $scope.statusFromDate.opened = true;
    };
    $scope.openToDate = function($event) {
        $scope.statusToDate.opened = true;
    };

    $scope.statusClaimMonth = {
        opened: false
    };
    $scope.statusFromDate = {
        opened: false
    };
    $scope.statusToDate = {
        opened: false
    };
});

uiBootstrapApp.factory('DataFormMain', function($filter){
    var data = {
        CurrSection: ''
    };

    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

/******************** Start : Mileage ********************/
uiBootstrapApp.controller('MileageCtrl', function($scope, $filter, DataFundType, DataLookup,
                                                  DataFormMain, DataFormMileage){
    
    $scope.initLoad = function(section){
        var initTime = new Date();
        initTime.setHours(0);
        initTime.setMinutes(0);
        setEmptyTable();
        if (section == 'OD') {
            var form = getForm();
            //form.mileageVehicleRate = get2Float(0);
            form.prevCumulativeMileage = get1Float(0); // 0 to assume there is no milage claim in current month
            form.cumulativeMileage = get1Float(0);
            
            $scope.$watch(function () { return DataFormMileage.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMileage.setCurrSection('OD');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var toWatchItems = [
                                'departDate', 'departTime', 'returnDate', 'returnTime',
                                'destinationFrom', 'destinationTo', 'description',
                                'vehicleCC', 'vehicleType', 'vehicleRegistrationNo',
                                'mileage', 'grossAmount', 'corporateCard'
                            ];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                    form[objToWatch] = initTime;
                }
                else if (objToWatch == 'corporateCard') {
                    form[objToWatch] = false;
                }
                else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('mileageForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                            $scope.forceValidTime(form, objToWatch);
                        }
                        else if (objToWatch == 'vehicleCC' || objToWatch == 'vehicleType'
                                 || objToWatch == 'mileage') {
                            calculateMileageAmount();
                        }
                        
                        // Set value
                        if (objToWatch == 'mileage') {
                            changeItemVal(objToWatch, get1Float(newVal));
                        }
                        else if (objToWatch == 'grossAmount') {
                            changeItemVal(objToWatch, get2Float(newVal));
                            calculateGrandTotal();
                        }else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
        }
        else if (section == 'ST') {
            $scope.$watch(function () { return DataFormMileage.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMileage.setCurrSection('ST');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
        }
    };
    
    /** Date : Start */
    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('#mileageODModalForm, #mileageSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.departDate = getDateFromStr(objDB.depart_date);
            form.returnDate = getDateFromStr(objDB.return_date);
            form.departTime = getTimeFromStr(objDB.depart_time);
            form.returnTime = getTimeFromStr(objDB.return_time);
            form.destinationFrom = objDB.destination_from;
            form.destinationTo = objDB.destination_to;
            form.description = objDB.travelling_info;
            form.vehicleType = $scope.getVehicleTypeByID(objDB.vehicle_type);
            form.vehicleCC = $scope.getVehicleCCByCode(objDB.vehicle_cc);
            form.vehicleRegistrationNo = objDB.vehicle_reg_no;
            form.mileage = objDB.mileage;
            form.grossAmount = objDB.amount;
            form.corporateCard = objDB.corporate_card;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            departDate: form.departDate, departDateTxt: getDateStr($filter, form.departDate),
            departTime: form.departTime, departTimeTxt: getTimeStr(form.departTime),
            returnDate: form.returnDate, returnDateTxt: getDateStr($filter, form.returnDate),
            returnTime: form.returnTime, returnTimeTxt: getTimeStr(form.returnTime),
            destinationFrom: form.destinationFrom, destinationTo: form.destinationTo,
            description: form.description,
            vehicleCC: form.vehicleCC, vehicleType: form.vehicleType,
            vehicleRegistrationNo: $filter('uppercase')(form.vehicleRegistrationNo),
            vehicleType: form.vehicleType,
            mileage: get1Float(form.mileage),
            cumulativeMileage: get1Float(form.cumulativeMileage),
            grossAmount: get2Float(form.grossAmount),
            corporateCard: form.corporateCard,
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };
    
    var setForm = function(currItem){
        var form = getForm();
        form.departDate = currItem.departDate;
        form.departTime = currItem.departTime;
        form.returnDate = currItem.returnDate;
        form.returnTime = currItem.returnTime;
        form.destinationFrom = currItem.destinationFrom;
        form.destinationTo = currItem.destinationTo;
        form.description = currItem.description;
        form.vehicleCC = currItem.vehicleCC;
        form.vehicleType = currItem.vehicleType;
        form.vehicleRegistrationNo = currItem.vehicleRegistrationNo;
        form.mileage = currItem.mileage;
        form.grossAmount = currItem.grossAmount;
        form.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var resetForm = function(){
        /*
        var trip = getTrip('mileage');
        console.log(trip);
        trip['departDate'] = '';
        trip['returnDate'] = '';
        trip['departTime'] = initTime;
        trip['returnTime'] = initTime;
        trip['destinationFrom'] = '';
        trip['destinationTo'] = '';
        trip['description'] = '';
        trip['mileage'] = '';
        trip['grossAmount'] = '';
        trip['corporateCard'] = false;*/
    };
    
    var getForm = function(){
        return $scope.mileageForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormMileage.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var obj = getTrip('mileageItems');
        
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(objName, newValue) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            if (currItem) {
                currItem[objName] = newValue;
                if (objName == 'departDate' || objName == 'returnDate') {
                    currItem.departDateTxt = getDateStr($filter, form[objName]);
                    currItem.returnDateTxt = getDateStr($filter, form[objName]);
                }
                else if (objName == 'departTime' || objName == 'returnTime') {
                    currItem.departTimeTxt = getTimeStr(form[objName]);
                    currItem.returnTimeTxt = getTimeStr(form[objName]);
                }
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormMileage.setCurrSection(section);
        $('#mileage'+section+'ModalForm').modal('show');
        var form = getForm();
        if (mode == 'newForm') {
            form.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            form.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        resetForm();
        calculateAll();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormMileage.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var form = getForm();
        form.isEditMode = true;
        form.currIndex = index;
        form.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        var form = getForm();
        if (items.length > 0) {
            if (form.directIndex == items.length) {
                form.directIndex = items.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                currItem = items[form.directIndex];
                setForm(currItem);
                form.currIndex = form.directIndex;
                form.isEditMode = true;
            }else if (direct == 'next' && !(form.directIndex >= items.length-1)) {
                form.directIndex++;
                currItem = items[form.directIndex];
                setForm(currItem);
                form.currIndex = form.directIndex;
                form.isEditMode = true;
            }
        }
    };

    // Calculation : Start
        var calculateCumulativeMileageEachRow = function(){
            var index = 1;
            var rowCumulativeMileage = 0;
            var prevCumulativeMileage = 0;
            var currMileageAmount = 0;
            var items = getItems();
            var form = getForm();
            console.log('--- Start ---');
            angular.forEach(items, function(obj){
                var vehicleCCRates = obj['vehicleCC'];
                var rowMileage = parseFloat(obj['mileage']);
                if (index == 1) {
                    rowCumulativeMileage = parseFloat(form.prevCumulativeMileage) + rowMileage;
                }else{
                    rowCumulativeMileage = rowCumulativeMileage + rowMileage;
                    console.log(' ');
                }
                obj['cumulativeMileage'] = get1Float(rowCumulativeMileage);
                currMileageAmount = calculateAmountBaseOnCumulative(prevCumulativeMileage, rowMileage, rowCumulativeMileage, vehicleCCRates);
                prevCumulativeMileage = prevCumulativeMileage + rowMileage;
                obj['grossAmount'] = get2Float(currMileageAmount);
                index++;
            });
            console.log('--- End ---');
            };
        
        var calculateMileageAmount = function () {
            var form = getForm();
            var mileage = form.mileage;
            var grossAmount = 0;
            var rate = 0;
            
            if ($scope.isConfVEHICLETYPE) {
                var vehicleType = form.vehicleType;
                rate = $scope.getVehicleRateByTypeID(vehicleType.id);
                grossAmount = parseFloat(mileage) * parseFloat(rate);
            }else{
                var cumulativeMileage = 0;
                prevCumulativeMileage = getListTotalAmount(getItems(), 'mileage');
                cumulativeMileage = parseFloat(mileage) + parseFloat(prevCumulativeMileage);
                if (form.vehicleCC && form.vehicleCC.rates_bycc) {
                    grossAmount = calculateAmountBaseOnCumulative(prevCumulativeMileage, mileage,
                                                                    cumulativeMileage, form.vehicleCC);
                }
            };
            
            form.grossAmount = get2Float(grossAmount);
        };

        var calculateAll = function(){
            if (!$scope.isConfVEHICLETYPE) {
                calculateCumulativeMileageEachRow();
            }
            calculateGrandTotal();
        };

        var calculateGrandTotal =  function(){
            var trip = getTrip('mileage');
            var items = getTrip('mileageItems');
            
            if (items) {
                var grandTotalGrossAmount = getListTotalAmount(items, 'grossAmount');
                trip['grandTotalMileage'] = get1Float(getListTotalAmount(items, 'mileage'));
                trip['grandTotalCumulativeMileage'] = get1Float(getListTotalAmount(items, 'cumulativeMileage'));
                trip['grandTotalGrossAmount'] = grandTotalGrossAmount;
                DataFormMileage.setGrandTotal(grandTotalGrossAmount);
            }
        };
    // Calculation : End

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('fundType', newValue);
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('projectCode', newValue);
    });
    
    /*
    $scope.$watch('mileageItems', function(newValue, oldValue) {
        if (newValue != oldValue) { DataFormMileage.setMileageItems($scope.mileageItems);}
    }, true);

    $scope.$watch('mileageSTItems', function(newValue, oldValue) {
        if (newValue != oldValue) { DataFormMileage.setMileageSTItems($scope.mileageSTItems); }
    }, true);*/

});

uiBootstrapApp.factory('DataFormMileage', function ($filter) {
    var data = {
        CurrSection: '',
        MileageItems: [],
        MileageSTItems: [],
        GrandTotalOD: get2Float(0),
        GrandTotalST: get2Float(0),
        ODDBItems: [],
        STDBItems: []
    };

    return {
        getCurrSection: function () {
            return data.CurrSection;
        },
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getMileageItems: function () {
            return data.MileageItems;
        },
        setMileageItems: function (obj) {
            data.MileageItems = obj;
        },
        getMileageSTItems: function () {
            return data.MileageSTItems;
        },
        setMileageSTItems: function (obj) {
            data.MileageSTItems = obj;
        },
        getGrandTotalOD: function(){
            return data.GrandTotalOD;
        },
        getGrandTotalST: function(){
            return data.GrandTotalST;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'OD') {
                data.GrandTotalOD = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            }
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        }
    };
});
/******************** End : Mileage ********************/

/******************** Start : Public Transport ********************/
uiBootstrapApp.controller('PublicTransportCtrl', function($scope, $filter, DataFundType, DataLookup
                                                , DataGST, DataFormPublicTransport, DataFormMain){
    
    $scope.initLoad = function(section){
        setEmptyTable();
        
        initTime = new Date();
        initTime.setHours(0);
        initTime.setMinutes(0);
        
        if (section == 'OD') {
            var form = getForm();
            $scope.$watch(function () { return DataFormPublicTransport.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormPublicTransport.setCurrSection(section);
                    if (newValue.length > 0){
                        newValue.forEach(function(obj){
                            $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var toWatchItems = [
                                'departDate', 'departTime', 'returnDate', 'returnTime',
                                'destinationFrom', 'destinationTo', 'description',
                                'publicTransportType', 'receiptNo', 'grossAmount',
                                'gstAmount', 'corporateCard'
                            ];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                    form[objToWatch] = initTime;
                }
                else if (objToWatch == 'corporateCard') {
                    form[objToWatch] = false;
                }
                else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('publicTransportForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                            $scope.forceValidTime(form, objToWatch);
                        }else if (objToWatch == 'grossAmount' || objToWatch == 'gstAmount') {
                            calculateNettAmount();
                        }
                        
                        // Set value
                        if (objToWatch == 'grossAmount' || objToWatch == 'gstAmount') {
                            changeItemVal(objToWatch, get2Float(newVal));
                            calculateGrandTotal();
                        }else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
        }else if (section == 'ST') {
            $scope.$watch(function () { return DataFormPublicTransport.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormPublicTransport.setCurrSection('ST');
                    if (newValue.length > 0){
                        newValue.forEach(function(obj){
                            $scope.addItem(obj);
                        });
                    }
                };
            });
        }
    };
    
    /** Date : Start */
    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('#publicTransportODModalForm, #publicTransportSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.departDate = getDateFromStr(objDB.depart_date);
            form.returnDate = getDateFromStr(objDB.return_date);
            form.departTime = getTimeFromStr(objDB.depart_time);
            form.returnTime = getTimeFromStr(objDB.return_time);
            form.destinationFrom = objDB.destination_from;
            form.destinationTo = objDB.destination_to;
            form.description = objDB.travelling_info;
            form.publicTransportType = $scope.getTransportTypeByCode(objDB.type);
            form.receiptNo = objDB.receipt_no;
            form.grossAmount = objDB.amount;
            form.gstAmount = objDB.gst_amount;
            form.nettAmount = objDB.nett_amount;
            form.corporateCard = objDB.corporate_card;
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            departDate: form.departDate, departDateTxt: getDateStr($filter, form.departDate),
            returnDate: form.returnDate, returnDateTxt: getDateStr($filter, form.returnDate),
            departTime: form.departTime, departTimeTxt: getTimeStr(form.departTime),
            returnTime: form.returnTime, returnTimeTxt: getTimeStr(form.returnTime),
            destinationFrom: form.destinationFrom, destinationTo: form.destinationTo,
            description: form.description,
            publicTransportType: form.publicTransportType,
            receiptNo: $filter('uppercase')(form.receiptNo),
            grossAmount: get2Float(form.grossAmount),
            gstType: DataGST.getGSTType(),
            gstAmount: get2Float(form.gstAmount),
            nettAmount: get2Float(form.nettAmount),
            corporateCard: form.corporateCard,
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        var form = getForm();
        form.departDate = currItem.departDate;
        form.returnDate = currItem.returnDate;
        form.departTime = currItem.departTime;
        form.returnTime = currItem.returnTime;
        form.destinationFrom = currItem.destinationFrom;
        form.destinationTo = currItem.destinationTo;
        form.description = currItem.description;
        form.publicTransportType = currItem.publicTransportType;
        form.receiptNo = currItem.receiptNo;
        form.grossAmount = currItem.grossAmount;
        form.gstAmount = currItem.gstAmount;
        form.nettAmount = currItem.nettAmount;
        form.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        DataGST.setGSTType(currItem.gstType);
    };

    var resetForm = function(){

    };

    var changeItemVal = function(objName, newValue) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            if (currItem) {
                currItem[objName] = newValue;
                if (objName == 'departDate') {
                    currItem.departDateTxt = getDateStr($filter, form.departDate);
                }else if (objName == 'returnDate') {
                    currItem.returnDateTxt = getDateStr($filter, form.returnDate);
                }else if (objName == 'departTime') {
                    currItem.departTimeTxt = getTimeStr(form.departTime);
                }else if (objName == 'returnTime') {
                    currItem.returnTimeTxt = getTimeStr(form.returnTime);
                }
            }
        }
    };
    
    var getForm = function(){
        return $scope.publicTransportForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormPublicTransport.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var currSection = DataFormPublicTransport.getCurrSection();
        var obj = getTrip('publicTransportItems');

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    $scope.openModal = function(section, mode){
        DataFormPublicTransport.setCurrSection(section);
        $('#publicTransport'+section+'ModalForm').modal('show');
        var form = getForm();
        if (mode == 'newForm') {
            form.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            form.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormPublicTransport.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var form = getForm();
        form.isEditMode = true;
        form.currIndex = index;
        form.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        var form = getForm();
        if (items.length > 0) {
            if (form.directIndex == items.length) {
                form.directIndex = items.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                setForm(items[form.directIndex]);
                form.currIndex = form.directIndex;
                form.isEditMode = true;
            }else if (direct == 'next' && !(form.directIndex >= items.length-1)) {
                form.directIndex++;
                setForm(items[form.directIndex]);
                form.currIndex = form.directIndex;
                form.isEditMode = true;
            }
        }
    };

    /* Start : Calculation */
        var calculateNettAmount = function(){
            var form = getForm();
            var amountOri = form.grossAmount;
            var amountGST = calculateGSTAmount(amountOri);
            var amountFinal = parseFloat(amountOri) + parseFloat(amountGST);
            
            form.gstAmount = get2Float(amountGST);
            form.nettAmount = get2Float(amountFinal);
            calculateGrandTotal();
            changeItemVal('nettAmount', get2Float(amountFinal));
        };

        var calculateGSTAmount = function(oriAmount){
            return get2Float((parseFloat(oriAmount) * parseFloat(DataGST.getGSTFloat())));
        };

        var calculateGrandTotal = function () {
            var trip = getTrip('publicTransport');
            var items = getTrip('publicTransportItems');
            
            if (items) {
                var grandTotalNettAmount = getListTotalAmount(items, 'nettAmount');
                
                trip['grandTotalGrossAmount'] = get2Float(getListTotalAmount(items, 'grossAmount'));
                trip['grandTotalGSTAmount'] = get2Float(getListTotalAmount(items, 'gstAmount'));
                trip['grandTotalNettAmount'] = get2Float(grandTotalNettAmount);
                DataFormPublicTransport.setGrandTotal(grandTotalNettAmount);
            }
        };
    /* End : Calculation */

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('fundType', newValue);};
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('projectCode', newValue);};
    });

    $scope.$watch(function () { return DataGST.getGSTType(); }, function (newValue, oldValue) {
        if (newValue != oldValue && newValue) {
            changeItemVal('gstType', newValue);
            calculateNettAmount();
        }
    });
    /*
    $scope.$watch('publicTransportItems', function() {
        DataFormPublicTransport.setPublicTransportItems($scope.publicTransportItems);
    }, true);

    $scope.$watch('publicTransportSTItems', function() {
        DataFormPublicTransport.setPublicTransportSTItems($scope.publicTransportSTItems);
    }, true);*/
});

uiBootstrapApp.factory('DataFormPublicTransport', function ($filter) {
    var data = {
        CurrSection: '',
        PublicTransportItems: [],
        PublicTransportSTItems: [],
        GrandTotalOD: get2Float(0),
        GrandTotalST: get2Float(0),
        ODDBItems: [],
        STDBItems: []
    };

    return {
        getCurrSection: function () {
            return data.CurrSection;
        },
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getPublicTransportItems: function () {
            return data.PublicTransportItems;
        },
        setPublicTransportItems: function (obj) {
            data.PublicTransportItems = obj;
        },
        getPublicTransportSTItems: function () {
            return data.PublicTransportSTItems;
        },
        setPublicTransportSTItems: function (obj) {
            data.PublicTransportSTItems = obj;
        },
        getGrandTotalOD: function(){
            return data.GrandTotalOD;
        },
        getGrandTotalST: function(){
            return data.GrandTotalST;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'OD') {
                data.GrandTotalOD = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            }
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        }
    };
});

uiBootstrapApp.controller('HotelCtrl', function($scope, $filter, DataFundType, DataLookup, DataGST,
                                                DataFormHotel, DataFormSubsis, DataFormMain){

    $scope.initLoad = function(section){
        setEmptyTable();
        if (section == 'OD') {
            $scope.$watch(function () { return DataFormHotel.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormHotel.setCurrSection('OD');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var form = getForm();
            var toWatchItems = [
                                'checkinDate', 'checkoutDate', 'regionDestination', 'description',
                                'receiptNo', 'roomPrice', 'serviceCharge', 'corporateCard'
                            ];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'corporateCard') {
                    form[objToWatch] = false;
                }else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('hotelForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'checkinDate' || objToWatch == 'checkoutDate') {
                            calculateDiffDate(form.checkinDate, form.checkoutDate);
                        }
                        else if (objToWatch == 'roomPrice' || objToWatch == 'regionDestination') {
                            validateHotelMaxLimit();
                        }
                        else if (objToWatch == 'roomPrice' || objToWatch == 'serviceCharge') {
                            calculateAll();
                        }
                        
                        // Set value
                        if (objToWatch == 'roomPrice' || objToWatch == 'serviceCharge') {
                            changeItemVal(objToWatch, get2Float(newVal));
                        }else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
            
        }else if (section == 'ST') {
            $scope.$watch(function () { return DataFormHotel.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormHotel.setCurrSection('ST');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
        }else if (section == 'LT') {
            //$scope.hotelLTItems = [];
        }
    };
    
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openCheckinDate = function($event) {
        $scope.statusCheckinDate.opened = true;
    };
    $scope.openCheckoutDate = function($event) {
        $scope.statusCheckoutDate.opened = true;
    };

    $scope.statusCheckinDate = {
        opened: false
    };
    $scope.statusCheckoutDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('#hotelODModalForm, #hotelLTModalForm, #hotelSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.checkinDate = getDateFromStr(objDB.check_in_date);
            form.checkoutDate = getDateFromStr(objDB.check_out_date);
            form.regionDestination = $scope.getRegionByCode(objDB.region_destination);
            form.description = objDB.travelling_info;
            form.receiptNo = objDB.receipt_no;
            form.roomPrice = objDB.room_price;
            form.serviceCharge = objDB.service_charge;
            form.totalRoomPrice = objDB.perday_amount;
            form.totalDays = objDB.int_days;
            form.grossAmount = objDB.amount;
            form.nettAmount = objDB.nett_amount;
            form.gstAmount = objDB.gst_amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
        }
        return {
            checkinDate: form.checkinDate, checkinDateTxt: getDateStr($filter, form.checkinDate),
            checkoutDate: form.checkoutDate, checkoutDateTxt: getDateStr($filter, form.checkoutDate),
            description: form.description,
            regionDestination: form.regionDestination,
            receiptNo: $filter('uppercase')(form.receiptNo),
            roomPrice: get2Float(form.roomPrice), serviceCharge: get2Float(form.serviceCharge),
            totalRoomPrice: get2Float(form.totalRoomPrice), totalDays: getNumber(form.totalDays),
            grossAmount: get2Float(form.grossAmount),
            gstAmount: get2Float(form.gstAmount),
            nettAmount: get2Float(form.nettAmount),
            corporateCard: form.corporateCard,
            fundType: DataFundType.getFundType(), projectCode: DataLookup.getProjectCode(),
            gstType: DataGST.getGSTType()
        };
    };

    var setForm = function(currItem){
        var form = getForm();
        form.checkinDate = currItem.checkinDate;
        form.checkoutDate = currItem.checkoutDate;
        form.description = currItem.description;
        form.regionDestination = currItem.regionDestination;
        form.receiptNo = currItem.receiptNo;
        form.roomPrice = currItem.roomPrice;
        form.serviceCharge = currItem.serviceCharge;
        form.totalDays = currItem.totalDays;
        form.totalRoomPrice = currItem.totalRoomPrice;
        form.grossAmount = currItem.grossAmount;
        form.gstAmount = currItem.gstAmount;
        form.nettAmount = currItem.nettAmount;
        form.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        DataGST.setGSTType(currItem.gstType);
    };

    var resetForm = function(){
        // Reset form
        //$scope.hotelLTItems = [];
    };
    
    var getForm = function(objName){
        var form = $scope.hotelForm;
        if (objName) {
            form = form[objName];
        }
        return form;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormHotel.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var obj = getTrip('hotelItems');

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(objName, newValue) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            if (currItem) {
                currItem[objName] = newValue;
                if (objName == 'checkinDate') {
                    currItem.checkinDateTxt = getDateStr($filter, form.checkinDate);
                }else if (objName == 'checkoutDate') {
                    currItem.checkoutDateTxt = getDateStr($filter, form.checkoutDate);
                }
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormHotel.setCurrSection(section);
        $('#hotel'+section+'ModalForm').modal('show');
        var form = getForm();
        if (mode == 'newForm') {
            form.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            form.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateAll();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormHotel.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var currItems = [];

        currItems = getItems();

        currItems.splice(index, 1); //remove the object from the array based on index
        if (currItems.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var form = getForm();
        form.currIndex = index;
        form.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            var form = getForm();
            if (form.directIndex == items.length) {
                form.directIndex = items.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                setForm(getItems(form.directIndex));
                form.currIndex = form.directIndex;
            }else if (direct == 'next' && !(form.directIndex >= items.length-1)) {
                form.directIndex++;
                setForm(getItems(form.directIndex));
                form.currIndex = form.directIndex;
            }
        }
    };

    /* Calculation */
        var calculateDiffDate = function(dateStart, dateEnd){
            var totalDays = 0;
            if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
                totalDays = getNightDiffDate(dateStart, dateEnd);
                var form = getForm();
                form.totalDays = totalDays;
                changeItemVal('totalDays', totalDays);
                calculateAll();
            }
        };
    
        var calculateAll = function() {
            var form = getForm();
            var roomPrice = get2Float(form.roomPrice);
            var serviceCharge = get2Float(form.serviceCharge);
            var totalAmountPerday = parseFloat(roomPrice) + parseFloat(serviceCharge);
            var totalDays = getNumber(form.totalDays);
            var totalAmountExclusive = totalAmountPerday * parseFloat(totalDays);
            var gstAmount = parseFloat(totalAmountExclusive) * parseFloat(DataGST.getGSTFloat());
            var totalAmountInclusive = parseFloat(totalAmountExclusive) + parseFloat(gstAmount);

            form.totalRoomPrice = get2Float(totalAmountPerday);
            form.grossAmount = get2Float(totalAmountExclusive);
            form.gstAmount = get2Float(gstAmount);
            form.nettAmount = get2Float(totalAmountInclusive);
            changeItemVal('totalRoomPrice', get2Float(totalAmountPerday));
            changeItemVal('grossAmount', get2Float(totalAmountExclusive));
            changeItemVal('gstAmount', get2Float(gstAmount));
            changeItemVal('nettAmount', get2Float(totalAmountInclusive));

            calculateGrandTotal();
        };

        var calculateGrandTotal = function() {
            var trip = getTrip('hotel');
            var items = getTrip('hotelItems');
            if (items) {
                var grandTotalGrossAmount = getListTotalAmount(items, 'grossAmount');
                trip['grandTotalGrossAmount'] = grandTotalGrossAmount;
                trip['grandTotalGSTAmount'] = getListTotalAmount(items, 'gstAmount');
                trip['grandTotalNettAmount'] = getListTotalAmount(items, 'nettAmount');
                DataFormHotel.setGrandTotal(grandTotalGrossAmount);
            }
        };
    /* Calculation */
    
    /* Validation */
        var validateHotelMaxLimit = function(){
            var form = getForm();
            var regionDestination = form.regionDestination;
            if (regionDestination) {
                var maxHotelRate = $scope.getRate('offduty_trip', regionDestination.code, 'hotel');
                var currRate = form.roomPrice;
                if (parseFloat(currRate) > parseFloat(maxHotelRate)) {
                    form.roomPrice = get2Float(maxHotelRate);
                }
            }
        };
    /* Validation */
    
    $scope.$watch(function () { return DataGST.getGSTType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('gstType', newValue);
            calculateAll();
        }
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('fundType', newValue);}
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('projectCode', newValue);}
    });
});

uiBootstrapApp.factory('DataFormHotel', function ($filter) {
    var data = {
        CurrSection: '',
        ProjectCode: '',
        GrandTotalOD: get2Float(0),
        GrandTotalLT: get2Float(0),
        GrandTotalST: get2Float(0),
        ODDBItems: [],
        STDBItems: []
    };

    return {
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getCurrSection: function () {
            return data.CurrSection;
        },
        getGrandTotalOD: function(){
            return data.GrandTotalOD;
        },
        getGrandTotalLT: function(){
            return data.GrandTotalLT;
        },
        getGrandTotalST: function(){
            return data.GrandTotalST;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'OD') {
                data.GrandTotalOD = val;
            }else if (data.CurrSection == 'LT') {
                data.GrandTotalLT = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            };
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        }
    };
});

uiBootstrapApp.controller('LodgingCtrl', function($scope, $filter, DataFundType, DataLookup,
                                                  DataGST, DataFormLodging, DataFormSubsis, DataFormMain){

    $scope.initLoad = function(section){
        setEmptyTable();
        if (section == 'OD') {
            $scope.$watch(function () { return DataFormLodging.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormLodging.setCurrSection('OD');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var form = getForm();
            var toWatchItems = [
                                'checkinDate', 'checkoutDate', 'regionDestination', 'description',
                                'lodgingAddress'
                            ];
            
            toWatchItems.forEach(function(objToWatch){
                form[objToWatch] = '';
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('lodgingForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'checkinDate' || objToWatch == 'checkoutDate') {
                            calculateDiffDate(form.checkinDate, form.checkoutDate);
                            calculateTotalLodgingAmount();
                        }
                        else if (objToWatch == 'regionDestination') {
                            calculateTotalLodgingAmount();
                        }
                        
                        // Set value
                        changeItemVal(objToWatch, newVal);
                    }
                });
            });
        }else if (section == 'ST') {
            $scope.$watch(function () { return DataFormLodging.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormLodging.setCurrSection('ST');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
        }else if (section == 'LT') {
            //$scope.lodgingLTItems = [];
        }
    };
    
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openCheckinDate = function($event) {
        $scope.statusCheckinDate.opened = true;
    };
    $scope.openCheckoutDate = function($event) {
        $scope.statusCheckoutDate.opened = true;
    };

    $scope.statusCheckinDate = {
        opened: false
    };
    $scope.statusCheckoutDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('#lodgingODModalForm, #lodgingLTModalForm, #lodgingSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.checkinDate = getDateFromStr(objDB.check_in_date);
            form.checkoutDate = getDateFromStr(objDB.check_out_date);
            form.regionDestination = $scope.getRegionByCode(objDB.region_destination);
            form.description = objDB.travelling_info;
            form.lodgingAddress = objDB.address;
            form.totalDays = objDB.int_days;
            form.grossAmount = objDB.amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            checkinDate: form.checkinDate, checkinDateTxt: getDateStr($filter, form.checkinDate),
            checkoutDate: form.checkoutDate, checkoutDateTxt: getDateStr($filter, form.checkoutDate),
            regionDestination: form.regionDestination,
            description: form.description,
            lodgingAddress: form.lodgingAddress,
            totalDays: getNumber(form.totalDays),
            grossAmount: get2Float(form.grossAmount),
            lodgingFundType: DataFundType.getFundType(), lodgingProjectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        var form = getForm();
        form.checkinDate = currItem.checkinDate;
        form.checkoutDate = currItem.checkoutDate;
        form.regionDestination = currItem.regionDestination;
        form.description = currItem.description;
        form.lodgingAddress = currItem.lodgingAddress;
        form.totalDays = currItem.totalDays;
        form.grossAmount = currItem.grossAmount;
        DataFundType.setFundType(currItem.lodgingFundType);
        DataLookup.setProjectCode(currItem.lodgingProjectCode);
    };

    var resetForm = function(){
        // Reset form
    };
    
    var getForm = function(){
        return $scope.lodgingForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormLodging.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var obj = getTrip('lodgingItems');
        
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(objName, newValue) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            if (currItem) {
                currItem[objName] = newValue;
                if (objName == 'checkinDate') {
                    currItem.checkinDateTxt = getDateStr($filter, form.checkinDate);
                }else if (objName == 'checkoutDate') {
                    currItem.checkoutDateTxt = getDateStr($filter, form.checkoutDate);
                }
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormLodging.setCurrSection(section);
        $('#lodging'+section+'ModalForm').modal('show');
        var form = getForm();
        if (mode == 'newForm') {
            form.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            form.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormLodging.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var currItems = getItems();
        currItems.splice(index, 1); //remove the object from the array based on index
        if (currItems.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var form = getForm();
        form.currIndex = index;
        form.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'previous' or 'next' */
        var currItem = '';
        var items = getItems();
        var form = getForm();
        if (items.length > 0) {
            if (form.directIndex == items.length) {
                form.directIndex = items.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                currItem = getItems(form.directIndex);
                setForm(currItem);
                form.currIndex = form.directIndex;
            }else if (direct == 'next' && !(form.directIndex >= items.length-1)) {
                form.directIndex++;
                currItem = getItems(form.directIndex);
                setForm(currItem);
                form.currIndex = form.directIndex;
            }
        }
    };

    /** Calculation */
        var getLodgingRate = function(regionDestination){
            return $scope.getRate('offduty_trip', regionDestination.code, 'lodging');
        };
        
        var calculateDiffDate = function(dateStart, dateEnd){
            var totalDays = 0;
            if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
                totalDays = getNightDiffDate(dateStart, dateEnd);
                var form = getForm();
                form.totalDays = totalDays;
                changeItemVal('totalDays', totalDays);
                calculateTotalLodgingAmount();
            }
        };

        var calculateTotalLodgingAmount = function(){
            var form = getForm();
            if (form.regionDestination) {
                var regionDestination = form.regionDestination;
                var lodgingRate = getLodgingRate(regionDestination);
                var totalDays = get2Float(form.totalDays);
                var grossAmount = parseFloat(lodgingRate) * parseFloat(totalDays);
                form.grossAmount = get2Float(grossAmount);
                changeItemVal('grossAmount', get2Float(grossAmount));
                calculateGrandTotal();
            }
        };

        var calculateGrandTotal = function () {
            var trip = getTrip('lodging');
            var items = getTrip('lodgingItems');
            
            if (items) {
                var grandTotalGrossAmount = getListTotalAmount(items, 'grossAmount');
                trip['grandTotalGrossAmount'] = grandTotalGrossAmount;
                DataFormLodging.setGrandTotal(grandTotalGrossAmount);
            }
        };
    /** Calculation */

    $scope.$watch(function () { return DataFundType.getFundType();}, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('lodgingFundType', newValue);}
    });

    $scope.$watch(function () { return DataLookup.getProjectCode();}, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('lodgingProjectCode', newValue);}
    });
});

uiBootstrapApp.factory('DataFormLodging', function ($filter) {
    var data = {
        CurrSection: '',
        GrandTotalOD: get2Float(0),
        GrandTotalLT: get2Float(0),
        GrandTotalST: get2Float(0),
        ODDBItems: [],
        STDBItems: []
    };

    return {
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getCurrSection: function () {
            return data.CurrSection;
        },
        getGrandTotalOD: function(){
            return data.GrandTotalOD;
        },
        getGrandTotalLT: function(){
            return data.GrandTotalLT;
        },
        getGrandTotalST: function(){
            return data.GrandTotalLT;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'OD') {
                data.GrandTotalOD = val;
            }else if (data.CurrSection == 'LT') {
                data.GrandTotalLT = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            };
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        }
    };
});

uiBootstrapApp.controller('MealCtrl', ['$scope', '$filter', '$uibModal', 'DataFundType', 'DataLookup',
                                       'DataFormMeal', 'DataFormSubsis', 'DataFormMain'
                        , function($scope, $filter, $uibModal, DataFundType, DataLookup,
                                   DataFormMeal, DataFormSubsis, DataFormMain){

    $scope.initLoad = function(section){
        setEmptyTable();
        if (section == 'OD') {
            var form = getForm();
            $scope.$watch(function () { return DataFormMeal.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMeal.setCurrSection('OD');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var toWatchItems = [
                                'departDate', 'departTime', 'returnDate', 'returnTime',
                                'regionDestination', 'description', 'chkDistribution', 'mealDistribution',
                                'mealRate', 'intMeal', 'intDaily', 'dailyAmount', 'mealAmount'
                            ];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                    form[objToWatch] = initTime;
                }
                else if (objToWatch == 'mealDistribution') {
                    form[objToWatch] = [];
                }
                else if (objToWatch == 'chkDistribution') {
                    form[objToWatch] = false;
                }
                else if (objToWatch == 'mealRate') {
                    form[objToWatch] = get2Float(0);
                }
                else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('mealForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'departDate' || objToWatch == 'returnDate') {
                            calculateIntMealDaily(form.departDate, form.departTime, form.returnDate, form.returnTime);
                        }
                        else if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                            $scope.forceValidTime(form, objToWatch);
                            calculateIntMealDaily(form.departDate, form.departTime, form.returnDate, form.returnTime);
                        }else if (objToWatch == 'regionDestination') {
                            calculateMealDailyAmount();
                        }
                        
                        // Set value
                        if (objToWatch == 'intMeal' || objToWatch == 'intDaily') {
                            changeItemVal(objToWatch, getNumber(newVal));
                        }
                        else if (objToWatch == 'dailyAmount' || objToWatch == 'mealAmount') {
                            changeItemVal(objToWatch, get2Float(newVal));
                            calculateGrandTotal();
                        }
                        else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
            
        }
        else if (section == 'ST') {
            $scope.$watch(function () { return DataFormMeal.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMeal.setCurrSection('ST');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
        }
        else if (section == 'LT') {
            //$scope.mealLTItems = [];
        }
    };
    
    /** Date : Start */
    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    /** Time : Start */
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.departTime = initTime;
    $scope.returnTime = initTime;
    /** Time : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('#mealODModalForm, #mealLTModalForm, #mealSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var resetForm = function(){
        var form = $scope.mealForm;
        form.chkDistribution = false;
        form.mealDistribution = [];
    };

    var setForm = function(currItem){
        var form = $scope.mealForm;
        form.chkDistribution = currItem.chkDistribution;
        form.departDate = currItem.departDate;
        form.returnDate = currItem.returnDate;
        form.departTime = currItem.departTime;
        form.returnTime = currItem.returnTime;
        form.regionDestination = currItem.regionDestination;
        form.description = currItem.description;
        form.chkDistribution = currItem.chkDistribution;
        form.mealDistribution = currItem.mealDistribution;
        form.intMeal = currItem.intMeal;
        form.intDaily = currItem.intDaily;
        form.mealAmount = currItem.mealAmount;
        form.dailyAmount = currItem.dailyAmount;
        form.grossAmount = currItem.grossAmount;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        getMealRate(currItem.regionDestination);
    };

    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.departDate = getDateFromStr(objDB.depart_date);
            form.returnDate = getDateFromStr(objDB.return_date);
            form.departTime = getTimeFromStr(objDB.depart_time);
            form.returnTime = getTimeFromStr(objDB.return_time);
            form.regionDestination = $scope.getRegionByCode(objDB.region_destination);
            form.description = objDB.travelling_info;
            form.chkDistribution = objDB.chk_meal_distribution;
            form.mealDistribution = DataFormMeal.getDBDistributionByParentID(objDB.id);
            form.intMeal = objDB.int_meal_allowance;
            form.intDaily = objDB.int_daily_allowance;
            form.mealAmount = objDB.meal_amount;
            form.dailyAmount = objDB.daily_amount;
            form.grossAmount = objDB.amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            departDate: form.departDate, departDateTxt: getDateStr($filter, form.departDate),
            returnDate: form.returnDate, returnDateTxt: getDateStr($filter, form.returnDate),
            departTime: form.departTime, departTimeTxt: getTimeStr(form.departTime),
            returnTime: form.returnTime, returnTimeTxt: getTimeStr(form.returnTime),
            regionDestination: form.regionDestination, description: form.description,
            chkDistribution: form.chkDistribution, mealDistribution: form.mealDistribution,
            intMeal: getNumber(form.intMeal), intDaily: getNumber(form.intDaily),
            mealAmount: get2Float(form.mealAmount),
            dailyAmount: get2Float(form.dailyAmount),
            grossAmount: get2Float(form.grossAmount),
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setEditMode = function(itemIndex){
        setForm(getItems(itemIndex));
        var form = $scope.mealForm;
        form.currIndex = itemIndex;
        form.directIndex = itemIndex;
        form.isEditMode = true;
    };
    
    var getForm = function(){
        return $scope.mealForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormMeal.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var currSection = DataFormMeal.getCurrSection();
        var obj = getTrip('mealItems');
        
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(objName, newValue) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            
            if (currItem) {
                currItem[objName] = newValue;
                if (objName == 'departDate' || objName == 'returnDate') {
                    currItem.departDateTxt = getDateStr($filter, form.departDate);
                    currItem.returnDateTxt = getDateStr($filter, form.returnDate);
                }else if (objName == 'departTime' || objName == 'returnTime') {
                    currItem.departTimeTxt = getTimeStr(form.departTime);
                    currItem.returnTimeTxt = getTimeStr(form.returnTime);
                }
            }
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        resetForm();
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormMeal.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var list = [];
        list = getItems();

        list.splice(index, 1); //remove the object from the array based on index
        if (list.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.openModal(section, 'editForm');
        setEditMode(index);
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var list = getItems();
        var form = getForm();
        if (list.length > 0) {
            if (form.directIndex == list.length) {
                form.directIndex = list.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                setEditMode(form.directIndex);
            }else if (direct == 'next' && !(form.directIndex >= list.length-1)) {
                form.directIndex++;
                setEditMode(form.directIndex);
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormMeal.setCurrSection(section);
        $('#meal'+section+'ModalForm').modal('show');
        var form = getForm();
        if (mode == 'newForm') {
            form.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            DataFormMeal.setIsNewMealLTItems(false);
            form.isEditMode = true;
        }
    };

    $scope.openModalMealDistribution = function (section, itemIndex) {
        var form = getForm();
        var departDate = form.departDate;
        var returnDate = form.returnDate;
        var chkDistribution = form.chkDistribution;
        var mealDistribution = form.mealDistribution;
        var mealRate = form.mealRate;

        if (itemIndex != undefined) {
            DataFormMeal.setCurrSection(section);
            mealRate = getMealRate(getItems(itemIndex).regionDestination);
            chkDistribution = getItems(itemIndex).chkDistribution;
            mealDistribution = getItems(itemIndex).mealDistribution;
        }

        $scope.animationsEnabled = true;
        instance_controller = 'ModalMealDistributionCtrl';
        ng_template = 'MealDistribution.html';
        if (chkDistribution) {
            if (angular.isDate(departDate) && angular.isDate(returnDate) && form.regionDestination) {
                var dataModal = {dateFrom: departDate, dateTo: returnDate, mealRate: mealRate, mealDistribution: mealDistribution};
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: ng_template,
                    controller: instance_controller,
                    size: '',
                    resolve: {
                        data: function () {
                            return dataModal;
                        }
                    }
                });

                modalInstance.result.then(
                    function (returnData) {
                        console.log('OK, box closed');
                        var mealDistribution = returnData.mealDistribution;
                        var mealAmount = get2Float(returnData.totalMealAmount);
                        form.mealDistribution = mealDistribution;
                        form.mealAmount = get2Float(mealAmount);
                        form.dailyAmount = get2Float(0);
                        form.intMeal = 0;
                        form.intDaily = 0;
                        
                        if (itemIndex != undefined) {
                            form.currIndex = itemIndex;
                            form.isEditMode = true;
                        }
                            
                        changeItemVal('chkDistribution', chkDistribution);
                        changeItemVal('mealDistribution', mealDistribution);
                        changeItemVal('mealAmount', get2Float(mealAmount));
                        changeItemVal('dailyAmount', get2Float(0));
                        changeItemVal('grossAmount', get2Float(mealAmount));
                        changeItemVal('intMeal', 0);
                        changeItemVal('intDaily', 0);
                    },
                    function () {
                        console.log('Cancel, box closed');
                    }
                );
            }
        }else{
            // Reset amount based on selected Date & Time.
            //calculateIntMeal(departDate, returnDate);
            //calculateIntDaily(form.departTime, form.returnTime);
            calculateIntMealDaily(departDate, form.departTime, returnDate, form.returnTime);
        }
    };

    /* Calculation */
        var getMealRate = function(regionDestination){
            var currSection = DataFormMeal.getCurrSection();
            var rate = 0;
            
            if (regionDestination) {
                if (currSection == 'OD') {
                    rate = $scope.getRate('offduty_trip', regionDestination.code, 'meal');
                }else{
                    rate = $scope.getRate('course_trip', regionDestination.code, 'meal');
                }
            }
            var form = getForm();
            form.mealRate = get2Float(rate);
            return rate;
        };
        
        var calculateIntMealDaily = function(dateStart, timeStart, dateEnd, timeEnd){
            // Combined Date & Time.
            var intMeal = 0;
            var intDaily = 0;
            if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
                var hours = getDateDiff(combineDateTime(dateStart, timeStart),
                                       combineDateTime(dateEnd, timeEnd));
                if (hours >= 24) {
                    var days = hours / 24; // Convert hours to day
                    if (days > 0) {
                        intMeal = getNumber(days);
                        balanceDay = days - intMeal;
                        balanceHours = balanceDay * 24;
                        if (balanceHours >= 8) {
                            intDaily = 1;
                        }
                    }
                }else{
                    if (hours >= 8) {
                        intDaily = 1;
                    }
                }
                var form = getForm();
                form.intMeal = intMeal;
                form.intDaily = intDaily;
                calculateMealDailyAmount();
            }
        };
        
        var calculateMealDailyAmount = function(){
            var form = getForm();
            if (!form.chkDistribution) {
                var rate = getMealRate(form.regionDestination);
                var intMeal = getNumber(form.intMeal);
                var intDaily = getNumber(form.intDaily);
                var mealAmount = 0;
                var dailyAmount = 0;
                var grossAmount = 0;
                
                mealAmount = parseFloat(rate) * parseFloat(intMeal);
                dailyAmount = parseFloat(rate) * 0.5 * parseFloat(intDaily);
                grossAmount = mealAmount + dailyAmount;
                
                form.mealAmount = get2Float(mealAmount);
                form.dailyAmount = get2Float(dailyAmount);
                form.grossAmount = get2Float(grossAmount);
                changeItemVal('mealAmount', get2Float(mealAmount));
                changeItemVal('dailyAmount', get2Float(dailyAmount));
                changeItemVal('grossAmount', get2Float(grossAmount));
                calculateGrandTotal();
            }
        };
        
        var calculateGrandTotal = function (){
            var trip = getTrip('meal');
            var items = getTrip('mealItems');
            if (items) {
                trip['grandTotalMealAmount'] = getListTotalAmount(items, 'mealAmount');
                trip['grandTotalDailyAmount'] = getListTotalAmount(items, 'dailyAmount');
                var grandTotalGrossAmount = getListTotalAmount(items, 'grossAmount');
                trip['grandTotalGrossAmount'] = grandTotalGrossAmount;
                DataFormMeal.setGrandTotal(grandTotalGrossAmount);
            }
        };
    /** Calculation */
    
    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('fundType', newValue);
        }
    });

}]);

uiBootstrapApp.controller('ModalMealDistributionCtrl', ['$scope', '$filter', '$modalInstance', 'data', function ($scope, $filter, $uibModalInstance, data) {

    /* Start : General Config for Table */
        $scope.pageSize = 5;
        $scope.currentPage = 1;
    /* End : General Config for Table */

    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var mealRate = parseFloat(data.mealRate);
    var mealDistribution = data.mealDistribution;

    var breakfastRate = mealRate * (20/100);
    var lunchRate = mealRate * (40/100);
    var dinnerRate = mealRate * (40/100);
    var totalAmountBreakfast = 0;
    var totalAmountLunch = 0;
    var totalAmountDinner = 0;
    var totalMealAmount = 0;

    $scope.mealRate = get2Float(mealRate);
    $scope.breakfastRate = get2Float(breakfastRate);
    $scope.lunchRate = get2Float(lunchRate);
    $scope.dinnerRate = get2Float(dinnerRate);

    var generateDays = function (dateFrom, dateTo) {
        var mealDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            mealDistribution.push({date:objMinDate, breakfast:false, lunch:false, dinner:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return mealDistribution;
    };

    if (mealDistribution.length) {
        $scope.mealDistribution = mealDistribution;
    }else{
        $scope.mealDistribution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {totalMealAmount:$scope.totalMealAmount, mealDistribution:$scope.mealDistribution}
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('mealDistribution', function() {
        var totalBreakfast = 0;
        var totalLunch = 0;
        var totalDinner = 0;

        $scope.mealDistribution.forEach(function(obj){
            if(obj.breakfast){
                totalBreakfast++;
            }
            if (obj.lunch) {
                totalLunch++;
            }
            if (obj.dinner) {
                totalDinner++;
            }
        });

        $scope.totalBreakfast = totalBreakfast;
        $scope.totalLunch = totalLunch;
        $scope.totalDinner = totalDinner;
        totalAmountBreakfast = parseFloat(totalBreakfast) * breakfastRate;
        totalAmountLunch = parseFloat(totalLunch) * lunchRate;
        totalAmountDinner = parseFloat(totalDinner) * dinnerRate;
        $scope.totalAmountBreakfast = get2Float(totalAmountBreakfast);
        $scope.totalAmountLunch = get2Float(totalAmountLunch);
        $scope.totalAmountDinner = get2Float(totalAmountDinner);
        totalMealAmount = parseFloat(totalAmountBreakfast) + parseFloat(totalAmountLunch) + parseFloat(totalAmountDinner);
        $scope.totalMealAmount = get2Float(totalMealAmount);
    }, true);
}]);

uiBootstrapApp.factory('DataFormMeal', function ($filter) {
    var data = {
        CurrSection: '',
        MealItems: [],
        MealLTItems: [],
        MealSTItems: [],
        ChkMeal: false,
        IsNewMealLTItems: true,
        GrandTotalOD: get2Float(0),
        GrandTotalLT: get2Float(0),
        GrandTotalST: get2Float(0),
        ODDBItems: [],
        ODDBDistributions: [],
        STDBItems: [],
        STDBDistributions: []
    };

    return {
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getCurrSection: function () {
            return data.CurrSection;
        },
        getMealItems: function () {
            return data.MealItems;
        },
        setMealItems: function (obj) {
            data.MealItems = obj;
        },
        getMealLTItems: function () {
            return data.MealLTItems;
        },
        setMealLTItems: function (obj) {
            data.MealLTItems = obj;
        },
        getIsNewMealLTItems: function () {
            return data.IsNewMealLTItems;
        },
        setIsNewMealLTItems: function (val) {
            data.IsNewMealLTItems = val;
        },
        getChkMeal: function () {
            return data.ChkMeal;
        },
        setChkMeal: function (obj) {
            data.ChkMeal = obj;
        },
        getMealSTItems: function () {
            return data.MealSTItems;
        },
        setMealSTItems: function (obj) {
            data.MealSTItems = obj;
        },
        getGrandTotalOD: function(){
            return data.GrandTotalOD;
        },
        getGrandTotalLT: function(){
            return data.GrandTotalLT;
        },
        getGrandTotalST: function(){
            return data.GrandTotalST;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'OD') {
                data.GrandTotalOD = val;
            }else if (data.CurrSection == 'LT') {
                data.GrandTotalLT = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            };
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        setODDBDistributions: function(obj){
            data.ODDBDistributions = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        },
        setSTDBDistributions: function(obj){
            data.STDBDistributions = obj;
        },
        getDBDistributionByParentID: function(parentID){
            var distribution = [];
            var source = [];

            if (data.CurrSection == 'OD') {
                source = data.ODDBDistributions;
            }else if (data.CurrSection == 'ST') {
                source = data.STDBDistributions;
            }
            source.forEach(function(obj){
                if (parentID == obj.meal_item_id) {
                    distribution.push({date: getDateStr($filter, obj.date), breakfast: obj.breakfast
                                      , lunch: obj.lunch, dinner: obj.dinner});
                }
            });
            return distribution;
        }
    };
});
/******************** End : Meal & Daily Allowance ********************/


/******************** Start : Misc ********************/
uiBootstrapApp.controller('MiscCtrl', ['$scope', '$http', '$filter', '$uibModal', 'DataFundType'
                        , 'DataLookup', 'DataFormMisc', 'DataFormMain'
                        , function($scope, $http, $filter, $uibModal, DataFundType, DataLookup
                                   , DataFormMisc, DataFormMain){

    $scope.initLoad = function(section) {
        setEmptyTable();
        if (section == 'OD') {
            $scope.$watch(function () { return DataFormMisc.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMisc.setCurrSection('OD');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var form = getForm();
            var toWatchItems = ['date', 'miscType', 'receiptNo', 'grossAmount', 'corporateCard'];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'corporateCard') {
                    form[objToWatch] = false;
                }else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('miscellaneousForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        
                        // Set value
                        if (objToWatch == 'grossAmount') {
                            changeItemVal(objToWatch, get2Float(newVal));
                            calculateGrandTotal();
                        }
                        else if (objToWatch == 'receiptNo') {
                            changeItemVal(objToWatch, $filter('uppercase')(newVal));
                        }
                        else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
        };

        if (section == 'LT') {
            $scope.$watch(function () { return DataFormMisc.getLTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMisc.setCurrSection('LT');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
        };

        if (section == 'ST') {
            $scope.$watch(function () { return DataFormMisc.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormMisc.setCurrSection('ST');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
        };
    };
    
    /** Date : Start */
    $scope.openDate = function($event) {
        $scope.statusDate.opened = true;
    };
    
    $scope.statusDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('#miscODModalForm, #miscLTModalForm, #miscSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var setEmptyTable = function() {
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var resetForm = function() {
        var form = getForm();
        form.date = '';
        form.miscType = '';
        form.receiptNo = '';
        form.grossAmount = '';
        form.corporateCard = false;
        DataFundType.setFundType('');
    };

    var setForm = function(currItem) {
        var form = getForm();
        form.date = currItem.date;
        form.miscType = currItem.miscType;
        form.receiptNo = $filter('uppercase')(currItem.receiptNo);
        form.grossAmount = get2Float(currItem.grossAmount);
        form.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var setRow = function(objDB) {
        var form = getForm();
        if (objDB) {
            form.date = getDateFromStr(objDB.date);
            form.miscType = $scope.getMiscExpensesByCode(objDB.type);
            form.receiptNo = objDB.receipt_no;
            form.grossAmount = objDB.amount;
            form.corporateCard = objDB.corporate_card;
            DataLookup.setProjectCode(objDB.project_code);
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            date: form.date, dateTxt: getDateStr($filter, form.date),
            miscType: form.miscType, receiptNo: $filter('uppercase')(form.receiptNo),
            grossAmount: get2Float(form.grossAmount), corporateCard: form.corporateCard,
            fundType: DataFundType.getFundType(), projectCode: DataLookup.getProjectCode()
        };
    };

    var setEditMode = function(itemIndex) {
        var form = getForm();
        setForm(getItems(itemIndex));
        form.currIndex = itemIndex;
        form.directIndex = itemIndex;
        form.isEditMode = true;
    };
    
    var getForm = function(){
        return $scope.miscellaneousForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormMisc.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var obj = getTrip('miscellaneousItems');
        
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(objName, newValue) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            var form = getForm();
            if (currItem) {
                currItem[objName] = newValue;
                if (objName == 'date') {
                    currItem.dateTxt = getDateStr($filter, form.date);
                }
            }
        }
    };

    $scope.addItem = function(objDB) {
        var items = getItems();
        items.push(setRow(objDB));
        resetForm();
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex) {
        DataFormMisc.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var list = getItems();
        list.splice(index, 1); //remove the object from the array based on index
        if (list.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.openModal(section, 'editForm');
        setEditMode(index);
    };

    $scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var form = getForm();
        var currItem = '';
        var list = getItems();

        if (list.length > 0) {
            if (form.directIndex == list.length) {
                form.directIndex = list.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                setEditMode(form.directIndex);
            }else if (direct == 'next' && !(form.directIndex >= list.length-1)) {
                form.directIndex++;
                setEditMode(form.directIndex);
            }
        }
    };

    $scope.openModal = function(section, mode) {
        DataFormMisc.setCurrSection(section);
        $('#misc'+section+'ModalForm').modal('show');
        var form = getForm();
        if (mode == 'newForm') {
            form.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            form.isEditMode = true;
        }
    };

    /* Start : Calculation */
        var calculateGrandTotal = function() {
            var trip = getTrip('miscellaneous');
            var items = getTrip('miscellaneousItems');
            
            if (items) {
                var grandTotalGrossAmount = getListTotalAmount(items, 'grossAmount');
                trip['grandTotalGrossAmount'] = grandTotalGrossAmount;
                DataFormMisc.setGrandTotal(grandTotalGrossAmount);
            }
        };
    /* End : Calculation */

    $scope.$watch(function() { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('fundType', newValue);}
    });

    $scope.$watch(function() { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('projectCode', newValue);}
    });
    /*
    $scope.$watch('miscellaneousItems', function() {
        DataFormMisc.setMiscItems($scope.miscellaneousItems);
    }, true);

    $scope.$watch('miscLTItems', function() {
        DataFormMisc.setMiscLTItems($scope.miscLTItems);
    }, true);

    $scope.$watch('miscSTItems', function() {
        DataFormMisc.setMiscSTItems($scope.miscSTItems);
    }, true);*/
}]);

uiBootstrapApp.factory('DataFormMisc', function($filter) {
    var data = {
        CurrSection: '',
        MiscItems: [],
        MiscLTItems: [],
        MiscSTItems: [],
        GrandTotalOD: get2Float(0),
        GrandTotalLT: get2Float(0),
        GrandTotalST: get2Float(0),
        ODDBItems: [],
        LTDBItems: [],
        STDBItems: []
    };

    return {
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getCurrSection: function () {
            return data.CurrSection;
        },
        getMiscItems: function () {
            return data.MiscItems;
        },
        setMiscItems: function (obj) {
            data.MiscItems = obj;
        },
        getMiscLTItems: function () {
            return data.MiscLTItems;
        },
        setMiscLTItems: function (obj) {
            data.MiscLTItems = obj;
        },
        getMiscSTItems: function () {
            return data.MiscSTItems;
        },
        setMiscSTItems: function (obj) {
            data.MiscSTItems = obj;
        },
        getGrandTotalOD: function(){
            return data.GrandTotalOD;
        },
        getGrandTotalLT: function(){
            return data.GrandTotalLT;
        },
        getGrandTotalST: function(){
            return data.GrandTotalST;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'OD') {
                data.GrandTotalOD = val;
            }else if (data.CurrSection == 'LT') {
                data.GrandTotalLT = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            };
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        getLTDBItems: function(){
            return data.LTDBItems;
        },
        setLTDBItems: function(obj){
            data.LTDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        }
    };
});
/******************** End : Misc ********************/


/******************** Start : Subsistence Meal ********************/
uiBootstrapApp.controller('SubsisCtrl', ['$scope', '$http', '$filter', '$uibModal', 'DataClaimant',
                                         'DataFundType', 'DataLookup', 'DataFormSubsis',
                                         'DataFormHotel', 'DataFormLodging', 'DataFormMeal', 'DataFormMain',
                                         function($scope, $http, $filter, $uibModal, DataClaimant,
                                                  DataFundType, DataLookup, DataFormSubsis,
                                                  DataFormHotel, DataFormLodging, DataFormMeal, DataFormMain){

    $scope.initLoad = function(section){
        setEmptyTable();
        if (section == 'LT') {
            var form = getForm();
            form.displayChkMealAccommodation = true;
            
            $scope.$watch(function () { return DataFormSubsis.getLTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    if (newValue.length > 0) {
                        DataFormSubsis.setCurrSection('LT');
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                    }
                };
            });
            
            var toWatchItems = [
                                'departDate', 'returnDate',
                                'courseLocation', 'chkSubstitute', 'chkOthers',
                                'chkMeal', 'chkHotel', 'chkLodging',
                                'mealSubstitution', 'intDays', 'grossAmount'
                            ];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'chkSubstitute') {
                    form[objToWatch] = false;
                }
                else if (objToWatch == 'mealSubstitution') {
                    form[objToWatch] = [];
                }
                else if (objToWatch == 'grossAmount') {
                    form[objToWatch] = get2Float(0);
                }
                else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('subsisForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'departDate' || objToWatch == 'returnDate') {
                            calculateDiffDays(form.departDate, form.returnDate);
                            calculateSubsistenceAmount();
                        }
                        else if (objToWatch == 'courseLocation') {
                            getRateDailyAllowance(newVal);
                            calculateSubsistenceAmount();
                        }else if (objToWatch == 'chkOthers') {
                            if (!newValue) {
                                form.chkMeal = false;
                                form.chkHotel = false;
                                form.chkLodging = false;
                            }
                        }
                        
                        // Set value
                        if (objToWatch == 'intDays') {
                            changeItemVal(objToWatch, getNumber(newVal));
                        }
                        else if (objToWatch == 'grossAmount') {
                            changeItemVal(objToWatch, get2Float(newVal));
                            calculateGrandTotal();
                        }
                        else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
        }else if (section == 'ST') {/*
            $scope.subsisSTItems = [];
            $scope.$watch(function () { return DataFormSubsis.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    DataFormSubsis.setCurrSection('ST');
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem(obj);
                        });
                        DataFormSubsis.setSubsisSTItems($scope.subsisSTItems);
                    }
                };
            });*/
        };
    };
    
    /** Date : Start */
    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    $('#subsisLTModalForm, #subsisSTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var resetForm = function(){
        var form = getForm();
        form.courseLocation = '';
        //$scope.subsisChkOptions = '';
        form.chkSubstitute = false;
        form.chkOthers = false;
        form.chkHotel = false;
        form.chkLodging = false;
        form.chkMeal = false;
        form.mealSubstitution = [];
        
        /*DataFormHotel.setIsNewHotelLTItems(true);
        DataFormHotel.setHotelLTItems([]);
        DataFormLodging.setIsNewLodgingLTItems(true);
        DataFormLodging.setLodgingLTItems([]);
        DataFormMeal.setIsNewMealLTItems(true);
        DataFormMeal.setMealLTItems([]);*/
    };

    var setEditMode = function(index){
        setForm(getItems(index));
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.isEditMode = true;
    };

    var setForm = function(currItem){
        var form = getForm();
        form.departDate = currItem.departDate;
        form.returnDate = currItem.returnDate;
        form.courseLocation = currItem.courseLocation;
        form.chkSubstitute = currItem.chkSubstitute;
        form.chkOthers = currItem.chkOthers;
        /*if (currItem.chkSubstitute) {
            $scope.subsisChkOptions = 'chkSubstitute';
        }else if (currItem.chkOthers){
            $scope.subsisChkOptions = 'chkOthers';
        }*/
        form.chkHotel = currItem.chkHotel;
        form.chkLodging = currItem.chkLodging;
        form.chkMeal = currItem.chkMeal;

        /*DataFormHotel.setHotelLTItems(currItem.subsisHotelItems);
        DataFormHotel.setIsNewHotelLTItems(false);
        DataFormLodging.setLodgingLTItems(currItem.subsisLodgingItems);
        DataFormLodging.setIsNewLodgingLTItems(false);
        DataFormMeal.setMealLTItems(currItem.subsisMealItems);
        DataFormMeal.setIsNewMealLTItems(false);*/

        form.mealSubstitution = currItem.mealSubstitution;
        form.grossAmount = get2Float(currItem.grossAmount);
        form.mealAmount = get2Float(currItem.mealAmount);
        form.accommodationAmount = get2Float(currItem.accommodationAmount);

        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.departDate = getDateFromStr(objDB.depart_date);
            form.returnDate = getDateFromStr(objDB.return_date);
            form.courseLocation = $scope.getCourseLocationByCode(objDB.course_location);
            form.travellingInfo = objDB.travelling_info;
            form.chkSubstitute = objDB.chk_substitution;
            form.mealSubstitution = DataFormSubsis.getDBDistributionByParentID(objDB.id);
            form.chkMeal = objDB.chk_meal;
            form.chkHotel = objDB.chk_hotel;
            form.chkLodging = objDB.chk_lodging;
            form.totalDays = objDB.int_days;
            if (objDB.chk_meal || objDB.chk_hotel || objDB.chk_lodging) {
                form.chkOthers = true;
            }
            form.grossAmount = objDB.amount;
            form.mealAmount = objDB.meal_amount;
            form.accommodationAmount = objDB.accommodation_amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
            DataLookup.setProjectCode(objDB.project_code);
        }
        return {
            departDate: form.departDate, departDateTxt: getDateStr($filter, form.departDate),
            returnDate: form.returnDate, returnDateTxt: getDateStr($filter, form.returnDate),
            courseLocation: form.courseLocation,
            travellingInfo: form.travellingInfo,
            chkSubstitute: form.chkSubstitute, mealSubstitution: form.mealSubstitution,
            chkOthers: form.chkOthers,
            chkHotel: form.chkHotel, chkLodging: form.chkLodging, chkMeal: form.chkMeal,
            /*subsisHotelItems: angular.copy(DataFormHotel.getHotelLTItems()),
            subsisLodgingItems: angular.copy(DataFormLodging.getLodgingLTItems()),
            subsisMealItems: angular.copy(DataFormMeal.getMealLTItems()),*/
            totalDays: form.totalDays,
            grossAmount: get2Float(form.grossAmount),
            mealAmount: get2Float(form.mealAmount),
            accommodationAmount: get2Float(form.accommodationAmount),
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };
    
    var getForm = function(){
        return $scope.subsisForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormSubsis.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var obj = [];
        obj = getTrip('subsisItems');

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var getItemIndex = function(index) {
        index = index + ($scope.currentPage - 1) * $scope.pageSize;
        return index;
    };

    var changeItemVal = function(objName, newVal) {
        if ($scope.isEditMode) {
            var form = getForm();
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                currItem[objName] = newVal;
                if (objName == 'departDate' || objName == 'returnDate') {
                    currItem.departDateTxt = getDateStr($filter, form.departDate);
                    currItem.returnDateTxt = getDateStr($filter, form.returnDate);
                }
            }
        }
    };

    $scope.addItem = function(objDB){
        getItems().push(setRow(objDB));
        resetForm();
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, index){
        DataFormSubsis.setCurrSection(section);
        index = getItemIndex(index);
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, index){
        index = getItemIndex(index);
        $scope.openModal(section, 'editForm');
        setEditMode(index);
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var list = getItems();

        if (list.length > 0) {
            if ($scope.directIndex == list.length) {
                $scope.directIndex = list.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= list.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormSubsis.setCurrSection(section);
        $('#subsis'+section+'ModalForm').modal('show');

        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.openModalMealSubstitution = function (section, itemIndex) {
        var form = getForm();
        var departDate = form.departDate;
        var returnDate = form.returnDate;
        var chkSubstitute = form.chkSubstitute;
        var mealSubstitution = form.mealSubstitution;
        var dailyAllowanceRate = form.dailyAllowanceRate;
        var courseLocation = form.courseLocation;
        
        if (itemIndex != undefined) {
            DataFormSubsis.setCurrSection(section);
            var item = getItems(itemIndex);
            dailyAllowanceRate = getRateDailyAllowance(item.courseLocation);
            chkSubstitute = item.chkSubstitute;
            mealSubstitution = item.mealSubstitution;
        };

        $scope.animationsEnabled = true;
        instance_controller = 'ModalMealSubstitutionCtrl';
        ng_template = 'MealSubstitution.html';
        if (chkSubstitute) {
            if (angular.isDate(departDate) && angular.isDate(returnDate) && parseFloat(dailyAllowanceRate) > 0) {
                var dataModal = {dateFrom: departDate, dateTo: returnDate, dailyAllowanceRate: dailyAllowanceRate, mealSubstitution: mealSubstitution};
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: ng_template,
                    controller: instance_controller,
                    size: '',
                    resolve: {
                        data: function () {
                            return dataModal;
                        }
                    }
                });

                modalInstance.result.then(
                    function (returnData) {
                        console.log('OK, box closed');
                        var grossAmount = get2Float(returnData.totalAmount);
                        var mealSubstitution = returnData.mealSubstitution;
                        form.grossAmount = grossAmount;
                        form.mealSubstitution = mealSubstitution;
                        form.totalDays = 0; // Reset No.of Days to 0
                        
                        if (itemIndex != undefined) {
                            $scope.currIndex = itemIndex;
                            $scope.isEditMode = true;
                            changeItemVal('chkSubstitute', chkSubstitute);
                            changeItemVal('mealSubstitution', mealSubstitution);
                            changeItemVal('grossAmount', grossAmount);
                            changeItemVal('totalDays', 0);
                        }
                    },
                    function () {
                        console.log('Cancel, box closed');
                    }
                );
            }
        }else{
            // Reset amount based on selected Date.
            calculateDiffDays(departDate, returnDate);
            calculateSubsistenceAmount();
        };
    };

    $scope.displayChildTable = function (index) {
        index = getItemIndex(index);
        var currItem = getItems(index);
        setEditMode(index);/*
        DataFormHotel.setHotelLTItems(currItem.subsisHotelItems);
        DataFormHotel.setIsNewHotelLTItems(false);
        DataFormLodging.setLodgingLTItems(currItem.subsisLodgingItems);
        DataFormLodging.setIsNewLodgingLTItems(false);
        DataFormMeal.setMealLTItems(currItem.subsisMealItems);
        DataFormMeal.setIsNewMealLTItems(false);*/
    };

    /* Start : Calculation */
        var getRateDailyAllowance = function (courseLocation) {
            var rate = 0;
            var form = getForm();
            if (courseLocation) {
                rate = $scope.getRate('course_daily', courseLocation.code, 'long_term');
            }
            form.dailyAllowanceRate = rate;
            return rate;
        };

        var calculateDiffDays = function (departDate, returnDate) {
            var totalDays = 0;
            if (angular.isDate(departDate) && angular.isDate(returnDate)) {
                totalDays = getNightDiffDate(departDate, returnDate);
            }
            var form = getForm();
            form.totalDays = getNumber(totalDays);
            changeItemVal('totalDays', totalDays);
        };

        var calculateSubsistenceAmount = function () {
            var total = 0;
            var form = getForm();
            total = parseFloat(form.dailyAllowanceRate) * getNumber(form.totalDays);
            form.grossAmount = get2Float(total);
            changeItemVal('grossAmount', get2Float(total));
        };

        var calculateGrandTotal = function () {
            var trip = getTrip('subsis');
            var items = getTrip('subsisItems');
            
            if (items) {
                var grandTotalGrossAmount = getListTotalAmount(items, 'grossAmount');
                trip['grandTotalGrossAmount'] = grandTotalGrossAmount;
                trip['grandTotalMealAmount'] = getListTotalAmount(items, 'mealAmount');
                trip['grandTotalAccommodationAmount'] = getListTotalAmount(items, 'accommodationAmount');
                DataFormSubsis.setGrandTotal(grandTotalGrossAmount);
            }
        };
    /* End : Calculation */

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('fundType', newValue); }
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('projectCode', newValue); }
    });
}]);

uiBootstrapApp.controller('ModalMealSubstitutionCtrl', ['$scope', '$filter', '$modalInstance', 'data', function ($scope, $filter, $uibModalInstance, data) {

    /* Start : General Config for Table */
        $scope.pageSize = 5;
        $scope.currentPage = 1;
    /* End : General Config for Table */

    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var dailyAllowanceRate = parseFloat(data.dailyAllowanceRate);
    var mealSubstitution = data.mealSubstitution;

    var mealRate = dailyAllowanceRate * (50/100);
    var accommodationRate = dailyAllowanceRate * (50/100);
    var totalMealAmount = 0;
    var totalAccommodationAmount = 0;
    var totalAmount = 0;

    $scope.dailyAllowanceRate = get2Float(dailyAllowanceRate);
    $scope.mealRate = get2Float(mealRate);
    $scope.accommodationRate = get2Float(accommodationRate);

    var generateDays = function (dateFrom, dateTo) {
        var mealDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            mealSubstitution.push({date:objMinDate, chkMeal:false, chkAccommodation:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return mealSubstitution;
    };

    if (mealSubstitution.length) {
        $scope.mealSubstitution = mealSubstitution;
    }else{
        $scope.mealSubstitution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {totalAmount:$scope.totalAmount, mealSubstitution:$scope.mealSubstitution}
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('mealSubstitution', function() {
        var mealTotal = 0;
        var accommodationTotal = 0;

        $scope.mealSubstitution.forEach(function(obj){
            if(obj.chkMeal){
                mealTotal++;
            }
            if (obj.chkAccommodation) {
                accommodationTotal++;
            }
        });

        mealTotalAmount = parseFloat(mealTotal) * mealRate;
        accommodationTotalAmount = parseFloat(accommodationTotal) * accommodationRate;

        $scope.mealTotal = mealTotal;
        $scope.accommodationTotal = accommodationTotal;
        $scope.mealTotalAmount = get2Float(mealTotalAmount);
        $scope.accommodationTotalAmount = get2Float(accommodationTotalAmount);

        totalAmount = parseFloat(mealTotalAmount) + parseFloat(accommodationTotalAmount);
        $scope.totalAmount = get2Float(totalAmount);
    }, true);
}]);

uiBootstrapApp.factory('DataFormSubsis', function ($filter) {
    var data = {
        CurrSection: '',
        GrandTotalLT: get2Float(0),
        GrandTotalST: get2Float(0),
        LTDBItems: [],
        LTDBDistributions: [],
        STDBItems: [],
        STDBDistributions: []
    };

    return {
        getCurrSection: function () {
            return data.CurrSection;
        },
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getGrandTotalLT: function(){
            return data.GrandTotalLT;
        },
        getGrandTotalST: function(){
            return data.GrandTotalST;
        },
        setGrandTotal: function(val){
            if (data.CurrSection == 'LT') {
                data.GrandTotalLT = val;
            }else if (data.CurrSection == 'ST') {
                data.GrandTotalST = val;
            };
        },
        getLTDBItems: function(){
            return data.LTDBItems;
        },
        setLTDBItems: function(obj){
            data.LTDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        },
        getDBDistributionByParentID: function(parentID){
            var distribution = [];
            var source = [];
            if (data.CurrSection == 'ST') {
                source = data.STDBDistributions;
            }else if (data.CurrSection == 'LT') {
                source = data.LTDBDistributions;
            }
            source.forEach(function(obj){
                if (parentID == obj.subsistence_item_id) {
                    distribution.push({date: getDateStr($filter, obj.date), chkMeal: obj.chk_meal
                                      , chkAccommodation: obj.chk_accommodation});
                }
            });
            return distribution;
        },
        setSTDBDistributions: function(obj){
            data.STDBDistributions = obj;
        },
        setLTDBDistributions: function(obj){
            data.LTDBDistributions = obj;
        },
    };
});
/******************** End : Subsistence Meal ********************/


/******************** Start : Meal Aid ********************/
uiBootstrapApp.controller('MealAidCtrl', ['$scope', '$http', '$uibModal', 'DataFundType', 'DataLookup',
                                          'DataFormMealAid', 'DataFormMain'
                        , function($scope, $http, $uibModal, DataFundType, DataLookup,
                                   DataFormMealAid, DataFormMain){

    $scope.initLoad = function(){
        $scope.mealAidPTItems = [];
        $scope.mealAidChkDistribution = false;
        $scope.mealAidDistribution = [];

        setEmptyTable();
        calculateAll();

        $scope.$watch(function () { return DataFormMealAid.getPTDBItems(); }, function (newValue, oldValue) {
            if (newValue != oldValue){
                DataFormMealAid.setCurrSection('PT');
                if (newValue.length > 0) {
                    newValue.forEach(function(obj){
                      $scope.addItem(obj);
                    });
                    DataFormMealAid.setMealAidPTItems($scope.mealAidPTItems);
                }
            };
        });
    };

    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    $('#mealAidPTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        $scope.isEmptyTable = true;
        $scope.currIndex = '';
        disableEditMode();
    };

    var resetForm = function(){
        $scope.mealAidChkDistribution = false;
        $scope.mealAidDistribution = [];
        $scope.mealAidTotalAmount = get2Float(0);
    };

    var setEditMode = function(index){
        setForm(getItems(index));
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.isEditMode = true;
    };

    var setForm = function(currItem){
        DataFormMealAid.setDepartDate(currItem.mealAidDepartDate);
        DataFormMealAid.setReturnDate(currItem.mealAidReturnDate);
        DataFundType.setFundType(currItem.mealAidFundType);
        DataLookup.setProjectCode(currItem.mealAidProjectCode);
        $scope.mealAidCourseLocation = currItem.mealAidCourseLocation;
        $scope.mealAidTravellingInfo = currItem.mealAidTravellingInfo;
        $scope.mealAidChkDistribution = currItem.mealAidChkDistribution;
        $scope.mealAidDistribution = currItem.mealAidDistribution;
        $scope.mealAidIntTotalDays = getNumber(currItem.mealAidIntTotalDays);
        $scope.mealAidTotalAmount = get2Float(currItem.mealAidTotalAmount);
    };

    var setRow = function(objDB){
        if (objDB) {
            DataFormMealAid.setDepartDate(getDateFromStr(objDB.depart_date));
            DataFormMealAid.setReturnDate(getDateFromStr(objDB.return_date));
            $scope.mealAidCourseLocation = DataFormMain.getCourseLocationByCode(objDB.course_location);
            $scope.mealAidTravellingInfo = objDB.travelling_info;
            $scope.mealAidChkDistribution = objDB.chk_meal_distribution;
            $scope.mealAidDistribution = DataFormMealAid.getDBDistributionByParentID(objDB.id);
            $scope.mealAidIntTotalDays = objDB.int_days;
            $scope.mealAidTotalAmount = objDB.amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            mealAidDepartDate: DataFormMealAid.getDepartDate(), mealAidDepartDateTxt: DataFormMealAid.getDepartDateTxt()
            , mealAidReturnDate: DataFormMealAid.getReturnDate(), mealAidReturnDateTxt: DataFormMealAid.getReturnDateTxt()
            , mealAidFundType: DataFundType.getFundType(), mealAidProjectCode: DataLookup.getProjectCode()
            , mealAidCourseLocation: $scope.mealAidCourseLocation
            , mealAidTravellingInfo: $scope.mealAidTravellingInfo
            , mealAidChkDistribution: $scope.mealAidChkDistribution, mealAidDistribution: $scope.mealAidDistribution
            , mealAidIntTotalDays: getNumber($scope.mealAidIntTotalDays)
            , mealAidTotalAmount: get2Float($scope.mealAidTotalAmount)
        };
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormMealAid.getCurrSection();
        if (currSection == 'PT') {
            obj = $scope.mealAidPTItems;
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var getItemIndex = function(index) {
        index = index + ($scope.currentPage - 1) * $scope.pageSize;
        return index;
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                if (obj == 'mealAidDepartDate' || obj == 'mealAidReturnDate') {
                    currItem.mealAidDepartDate = DataFormMealAid.getDepartDate();
                    currItem.mealAidDepartDateTxt = DataFormMealAid.getDepartDateTxt();
                    currItem.mealAidReturnDate = DataFormMealAid.getReturnDate();
                    currItem.mealAidReturnDateTxt = DataFormMealAid.getReturnDateTxt();
                }else if (obj == 'mealAidFundType' || obj == 'mealAidProjectCode') {
                    currItem.mealAidFundType = DataFundType.getFundType();
                    currItem.mealAidProjectCode = DataLookup.getProjectCode();
                }else if (obj == 'mealAidCourseLocation') {
                    currItem.mealAidCourseLocation = $scope.mealAidCourseLocation;
                }else if (obj == 'mealAidTravellingInfo') {
                    currItem.mealAidTravellingInfo = $scope.mealAidTravellingInfo;
                }else if (obj == 'mealAidChkDistribution') {
                    currItem.mealAidChkDistribution = $scope.mealAidChkDistribution;
                }else if (obj == 'mealAidDistribution') {
                    currItem.mealAidDistribution = $scope.mealAidDistribution;
                }else if (obj == 'mealAidIntTotalDays') {
                    currItem.mealAidIntTotalDays = $scope.mealAidIntTotalDays;
                }else if (obj == 'mealAidTotalAmount') {
                    currItem.mealAidTotalAmount = get2Float($scope.mealAidTotalAmount);
                    calculateAll();
                }
            }
        }
    };

    $scope.addItem = function(objDB){
        getItems().push(setRow(objDB));
        $scope.isEmptyTable = false;
        resetForm();
        calculateAll();
    };

    $scope.deleteItem = function(section, index){
        DataFormMealAid.setCurrSection(section);
        index = getItemIndex(index);
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };

    $scope.editItem = function(section, index){
        index = getItemIndex(index);
        $scope.openModal(section, 'editForm');
        setEditMode(index);
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();

        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormMealAid.setCurrSection(section);
        if (section == 'PT') {
            $('#mealAidPTModalForm').modal('show');
        }
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.openModalDistribution = function (index) {
        var isValidRate = false;

        var rateDaily = 0;

        var mealSubstitution = [];

        if (index != undefined) {
            index = getItemIndex(index);
            setEditMode(index);
        }

        var departDate = DataFormMealAid.getDepartDate();
        var returnDate = DataFormMealAid.getReturnDate();
        var courseLocation = $scope.mealAidCourseLocation;
        var chkDistribution = $scope.mealAidChkDistribution;
        var listDistribution = $scope.mealAidDistribution;
        //console.log(departDate +' | '+returnDate+' | '+chkSubstitute+' | '+mealSubstitution);

        if (courseLocation) {
            rateDaily = $scope.rateDailyMeal;
            isValidRate = true;
        }

        $scope.animationsEnabled = true;
        instance_controller = 'ModalMealAidDistributionCtrl';
        ng_template = 'MealAidDistribution.html';
        if (angular.isDate(departDate) && angular.isDate(returnDate) && isValidRate) {
            if (chkDistribution) {
                var dataModal = {dateFrom: departDate, dateTo: returnDate, rateDaily: rateDaily, listDistribution: listDistribution};
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: ng_template,
                    controller: instance_controller,
                    size: '',
                    resolve: {
                        data: function () {
                            return dataModal;
                        }
                    }
                });

                modalInstance.result.then(
                    function (returnData) {
                        console.log('OK, box closed');
                        $scope.mealAidTotalAmount = get2Float(returnData.totalAmount);
                        $scope.mealAidDistribution = returnData.listDistribution;
                        $scope.mealAidIntTotalDays = 0; // Reset no.of days
                    },
                    function () {
                        console.log('Cancel, box closed');
                    }
                );
            }else{
                // Reset amount based on selected Date.
                calculateDiffDays();
                calculateTotalAmount();
            }
        }
    };

    /* Start : Calculation */
        var calculateDiffDays = function () {
            var intDays = 0;
            if (angular.isDate(DataFormMealAid.getDepartDate()) && angular.isDate(DataFormMealAid.getReturnDate())) {
                intDays = getNightDiffDate(DataFormMealAid.getDepartDate(), DataFormMealAid.getReturnDate()) + 1;
            }
            $scope.mealAidIntTotalDays = getNumber(intDays);
            changeItemVal('mealAidIntTotalDays');
        };

        var getRateDaily = function () {
            var rate = 0;
            var courseLocation = $scope.mealAidCourseLocation;
            if (courseLocation) {
                rate = $scope.getRate('course_daily', courseLocation.code, 'meal_aid');
            }
            $scope.rateDailyMeal =  get2Float(rate);
        };

        var calculateTotalAmount = function () {
            var total = 0;
            total = parseFloat($scope.mealAidIntTotalDays) * parseFloat($scope.rateDailyMeal);
            $scope.mealAidTotalAmount = get2Float(total);
            changeItemVal('mealAidTotalAmount');
        };

        var calculateGrandTotal = function () {
            var grandTotalMealAidAmount = 0;
            getItems().forEach(function (obj){
                grandTotalMealAidAmount = grandTotalMealAidAmount + parseFloat(obj.mealAidTotalAmount);
            });
            $scope.grandTotalMealAidAmount = get2Float(grandTotalMealAidAmount);
            DataFormMealAid.setGrandTotalPT(grandTotalMealAidAmount);
        };

        var calculateAll = function () {
            calculateGrandTotal();
        };
    /* End : Calculation */

    $scope.$watch(function () { return DataFormMealAid.getDepartDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            calculateDiffDays();
            calculateTotalAmount();
            changeItemVal('mealAidDepartDate');
        }
    });

    $scope.$watch(function () { return DataFormMealAid.getReturnDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            calculateDiffDays();
            calculateTotalAmount();
            changeItemVal('mealAidReturnDate');
        }
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('mealAidFundType'); }
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('mealAidProjectCode'); }
    });

    $scope.$watch('mealAidCourseLocation', function(newValue, oldValue){
        if (newValue && newValue != oldValue) {
            getRateDaily();
            calculateTotalAmount();
            changeItemVal('mealAidCourseLocation');
        }
    });

    $scope.$watch('mealAidTravellingInfo', function(newValue, oldValue){
        if (newValue != oldValue) {changeItemVal('mealAidTravellingInfo');}
    });

    $scope.$watch('mealAidChkDistribution', function(newValue, oldValue){
        if (newValue != oldValue) {changeItemVal('mealAidChkDistribution');}
    });

    $scope.$watch('mealAidTotalAmount', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('mealAidTotalAmount');}
    });

    $scope.$watch('mealAidPTItems', function (newValue, oldValue) {
        DataFormMealAid.setMealAidPTItems($scope.mealAidPTItems);
    }, true);


}]);

uiBootstrapApp.controller('ModalMealAidDistributionCtrl', ['$scope', '$filter', '$modalInstance', 'data', function ($scope, $filter, $uibModalInstance, data) {

    /* Start : General Config for Table */
        $scope.pageSize = 5;
        $scope.currentPage = 1;
    /* End : General Config for Table */

    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var rateDaily = parseFloat(data.rateDaily);
    var listDistribution = data.listDistribution;

    var totalAmount = 0;

    $scope.rateDaily = get2Float(rateDaily);

    var generateDays = function (dateFrom, dateTo) {
        var listDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            listDistribution.push({date:objMinDate, mealAid:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return listDistribution;
    };

    if (listDistribution.length) {
        $scope.listDistribution = listDistribution;
    }else{
        $scope.listDistribution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {totalAmount:$scope.totalAmount, listDistribution:$scope.listDistribution}
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('listDistribution', function() {
        var totalMealAid = 0;

        $scope.listDistribution.forEach(function(obj){
            if(obj.mealAid){
                totalMealAid++;
            }
        });

        totalAmount = parseFloat(totalMealAid) * rateDaily;

        $scope.totalMealAid = totalMealAid;
        $scope.totalAmount = get2Float(totalAmount);
    }, true);
}]);

uiBootstrapApp.controller('MealAidDepartDateCtrl', function($scope, DataFormMealAid){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.mealAidDepartDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initLoad = function(){
        //console.log('Load initMileageDepartDate (Default)');
    };

	$scope.dateChanged = function(){
        DataFormMealAid.setDepartDate($scope.mealAidDepartDate);
	};

    $scope.$watch(function () { return DataFormMealAid.getDepartDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.mealAidDepartDate = newValue;
        }
    });
});

uiBootstrapApp.controller('MealAidReturnDateCtrl', function($scope, DataFormMealAid){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.mealAidReturnDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initLoad = function(){
        //console.log('Load initMileageDepartDate (Default)');
    };

	$scope.dateChanged = function(){
        DataFormMealAid.setReturnDate($scope.mealAidReturnDate);
	};

    $scope.$watch(function () { return DataFormMealAid.getReturnDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.mealAidReturnDate = newValue;
        }
    });
});

uiBootstrapApp.factory('DataFormMealAid', function ($filter) {
    var data = {
        CurrSection: '',
		DepartDate: '',
		ReturnDate: '',
        MealAidPTItems: [],
        GrandTotalPT: get2Float(0),
        PTDBItems: [],
        PTDBMealAidDistributions: []
    };

    return {
        getCurrSection: function () {
            return data.CurrSection;
        },
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getDepartDate: function () {
            return data.DepartDate;
        },
        getDepartDateTxt: function () {
            return getDateStr($filter, data.DepartDate);
        },
        setDepartDate: function (obj) {
            data.DepartDate = obj;
        },
        getReturnDate: function () {
            return data.ReturnDate;
        },
        getReturnDateTxt: function () {
            return getDateStr($filter, data.ReturnDate);
        },
        setReturnDate: function (obj) {
            data.ReturnDate = obj;
        },
        getMealAidPTItems: function () {
            return data.MealAidPTItems;
        },
        setMealAidPTItems: function (obj) {
            data.MealAidPTItems = obj;
        },
        getGrandTotalPT: function(){
            return data.GrandTotaPT;
        },
        setGrandTotalPT: function(val){
            data.GrandTotalPT = val;
        },
        getPTDBItems: function(){
            return data.PTDBItems;
        },
        setPTDBItems: function(obj){
            data.PTDBItems = obj;
        },
        getDBDistributionByParentID: function(parentID){
            var distribution = [];
            data.PTDBDistributions.forEach(function(obj){
                if (parentID == obj.meal_aid_item_id) {
                    distribution.push({date:getDateStr($filter, obj.date), mealAid: obj.meal_aid});
                }
            });
            return distribution;
        },
        setPTDBDistributions: function(obj){
            data.PTDBDistributions = obj;
        },
    };
});
/******************** End : Meal Aid ********************/


/******************** Start : Transport Aid ********************/
uiBootstrapApp.controller('TransportAidCtrl', ['$scope', '$http', '$uibModal', 'DataFundType', 'DataLookup',
                                               'DataFormTransportAid', 'DataFormMain'
                        , function($scope, $http, $uibModal, DataFundType, DataLookup,
                                   DataFormTransportAid, DataFormMain){
    $scope.initLoad = function(){
        $scope.transportAidPTItems = [];
        $scope.transportAidChkDistribution = false;
        $scope.transportAidDistribution = [];

        setEmptyTable();
        calculateAll();

        $scope.$watch(function () { return DataFormTransportAid.getPTDBItems(); }, function (newValue, oldValue) {
            if (newValue != oldValue){
                DataFormTransportAid.setCurrSection('PT');
                if (newValue.length > 0) {
                    newValue.forEach(function(obj){
                      $scope.addItem(obj);
                    });
                    DataFormTransportAid.setTransportAidPTItems($scope.transportAidPTItems);
                }
            };
        });
    };

    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    $('#transportAidPTModalForm').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        $scope.isEmptyTable = true;
        $scope.currIndex = '';
        disableEditMode();
    };

    var resetForm = function(){
        $scope.transportAidChkDistribution = false;
        $scope.transportAidDistribution = [];
        $scope.transportAidTotalAmount = get2Float(0);
    };

    var setEditMode = function(index){
        setForm(getItems(index));
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.isEditMode = true;
    };

    var setForm = function(currItem){
        DataFormTransportAid.setDepartDate(currItem.transportAidDepartDate);
        DataFormTransportAid.setReturnDate(currItem.transportAidReturnDate);
        DataFundType.setFundType(currItem.transportAidFundType);
        DataLookup.setProjectCode(currItem.transportAidProjectCode);
        $scope.transportAidCourseLocation = currItem.transportAidCourseLocation;
        $scope.transportAidTravellingInfo = currItem.transportAidTravellingInfo;
        $scope.transportAidChkDistribution = currItem.transportAidChkDistribution;
        $scope.transportAidDistribution = currItem.transportAidDistribution;
        $scope.transportAidIntTotalDays = getNumber(currItem.transportAidIntTotalDays);
        $scope.transportAidTotalAmount = get2Float(currItem.transportAidTotalAmount);
    };

    var setRow = function(objDB){
        if (objDB) {
            DataFormTransportAid.setDepartDate(getDateFromStr(objDB.depart_date));
            DataFormTransportAid.setReturnDate(getDateFromStr(objDB.return_date));
            $scope.transportAidCourseLocation = DataFormMain.getCourseLocationByCode(objDB.course_location);
            $scope.transportAidTravellingInfo = objDB.travelling_info;
            $scope.transportAidChkDistribution = objDB.chk_transport_distribution;
            $scope.transportAidDistribution = DataFormTransportAid.getDBDistributionByParentID(objDB.id);
            $scope.transportAidIntTotalDays = objDB.int_days;
            $scope.transportAidTotalAmount = objDB.amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            transportAidDepartDate: DataFormTransportAid.getDepartDate(), transportAidDepartDateTxt: DataFormTransportAid.getDepartDateTxt()
            , transportAidReturnDate: DataFormTransportAid.getReturnDate(), transportAidReturnDateTxt: DataFormTransportAid.getReturnDateTxt()
            , transportAidFundType: DataFundType.getFundType(), transportAidProjectCode: DataLookup.getProjectCode()
            , transportAidCourseLocation: $scope.transportAidCourseLocation
            , transportAidTravellingInfo: $scope.transportAidTravellingInfo
            , transportAidChkDistribution: $scope.transportAidChkDistribution, transportAidDistribution: $scope.transportAidDistribution
            , transportAidIntTotalDays: getNumber($scope.transportAidIntTotalDays)
            , transportAidTotalAmount: get2Float($scope.transportAidTotalAmount)
        };
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormTransportAid.getCurrSection();
        if (currSection == 'PT') {
            obj = $scope.transportAidPTItems;
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var getItemIndex = function(index) {
        index = index + ($scope.currentPage - 1) * $scope.pageSize;
        return index;
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                if (obj == 'transportAidDepartDate' || obj == 'transportAidReturnDate') {
                    currItem.transportAidDepartDate = DataFormTransportAid.getDepartDate();
                    currItem.transportAidDepartDateTxt = DataFormTransportAid.getDepartDateTxt();
                    currItem.transportAidReturnDate = DataFormTransportAid.getReturnDate();
                    currItem.transportAidReturnDateTxt = DataFormTransportAid.getReturnDateTxt();
                }else if (obj == 'transportAidFundType' || obj == 'transportAidProjectCode') {
                    currItem.transportAidFundType = DataFundType.getFundType();
                    currItem.transportAidProjectCode = DataLookup.getProjectCode();
                }
                else if (obj == 'transportAidCourseLocation') {
                    currItem.transportAidCourseLocation = $scope.transportAidCourseLocation;
                }else if (obj == 'transportAidTravellingInfo') {
                    currItem.transportAidTravellingInfo = $scope.transportAidTravellingInfo;
                }else if (obj == 'transportAidChkDistribution') {
                    currItem.transportAidChkDistribution = $scope.transportAidChkDistribution;
                }else if (obj == 'transportAidDistribution') {
                    currItem.transportAidDistribution = $scope.transportAidDistribution;
                }else if (obj == 'transportAidIntTotalDays') {
                    currItem.transportAidIntTotalDays = $scope.transportAidIntTotalDays;
                }else if (obj == 'transportAidTotalAmount') {
                    currItem.transportAidTotalAmount = get2Float($scope.transportAidTotalAmount);
                    calculateAll();
                }
            }
        }
    };

    $scope.addItem = function(objDB){
        getItems().push(setRow(objDB));
        $scope.isEmptyTable = false;
        resetForm();
        calculateAll();
    };

    $scope.deleteItem = function(section, index){
        DataFormTransportAid.setCurrSection(section);
        index = getItemIndex(index);
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };

    $scope.editItem = function(section, index){
        index = getItemIndex(index);
        $scope.openModal(section, 'editForm');
        setEditMode(index);
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();

        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormTransportAid.setCurrSection(section);
        if (section == 'PT') {
            $('#transportAidPTModalForm').modal('show');
        }
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.openModalDistribution = function (index) {
        var isValidRate = false;

        var rateDaily = 0;

        var mealSubstitution = [];

        if (index != undefined) {
            index = getItemIndex(index);
            setEditMode(index);
        }

        var departDate = DataFormTransportAid.getDepartDate();
        var returnDate = DataFormTransportAid.getReturnDate();
        var courseLocation = $scope.transportAidCourseLocation;
        var chkDistribution = $scope.transportAidChkDistribution;
        var listDistribution = $scope.transportAidDistribution;
        //console.log(departDate +' | '+returnDate+' | '+chkSubstitute+' | '+mealSubstitution);

        if (courseLocation) {
            rateDaily = $scope.rateDailyTransport;
            isValidRate = true;
        }

        $scope.animationsEnabled = true;
        instance_controller = 'ModalTransportAidDistributionCtrl';
        ng_template = 'TransportAidDistribution.html';
        if (angular.isDate(departDate) && angular.isDate(returnDate) && isValidRate) {
            if (chkDistribution) {
                var dataModal = {dateFrom: departDate, dateTo: returnDate, rateDaily: rateDaily, listDistribution: listDistribution};
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: ng_template,
                    controller: instance_controller,
                    size: '',
                    resolve: {
                        data: function () {
                            return dataModal;
                        }
                    }
                });

                modalInstance.result.then(
                    function (returnData) {
                        console.log('OK, box closed');
                        $scope.transportAidTotalAmount = get2Float(returnData.totalAmount);
                        $scope.transportAidDistribution = returnData.listDistribution;
                        $scope.transportAidIntTotalDays = 0; // Set to 0 as Meal Distribution is selected.
                    },
                    function () {
                        console.log('Cancel, box closed');
                    }
                );
            }else{
                calculateDiffDays();
                calculateTotalAmount();
            }
        }
    };

    /* Start : Calculation */
        var calculateDiffDays = function () {
            var intDays = 0;
            if (angular.isDate(DataFormTransportAid.getDepartDate()) && angular.isDate(DataFormTransportAid.getReturnDate())) {
                intDays = getNightDiffDate(DataFormTransportAid.getDepartDate(), DataFormTransportAid.getReturnDate()) + 1;
            }
            $scope.transportAidIntTotalDays = getNumber(intDays);
            changeItemVal('transportAidIntTotalDays');
        };

        var getRateDaily = function () {
            var rate = 0;
            var courseLocation = $scope.transportAidCourseLocation;
            if (courseLocation) {
                rate = $scope.getRate('course_daily', courseLocation.code, 'transport_aid');
            }
            $scope.rateDailyTransport =  get2Float(rate);
        };

        var calculateTotalAmount = function () {
            var total = 0;
            total = parseFloat($scope.transportAidIntTotalDays) * parseFloat($scope.rateDailyTransport);
            $scope.transportAidTotalAmount = get2Float(total);
            changeItemVal('transportAidTotalAmount');
        };

        var calculateGrandTotal = function () {
            var grandTotalTransportAidAmount = 0;

            getItems().forEach(function (obj){
                grandTotalTransportAidAmount = grandTotalTransportAidAmount + parseFloat(obj.transportAidTotalAmount);
            });
            $scope.grandTotalTransportAidAmount = get2Float(grandTotalTransportAidAmount);
            DataFormTransportAid.setGrandTotalPT(grandTotalTransportAidAmount);
        };

        var calculateAll = function () {
            calculateGrandTotal();
        };
    /* End : Calculation */

    $scope.$watch(function () { return DataFormTransportAid.getDepartDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            calculateDiffDays();
            calculateTotalAmount();
            changeItemVal('transportAidDepartDate')
        ;}
    });

    $scope.$watch(function () { return DataFormTransportAid.getReturnDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            calculateDiffDays();
            calculateTotalAmount();
            changeItemVal('transportAidReturnDate')
        ;}
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('transportAidFundType');}
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('transportAidProjectCode');}
    });

    $scope.$watch('transportAidCourseLocation', function(newValue, oldValue){
        if (newValue && newValue != oldValue) {
            getRateDaily();
            calculateTotalAmount();
            changeItemVal('transportAidCourseLocation');
        }
    });

    $scope.$watch('transportAidTravellingInfo', function(newValue, oldValue){
        if (newValue != oldValue) {changeItemVal('transportAidTravellingInfo');}
    });

    $scope.$watch('transportAidChkDistribution', function(newValue, oldValue){
        if (newValue != oldValue) {changeItemVal('transportAidChkDistribution');}
    });

    $scope.$watch('transportAidTotalAmount', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('transportAidTotalAmount');}
    });

    $scope.$watch('transportAidPTItems', function (newValue, oldValue) {
        DataFormTransportAid.setTransportAidPTItems($scope.transportAidPTItems);
    }, true);
}]);

uiBootstrapApp.controller('ModalTransportAidDistributionCtrl', ['$scope', '$filter', '$modalInstance', 'data', function ($scope, $filter, $uibModalInstance, data) {

    /* Start : General Config for Table */
        $scope.pageSize = 5;
        $scope.currentPage = 1;
    /* End : General Config for Table */

    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var rateDaily = parseFloat(data.rateDaily);
    var listDistribution = data.listDistribution;

    var totalAmount = 0;

    $scope.rateDaily = get2Float(rateDaily);

    var generateDays = function (dateFrom, dateTo) {
        var listDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            listDistribution.push({counter:counter, date:objMinDate, transportAid:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return listDistribution;
    };

    if (listDistribution.length) {
        $scope.listDistribution = listDistribution;
    }else{
        $scope.listDistribution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {totalAmount:$scope.totalAmount, listDistribution:$scope.listDistribution}
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('listDistribution', function() {
        var totalTransportAid = 0;

        $scope.listDistribution.forEach(function(obj){
            if(obj.transportAid){
                totalTransportAid++;
            }
        });

        totalAmount = parseFloat(totalTransportAid) * rateDaily;

        $scope.totalTransportAid = totalTransportAid;
        $scope.totalAmount = get2Float(totalAmount);
    }, true);
}]);

uiBootstrapApp.controller('TransportAidDepartDateCtrl', function($scope, DataFormTransportAid){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.transportAidDepartDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initLoad = function(){
        //console.log('Load initMileageDepartDate (Default)');
    };

	$scope.dateChanged = function(){
        DataFormTransportAid.setDepartDate($scope.transportAidDepartDate);
	};

    $scope.$watch(function () { return DataFormTransportAid.getDepartDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.transportAidDepartDate = newValue;
        }
    });
});

uiBootstrapApp.controller('TransportAidReturnDateCtrl', function($scope, DataFormTransportAid){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.transportAidReturnDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.initLoad = function(){
        //console.log('Load initMileageDepartDate (Default)');
    };

	$scope.dateChanged = function(){
        DataFormTransportAid.setReturnDate($scope.transportAidReturnDate);
	};

    $scope.$watch(function () { return DataFormTransportAid.getReturnDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.transportAidReturnDate = newValue;
        }
    });
});

uiBootstrapApp.factory('DataFormTransportAid', function ($filter) {
    var data = {
        CurrSection: '',
		DepartDate: '',
		ReturnDate: '',
        TransportAidPTItems: [],
        GrandTotalPT: get2Float(0),
        PTDBItems: [],
        PTDBDistributions: []
    };

    return {
        getCurrSection: function () {
            return data.CurrSection;
        },
        setCurrSection: function (val) {
            data.CurrSection = val;
        },
        getDepartDate: function () {
            return data.DepartDate;
        },
        getDepartDateTxt: function () {
            return getDateStr($filter, data.DepartDate);
        },
        setDepartDate: function (obj) {
            data.DepartDate = obj;
        },
        getReturnDate: function () {
            return data.ReturnDate;
        },
        getReturnDateTxt: function () {
            return getDateStr($filter, data.ReturnDate);
        },
        setReturnDate: function (obj) {
            data.ReturnDate = obj;
        },
        getTransportAidPTItems: function () {
            return data.TransportAidPTItems;
        },
        setTransportAidPTItems: function  (obj) {
            data.TransportAidPTItems = obj;
        },
        getGrandTotalPT: function(){
            return data.GrandTotalPT;
        },
        setGrandTotalPT: function(val){
            data.GrandTotalPT = val;
        },
        getPTDBItems: function(){
            return data.PTDBItems;
        },
        setPTDBItems: function(obj){
            data.PTDBItems = obj;
        },
        getDBDistributionByParentID: function(parentID){
            var distribution = [];
            data.PTDBDistributions.forEach(function(obj){
                if (parentID == obj.transport_aid_item_id) {
                    distribution.push({date:getDateStr($filter, obj.date), transportAid: obj.transport_aid});
                }
            });
            return distribution;
        },
        setPTDBDistributions: function(obj){
            data.PTDBDistributions = obj;
        },
    };
});
/******************** End : Transport Aid ********************/


/******************** Start : Supporting Docs ********************/
uiBootstrapApp.controller('SupportingDocumentCtrl', function($scope, $http, DataFormDoc){
    $scope.initLoad = function (section) {
        if (section == 'OD') {
            $scope.$watch(function () { return DataFormDoc.getODDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem('OD', obj);
                        });
                    }
                };
            });
        }
        else if (section == 'LT') {
            $scope.docLTItems = [];
            //$scope.loadLTList();
            $scope.$watch(function () { return DataFormDoc.getLTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem('LT', obj);
                        });
                    }
                };
            });
        }
        else if (section == 'ST') {
            $scope.docSTItems = [];
            //$scope.loadSTList();
            $scope.$watch(function () { return DataFormDoc.getSTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem('ST', obj);
                        });
                    }
                };
            });
        }
        else if (section == 'PT') {
            $scope.docPTItems = [];
            //$scope.loadPTList();
            $scope.$watch(function () { return DataFormDoc.getPTDBItems(); }, function (newValue, oldValue) {
                if (newValue != oldValue){
                    if (newValue.length > 0) {
                        newValue.forEach(function(obj){
                          $scope.addItem('PT', obj);
                        });
                    }
                };
            });
        }
    };

    var getTrip = function(objName){
        var currSection = DataFormDoc.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var getItems = function(index){
        var obj = getTrip('supportingDocuments');

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    $scope.addItem = function(section, objDB){
        DataFormDoc.setCurrSection(section);
        var items = getItems();
        if (objDB) {
            items.push({doc:$scope.getSupportingDocumentByID(section, objDB.document_list_id)});
        }else{
            items.push({});
        }
        $scope.isEmptyTable = false;
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormDoc.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
    };
    /*
    $scope.$watch('docODItems', function (newValue, oldValue) {
        DataFormDoc.setDocODItems($scope.docODItems);
    }, true);

    $scope.$watch('docLTItems', function (newValue, oldValue) {
        DataFormDoc.setDocLTItems($scope.docLTItems);
    }, true);

    $scope.$watch('docSTItems', function (newValue, oldValue) {
        DataFormDoc.setDocSTItems($scope.docSTItems);
    }, true);

    $scope.$watch('docPTItems', function (newValue, oldValue) {
        DataFormDoc.setDocPTItems($scope.docPTItems);
    }, true);*/
});

uiBootstrapApp.factory('DataFormDoc', function(){
    var data = {
        CurrSection: '',
        ODDBItems: [],
        LTDBItems: [],
        STDBItems: [],
        PTDBItems: []
    }

    return {
        getCurrSection: function() {
            return data.CurrSection;
        },
        setCurrSection: function(val) {
            data.CurrSection = val;
        },
        getODDBItems: function(){
            return data.ODDBItems;
        },
        setODDBItems: function(obj){
            data.ODDBItems = obj;
        },
        getLTDBItems: function(){
            return data.LTDBItems;
        },
        setLTDBItems: function(obj){
            data.LTDBItems = obj;
        },
        getSTDBItems: function(){
            return data.STDBItems;
        },
        setSTDBItems: function(obj){
            data.STDBItems = obj;
        },
        getPTDBItems: function(){
            return data.PTDBItems;
        },
        setPTDBItems: function(obj){
            data.PTDBItems = obj;
        }
    }
});
/******************** End : Supporting Docs ********************/


/******************** Start : Summary ********************/
uiBootstrapApp.controller('SummaryCtrl'
                          , function($scope, $http, $filter, DataFormMain, DataFormMileage , DataFormPublicTransport
                            , DataFormMeal, DataFormSubsis, DataFormHotel, DataFormLodging, DataFormMisc
                            , DataFormMealAid, DataFormTransportAid, DataAdvance){

    $scope.initLoad = function(){
    };
    
    $scope.claimGrandTotal = get2Float(0);
    $scope.claimGSTTotal = get2Float(0);
    $scope.claimNettTotal = get2Float(0);

    /**
     * Values in codeMap must exist in expenses.type_code DB Table
    */
    var MEAL                = {codeMap: 'MEAL', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};
    var MEAL_SUBSIS         = {codeMap: 'MEAL_SUBSIS', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};
    var ACCOMMODATION       = {codeMap: 'ACCOMMODATION', items: [], objFundType: '', objAmount: '', objGSTType: '', objGSTAmount: ''};
    var MILEAGE             = {codeMap: 'MILEAGE', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};
    var PUBLIC_TRANSPORT    = {codeMap: 'PUBLIC_TRANSPORT', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: 'gstType', objGSTAmount: 'gstAmount'};
    var MISC                = {codeMap: 'MISC', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};
    var REPLACEMENT_FEE     = {codeMap: 'REPLACEMENT_FEE', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: 'gstType', objGSTAmount: 'gstAmount'};
    var MEAL_AID            = {codeMap: 'MEAL_AID', items: [], objFundType: 'mealAidFundType', objAmount: 'mealAidTotalAmount', objGSTType: '', objGSTAmount: ''};
    var TRANSPORT_AID       = {codeMap: 'TRANSPORT_AID', items: [], objFundType: 'transportAidFundType', objAmount: 'transportAidTotalAmount', objGSTType: '', objGSTAmount: ''};

    /**
     * Separate these 2 as it always combined in  ACCOMMODATION
    */
    var HOTEL   = {codeMap: '', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: 'gstType', objGSTAmount: 'gstAmount'};
    var LODGING   = {codeMap: '', items: [], objFundType: 'lodgingFundType', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};

    ACCOMMODATION.itemsMix = [HOTEL, LODGING];

    /**
     * Set to display in Sub/Panel Summary
    */
    $scope.setOD    = [MEAL, ACCOMMODATION, MILEAGE, PUBLIC_TRANSPORT, MISC, REPLACEMENT_FEE];
    $scope.setLT    = [MEAL_SUBSIS, angular.copy(MEAL), angular.copy(ACCOMMODATION), MISC, angular.copy(REPLACEMENT_FEE)];
    $scope.setST    = [angular.copy(MEAL), angular.copy(MEAL_SUBSIS), angular.copy(ACCOMMODATION),
                       angular.copy(MILEAGE), angular.copy(PUBLIC_TRANSPORT), angular.copy(MISC),
                       angular.copy(REPLACEMENT_FEE)];
    $scope.setPT    = [MEAL_AID, TRANSPORT_AID];
    
    var getTrip = function(objName){
        var currSection = DataFormMain.getCurrSection();
        var trip = $scope.getActiveTrip(currSection);
        
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    };
    
    var extractReplacementFeeItems = function(items, isExtractOthers){
        replacements = [];
        others = [];
        if (items) {
            items.forEach(function(obj){
                var code = obj.publicTransportType.code;
                if (code == 'TrainReplacementFee' || code == 'AirplaneReplacementFee') {
                    replacements.push(obj);
                }else{
                    others.push(obj);
                }
            });
        }
        if (isExtractOthers) {
            return others;
        }else{
            return replacements;
        }
    }
    
    /* Start : Calculation */
        var updateGrandTotalOD = function(){
            DataFormMain.setCurrSection('OD');
            $scope.setOD[0].items = getTrip('mealItems');
            HOTEL.items = getTrip('hotelItems');
            LODGING.items = getTrip('lodgingItems');
            $scope.setOD[1].itemsMix = [HOTEL, LODGING];
            $scope.setOD[2].items = getTrip('mileageItems');
            $scope.setOD[3].items = extractReplacementFeeItems(getTrip('publicTransportItems'), true);
            $scope.setOD[4].items = getTrip('miscellaneousItems');
            $scope.setOD[5].items = extractReplacementFeeItems(getTrip('publicTransportItems'), false);
            loadSummary('OD');
            loadMasterSummary();
        };

        var updateGrandTotalLT = function(){
            DataFormMain.setCurrSection('LT');
            $scope.setLT[0].items = getTrip('subsisItems');
            //$scope.setLT[1].items = // Meal skip for now
            //$scope.setLT[2].items = // Accomodation skip for now
            $scope.setLT[3].items = getTrip('miscellaneousItems');
            //$scope.setLT[4].items = // Replacement Fee skip for now
            loadSummary('LT');
            loadMasterSummary();
        };

        var updateGrandTotalST = function(){
            DataFormMain.setCurrSection('ST');
            $scope.setST[0].items = getTrip('mealItems');
            $scope.setST[1].items = getTrip('subsisItems');
            HOTEL.items = getTrip('hotelItems');
            LODGING.items = getTrip('lodgingItems');
            $scope.setST[2].itemsMix = [HOTEL, LODGING];
            $scope.setST[3].items = getTrip('mileageItems');
            $scope.setST[4].items = extractReplacementFeeItems(getTrip('publicTransportItems'), true);
            $scope.setST[5].items = getTrip('miscellaneousItems');
            $scope.setOD[5].items = extractReplacementFeeItems(getTrip('publicTransportItems'), false);
            loadSummary('ST');
            loadMasterSummary();
        };

        var updateGrandTotalPT = function(){
            DataFormMain.setCurrSection('PT');
            $scope.setPT[0].items = DataFormMealAid.getMealAidPTItems();
            $scope.setPT[1].items = DataFormTransportAid.getTransportAidPTItems();
            loadSummary('PT');
            loadMasterSummary();
        };
    /* End : Calculation */

    /** Start : Summary Generator */
    var loadSummary = function(section){
        var expenses = [];
        var sets = [];
        
        trip = getTrip();
        
        if (section == 'OD') {
            expenses = $scope.expensesOD;
            sets = $scope.setOD;
        }else if (section == 'LT') {
            expenses = $scope.expensesLT;
            sets = $scope.setLT;
        }else if (section == 'ST') {
            expenses = $scope.expensesST;
            sets = $scope.setST;
        }else if (section == 'PT') {
            expenses = $scope.expensesPT;
            sets = $scope.setPT;
        }

        // Load grouped Fund Type for sub expenses summary
        expenses.forEach(function (obj) {
            obj.show = false;
            obj.amount = get2Float(0);
            obj.groupedFundType = [];

            sets.forEach(function (objSet) {
                var group = [];
                var amount = get2Float(0);

                if (obj.type_code == objSet.codeMap) {
                    if (objSet.itemsMix) {
                        var mixGroup = [];
                        objSet.itemsMix.forEach(function (objMix) {
                            mixGroup.push(getGroupedType(objMix.items, objMix.objFundType, objMix.objAmount));
                            if (objMix.items) {
                                amount = parseFloat(amount) + parseFloat(getListTotalAmount(objMix.items, objMix.objAmount));
                            }
                        });
                        group = getMixGroupedType(mixGroup);
                    }else{
                        if (objSet.items) {
                            group = getGroupedType(objSet.items, objSet.objFundType, objSet.objAmount);
                            amount = getListTotalAmount(objSet.items, objSet.objAmount);
                        }
                    }
                    angular.merge(obj, {show: true, amount: get2Float(amount), groupedFundType: group});
                }
            });
        });
        
        trip['expensesSummary'] = expenses;
        
        // Load grouped GST Type for sub expenses summary
        var groupedGSTType = [];

        sets.forEach(function (objSet) {
            var group = [];
            var amount = get2Float(0);

            if (objSet.itemsMix) {
                var mixGroup = [];
                objSet.itemsMix.forEach(function (objMix) {
                    mixGroup.push(getGroupedType(objMix.items, objMix.objGSTType, objMix.objGSTAmount));
                    if (objMix.items) {
                        amount = parseFloat(amount) + parseFloat(getListTotalAmount(objMix.items, objMix.objGSTAmount));
                    }
                });
                group = getMixGroupedType(mixGroup);
            }else{
                if (objSet.items) {
                    group = getGroupedType(objSet.items, objSet.objGSTType, objSet.objGSTAmount);
                    amount = getListTotalAmount(objSet.items, objSet.objGSTAmount);
                }
            }
            groupedGSTType.push(group);
        });

        var finalGroupedGSTType = getMixGroupedType(groupedGSTType);

        trip['gstSummary'] = finalGroupedGSTType;
    };
    
    var loadMasterSummary = function(){
        var claimGrandTotal = 0;
        var claimGSTTotal = 0;
        var claimNettTotal = 0;
        var masterExpensesSummary = [];
        var masterGSTSummary = [];
        var setMasterExpenses = [$scope.ODTrip, $scope.STTrip, $scope.LTTrip, $scope.PTTrip];

        setMasterExpenses.forEach(function(objMaster){
            objMaster.forEach(function(item){
                item.expensesSummary.forEach(function(objExpenses){
                    if (parseFloat(objExpenses.amount) > 0) {
                        masterExpensesSummary.push(objExpenses);
                    }
                });
                
                item.gstSummary.forEach(function(objExpenses){
                    if (parseFloat(objExpenses.amount) > 0) {
                        masterGSTSummary.push(objExpenses);
                    }
                });
            });
        });
        
        angular.merge($scope.masterExpensesSummary, getGroupedList(masterExpensesSummary, 'account_code', 'amount'));
        angular.merge($scope.masterGSTSummary, getGroupedList(masterGSTSummary, 'code', 'amount'));
        
        claimGrandTotal = getListTotalAmount(masterExpensesSummary, 'amount');
        claimGSTTotal = getListTotalAmount(masterGSTSummary, 'amount');
        claimNettTotal = parseFloat(claimGrandTotal) + parseFloat(claimGSTTotal);
        
        $scope.claimGrandTotal = claimGrandTotal;
        $scope.claimGSTTotal = claimGSTTotal;
        
        DataAdvance.setClaimGrandTotal(claimNettTotal);
    };
    /** End : Summary Generator */

    /* Start : Watch All OD Grand Total */
        $scope.$watch(function () { return DataFormMeal.getGrandTotalOD(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalOD(); }
        });
        $scope.$watch(function () { return DataFormHotel.getGrandTotalOD(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalOD(); }
        });
        $scope.$watch(function () { return DataFormLodging.getGrandTotalOD(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalOD(); }
        });
        $scope.$watch(function () { return DataFormMileage.getGrandTotalOD(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalOD(); }
        });
        $scope.$watch(function () { return DataFormPublicTransport.getGrandTotalOD(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalOD(); }
        });
        $scope.$watch(function () { return DataFormMisc.getGrandTotalOD(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalOD(); }
        });
    /* End : Watch All OD Grand Total */

    /* Start : Watch All LT Grand Total */
        $scope.$watch(function () { return DataFormSubsis.getGrandTotalLT(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalLT(); }
        });
        $scope.$watch(function () { return DataFormMisc.getGrandTotalLT(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalLT(); }
        });
    /* End : Watch All LT Grand Total */

    /* Start : Watch All ST Grand Total */
        $scope.$watch(function () { return DataFormMeal.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
        $scope.$watch(function () { return DataFormSubsis.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
        $scope.$watch(function () { return DataFormHotel.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
        $scope.$watch(function () { return DataFormLodging.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
        $scope.$watch(function () { return DataFormMileage.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
        $scope.$watch(function () { return DataFormPublicTransport.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
        $scope.$watch(function () { return DataFormMisc.getGrandTotalST(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalST(); }
        });
    /* End : Watch All ST Grand Total */

    /* Start : Watch All PT Grand Total */
        $scope.$watch(function () { return getListTotalAmount(DataFormMealAid.getMealAidPTItems(), 'mealAidTotalAmount'); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalPT(); }
        });

        $scope.$watch(function () { return DataFormTransportAid.getGrandTotalPT(); }, function (newValue, oldValue) {
            if (newValue != oldValue) { updateGrandTotalPT(); }
        });
    /* End : Watch All PT Grand Total */
});
/** Summary */

/********************
 *      SUBMIT      *
 ********************/
uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$filter', '$uibModal', '$http', '$window',
                                         'DataClaimant', 'DataFormMain', 'DataFormMileage',
                                         'DataFormPublicTransport', 'DataFormLodging', 'DataFormHotel',
                                         'DataFormMeal', 'DataFormMisc', 'DataFormSubsis',
                                         'DataFormMealAid', 'DataFormTransportAid', 'DataFormDoc', 'DataAdvance',
                                         'DataGLDistributions',
                                         function ($scope, $filter, $uibModal, $http, $window,
                                                   DataClaimant, DataFormMain, DataFormMileage,
                                                   DataFormPublicTransport, DataFormLodging, DataFormHotel,
                                                   DataFormMeal, DataFormMisc, DataFormSubsis, DataFormMealAid,
                                                   DataFormTransportAid, DataFormDoc, DataAdvance,
                                                   DataGLDistributions) {

	$scope.animationsEnabled = true;
    
	$scope.submit = function(btnMode) {
        glDistributions = {
            header: DataGLDistributions.getHeader(),
            details: DataGLDistributions.getDetails()
        };
        
		form_data = {
			btn_mode: btnMode,
            draft_id: $scope.draftID,
			claimant_no: DataClaimant.getStaffNo(),
            masterDetails: $scope.masterDetails,
            ODTrip: $scope.ODTrip,
            LTTrip: $scope.LTTrip,
            STTrip: $scope.STTrip,
            PTTrip: $scope.PTTrip,
            masterExpensesSummary: $scope.masterExpensesSummary,
            masterGSTSummary: $scope.masterGSTSummary,
            glDistributions: glDistributions
		}
        console.log(form_data);

        if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                } else {
                    if (btnMode == 'save_draft') {
                        $http({
                            url: URL_SAVE_DRAFT,
                            method: 'POST',
                            data: form_data
                        })
                        .success(function (data, status, headers, config) {
                            $uibModal.open({
                                animation: $scope.animationsEnabled,
                                templateUrl: 'SaveSuccess.html',
                                controller: 'ModalInstanceInfoCtrl',
                                size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
                                resolve: {
                                  data: function () {
                                    return data;
                                  }
                                }
                            });
                        });
                    }else if (btnMode == 'submit') {
                        $http({
                            url: URL_SUBMIT_CLAIM,
                            method: 'POST',
                            data: form_data
                        })
                        .success(function (data, status, headers, config) {
                            var submit_success_url = data.submit_success_url;
                            $window.location.href = submit_success_url;
                        });
                    }
                }
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};
}]);
/******************** End : SUBMIT ********************/
var calculateSet = function(sets, objName){
    var total = get2Float(0);
    sets.forEach(function (objSet) {
        if (objSet.itemsMix) {
            var mixGroup = [];
            objSet.itemsMix.forEach(function (objMix) {
                if (objMix.items) {
                    total = parseFloat(total) + parseFloat(getListTotalAmount(objMix.items, objMix[objName]));
                }
            });
        }else{
            if (objSet.items) {
                total = parseFloat(total) + parseFloat(getListTotalAmount(objSet.items, objSet[objName]));
            }
        }
    });
    return total;
};
