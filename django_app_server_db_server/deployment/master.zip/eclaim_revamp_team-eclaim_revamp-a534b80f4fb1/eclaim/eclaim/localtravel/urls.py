# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import LocalTravelIndexView, LocalTravelDraftView, LocalTravelDetailView

urlpatterns = patterns('',
    url(r'^$', LocalTravelIndexView.as_view(), name='localtravel_index'),
    url(r'^detail/$', LocalTravelDetailView.as_view(), name='localtravel_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', LocalTravelDraftView.as_view(), name='localtravel_draft')
)

urlpatterns += patterns(
    'eclaim.localtravel.ajax',

    url(r'^localtravel/save-draft/$', 'save_draft', name='localtravel_save_draft'),
    url(r'^localtravel/submit-claim/$', 'submit_claim', name='localtravel_submit_claim')
)