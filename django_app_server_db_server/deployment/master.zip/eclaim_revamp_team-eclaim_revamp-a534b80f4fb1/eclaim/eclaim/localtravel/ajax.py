import json
from django.utils.encoding import force_text
from django.core.urlresolvers import reverse_lazy
from django.http import HttpResponse, JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST, require_GET

from .processes import process_controller


@require_POST
@csrf_exempt
def save_draft(request):
    __MODE__ = 'DRAFT'
    data = json.loads(request.body)

    process_controller(__MODE__, data)

    return JsonResponse({'success': True})


@require_POST
@csrf_exempt
def submit_claim(request):
    __MODE__ = 'SUBMIT'
    data = json.loads(request.body)

    process_controller(__MODE__, data)

    response_data = {'success': True, 'submit_success_url': force_text(reverse_lazy('claim_list'))}
    return HttpResponse(json.dumps(response_data), content_type="application/json")
