import sys
import json
import datetime
from django.http import JsonResponse

from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.utils.common import (generate_claim_no, get_fund_type, get_gst_tax,
                                 get_claim_type_by_code, get_supporting_document)
from eclaim.utils.date import get_date_from_str
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.document import DocumentListItemDraft, DocumentListItem
from eclaim.masterfiles.utils import save_claimant_history
from eclaim.integrations.utils import process_gl_distribution
from .models import (LocalTravelClaimDraft, LocalTravelClaimDetailsDraft,
                     MealAidItemsDraft, TransportAidItemsDraft, MileageItemsDraft,
                     PublicTransportItemsDraft, MealItemsDraft, HotelItemsDraft,
                     LodgingItemsDraft, SubsistenceItemsDraft, MiscellaneousItemsDraft,
                     MealDistributionsDraft, MealAidDistributionsDraft,
                     TransportAidDistributionsDraft, SubsistenceDistributionsDraft,
                     LocalTravelClaim, LocalTravelClaimDetails,
                     MealAidItems, TransportAidItems, MileageItems, PublicTransportItems,
                     MealItems, HotelItems, LodgingItems, SubsistenceItems,
                     MiscellaneousItems, MealDistributions, MealAidDistributions,
                     TransportAidDistributions, SubsistenceDistributions)


def process_controller(MODE, form_data):
    claimant_no = form_data.get('claimant_no')
    draft_id = form_data.get('draft_id')
    claim_id = form_data.get('claim_id')
    is_new = False

    # MODE = DRAFT @ SUBMIT

    claim_details = None
    if MODE == 'DRAFT':
        if draft_id:
            try:
                claim = LocalTravelClaimDraft.objects.get(id=draft_id)
                claim_details = LocalTravelClaimDetailsDraft.objects.filter(claim_draft=claim)
            except LocalTravelClaimDraft.DoesNotExist:
                is_new = True
                claim = LocalTravelClaimDraft()
        else:
            is_new = True
            claim = LocalTravelClaimDraft()
    elif MODE == 'SUBMIT':
        if claim_id:
            try:
                claim = LocalTravelClaim.objects.get(id=claim_id)
                claim_details = LocalTravelClaimDetails.objects.filter(claim=claim)
            except LocalTravelClaim.DoesNotExist:
                is_new = True
                claim = LocalTravelClaim()
        else:
            is_new = True
            claim = LocalTravelClaim()

    claim.status = 'D'
    claim.claim_month = get_date_from_str(form_data['masterDetails'].get('claimMonthTxt'))
    claim.travel_date_from = get_date_from_str(form_data['masterDetails'].get('ltcFromDateTxt'))
    claim.travel_date_to = get_date_from_str(form_data['masterDetails'].get('ltcToDateTxt'))
    claim.save()

    delete_list = []

    if not is_new:
        # Collecting old form_data
        for i in claim_details:
            delete_list.append(i.id)

    od_form_data = form_data['ODTrip'][0]
    save_ltc_details(MODE, claim, od_form_data)

    lt_form_data = form_data['LTTrip'][0]
    save_ltc_details(MODE, claim, lt_form_data)

    st_form_data = form_data['STTrip'][0]
    save_ltc_details(MODE, claim, st_form_data)

    pt_form_data = form_data['PTTrip'][0]
    save_ltc_details(MODE, claim, pt_form_data)

    if is_new:
        # Extra process if needed put here'
        pass
    else:
        if delete_list:
            # If all complete, delete old form_data
            for i in delete_list:
                objDelete = claim_details.filter(id=i)
                objDelete.delete()

    if MODE == 'DRAFT':
        # Save claimant history
        save_claimant_history(claimant_no, claim.id, 'LTC')

        # Generate gl distributions
        process_gl_distribution('LTC', claim.id,
                                form_data['masterExpensesSummary'],
                                form_data['glDistributions'])

    if (MODE == 'SUBMIT' and is_new):

        # Generate & save no_claim
        type_id, prefix = get_claim_type_by_code('LTC')
        claim.claim_no = generate_claim_no(prefix, claim.id)
        claim.save()

        # Send a claim to workflow.
        try:
            claimant = Claimant.objects.get(staff_no=claimant_no)
        except Claimant.DoesNotExist:
            claimant = None

        if claimant is not None:
            save_claimant_history(claimant_no, claim.id, 'LTC')

            try:
                create_new_states(claimant, LocalTravelClaim, claim.id)
            except:
                raise

            # Assign a selected claimant as a next level approver.
            staff_no = form_data.get('assignee')
            if staff_no:
                assigned = Claimant.objects.get(pk=staff_no)
                create_selected_assignee(assigned, LocalTravelClaim, claim.id,
                                         new_claim=True)


def save_ltc_details(MODE, parent, form_data):
    activity_type = form_data.get('activityType')
    travel_date_from = form_data.get('fromDateTxt')
    travel_date_to = form_data.get('toDateTxt')

    if travel_date_from and travel_date_to:
        if MODE == 'DRAFT':
            ltc_details = LocalTravelClaimDetailsDraft()
            ltc_details.claim_draft = parent
        else:
            ltc_details = LocalTravelClaimDetails()
            ltc_details.claim = parent

        ltc_details.activitiy_type = activity_type
        ltc_details.travel_date_from = get_date_from_str(travel_date_from)
        ltc_details.travel_date_to = get_date_from_str(travel_date_to)
        ltc_details.save()
        save_all_items(MODE, ltc_details, form_data)


def save_all_items(MODE, parent, form_data):
    save_mileage_items(MODE, parent, form_data)
    save_public_transport_items(MODE, parent, form_data)
    save_meal_items(MODE, parent, form_data)
    save_hotel_items(MODE, parent, form_data)
    save_lodging_items(MODE, parent, form_data)
    save_miscellaneous_items(MODE, parent, form_data)

    # Subsis should only available for LT, ST
    save_subsistence_items(MODE, parent, form_data)
    save_transport_aid_items(MODE, parent, form_data)

    # Meal Aid & Transport Aid should only available for PT
    save_meal_aid_items(MODE, parent, form_data)

    save_supporting_documents(MODE, parent, form_data)


def save_mileage_items(MODE, parent, form_data):
    items = form_data.get('mileageItems')

    if items:
        for i in items:
            depart_date = get_date_from_str(i.get('departDateTxt'))
            return_date = get_date_from_str(i.get('returnDateTxt'))
            depart_time = i.get('departTimeTxt')
            return_time = i.get('returnTimeTxt')
            destination_from = i.get('destinationFrom')
            destination_to = i.get('destinationTo')
            travelling_info = i.get('description')
            vehicle_type = i.get('vehicleType')
            vehicle_cc = i.get('vehicleCC')
            vehicle_reg_no = i.get('vehicleRegistrationNo')
            mileage = i.get('mileage')
            amount = i.get('grossAmount')
            corporate_card = i.get('corporateCard')
            fund_type = i.get('fundType')
            project_code = i.get('projectCode')

            if MODE == 'DRAFT':
                objSave = MileageItemsDraft()
            else:
                objSave = MileageItems()

            objSave.claim_detail = parent
            objSave.depart_date = depart_date
            objSave.return_date = return_date
            objSave.depart_time = depart_time
            objSave.return_time = return_time
            objSave.destination_from = destination_from
            objSave.destination_to = destination_to
            if travelling_info:
                objSave.travelling_info = travelling_info
            if vehicle_type:
                objSave.vehicle_type = vehicle_type.get('id')
            if vehicle_cc:
                objSave.vehicle_cc = vehicle_cc.get('code')
            if vehicle_reg_no:
                objSave.vehicle_reg_no = vehicle_reg_no
            objSave.mileage = mileage
            objSave.amount = amount
            objSave.corporate_card = corporate_card
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()


def save_public_transport_items(MODE, parent, form_data):
    items = form_data.get('publicTransportItems')

    if items:
        for i in items:
            depart_date = get_date_from_str(i.get('departDateTxt'))
            depart_time = i.get('departTimeTxt')
            return_date = get_date_from_str(i.get('returnDateTxt'))
            return_time = i.get('returnTimeTxt')
            destination_from = i.get('destinationFrom')
            destination_to = i.get('destinationTo')
            travelling_info = i.get('description')
            type = i.get('publicTransportType')
            receipt_no = i.get('receiptNo')
            amount = i.get('grossAmount')
            gst_tax = i.get('gstType')
            gst_amount = i.get('gstAmount')
            nett_amount = i.get('nettAmount')
            corporate_card = i.get('corporateCard')
            fund_type = i.get('fundType')
            project_code = i.get('projectCode')

            if MODE == 'DRAFT':
                objSave = PublicTransportItemsDraft()
            else:
                objSave = PublicTransportItems()

            objSave.claim_detail = parent
            objSave.depart_date = depart_date
            objSave.depart_time = depart_time
            objSave.return_date = return_date
            objSave.return_time = return_time
            objSave.destination_from = destination_from
            objSave.destination_to = destination_to
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.type = type.get('code')
            objSave.receipt_no = receipt_no
            objSave.amount = amount
            objSave.gst_tax = get_gst_tax(gst_tax.get('code'))
            objSave.gst_amount = gst_amount
            objSave.nett_amount = nett_amount
            objSave.corporate_card = corporate_card
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()


def save_meal_items(MODE, parent, form_data):
    items = form_data.get('mealItems')

    if items:
        for i in items:
            depart_date = get_date_from_str(i.get('departDateTxt'))
            depart_time = i.get('departTimeTxt')
            return_date = get_date_from_str(i.get('returnDateTxt'))
            return_time = i.get('returnTimeTxt')
            region_destination = i.get('regionDestination')
            travelling_info = i.get('description')
            chk_meal_distribution = i.get('chkDistribution')
            meal_distributions = i.get('mealDistribution')
            int_meal_allowance = i.get('intMeal')
            if not int_meal_allowance:
                int_meal_allowance = 0
            int_daily_allowance = i.get('intDaily')
            if not int_daily_allowance:
                int_daily_allowance = 0
            meal_amount = i.get('mealAmount')
            daily_amount = i.get('dailyAmount')
            amount = i.get('grossAmount')
            fund_type = i.get('fundType')
            project_code = i.get('projectCode')

            if MODE == 'DRAFT':
                objSave = MealItemsDraft()
            else:
                objSave = MealItems()

            objSave.claim_detail = parent
            objSave.depart_date = depart_date
            objSave.depart_time = depart_time
            objSave.return_date = return_date
            objSave.return_time = return_time
            objSave.region_destination = region_destination.get('code')
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.chk_meal_distribution = chk_meal_distribution
            objSave.int_meal_allowance = int_meal_allowance
            objSave.int_daily_allowance = int_daily_allowance
            objSave.meal_amount = meal_amount
            objSave.daily_amount = daily_amount
            objSave.amount = amount
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()
            save_meal_distributions(MODE, objSave, meal_distributions)


def save_meal_distributions(MODE, parent, distributions):
    if distributions:
        for i in distributions:
            date = i.get('date')
            breakfast = i.get('breakfast')
            lunch = i.get('lunch')
            dinner = i.get('dinner')

            if MODE == 'DRAFT':
                objSave = MealDistributionsDraft()
            else:
                objSave = MealDistributions()

            objSave.meal_item = parent
            objSave.date = get_date_from_str(date)
            objSave.breakfast = breakfast
            objSave.lunch = lunch
            objSave.dinner = dinner
            objSave.save()


def save_hotel_items(MODE, parent, form_data):
    items = form_data.get('hotelItems')

    if items:
        for i in items:
            check_in_date = get_date_from_str(i.get('checkinDateTxt'))
            check_out_date = get_date_from_str(i.get('checkoutDateTxt'))
            region_destination = i.get('regionDestination')
            travelling_info = i.get('description')
            receipt_no = i.get('receiptNo')
            room_price = i.get('roomPrice')
            service_charge = i.get('serviceCharge')
            perday_amount = i.get('totalRoomPrice')
            int_days = i.get('totalDays')
            amount = i.get('grossAmount')
            gst_tax = i.get('gstType')
            gst_amount = i.get('gstAmount')
            nett_amount = i.get('nettAmount')
            corporate_card = i.get('corporateCard')
            fund_type = i.get('fundType')
            project_code = i.get('projectCode')

            if MODE == 'DRAFT':
                objSave = HotelItemsDraft()
            else:
                objSave = HotelItems()

            objSave.claim_detail = parent
            objSave.check_in_date = check_in_date
            objSave.check_out_date = check_out_date
            objSave.region_destination = region_destination.get('code')
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.receipt_no = receipt_no
            objSave.room_price = room_price
            objSave.service_charge = service_charge
            objSave.perday_amount = perday_amount
            objSave.int_days = int_days
            objSave.amount = amount
            objSave.gst_tax = get_gst_tax(gst_tax.get('code'))
            objSave.gst_amount = gst_amount
            objSave.nett_amount = nett_amount
            objSave.corporate_card = corporate_card
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()


def save_lodging_items(MODE, parent, form_data):
    items = form_data.get('lodgingItems')
    if items:
        for i in items:
            check_in_date = get_date_from_str(i.get('checkinDateTxt'))
            check_out_date = get_date_from_str(i.get('checkoutDateTxt'))
            region_destination = i.get('regionDestination')
            travelling_info = i.get('description')
            address = i.get('lodgingAddress')
            int_days = i.get('totalDays')
            amount = i.get('grossAmount')
            fund_type = i.get('lodgingFundType')
            project_code = i.get('lodgingProjectCode')

            if MODE == 'DRAFT':
                objSave = LodgingItemsDraft()
            else:
                objSave = LodgingItems()

            objSave.claim_detail = parent
            objSave.check_in_date = check_in_date
            objSave.check_out_date = check_out_date
            objSave.region_destination = region_destination.get('code')
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.address = address
            objSave.int_days = int_days
            objSave.amount = amount
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()


def save_miscellaneous_items(MODE, parent, form_data):
    items = form_data.get('miscellaneousItems')
    if items:
        for i in items:
            date = get_date_from_str(i.get('dateTxt'))
            type = i.get('miscType')
            receipt_no = i.get('receiptNo')
            amount = i.get('grossAmount')
            fund_type = i.get('fundType')
            project_code = i.get('projectCode')
            corporate_card = i.get('corporateCard')

            if MODE == 'DRAFT':
                objSave = MiscellaneousItemsDraft()
            else:
                objSave = MiscellaneousItems()

            objSave.claim_detail = parent
            objSave.date = date
            objSave.type = type.get('code')
            objSave.receipt_no = receipt_no
            objSave.amount = amount
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.corporate_card = corporate_card
            objSave.save()


def save_subsistence_items(MODE, parent, form_data):
    items = form_data.get('subsisItems')
    if items:
        for i in items:
            depart_date = get_date_from_str(i.get('departDateTxt'))
            return_date = get_date_from_str(i.get('returnDateTxt'))
            course_location = i.get('courseLocation')
            travelling_info = i.get('travellingInfo')
            chk_substitution = i.get('chkSubstitute')
            subsis_distributions = i.get('mealSubstitution')
            chk_meal = i.get('chkMeal')
            chk_hotel = i.get('chkHotel')
            chk_lodging = i.get('chkLodging')
            int_days = i.get('totalDays')
            amount = i.get('grossAmount')
            amount_meal = i.get('mealAmount')
            amount_accommodation = i.get('accommodationAmount')
            fund_type = i.get('fundType')
            project_code = i.get('projectCode')

            if MODE == 'DRAFT':
                objSave = SubsistenceItemsDraft()
            else:
                objSave = SubsistenceItems()

            objSave.claim_detail = parent
            objSave.depart_date = depart_date
            objSave.return_date = return_date
            objSave.course_location = course_location.get('code')
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.chk_substitution = chk_substitution
            objSave.chk_meal = chk_meal
            objSave.chk_hotel = chk_hotel
            objSave.chk_lodging = chk_lodging
            objSave.int_days = int_days
            objSave.amount = amount
            objSave.amount_meal = amount_meal
            objSave.amount_accommodation = amount_accommodation
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()
            save_subsistence_distributions(MODE, objSave, subsis_distributions)


def save_subsistence_distributions(MODE, parent, distributions):
    if distributions:
        for i in distributions:
            date = i.get('date')
            chk_meal = i.get('chkMeal')
            chk_accommodation = i.get('chkAccommodation')

            if MODE == 'DRAFT':
                objSave = SubsistenceDistributionsDraft()
            else:
                objSave = SubsistenceDistributions()

            objSave.subsistence_item = parent
            objSave.date = get_date_from_str(date)
            objSave.chk_meal = chk_meal
            objSave.chk_accommodation = chk_accommodation
            objSave.save()


def save_meal_aid_items(MODE, parent, form_data):
    items = form_data.get('mealaid_items')
    if items:
        for i in items:
            depart_date = get_date_from_str(i.get('mealAidDepartDateTxt'))
            return_date = get_date_from_str(i.get('mealAidReturnDateTxt'))
            course_location = i.get('mealAidCourseLocation')
            travelling_info = i.get('mealAidTravellingInfo')
            chk_meal_distribution = i.get('mealAidChkDistribution')
            meal_aid_distributions = i.get('mealAidDistribution')
            int_days = i.get('mealAidIntTotalDays')
            amount = i.get('mealAidTotalAmount')
            fund_type = i.get('mealAidFundType')
            project_code = i.get('mealAidProjectCode')

            if MODE == 'DRAFT':
                objSave = MealAidItemsDraft()
            else:
                objSave = MealAidItems()

            objSave.claim_detail = parent
            objSave.depart_date = depart_date
            objSave.return_date = return_date
            objSave.course_location = course_location.get('code')
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.chk_meal_distribution = chk_meal_distribution
            objSave.int_days = int_days
            objSave.amount = amount
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()
            save_meal_aid_distributions(MODE, objSave, meal_aid_distributions)


def save_meal_aid_distributions(MODE, parent, distributions):
    if distributions:
        for i in distributions:
            date = i.get('date')
            meal_aid = i.get('mealAid')

            if MODE == 'DRAFT':
                objSave = MealAidDistributionsDraft()
            else:
                objSave = MealAidDistributions()

            objSave.meal_aid_item = parent
            objSave.date = get_date_from_str(date)
            objSave.meal_aid = meal_aid
            objSave.save()


def save_transport_aid_items(MODE, parent, form_data):
    items = form_data.get('transportaid_items')

    if items:
        for i in items:
            depart_date = get_date_from_str(i.get('transportAidDepartDateTxt'))
            return_date = get_date_from_str(i.get('transportAidReturnDateTxt'))
            course_location = i.get('transportAidCourseLocation')
            travelling_info = i.get('transportAidTravellingInfo')
            chk_transport_distribution = i.get('transportAidChkDistribution')
            transport_aid_distributions = i.get('transportAidDistribution')
            int_days = i.get('transportAidIntTotalDays')
            amount = i.get('transportAidTotalAmount')
            fund_type = i.get('transportAidFundType')
            project_code = i.get('transportAidProjectCode')

            if MODE == 'DRAFT':
                objSave = TransportAidItemsDraft()
            else:
                objSave = TransportAidItems()

            objSave.claim_detail = parent
            objSave.depart_date = depart_date
            objSave.return_date = return_date
            objSave.course_location = course_location.get('code')
            if travelling_info:
                objSave.travelling_info = travelling_info
            objSave.chk_transport_distribution = chk_transport_distribution
            objSave.int_days = int_days
            objSave.amount = amount
            objSave.fund_type = get_fund_type(fund_type.get('code'))
            objSave.project_code = project_code
            objSave.save()
            save_transport_aid_distributions(MODE, objSave, transport_aid_distributions)


def save_transport_aid_distributions(MODE, parent, distributions):
    if distributions:
        for i in distributions:
            date = i.get('date')
            transport_aid = i.get('transportAid')

            if MODE == 'DRAFT':
                objSave = TransportAidDistributionsDraft()
            else:
                objSave = TransportAidDistributions()

            objSave.transport_aid_item = parent
            objSave.date = get_date_from_str(date)
            objSave.transport_aid = transport_aid
            objSave.save()


def save_supporting_documents(MODE, parent, form_data):
    items = form_data.get('supportingDocuments')
    if items:
        for i in items:
            doc = i.get('doc')
            if doc:
                doc_id = doc.get('id')

            if MODE == 'DRAFT':
                objSave = DocumentListItemDraft()
                objSave.draft_id = parent.claim_draft.id
            else:
                objSave = DocumentListItem()
                objSave.claim_no = parent.claim.id

            objSave.sub_group_id = parent.id
            objSave.claim_type = 'LTC'
            objSave.document_list = get_supporting_document(doc_id)
            objSave.save()
