import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text

from eclaim.auth.authenticate import Authenticate
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.misc import (VEHICLE_CC_LIST, PUBLIC_TRANSPORT_LIST, REGION_LIST, COURSE_LOCATION_LIST
                                            , MISC_EXPENSES_LIST)
from eclaim.masterfiles.entitlements import get_json_inmalaysia_trip_ent
from eclaim.masterfiles.models.document import DocumentListItemDraft
from eclaim.utils.common import get_json_from_list, get_json_from_set_obj, get_config, get_json_vehiclecc_mileage_rates
from .models import LocalTravelClaimDraft, LocalTravelClaimDetailsDraft, MealAidItemsDraft, TransportAidItemsDraft \
                    , MileageItemsDraft, PublicTransportItemsDraft, MealItemsDraft, HotelItemsDraft, LodgingItemsDraft \
                    , SubsistenceItemsDraft, MiscellaneousItemsDraft


class LocalTravelIndexView(TemplateView):
    """
    This is index page for Local Travel Claims.
    """
    template_name = 'localtravel/localtravel_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(LocalTravelIndexView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        context = super(LocalTravelIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        if claimant:
            context['claimant'] = claimant
            context['jsonVehicleCCList'] = get_json_vehiclecc_mileage_rates(claimant.basic_salary)

        context['jsonPublicTransportList'] = get_json_from_list(PUBLIC_TRANSPORT_LIST)
        context['jsonRegionList'] = get_json_from_list(REGION_LIST)
        context['jsonCourseLocationList'] = get_json_from_list(COURSE_LOCATION_LIST)
        context['jsonMiscExpensesList'] = get_json_from_list(MISC_EXPENSES_LIST)

        config = {}
        config.update({'VEHICLETYPE': get_config('VEHICLETYPE')})
        context['config'] = get_json_from_list(config)
        
        return context


class LocalTravelDraftView(TemplateView):
    template_name = 'localtravel/localtravel_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(LocalTravelDraftView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')
        
    def get_context_data(self, **kwargs):
        context = super(LocalTravelDraftView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        if claimant:
            context['claimant'] = claimant
            context['jsonVehicleCCList'] = get_json_vehiclecc_mileage_rates(claimant.basic_salary)

        context['jsonPublicTransportList'] = get_json_from_list(PUBLIC_TRANSPORT_LIST)
        context['jsonRegionList'] = get_json_from_list(REGION_LIST)
        context['jsonCourseLocationList'] = get_json_from_list(COURSE_LOCATION_LIST)
        context['jsonMiscExpensesList'] = get_json_from_list(MISC_EXPENSES_LIST)

        config = {}
        config.update({'VEHICLETYPE': get_config('VEHICLETYPE')})
        context['config'] = get_json_from_list(config)
        
        draft_id = self.kwargs['draft_id']
        context['draftID'] = draft_id
        context['claimID'] = ''
        return context


class LocalTravelDetailView(TemplateView):
    template_name = 'localtravel/localtravel_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(LocalTravelDetailView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')
        
    def get_context_data(self, **kwargs):
        context = super(LocalTravelDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        if claimant:
            context['claimant'] = claimant
            context['jsonVehicleCCList'] = get_json_vehiclecc_mileage_rates(claimant.basic_salary)

        context['jsonPublicTransportList'] = get_json_from_list(PUBLIC_TRANSPORT_LIST)
        context['jsonRegionList'] = get_json_from_list(REGION_LIST)
        context['jsonCourseLocationList'] = get_json_from_list(COURSE_LOCATION_LIST)
        context['jsonMiscExpensesList'] = get_json_from_list(MISC_EXPENSES_LIST)

        config = {}
        config.update({'VEHICLETYPE': get_config('VEHICLETYPE')})
        context['config'] = get_json_from_list(config)
        
        obj_pk = self.request.GET['pk']
        context['draftID'] = ''
        context['claimID'] = obj_pk
        return context