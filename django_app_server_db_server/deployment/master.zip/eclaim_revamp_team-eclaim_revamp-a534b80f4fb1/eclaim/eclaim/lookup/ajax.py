from django.core import serializers
from django.http import HttpResponse, JsonResponse

from eclaim.advance.models import OpenAdvance


def lookup_advance(request):
    result = []
    ptj = OpenAdvance.objects.filter(reference_no__icontains=request.GET['advanceNo'])
    for i in ptj:
        result.append({'reference_no':i.reference_no, 'balance_amount':i.balance_amount})
    return JsonResponse(result, safe=False)