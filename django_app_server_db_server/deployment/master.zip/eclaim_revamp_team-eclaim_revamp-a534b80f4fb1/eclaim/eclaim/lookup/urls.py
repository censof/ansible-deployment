# from Django
from django.conf.urls import patterns, url

# from eClaim
from .ajax import lookup_advance

urlpatterns = patterns('',
    url(r'^lookup-advance', lookup_advance, name='lookup_advance'),
)