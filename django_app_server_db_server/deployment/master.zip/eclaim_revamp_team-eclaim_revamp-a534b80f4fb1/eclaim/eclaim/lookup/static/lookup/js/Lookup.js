console.log('Lookup JS Loaded!!!');

uiBootstrapApp.controller('LookupCtrl', function ($scope, $http, DataLookup) {
    $scope.projectCode = '';
    $scope.isDisabled = true;
    
    
    $scope.getProjectCode = function(obj){
        return $http.get('/eclaim/lookup_project/?projectCode='+obj).then(function(data) {
            return data.data;
        });
    };
    
    $scope.$watch('projectCode',function() {
        DataLookup.setProjectCode($scope.projectCode);
    });
    
    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.projectCode = newValue;
        }
    });
    
    $scope.$watch(function () { return DataLookup.getDisabled(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.isDisabled = newValue;
            if (newValue) {
                $scope.projectCode = '';
                DataLookup.setProjectCode('');
            }
        }
    });
});

uiBootstrapApp.factory('DataLookup', function () {
    var data = {
        ProjectCode:'',
        Disabled:true,
    };

    return {
        getProjectCode: function () {
            return data.ProjectCode;
        },
        setProjectCode: function (obj) {
            data.ProjectCode = obj;
        },
        getDisabled: function () {
            return data.Disabled;
        },
        setDisabled: function (val) {
            data.Disabled = val;
        }
    };
});