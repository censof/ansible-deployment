from django.core import serializers
from django.http import HttpResponse, JsonResponse

def lookup_project(request):
    result = []
    ptj = PTJ.objects.filter(code__icontains=request.GET['projectCode'])
    for i in ptj:
        result.append({'code':i.code, 'description':i.description})
    return JsonResponse(result, safe=False)