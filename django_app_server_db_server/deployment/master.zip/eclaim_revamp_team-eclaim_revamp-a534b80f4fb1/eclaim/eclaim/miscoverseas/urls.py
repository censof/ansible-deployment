# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import MiscoverseasIndexView, MiscoverseasDetailView, MiscoverseasDraftView

urlpatterns = patterns('',
    url(r'^miscoverseas/$', MiscoverseasIndexView.as_view(), name='miscoverseas_index'),
    url(r'^miscoverseas/detail/$', MiscoverseasDetailView.as_view(), name='miscoverseas_detail'),
    url(r'^miscoverseas/draft/(?P<draft_id>[0-9]+)/$', MiscoverseasDraftView.as_view(), name='miscoverseas_draft')
)
