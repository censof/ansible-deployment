from decimal import *
from django.utils import timezone
from eclaim.masterfiles.models.misc import FundType, MiscellaneousType
from eclaim.masterfiles.common import CLAIM_TYPE
from eclaim.masterfiles.utils import save_claimant_history
from eclaim.utils.common import generate_claim_no
from .models import *


__ClaimType__ = CLAIM_TYPE.OMISC
__ClaimNoPrefix__ = CLAIM_TYPE.MiscoverseasNoPrefix


def process_controller(form_data):
    claim_id = None

    if form_data.get('btn_mode') in ['save_draft']:
        save_draft(form_data)

    elif form_data.get('btn_mode') in ['submit']:
        claim_id = submit_claim(form_data)

    return claim_id

def save_draft(form_data):
    draft_id = form_data.get('draft_id')

    if draft_id == '':
        claim_draft = MiscoverseasClaimDraft()
    else:
        claim_draft = MiscoverseasClaimDraft(id=int(draft_id))
        delete_miscoverseas_claim_draft_item(claim_draft)

    claim_draft.status = 'D'
    claim_draft.save()
    save_miscoverseas_claim_item('save_draft', claim_draft, form_data)
    #save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)

def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')

    claim = MiscoverseasClaim()
    claim.status = 'S'
    claim.save()
    claim.claim_no = generate_claim_no(__ClaimNoPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_miscoverseas_claim_item('submit_claim', claim, form_data)
    #save_document_list_item(claim.claim_no, __ClaimType__, form_data)
    return claim.id

def save_miscoverseas_claim_item(mode, parent, form_data):

    for obj in form_data.get('miscoverseasItems'):

        if mode in ['save_draft']:
            saveObj = MiscoverseasClaimItemDraft()
            saveObj.miscoverseasClaimDraft = parent
            saveObj.miscoverseasClaimDraft.modified = timezone.now()
            saveObj.miscoverseasClaimDraft.save()

        elif mode in ['submit_claim']:
            saveObj = MiscoverseasClaimItem()
            saveObj.miscoverseasClaim = parent
            saveObj.miscoverseasClaim.modified = timezone.now()
            saveObj.miscoverseasClaim.save()

        saveObj.date = obj['date']
        saveObj.receiptNumber = obj['receiptNumber']
        saveObj.expensesType = MiscellaneousType.objects.get(code= obj['expensesType'].get('code'))
        saveObj.fundType = FundType.objects.get(code= obj['fundType'].get('code'))
        saveObj.projectCode = obj['projectCode']
        saveObj.expenseDetails = obj['expenseDetails']
        saveObj.country = obj['country']
        saveObj.currencyType = obj['currencyType']
        saveObj.exchangeRate = obj['exchangeRate']
        saveObj.amountForeignCrncy = obj['amountForeignCrncy']
        saveObj.totalPrice = obj['totalPrice']
        saveObj.save()

def delete_miscoverseas_claim_draft_item(parent):
    delObj = MiscoverseasClaimItemDraft.objects.filter(miscellaneousClaimDraft=parent)
    delObj.delete()
