console.log('miscoverseas App Loaded!!!');

uiBootstrapApp.controller('miscoverseasClaimCtrl', function ($scope, $http) {

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;
    $scope.panel = {};
    $scope.panel.p2 = true;

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel.p1 = true;
        $scope.panel.p2 = true;
        $scope.panel.p3 = true;
        $scope.panel.p4 = true;
        $scope.panel.p5 = true;
        $scope.panel.p6 = true;
        $scope.panel.p7 = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel.p1 = false;
        $scope.panel.p2 = false;
        $scope.panel.p3 = false;
        $scope.panel.p4 = false;
        $scope.panel.p5 = false;
        $scope.panel.p6 = false;
        $scope.panel.p7 = false;
    };
    /*************** Accordion End ***************/

    /**
     * Detail view
     */
    if (PK) {
        // Initialize variables.
        $scope.viewClaim = false;
        $scope.grandColspan = 9;

        $http({
            url: API_URL+'miscoverseas-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            // Add a form declaration to the scope.
            add_form_declaration($scope, 8, data.current_level_ordering);
        });
    } else {
        $scope.viewClaim = true;
        $scope.grandColspan = 10;

        // Add a form declaration to the scope.
        add_form_declaration($scope, 22, 1);
    }

    var claim_api_url = API_URL+'miscoverseas-claims/';
    init_workflow($scope, $http, 'miscoverseas', 'MiscoverseasClaim', PK, claim_api_url, WF_TEMPLATE);

});

uiBootstrapApp.controller('miscellaneousLocalClaimCtrl', function ($scope, $q, $http, DataFundType, DataLookup, DataClaimant, MiscellaneousLocalData) {
    $scope.ng_form = {};
    $scope.expenditure_list = [];
    $scope.fundType_list = [];
    $scope.miscClaimList = [];
    $scope.ng_form.expenditure = {};
    $scope.isEmptyTable = true;
    $scope.grandTotal = 0;
    MiscellaneousLocalData.setClaimantNo($scope.claimant_no);
    var indxOfChangedItem;
    $scope.ng_form.exch_rate = 0;
    $scope.unitInForeignCurr = '';
    $scope.ng_form.totalInRM = 0;
    $scope.ng_form.ngDescription = '';

    var _promises = {};

    _promises['misc_type'] =
        $http({
            url: API_URL+'miscellaneous-type/',
            method: 'GET'
        });

    _promises['fund_type'] =
        $http({
            url: API_URL+'fund-type/',
            method: 'GET'
        });

    if(PK){
        _promises['claim_details'] =
            $http({
                url: API_URL+'miscoverseas-claims/'+PK+'/',
                method: 'GET'
            });
    }

    $q.all(_promises).then(function (resolutions) {
        var _expenditure_list = resolutions.misc_type.data.results;
        for (var i=0; i<_expenditure_list.length; i++){
            if(_expenditure_list[i].claim_type == 'Misc')
                $scope.expenditure_list.push(_expenditure_list[i]);
        }
    });

    $scope.getDraft_id = function(draft_id){

        $q.all(_promises).then(function (resolutions) {
                // Misc type
            if($scope.expenditure_list.length<1){
                var _expenditure_list = resolutions.misc_type.data.results;
                for (var i=0; i<_expenditure_list.length; i++){
                    if(_expenditure_list[i].claim_type == 'Misc'){
                        $scope.expenditure_list.push(_expenditure_list[i]);
                    }
                }
            }
            // Fund type
            $scope.fundType_list = resolutions.fund_type.data.results;

            //claim details
            if(PK)
                $scope.claim_details = resolutions.claim_details.data.results;

            if(draft_id){
                $http({
                        url: API_URL+'miscoverseas-claim-drafts/'+draft_id+'/',
                        method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    MiscellaneousLocalData.setMiscellaneousItems(data.items);
                    takeItems();
                });
            }else{
                if(PK){
                    MiscellaneousLocalData.setMiscellaneousItems($scope.claim.items);
                    takeItems();
                }
            }
        });
    }

    function takeItems(){
        $scope.miscClaimList = MiscellaneousLocalData.getMiscellaneousItems();
        if($scope.miscClaimList.length)
            $scope.isEmptyTable = false;
        $scope.grandTotal = getGrandTotal();

        for(var i=0; i<$scope.miscClaimList.length; i++){

            $scope.miscClaimList[i].dateToUpdate = getDateFromStr($scope.miscClaimList[i].date);

            for (var ft=0; ft<$scope.fundType_list.length; ft++){
                if ($scope.miscClaimList[i].fundType_id == $scope.fundType_list[ft].code){
                    $scope.miscClaimList[i].fundType = $scope.fundType_list[ft];
                }
            }

            for (var ex=0; ex<$scope.expenditure_list.length; ex++){
                if ($scope.miscClaimList[i].expensesType_id == $scope.expenditure_list[ex].id){
                    $scope.miscClaimList[i].expensesType = $scope.expenditure_list[ex];
                }
            }
        }
    }

    $scope.getToUpdate = function(indx){
        var currentItem = $scope.miscClaimList[indx];
        $scope.openModal();
        $scope.btnUpdate = true;
        $scope.totalPrice = 0;
        indxOfChangedItem = indx;

        MiscellaneousLocalData.setDate(currentItem.dateToUpdate);
        $scope.ng_form.ngReceipt = currentItem.receiptNumber;
        $scope.ng_form.expenditure = currentItem.expensesType;
        DataFundType.setFundType(currentItem.fundType);
        DataLookup.setProjectCode(currentItem.projectCode);
        $scope.ng_form.ngClinicName = currentItem.clinicName;
        $scope.ng_form.totalInForeignCurr = currentItem.amountForeignCrncy;

        for(var i=0; i<$scope.country_list.length; i++)
            if($scope.country_list[i].name == currentItem.country)
                $scope.ng_form.overseaMiscToCountry = $scope.country_list[i];


        for(var i=0; i<$scope.currency_list.length; i++)
            if($scope.currency_list[i].name == currentItem.currencyType)
                $scope.ng_form.overseaMiscForeignCurrType = $scope.currency_list[i];

        $scope.updateRate();
        $scope.updateTotal();
        $scope.ng_form.ngDescription = currentItem.expenseDetails;
    }

    $scope.deleteMiscLocalItem = function(indx){
        $scope.miscClaimList.splice(indx, 1);
        if( !$scope.miscClaimList.length)
            $scope.isEmptyTable = true;

        $scope.grandTotal = getGrandTotal();

        $scope.$watch('MiscellaneousLocalData', function() {
            MiscellaneousLocalData.setMiscellaneousItems($scope.miscClaimList);
        }, true);
    }

    $scope.addClaimItem = function(indx){
        var item = {};

        item.dateToUpdate = MiscellaneousLocalData.getDate();
        item.date = MiscellaneousLocalData.getDateTxt();
        item.receiptNumber = $scope.ng_form.ngReceipt;
        item.expensesType = $scope.ng_form.expenditure;
        item.fundType = DataFundType.getFundType();
        item.projectCode = DataLookup.getProjectCode();
        item.expenseDetails = $scope.ng_form.ngDescription;
        item.country = $scope.ng_form.overseaMiscToCountry.name;
        item.currencyType = $scope.ng_form.overseaMiscForeignCurrType.name;
        item.exchangeRate = $scope.ng_form.exch_rate;
        item.amountForeignCrncy = $scope.ng_form.totalInForeignCurr;
        item.totalPrice = $scope.ng_form.totalInRM;

        if(Number(indx) > -1){
            $scope.miscClaimList[indx] = item;
        }
        else{
            $scope.miscClaimList.push(item);
        }

        $scope.grandTotal = getGrandTotal();

        if( $scope.miscClaimList.length)
             $scope.isEmptyTable = false;

        $scope.$watch('MiscellaneousLocalData', function() {
            MiscellaneousLocalData.setMiscellaneousItems($scope.miscClaimList);
        }, true);

        DataFundType.setFundType({});
        MiscellaneousLocalData.setDate('');
        $scope.ng_form = {};
        $scope.ng_form.ngDescription = '';
    }

    function getGrandTotal(){
        var total = 0;
        for (var i=0; i<$scope.miscClaimList.length; i++)
            total += Number($scope.miscClaimList[i].totalPrice);
        total = total.toFixed(2);
        return total;
    }

    $scope.update = function(){
        $scope.addClaimItem(indxOfChangedItem);
    }

    $scope.updateTotal = function(){
        $scope.ng_form.totalInRM = $scope.ng_form.totalInForeignCurr * $scope.ng_form.exch_rate;
        $scope.ng_form.totalInRM = $scope.ng_form.totalInRM.toFixed(2);
        if(isNaN($scope.ng_form.totalInRM))
            $scope.ng_form.totalInRM = 0.00;
    }

    $scope.$watch('ng_form.exch_rate', function(newValue,oldValue) {
        if (newValue != oldValue) {
            $scope.ng_form.totalInRM = newValue * $scope.ng_form.totalInForeignCurr;
            $scope.ng_form.totalInRM = $scope.ng_form.totalInRM.toFixed(2);
            if(isNaN($scope.ng_form.totalInRM))
                $scope.ng_form.totalInRM = 0.00;
        }
    });

    $scope.updateRate = function(){

        if ($scope.ng_form.overseaMiscForeignCurrType){
            $scope.unitInForeignCurr = $scope.ng_form.overseaMiscForeignCurrType.currency;
            $http({
                url: API_URL+'currency-rates/',
                method: 'GET',
                params: {
                    currency : $scope.ng_form.overseaMiscForeignCurrType.currency,
                    date : MiscellaneousLocalData.getDateTxt()
                }
            })
            .success(function (data, status, headers, config) {
                obj = data.results;
                if (obj.length==1){
                    $scope.ng_form.exch_rate = obj[0].value;
                }
                else{
                    $scope.ng_form.exch_rate = 0;
                }
            });
        }
        else
             $scope.unitInForeignCurr = '';
    }

    $http({
        url: API_URL+'fund-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.fundType_list = data.results;
    });

    $scope.openModal = function(){
        $scope.btnUpdate = false;
        $('#miscModalForm').modal('show');
    };

/**** get country and currency ****/
    $scope.country_list = [];
    $scope.currency_list = [];
    $scope.currRate_list = [];

    $http({
        url: API_URL+'countries/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.country_list = data.results;
    });

    $http({
        url: API_URL+'currencies/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.currency_list = data.results;
    });

    $http({
        url: API_URL+'currency-rates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.currRate_list = data.results;
    });
/**** end get country and currency ****/

});

uiBootstrapApp.factory('MiscellaneousLocalData', function ($filter) {
    var data = {
            miscoverseasItems:[],
            error_validation:'',
            claimant_no:'',
            draft_id:'',
            claim_id:'',
            claim_date:'',
            DateTxt:'-',
            grand_total:0
        };
    return {
        getMiscellaneousItems: function () {
            return data.miscoverseasItems;
        },
        setMiscellaneousItems: function (objt){
            data.miscoverseasItems = objt;
        },
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (objt){
            data.error_validation = objt;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        },
        getDate: function () {
            return data.claim_date;
        },
        getDateTxt: function () {
            return data.DateTxt;
        },
        setDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.claim_date = obj;
            data.DateTxt = minDate;
        },
        getGrandTotal: function () {
            return data.grand_total;
        },
        setGrandTotal: function (obj) {
            data.grand_total = obj;
        }
    };
});
//submit and draft controller

uiBootstrapApp.controller('SubmitCtrl', function ($scope, $http, MiscellaneousLocalData, $uibModal) {

    $scope.animationsEnabled = true;

    $scope.submit = function(btnMode) {

        form_data = {
            btn_mode:btnMode,
            miscoverseasItems:MiscellaneousLocalData.getMiscellaneousItems(),
            claimant_no:MiscellaneousLocalData.getClaimantNo(),
            draft_id:MiscellaneousLocalData.getDraftID()
        }

        var instance_controller = '';

        if (btnMode == 'save_draft') {
            instance_controller = 'ModalInstanceSaveCtrl';
            ng_template = 'SaveConformation.html';
        }else if (btnMode == 'submit'){
            instance_controller = 'ModalInstanceSubmitCtrl';
            ng_template = 'SubmitConformation.html';
        }
        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: ng_template,
            controller: instance_controller,
            size: 'sm',
            resolve: {
                data: function () {
                    return form_data;
                }
            }
        });

        modalInstance.result.then( function () {
                console.log('OK, conformation box closed');

                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                } else {
                    $http({
                        url: '',
                        method: 'POST',
                        data: form_data
                    })
                    .success(function (data, status, headers, config) {
                        var submit_success_url = data.submit_success_url || URL_HOMEPAGE;

                        if (btnMode == 'submit') {
                            $window.location.href = submit_success_url;
                        } else if (btnMode == 'save_draft') {
                            $scope.initSubmitCtrl(data.draft_id);
                            $uibModal.open({
                                animation: $scope.animationsEnabled,
                                templateUrl: 'SaveSuccess.html',
                                controller: 'ModalInstanceInfoCtrl',
                                size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
                                resolve: {
                                  data: function () {
                                    return data;
                                  }
                                }
                            });
                            window.location.href = URL_HOMEPAGE;
                        }
                    });
                }
        });
    };

    $scope.initSubmitCtrl = function(draft_id){
        $scope.draft_id = draft_id;
        MiscellaneousLocalData.setDraftID(draft_id);
    };
});

uiBootstrapApp.controller('ModalInstanceSaveCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

uiBootstrapApp.controller('ModalInstanceSubmitCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

uiBootstrapApp.controller('ModalInstanceInfoCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };
}]);

uiBootstrapApp.controller('ModalDemoCtrl', ['$scope', '$uibModal', function ($scope, $uibModal) {

    $scope.items = ['item1', 'item2', 'item3'];

    $scope.animationsEnabled = true;

    $scope.open = function (size) {

    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'myModalContent.html',
      controller: 'ModalInstanceCtrl',
      size: size,
      resolve: {
        items: function () {
          return $scope.items;
        }
      }
    });

    modalInstance.result.then(
        function (selectedItem) {
            $scope.selected = selectedItem;
        },
        function () {
            $log.info('Modal dismissed at: ' + new Date());
        }
    );
  };

  $scope.toggleAnimation = function () {
    $scope.animationsEnabled = !$scope.animationsEnabled;
  };

}]);

uiBootstrapApp.controller('ModalInstanceCtrl', ['$scope', '$modalInstance', 'items', function ($scope, $uibModalInstance, items) {

  $scope.items = items;
  $scope.selected = {
    item: $scope.items[0]
  };

  $scope.ok = function () {
    $uibModalInstance.close($scope.selected.item);
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
}]);

uiBootstrapApp.controller('claimDateCtrl', function($scope, MiscellaneousLocalData){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.miscDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.dateChanged = function(){
        MiscellaneousLocalData.setDate($scope.miscDate);
        $scope.updateRate();
    };

    $scope.$watch(function () { return MiscellaneousLocalData.getDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.miscDate = newValue;
        }
    });
});

uiBootstrapApp.controller('summaryCtr', function($scope, $http, MiscellaneousLocalData){

    $scope.$watchCollection(function () { return MiscellaneousLocalData.getMiscellaneousItems(); }, function (newValue, oldValue) {
        $scope.summary_list = [];
        $scope.grandSummaryTotal = 0;

        var miscClaim_list = $.extend(true, [], MiscellaneousLocalData.getMiscellaneousItems());

        if(miscClaim_list.length)
        {
            getSummaryList(getExpensesObjects(groupByExp(miscClaim_list)));
            $scope.grandSummaryTotal = $scope.grandSummaryTotal.toFixed(2);
        }
    });

    function groupByExp(miscClaim_list){
        grouped_list = [];

        while(miscClaim_list.length>0){
            grouped_list.push(miscClaim_list[0]);
            exp = miscClaim_list[0].expensesType.id;
            miscClaim_list.splice(0, 1);

            for (var i=0; i<miscClaim_list.length; i++){
                if(miscClaim_list[i].expensesType.id == exp){
                    grouped_list.push(miscClaim_list[i]);
                    miscClaim_list.splice(i, 1);
                    i--;
                 }
            }
        }

        return grouped_list;
    }

    function getExpensesObjects(expGrouped_list){
        expensesObjs = [];
        ls = [];
        var j=0;

        for (var i=0; i<expGrouped_list.length; i++){
            while(i<expGrouped_list.length){
                if(expGrouped_list[i].expensesType.id==expGrouped_list[j].expensesType.id){
                    ls.push(expGrouped_list[i]);
                    i++;
                }
                else{ j=i; i--; break; }
            }
            expensesObjs.push(ls);
            ls = [];
        }
        return expensesObjs;
    }

    function fundObjExist(fund_list, _description){
        for (var i=0; i<fund_list.length; i++){
            if(fund_list[i].description == _description)
                return i;
        }
        return -1;
    }

    function getSummaryList(expensesObjs_list){
        for (var i=0; i<expensesObjs_list.length; i++){

            sumryObj = {};
            sumryObj.fundType = [];
            sumryObj.title = expensesObjs_list[i][0].expensesType.description;
            sumryObj.expenseCode = expensesObjs_list[i][0].expensesType.exp_code;
            sumryObj.amount = 0;

            for(var j=0; j<expensesObjs_list[i].length; j++){

                sumryObj.amount +=  Number(expensesObjs_list[i][j].totalPrice);

                indx = fundObjExist(sumryObj.fundType, expensesObjs_list[i][j].fundType.description);
                if(indx != -1){
                    sumryObj.fundType[indx].amount += Number(expensesObjs_list[i][j].totalPrice);
                }else{
                    fundObj = {};
                    fundObj.amount = Number(expensesObjs_list[i][j].totalPrice);
                    fundObj.description = expensesObjs_list[i][j].fundType.description;
                    sumryObj.fundType.push(fundObj);
                }
            }
            $scope.summary_list.push(sumryObj);
        }
    }
});
