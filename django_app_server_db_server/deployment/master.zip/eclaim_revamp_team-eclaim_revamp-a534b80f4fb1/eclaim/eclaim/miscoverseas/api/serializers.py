from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *


__all__ = [
    'MiscoverseasClaimSerializer',
    'MiscoverseasClaimDraftSerializer'
    ]


class MiscoverseasClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MiscoverseasClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        draftList = obj.miscoverseasclaimitem_set.all()
        return list(draftList.values())


class MiscoverseasClaimDraftSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MiscoverseasClaimDraft
        fields = ('id', 'items')

    def get_items(self, obj):
        draftList = obj.miscoverseasclaimitemdraft_set.all()
        return list(draftList.values())
