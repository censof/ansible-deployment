from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)
from .serializers import *
from ..models import *


__all__ = [
    'MiscoverseasClaimViewSet',
    'MiscoverseasClaimDraftViewSet'
    ]



class MiscoverseasClaimViewSet(viewsets.ModelViewSet):
    serializer_class = MiscoverseasClaimSerializer
    queryset = MiscoverseasClaim.objects.all()


class MiscoverseasClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = MiscoverseasClaimDraftSerializer
    queryset = MiscoverseasClaimDraft.objects.all()
