from django.db import models
from django.core.urlresolvers import reverse_lazy
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import MiscellaneousType, FundType


class MiscoverseasClaimAbstract(BaseModel):
    CLAIM_TYPE = 22

    status = models.CharField(max_length=1)

    class Meta:
        app_label = 'miscoverseas'
        abstract = True


class MiscoverseasClaimItemAbstract(models.Model):
    date = models.DateField(null=True)
    receiptNumber = models.CharField(max_length=125)
    expensesType = models.ForeignKey(MiscellaneousType)
    fundType = models.ForeignKey(FundType)
    projectCode = models.CharField(max_length=125)
    expenseDetails = models.CharField(max_length=125)
    country = models.CharField(max_length=125)
    currencyType = models.CharField(max_length=125)
    exchangeRate = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    amountForeignCrncy = models.DecimalField(max_digits=17, decimal_places=2, default=0.00)
    totalPrice = models.DecimalField(max_digits=17, decimal_places=2, default=0.00)


    def getTotal(self):
        return self.exchangeRate * self.amountForeignCrncy

    class Meta:
        app_label = 'miscoverseas'
        abstract = True

class MiscoverseasClaim(MiscoverseasClaimAbstract):
    claim_no = models.CharField(max_length=30, blank=True)

    class Meta:
        app_label = 'miscoverseas'
        verbose_name = 'Miscellaneous overseas claim'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('miscoverseas_detail'), self.pk)

class MiscoverseasClaimItem(MiscoverseasClaimItemAbstract):
    miscoverseasClaim = models.ForeignKey(MiscoverseasClaim)

    class Meta:
        app_label = 'miscoverseas'
        verbose_name = 'Miscellaneous overseas claim item'
        verbose_name_plural = verbose_name
        ordering = ['id']

class MiscoverseasClaimDraft(MiscoverseasClaimAbstract):

    class Meta:
        app_label = 'miscoverseas'
        verbose_name = 'miscoverseas Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('miscoverseas_draft', args=[self.pk])

class MiscoverseasClaimItemDraft(MiscoverseasClaimItemAbstract):
    miscoverseasClaimDraft = models.ForeignKey(MiscoverseasClaimDraft)

    class Meta:
        app_label = 'miscoverseas'
        verbose_name = 'miscoverseas Claim Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
