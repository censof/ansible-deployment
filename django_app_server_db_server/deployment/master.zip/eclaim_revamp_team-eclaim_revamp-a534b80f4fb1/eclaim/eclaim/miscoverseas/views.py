import json
from eclaim.libs.views import ClaimIndexView
from django.shortcuts import redirect
from django.core.urlresolvers import reverse_lazy
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import AngularUpdateAndDetailView
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.claimant import Claimant
from .processes import process_controller
from .models import MiscoverseasClaim


class MiscoverseasIndexView(ClaimIndexView):
    template_name = 'miscoverseas/miscoverseas_claim.html'
    claim_type = ClaimType.get_claim_type(22)

    def get_context_data(self, **kwargs):
        ctx = super(ClaimIndexView, self).get_context_data(**kwargs)
        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        claim_id = process_controller(form_data)
        btn_mode = form_data.get('btn_mode')

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscoverseasClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscoverseasClaim, claim_id)

        return redirect(reverse_lazy('claim_list'))


class MiscoverseasDetailView(AngularUpdateAndDetailView):

    model = MiscoverseasClaim
    template_name = 'miscoverseas/miscoverseas_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(MiscoverseasDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant

        obj_pk = self.request.GET['pk']
        claim = MiscoverseasClaim.objects.get(pk=obj_pk)

        ctx['claim_no'] = claim.claim_no
        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = process_controller(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscoverseasClaim, claim_id)

        return redirect(reverse_lazy('claim_list'))


class MiscoverseasDraftView(ClaimIndexView):
    template_name = 'miscoverseas/miscoverseas_claim.html'
    claim_type = ClaimType.get_claim_type(22)

    def get_context_data(self, **kwargs):
        ctx = super(ClaimIndexView, self).get_context_data(**kwargs)
        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        claim_id = process_controller(form_data)
        btn_mode = form_data.get('btn_mode')

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, MiscoverseasClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, MiscoverseasClaim, claim_id)

        return redirect(reverse_lazy('claim_list'))
