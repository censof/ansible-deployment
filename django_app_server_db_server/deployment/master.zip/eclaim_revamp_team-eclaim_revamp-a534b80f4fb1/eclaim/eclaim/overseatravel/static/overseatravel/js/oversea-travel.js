/*****************************************
 *      CREATED BY  :   DANIAL DARWIN    *
 *      DATE        :   March 2015       *
 *****************************************/
uiBootstrapApp.controller('MainCtrl', function($scope, $http, $filter, DataClaimant){
    /****************
    *   Accordion   *
    *****************/
    $scope.oneAtATime = false;

    $scope.panels = [
        {name: 'claimantDetails', open: false},
        {name: 'claimantEntitlements', open: false},
        {name: 'journeyDetails', open: false},
        {name: 'officialDuty', open: false},
        {name: 'course', open: true},
        {name: 'summary', open: false},
    ];

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** End */
    
    /**
    **************************************
    *   Global Table Pagination Config   *
    **************************************
    */
    $scope.pageSize = 10;
    $scope.currentPage = 1;
    /* Global Table Pagination Config : End */
    
    /**
    **************************
    *   Global Date Config   *
    **************************
    */
    $scope.dateFormats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MM-yyyy'];
    
    $scope.standardDateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.monthDateOptions = {
        datepickerMode: "'month'",
    	minMode: 'month'
    };
    
    $scope.formatDate = $scope.dateFormats[0];
    /** Global Date Config : End */
    
    /**
    **************************
    *   Global Time Config   *
    **************************
    */
    $scope.hstep = 1;
	$scope.mstep = 1;

	$scope.options = {
	  hstep: [1, 2, 3],
	  mstep: [1, 5, 10, 15, 25, 30]
	};

	$scope.ismeridian = false;
    
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.forceValidTime = function (section, objName) {
        var objSelect = $scope.getActiveTrip(section);
        if (objSelect == undefined){
            objSelect = section;
        }
        var objDate = objSelect[objName];
        if (!angular.isDate(objDate)) {
            objSelect[objName] = initTime;
        }
    };
    /** Global Time Config : End */
    
    /**
    *************************************
    *   Load Vehicle CC, Types & Rate   *
    *************************************
    */
    $scope.initVehicleCCs = function(jsonVehicleCCList){
        $scope.vehicleCCs = getAngularObjFromJson(jsonVehicleCCList);
    };
    
    $http({
        url: API_URL+'vehicle-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.vehicleTypes = data.results;
    });
    
    $http({
        url: API_URL+'vehicle-rate/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.vehicleTypeRates = data.results;
    });
    
    $scope.getVehicleRateByTypeID = function(typeID){
        var rate = 0;
        var objType = $filter("filter")($scope.vehicleTypes, {id: typeID});
        var objRate = $filter("filter")($scope.vehicleTypeRates, {vehicle_type: typeID});
        if (objType) {
            rate = objRate[0].rate;
        }
        return rate;
    };
    /** Load Vehicle Types & Rate : End */
    
    /**
     ****************************
     *  Load Mileage Trip Type  *
     ****************************
     */
    $scope.mileageTripTypes = [];
    
    $http({
        url: '/eclaim/masterfiles/mileage-trip-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileageTripTypes = data;
    });
    
    $scope.getTripTypeByCode = function(code){
        var objSelect = $filter("filter")($scope.mileageTripTypes, {code:code})[0];
        return objSelect[0];
    };
    /** Load Trip Type : END */
    
    /**
    ********************************
    *  Load Public Transport Type  *
    ********************************
    */
    $scope.publicTransportTypes = [];
    
    $http({
        url: '/eclaim/masterfiles/public-transport-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.publicTransportTypes = data;
    });
    
    $scope.getTransportTypeByCode = function(code){
        var objSelect = $filter("filter")($scope.publicTransportTypes, {code:code})[0];
        return objSelect[0];
    };
    /** Load Public Transport Type : END */
    
    
    /**
    ******************************
    *   Load Destination Type    *
    ******************************
    */
    $scope.destinationTypes = [];
    
    $http({
        url: '/eclaim/masterfiles/destination-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.destinationTypes = data;
    });
    /** Load Destination Type : End */
    
    /**
    ***************************************
    *  Load Transit & Accommodation Type  *
    ***************************************
    */
    $scope.transitTypes = [];
    $scope.accommodationTypes = [];
    
    $http({
        url: '/eclaim/masterfiles/transit-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transitTypes = data;
    });
    
    $http({
        url: '/eclaim/masterfiles/accommodation-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.accommodationTypes = data;
    });
    /** */
    
    /**
    **************************
    *   Load Misc Expenses   *
    **************************
    */
    $scope.miscExpenses = [];
    
    $http({
        url: API_URL+'miscellaneous-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.miscExpenses = data.results;
    });
    /** Load Misc Expenses : End */
    
    /**
    **************************
    *   Load Fare Replacement & Flight Class Type   *
    **************************
    */
    $scope.fareReplacements = [];
    $scope.flightClasses = [];
    
    $http({
        url: '/eclaim/masterfiles/fare-replacement-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.fareReplacements = data;
    });
    
    $http({
        url: '/eclaim/masterfiles/flight-class-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.flightClasses = data;
    });
    /** Load Misc Expenses : End */
    
    /**
    **********************************
    *   Load Country & Currencies    *
    **********************************
    */
    $scope.countries = [];
    $scope.currencies = [];
    
    $http({
        url: API_URL+'countries/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.countries = data.results;
    });
    
    $http({
        url: API_URL+'currency-rates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.currencies = data.results;
    });
    
    $scope.onSelectCurrencyType = function($item, $model, $label, section){
        var objSelect = $scope.getActiveTrip(section);
        objSelect.currencyDate = $item.date;
        objSelect.currencyRate = $item.value;
    };
    /** Load Country & Currencies : End */
    
    /**
    *********************************
    *   Load Supporting Documents   *
    *********************************
    */
    $scope.supportingDocsOD = [];
    
    $http({
        url: API_URL+'document-list/',
        method: 'GET',
        params: {'claim_type': 'OTC'
            ,'document_group': 'OD'
        }
    })
    .success(function (data, status, headers, config) {
        $scope.supportingDocsOD = data.results;
    });
    /** Load Supporting Documents : End */
    
    /**
    *********************************
    *   Load Rate & Entitlements    *
    *********************************
    */
    $scope.offDutyEntitlements = [];
    $scope.courseEntitlements = [];
    
    $scope.initEntitlements = function(){
        /** Load Entitlement Rates */
        $http({
            url: API_URL+'offduty-trip-oversea-allowance/',
            method: 'GET',
            params: {'staffNo':DataClaimant.getStaffNo()}
        })
        .success(function (data, status, headers, config) {
            $scope.offDutyEntitlements = data.results;
        });
        
        $http({
            url: API_URL+'course-trip-oversea-allowance/',
            method: 'GET',
            params: {'staffNo':DataClaimant.getStaffNo()}
        })
        .success(function (data, status, headers, config) {
            $scope.courseEntitlements = data.results;
        });
        /** End */
    };
    
    $scope.getRate = function(activity_type, objType){
        var rate = 0;
        
        if (activity_type == 'offduty') {
            rate = $scope.offDutyEntitlements[0][objType];
        }else if (activity_type == 'course') {
            rate = $scope.courseEntitlements[0][objType];
        }
        return rate;
    };
    /** Load Rate & Entitlements : End */
    
    /**
    *****************************
    *   Load Summary Expenses   *
    *****************************
    */
    $scope.localExpenses = [];
    $scope.overseaExpenses = [];

    $http({
        url: API_URL+'expenses/',
        method: 'GET',
        params: {'claim_code':'LTC'}
    })
    .success(function (data, status, headers, config) {
        $scope.localExpenses = angular.copy(data.results);
    });
    
    $http({
        url: API_URL+'expenses/',
        method: 'GET',
        params: {'claim_code':'OTC'}
    })
    .success(function (data, status, headers, config) {
        $scope.overseaExpenses = angular.copy(data.results);
    });
    /* Load Summary Expenses : End */
    
    /********************
    *   Trip Options    *
    *********************/
    $scope.activeTripIndex = 0;
    
    var setAttribute = function(){
        return {
            id: 1, active: true,
            mealItems: [], meal: {},
            hotelItems:[], hotel: {},
            lodgingItems:[], lodging: {},
            mileageItems:[], mileage: {},
            publicTransportItems: [], publicTransport: {},
            transitItems: [],
            transit: {},
            fixedReplacementItems: [],
            fixedReplacement: {},
            miscellaneousItems: [],
            miscellaneous: {},
            fareReplacementItems: [],
            fareReplacement: {},
            supportingDocuments: [],
            overseaExpensesSummary: [],
            overseaForexSummary: [],
            localExpensesSummary: [],
            gstSummary: [],
            overseaSubTotal: 0,
            overseaGrandTotal: 0,
            localGrandTotal: 0,
            gstGrandTotal: 0
        }
    };
    
    $scope.mealForm = {};
    
    $scope.ODTrips = [angular.merge(setAttribute(), {activity_type: 'OD'})];
    $scope.CourseTrips = [angular.merge(setAttribute(), {activity_type: 'COURSE'})];
    
    $scope.tripsSelector = function(section){
        var trips = [];
        
        if (section == 'OD') {
            trips = $scope.ODTrips;
        }
        else if (section == 'COURSE') {
            trips = $scope.CourseTrips;
        }
        return trips;
    };
    
    $scope.addTrip = function(section){
        var trips = $scope.tripsSelector(section);
        var newTabID = trips.length;
        
        newTabID += 1;
        trips.push({
            id: newTabID, active: true, activity_type: section,
            mealItems: [], meal: {},
            hotelItems:[], hotel: {},
            lodgingItems:[], lodging: {},
            mileageItems:[], mileage: {},
            publicTransportItems: [], publicTransport: {},
            transitItems: [],
            transit: {},
            fixedReplacementItems: [],
            fixedReplacement: {},
            miscellaneousItems: [],
            miscellaneous: {},
            fareReplacementItems: [],
            fareReplacement: {},
            supportingDocuments: [],
            overseaExpensesSummary: [],
            overseaForexSummary: [],
            localExpensesSummary: [],
            gstSummary: [],
            overseaSubTotal: 0,
            overseaGrandTotal: 0,
            localGrandTotal: 0,
            gstGrandTotal: 0
        });
    };
    
    $scope.selectODTrip = function(index){
        // Do something later
    };
    
    $scope.getActiveTrip = function(section){
        /** Return entire object only for active trip */
        var trips = $scope.tripsSelector(section);
        return $filter("filter")(trips, {active: true})[0]
    };
    /** Trip Options : End */
    
    $scope.printConsole = function(){
        /** for Developer testing only */
    };
});

uiBootstrapApp.controller('JourneyDetailsCtrl', function ($scope, $filter) {
	$scope.claimMonth = new Date();
    $scope.travelFromDate = new Date();
    $scope.travelToDate = new Date();

    $scope.formatMonth = $scope.dateFormats[4];
    $scope.formatDay = $scope.dateFormats[0];

    $scope.openClaimMonth = function($event) {
        $scope.statusClaimMonth.opened = true;
    };
    $scope.openTravelFromDate = function($event) {
        $scope.statusTravelFromDate.opened = true;
    };
    $scope.openTravelToDate = function($event) {
        $scope.statusTravelToDate.opened = true;
    };

    $scope.statusClaimMonth = {
        opened: false
    };
    $scope.statusTravelFromDate = {
        opened: false
    };
    $scope.statusTravelToDate = {
        opened: false
    };
    
    $scope.$watch('claimMonth', function(newValue, oldValue){
        if (newValue != oldValue) {
            DataFormDate.setClaimMonth(newValue);
        }
    });
    
    $scope.$watch('travelFromDate', function(newValue, oldValue){
        if (newValue != oldValue) {
            DataFormDate.setTravelFromDate(newValue);
        }
    });
    
    $scope.$watch('travelToDate', function(newValue, oldValue){
        if (newValue != oldValue) {
            DataFormDate.setTravelToDate(newValue);
        }
    });
});

uiBootstrapApp.controller('TripJourneyDetailsCtrl', function ($scope, $filter) {
    
    $scope.openFromDate = function($event){
        $scope.statusFromDate.opened = true;
    };
    $scope.openToDate = function($event){
        $scope.statusToDate.opened = true;
    };
    $scope.openDepartureDate = function($event){
        $scope.statusDepartureDate.opened = true;
    };

    $scope.statusFromDate = {
        opened: false
    };
    $scope.statusToDate = {
        opened: false
    };
    $scope.statusDepartureDate = {
        opened: false
    };
    
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.initLoad = function(trip, section){
        if (trip.id == 1) {
            var toWatchItems = ['fromDate', 'departureTime'];
            var activityTrips = $scope.tripsSelector(section);
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch(function() {
                    return activityTrips.map(function(obj) {
                        return obj[objToWatch];
                    });
                }, function (newVal, oldVal) {
                    if (newVal != oldVal) {
                        if (objToWatch == 'fromDate') {
                            // Do validation later
                        }else if (objToWatch == 'departureTime') {
                            $scope.forceValidTime(section, objToWatch);
                        }
                    }
                }, true);
            });
        }
        
        trip.departureTime = initTime;
    };
});

uiBootstrapApp.controller('MealCtrl', ['$scope', '$filter', '$uibModal', 'DataFormMain',
                                       'DataFundType', 'DataLookup', 'DataFormMeal',
                          function($scope, $filter, $uibModal, DataFormMain,
                                   DataFundType, DataLookup, DataFormMeal){
    
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    /** Time : Start */
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.departTime = initTime;
    $scope.returnTime = initTime;
    /** Time : End */
    
    /** Calculation : Start */
    var getMealRate = function(section){
        var rate = 0;
        if (section == 'OD') {
            rate = $scope.getRate('offduty', 'meal');
        }else if (section == 'COURSE') {
            rate = $scope.getRate('course', 'meal');
        }
        return rate;
    };
    
    var calculateIntMealDaily = function(dateStart, timeStart, dateEnd, timeEnd){
        // Combined Date & Time.
        var intMeal = 0;
        var intDaily = 0;
        if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
            var hours = getDateDiff(combineDateTime(dateStart, timeStart),
                                   combineDateTime(dateEnd, timeEnd));
            if (hours >= 24) {
                var days = hours / 24; // Convert hours to day
                if (days > 0) {
                    intMeal = getNumber(days);
                    balanceDay = days - intMeal;
                    balanceHours = balanceDay * 24;
                    if (balanceHours >= 8) {
                        intDaily = 1;
                    }
                }
            }else{
                if (hours >= 8) {
                    intDaily = 1;
                }
            }
            var form = getForm();
            form.intMeal = intMeal;
            form.intDaily = intDaily;
            calculateMealDailyAmount();
        }
    };
        
    var calculateMealDailyAmount = function(){
        var form = getForm();
        if (!form.chkDistribution) {
            var rate = form.mealRate;
            var intMeal = getNumber(form.intMeal);
            var intDaily = getNumber(form.intDaily);
            var mealAmount = 0;
            var dailyAmount = 0;
            var grossAmount = 0;
            mealAmount = parseFloat(rate) * parseFloat(intMeal);
            dailyAmount = parseFloat(rate) * 0.5 * parseFloat(intDaily);
            grossAmount = get2Float(mealAmount + dailyAmount);
            form.mealAmount = get2Float(mealAmount);
            form.dailyAmount = get2Float(dailyAmount);
            form.grossAmount = grossAmount;
            changeItemVal('mealAmount', get2Float(mealAmount));
            changeItemVal('dailyAmount', get2Float(dailyAmount));
            changeItemVal('grossAmount', grossAmount);
        };
    };
    
    var calculateGrandTotal = function (){
        var trip = getTrip('meal');
        var items = getTrip('mealItems');
        trip['grandTotalMealAmount'] = getListTotalAmount(items, 'mealAmount');
        trip['grandTotalDailyAmount'] = getListTotalAmount(items, 'dailyAmount');
        trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
    };
    /** Calculation : End */
    
    var disableEditMode = function(){
        var form = getForm();
        form.isEditMode = false;
        form.directIndex = 0;
    };

    $('div[id^=meal-modal_form-OD-trip_], div[id^=meal-modal_form-COURSE-trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getForm = function(){
        return $scope.mealForm;  
    };
    
    var getTrip = function(objName){
        var currSection = DataFormMeal.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var setEmptyTable = function(){
        var form = getForm();
        form.currIndex = '';
        disableEditMode();
    };

    var resetForm = function(){
        var form = getForm();
        form.chkDistribution = false;
        form.mealDistribution = [];
    };

    var setForm = function(currItem){
        var form = getForm();
        form.chkDistribution = currItem.chkDistribution;
        form.departDate = currItem.departDate;
        form.returnDate = currItem.returnDate;
        form.departTime = currItem.departTime;
        form.returnTime = currItem.returnTime;
        form.travellingInfo = currItem.travellingInfo;
        form.mealDistribution = currItem.mealDistribution;
        form.intMeal = currItem.intMeal;
        form.intDaily = currItem.intDaily;
        form.mealAmount = currItem.mealAmount;
        form.dailyAmount = currItem.dailyAmount;
        form.grossAmount = currItem.grossAmount;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };
    
    var setEditMode = function(itemIndex){
        var form = getForm();
        setForm(getItems(itemIndex));
        form.currIndex = itemIndex;
        form.directIndex = itemIndex;
        form.isEditMode = true;
    };

    var getItems = function(index){
        var obj = [];
        trip = getTrip();
        obj = trip.mealItems;
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    var setRow = function(objDB){
        var form = getForm();
        if (objDB) {
            form.departDate = getDateFromStr(objDB.depart_date);
            form.returnDate = getDateFromStr(objDB.return_date);
            form.departTime = getDateFromStr(objDB.depart_time);
            form.returnTime = getDateFromStr(objDB.return_time);
            form.travellingInfo = objDB.travelling_info;
            form.chkDistribution = objDB.chk_meal_distribution;
            form.mealDistribution = DataFormMeal.getDBDistributionByParentID(objDB.id);
            form.intMeal = objDB.int_meal_allowance;
            form.intDaily = objDB.int_daily_allowance;
            form.mealAmount = objDB.meal_amount;
            form.dailyAmount = objDB.daily_amount;
            form.grossAmount = objDB.amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            departDate: form.departDate, departDateTxt: getDateStr($filter, form.departDate),
            departTime: form.departTime, departTimeTxt: getTimeStr(form.departTime),
            returnDate: form.returnDate, returnDateTxt: getDateStr($filter, form.returnDate),
            returnTime: form.returnTime, returnTimeTxt: getTimeStr(form.returnTime),
            travellingInfo: form.travellingInfo,
            chkDistribution: form.chkDistribution, mealDistribution: form.mealDistribution,
            intMeal: getNumber(form.intMeal), intDaily: getNumber(form.intDaily),
            mealAmount: get2Float(form.mealAmount),
            dailyAmount: get2Float(form.dailyAmount),
            grossAmount: get2Float(form.grossAmount),
            fundType: DataFundType.getFundType(), projectCode: DataLookup.getProjectCode()
        };
    };
    
    var changeItemVal = function(objName, newVal) {
        var form = getForm();
        if (form.isEditMode) {
            var currItem = getItems(form.currIndex);
            if (currItem) {
                currItem[objName] = newVal;
                if (objName == 'departDate' || objName == 'returnDate') {
                    currItem.departDateTxt = getDateStr($filter, form.departDate);
                    currItem.returnDateTxt = getDateStr($filter, form.returnDate);
                }else if (objName == 'departTime' || objName == 'returnTime') {
                    currItem.departTimeTxt = getTimeStr(form.departTime);
                    currItem.returnTimeTxt = getTimeStr(form.returnTime);
                }
            }
        }
    };
    
    $scope.addItem = function(objDB){
        var section = DataFormMeal.getCurrSection();
        var items = getItems();
        items.push(setRow(objDB));
        resetForm();
        calculateGrandTotal();
    };
    
    $scope.deleteItem = function(section, itemIndex){
        DataFormMeal.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var list = [];
        list = getItems();
        list.splice(index, 1); //remove the object from the array based on index
        if (list.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.openModal(section, 'editForm');
        setEditMode(index);
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var form = getForm();
        var list = getItems();
        if (list.length > 0) {
            if (form.directIndex == list.length) {
                form.directIndex = list.length - 1;
            }else if (form.directIndex < 0) {
                form.directIndex = 0;
            }

            if (direct == 'previous' && !(form.directIndex <= 0)) {
                form.directIndex--;
                setEditMode(form.directIndex);
            }else if (direct == 'next' && !(form.directIndex >= list.length-1)) {
                form.directIndex++;
                setEditMode(form.directIndex);
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormMeal.setCurrSection(section);
        var trip = getTrip();
        var form = getForm();
        form.mealRate = getMealRate(section);
        $('#meal-modal_form-'+section+'-trip_'+trip.id).modal('show');
        
        if (mode == 'newForm') {
            form.isEditMode = false;
            //resetForm();
        }else if (mode == 'editForm') {
            form.isEditMode = true;
        }
    };
    
    $scope.openModalMealDistribution = function (section, itemIndex) {
        var form = getForm();
        var departDate = form.departDate;
        var returnDate = form.returnDate;
        var chkDistribution = form.chkDistribution;
        var mealDistribution = form.mealDistribution;
        var mealRate = form.mealRate;

        if (itemIndex != undefined) {
            DataFormMeal.setCurrSection(section);
            chkDistribution = getItems(itemIndex).chkDistribution;
            mealDistribution = getItems(itemIndex).mealDistribution;
            mealRate = getMealRate(section);
        }

        $scope.animationsEnabled = true;
        instance_controller = 'ModalMealDistributionCtrl';
        ng_template = 'MealDistribution.html';
        if (chkDistribution) {
            if (angular.isDate(departDate) && angular.isDate(returnDate)) {
                var dataModal = {dateFrom: departDate, dateTo: returnDate, mealRate: mealRate, mealDistribution: mealDistribution};
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: ng_template,
                    controller: instance_controller,
                    size: '',
                    resolve: {
                        data: function () {
                            return dataModal;
                        }
                    }
                });
                
                modalInstance.result.then(
                    function (returnData) {
                        form.mealDistribution = returnData.mealDistribution;
                        var mealAmount = returnData.totalMealAmount;
                        form.mealAmount = get2Float(mealAmount);
                        form.dailyAmount = get2Float(0);
                        form.grossAmount = get2Float(mealAmount);
                        form.intMeal = 0;
                        form.intDaily = 0;
                        
                        if (itemIndex != undefined) {
                            form.currIndex = itemIndex;
                            form.isEditMode = true;
                        }
                        
                        changeItemVal('chkDistribution', chkDistribution);
                        changeItemVal('mealDistribution', mealDistribution);
                        changeItemVal('mealAmount', get2Float(mealAmount));
                        changeItemVal('dailyAmount', get2Float(0));
                        changeItemVal('grossAmount', get2Float(mealAmount));
                        changeItemVal('intMeal', 0);
                        changeItemVal('intDaily', 0);
                    },
                    function () {
                        // Cancel, box closed;
                    }
                );
            }
        }else{
            // Reset amount based on selected Date & Time.
            // calculateIntMeal($scope.departDate, $scope.returnDate);
            // calculateIntDaily($scope.departTime, $scope.returnTime);
            calculateIntMealDaily(departDate, form.departTime, returnDate, form.returnTime);
        }
        //changeItemVal('chkDistribution');
    };

    $scope.initLoad = function(section, trip){
        if (section == 'OD' && trip.id == 1) {
            var form = getForm();
            var toWatchItems = [
                    'departDate', 'departTime', 'returnDate', 'returnTime',
                    'regionDestination', 'description', 'chkDistribution', 'mealDistribution',
                    'mealRate', 'intMeal', 'intDaily', 'dailyAmount', 'mealAmount'
                ];
            
            toWatchItems.forEach(function(objToWatch){
                if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                    form[objToWatch] = initTime;
                }
                else if (objToWatch == 'mealDistribution') {
                    form[objToWatch] = [];
                }
                else if (objToWatch == 'chkDistribution') {
                    form[objToWatch] = false;
                }
                else if (objToWatch == 'mealRate') {
                    form[objToWatch] = get2Float(0);
                }
                else{
                    form[objToWatch] = '';
                }
            });
            
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch('mealForm.'+objToWatch, function(newVal, oldVal){
                    if(newVal != oldVal){
                        // Trigger function
                        if (objToWatch == 'departDate' || objToWatch == 'returnDate') {
                            calculateIntMealDaily(form.departDate, form.departTime, form.returnDate, form.returnTime);
                        }
                        else if (objToWatch == 'departTime' || objToWatch == 'returnTime') {
                            $scope.forceValidTime(form, objToWatch);
                            calculateIntMealDaily(form.departDate, form.departTime, form.returnDate, form.returnTime);
                        }
                        
                        // Set value
                        if (objToWatch == 'intMeal' || objToWatch == 'intDaily') {
                            changeItemVal(objToWatch, getNumber(newVal));
                        }
                        else if (objToWatch == 'dailyAmount' || objToWatch == 'mealAmount') {
                            changeItemVal(objToWatch, get2Float(newVal));
                            calculateGrandTotal();
                        }
                        else{
                            changeItemVal(objToWatch, newVal);
                        }
                    }
                });
            });
        }
    };
    
    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('fundType', newValue); }
    });
}]);

uiBootstrapApp.controller('ModalMealDistributionCtrl', ['$scope', '$filter', '$modalInstance', 'data',
                                                        function ($scope, $filter, $uibModalInstance, data) {
    /* Config for table pagination : Start */
    $scope.pageSize = 10;
    $scope.currentPage = 1;
    /* Config for table pagination : End */
    
    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var mealRate = parseFloat(data.mealRate);
    var mealDistribution = data.mealDistribution;

    var rateBreakfast = mealRate * (20/100);
    var rateLunch = mealRate * (40/100);
    var rateDinner = mealRate * (40/100);
    var totalAmountBreakfast = 0;
    var totalAmountLunch = 0;
    var totalAmountDinner = 0;
    var totalMealAmount = 0;

    $scope.mealRate = get2Float(mealRate);
    $scope.rateBreakfast = get2Float(rateBreakfast);
    $scope.rateLunch = get2Float(rateLunch);
    $scope.rateDinner = get2Float(rateDinner);

    var generateDays = function (dateFrom, dateTo) {
        var mealDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            mealDistribution.push({date:objMinDate, breakfast:false, lunch:false, dinner:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return mealDistribution;
    };

    if (mealDistribution.length) {
        $scope.mealDistribution = mealDistribution;
    }else{
        $scope.mealDistribution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {totalMealAmount:$scope.totalMealAmount, mealDistribution:$scope.mealDistribution}
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('mealDistribution', function() {
        var totalBreakfast = 0;
        var totalLunch = 0;
        var totalDinner = 0;

        $scope.mealDistribution.forEach(function(obj){
            if(obj.breakfast){
                totalBreakfast++;
            }
            if (obj.lunch) {
                totalLunch++;
            }
            if (obj.dinner) {
                totalDinner++;
            }
        });

        $scope.totalBreakfast = totalBreakfast;
        $scope.totalLunch = totalLunch;
        $scope.totalDinner = totalDinner;
        totalAmountBreakfast = parseFloat(totalBreakfast) * rateBreakfast;
        totalAmountLunch = parseFloat(totalLunch) * rateLunch;
        totalAmountDinner = parseFloat(totalDinner) * rateDinner;
        $scope.totalAmountBreakfast = get2Float(totalAmountBreakfast);
        $scope.totalAmountLunch = get2Float(totalAmountLunch);
        $scope.totalAmountDinner = get2Float(totalAmountDinner);
        totalMealAmount = parseFloat(totalAmountBreakfast) + parseFloat(totalAmountLunch) +
                        parseFloat(totalAmountDinner);
        $scope.totalMealAmount = get2Float(totalMealAmount);
    }, true);
}]);

uiBootstrapApp.controller('HotelCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormHotel',
                                        'DataFundType', 'DataLookup', 'DataGST',
                                        function($scope, $filter, DataFormMain, DataFormHotel,
                                                 DataFundType, DataLookup, DataGST){
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openCheckinDate = function($event) {
        $scope.statusCheckinDate.opened = true;
    };
    $scope.openCheckoutDate = function($event) {
        $scope.statusCheckoutDate.opened = true;
    };

    $scope.statusCheckinDate = {
        opened: false
    };
    $scope.statusCheckoutDate = {
        opened: false
    };
    /** Date : End */
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    $('div[id^=hotelODModalForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getTrip = function(objName){
        var currSection = DataFormHotel.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    };
    
    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.checkinDate = getDateFromStr(objDB.check_in_date);
            $scope.checkoutDate = getDateFromStr(objDB.check_out_date);
            $scope.travellingInfo = objDB.travelling_info;
            $scope.receiptNo = objDB.receipt_no;
            $scope.roomPrice = objDB.room_price;
            $scope.serviceCharge = objDB.service_charge;
            $scope.totalAmountPerDay = objDB.perday_amount;
            $scope.totalDays = objDB.int_days;
            $scope.grossAmount = objDB.amount;
            $scope.nettAmount = objDB.nett_amount;
            $scope.gstAmount = objDB.gst_amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
        }
        return {
            checkinDate: $scope.checkinDate, checkinDateTxt: getDateStr($filter, $scope.checkinDate),
            checkoutDate: $scope.checkoutDate, checkoutDateTxt: getDateStr($filter, $scope.checkoutDate),
            travellingInfo: $scope.travellingInfo,
            receiptNo: $filter('uppercase')($scope.receiptNo),
            roomPrice: get2Float($scope.roomPrice), serviceCharge: get2Float($scope.serviceCharge),
            totalAmountPerDay: get2Float($scope.totalAmountPerDay), totalDays: getNumber($scope.totalDays),
            grossAmount: get2Float($scope.grossAmount),
            gstAmount: get2Float($scope.gstAmount),
            nettAmount: get2Float($scope.nettAmount),
            corporateCard: false,
            fundType: DataFundType.getFundType(), projectCode: DataLookup.getProjectCode(),
            gstType: DataGST.getGSTType()
        };
    };

    var setForm = function(currItem){
        $scope.checkinDate = currItem.checkinDate;
        $scope.checkoutDate = currItem.checkoutDate;
        $scope.travellingInfo = currItem.travellingInfo;
        $scope.receiptNo = currItem.receiptNo;
        $scope.roomPrice = currItem.roomPrice;
        $scope.serviceCharge = currItem.serviceCharge;
        $scope.totalAmountPerDay = currItem.totalAmountPerDay;
        $scope.grossAmount = currItem.grossAmount;
        $scope.gstAmount = currItem.gstAmount;
        $scope.nettAmount = currItem.nettAmount;
        $scope.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        DataGST.setGSTType(currItem.gstType);
    };

    var resetForm = function(){
        // Reset form
        //$scope.hotelLTItems = [];
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormHotel.getCurrSection();

        if (currSection == 'OD') {
            obj = getTrip('hotelItems');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                if (obj == 'checkinDate') {
                    currItem.checkinDate = $scope.checkinDate;
                    currItem.checkinDateTxt = getDateStr($filter, $scope.checkinDate);
                }else if (obj == 'checkoutDate') {
                    currItem.checkoutDate = $scope.checkoutDate;
                    currItem.checkoutDateTxt = getDateStr($filter, $scope.checkoutDate);
                }else if (obj == 'travellingInfo') {
                    currItem.travellingInfo = $scope.travellingInfo;
                }else if (obj == 'hotelRegionDestination') {
                    currItem.hotelRegionDestination = $scope.hotelRegionDestination;
                }else if (obj == 'receiptNo') {
                    currItem.receiptNo = $filter('uppercase')($scope.receiptNo);
                }else if (obj == 'roomPrice') {
                    currItem.roomPrice = get2Float($scope.roomPrice);
                }else if (obj == 'serviceCharge') {
                    currItem.serviceCharge = get2Float($scope.serviceCharge);
                }else if (obj == 'totalAmountPerDay') {
                    currItem.totalAmountPerDay = get2Float($scope.totalAmountPerDay);
                }else if (obj == 'totalDays') {
                    currItem.totalDays = getNumber($scope.totalDays);
                }else if (obj == 'grossAmount') {
                    currItem.grossAmount = get2Float($scope.grossAmount);
                }else if (obj == 'gstAmount') {
                    currItem.gstAmount = get2Float($scope.gstAmount);
                }else if (obj == 'nettAmount') {
                    currItem.nettAmount = get2Float($scope.nettAmount);
                }else if (obj == 'corporateCard') {
                    currItem.corporateCard = $scope.corporateCard;
                }else if (obj == 'fundType') {
                    currItem.fundType = DataFundType.getFundType();
                }else if (obj == 'projectCode') {
                    currItem.projectCode = DataLookup.getProjectCode();
                }else if (obj == 'gstType') {
                    currItem.gstType = DataGST.getGSTType();
                }
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormHotel.setCurrSection(section);
        if (section == 'OD') {
            var trip = getTrip();
            $('#hotelODModalForm_trip_'+trip.id).modal('show');
        }

        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateAll();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormHotel.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var currItems = [];

        currItems = getItems();

        currItems.splice(index, 1); //remove the object from the array based on index
        if (currItems.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setForm(getItems($scope.directIndex));
                $scope.currIndex = $scope.directIndex;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setForm(getItems($scope.directIndex));
                $scope.currIndex = $scope.directIndex;
            }
        }
    };

    /* Calculation : Start */
    var calculateDiffDate = function(dateStart, dateEnd){
        if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
            $scope.totalDays = getNightDiffDate(dateStart, dateEnd);
            changeItemVal('totalDays');
            calculateAll();
        }
    };
    
    var calculateAll = function() {
        var roomPrice = get2Float($scope.roomPrice);
        var serviceCharge = get2Float($scope.serviceCharge);
        var totalAmountPerday = parseFloat(roomPrice) + parseFloat(serviceCharge);
        var totalDays = getNumber($scope.totalDays);
        var grossAmount = totalAmountPerday * parseFloat(totalDays);
        var gstAmount = parseFloat(grossAmount) * parseFloat(DataGST.getGSTFloat());
        var totalAmountInclusive = parseFloat(grossAmount) + parseFloat(gstAmount);

        $scope.totalAmountPerDay = get2Float(totalAmountPerday);
        $scope.grossAmount = get2Float(grossAmount);
        $scope.gstAmount = get2Float(gstAmount);
        $scope.nettAmount = get2Float(totalAmountInclusive);
        changeItemVal('totalAmountPerDay');
        changeItemVal('grossAmount');
        changeItemVal('gstAmount');
        changeItemVal('nettAmount');

        calculateGrandTotal();
    };

    var calculateGrandTotal = function(){
        var trip = getTrip('hotel');
        var items = getTrip('hotelItems');
        
        if (items) {
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
            trip['grandTotalGSTAmount'] = getListTotalAmount(items, 'gstAmount');
            trip['grandTotalNettAmount'] = getListTotalAmount(items, 'nettAmount');
        }
    };
    /* Calculation : End */
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
            $scope.grandTotalGrossAmount = get2Float(0);
            $scope.grandTotalGSTAmount = get2Float(0);
            $scope.grandTotalNettAmount = get2Float(0);
        }
    };
    
    $scope.$watch('checkinDate', function (newValue, oldValue) {
        if (newValue != oldValue) {
            calculateDiffDate(newValue, $scope.checkoutDate);
            changeItemVal('checkinDate');
            calculateAll();
        }
    });

    $scope.$watch('checkoutDate', function (newValue, oldValue) {
        if (newValue != oldValue) {
            calculateDiffDate($scope.checkinDate, newValue);
            changeItemVal('checkoutDate');
            calculateAll();
        }
    });

    $scope.$watch('travellingInfo', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('travellingInfo');}
    });

    $scope.$watch('receiptNo', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('receiptNo');}
    });

    $scope.$watch('roomPrice', function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('roomPrice');
            calculateAll();
        }
    });

    $scope.$watch('corporateCard', function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('corporateCard'); }
    });

    $scope.$watch('serviceCharge', function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('serviceCharge');
            calculateAll();
        }
    });

    $scope.$watch(function () { return DataGST.getGSTType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('gstType');
            calculateAll();
        }
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('fundType');}
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('projectCode');}
    });

}]);

uiBootstrapApp.controller('LodgingCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormLodging',
                                          'DataFundType', 'DataLookup',
                                          function($scope, $filter, DataFormMain, DataFormLodging,
                                                   DataFundType, DataLookup){
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openCheckinDate = function($event) {
        $scope.statusCheckinDate.opened = true;
    };
    $scope.openCheckoutDate = function($event) {
        $scope.statusCheckoutDate.opened = true;
    };

    $scope.statusCheckinDate = {
        opened: false
    };
    $scope.statusCheckoutDate = {
        opened: false
    };
    /** Date : End */
    
    var getTrip = function(objName){
        var currSection = DataFormLodging.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    };
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    $('div[id^=hotelODModalForm_trip_]').on('hidden.bs.modal', function (e) {
        // Close form
        disableEditMode();
    });

    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.checkinDate = getDateFromStr(objDB.check_in_date);
            $scope.checkoutDate = getDateFromStr(objDB.check_out_date);
            $scope.travellingInfo = objDB.travelling_info;
            $scope.address = objDB.address;
            $scope.totalDays = objDB.int_days;
            $scope.grossAmount = objDB.amount;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            checkinDate: $scope.checkinDate, checkinDateTxt: getDateStr($filter, $scope.checkinDate),
            checkoutDate: $scope.checkoutDate, checkoutDateTxt: getDateStr($filter, $scope.checkoutDate),
            travellingInfo: $scope.travellingInfo,
            address: $scope.address,
            totalDays: getNumber($scope.totalDays),
            grossAmount: get2Float($scope.grossAmount),
            fundType: DataFundType.getFundType(), projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        $scope.checkinDate = currItem.checkinDate;
        $scope.checkoutDate = currItem.checkoutDate;
        $scope.travellingInfo = currItem.travellingInfo;
        $scope.address = currItem.address;
        $scope.totalDays = currItem.totalDays;
        $scope.grossAmount = currItem.grossAmount;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var resetForm = function(){
        // Reset form
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormLodging.getCurrSection();

        if (currSection == 'OD') {
            var trip = getTrip();
            obj = trip.lodgingItems;
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                if (obj == 'checkinDate') {
                    currItem.checkinDate = DataFormLodging.getCheckinDate();
                    currItem.checkinDateTxt = DataFormLodging.getCheckinDateTxt();
                }else if (obj == 'checkoutDate') {
                    currItem.checkoutDate = DataFormLodging.getCheckoutDate();
                    currItem.checkoutDateTxt = DataFormLodging.getCheckoutDateTxt();
                }else if (obj == 'lodgingRegionDestination') {
                    currItem.lodgingRegionDestination = $scope.lodgingRegionDestination;
                }else if (obj == 'travellingInfo') {
                    currItem.travellingInfo = $scope.travellingInfo;
                }else if (obj == 'address') {
                    currItem.address = $scope.address;
                }else if (obj == 'totalDays') {
                    currItem.totalDays = getNumber($scope.totalDays);
                }else if (obj == 'totalAmount') {
                    currItem.grossAmount = get2Float($scope.grossAmount);
                }else if (obj == 'fundType') {
                    currItem.fundType = DataFundType.getFundType();
                }else if (obj == 'projectCode') {
                    currItem.projectCode = DataLookup.getProjectCode();
                }
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormLodging.setCurrSection(section);
        if (section == 'OD') {
            var trip = getTrip();
            $('#lodgingODModalForm_trip_'+trip.id).modal('show');
        }

        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormLodging.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var currItems = getItems();
        currItems.splice(index, 1); //remove the object from the array based on index
        if (currItems.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'previous' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                currItem = getItems($scope.directIndex);
                setForm(currItem);
                $scope.currIndex = $scope.directIndex;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                currItem = getItems($scope.directIndex);
                setForm(currItem);
                $scope.currIndex = $scope.directIndex;
            }
        }
    };

    /* Calculation : Start */
    var calculateDiffDate = function(dateStart, dateEnd){
        if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
            $scope.totalDays = getNightDiffDate(dateStart, dateEnd);
            changeItemVal('totalDays');
            calculateTotalLodgingAmount();
        }
    };
    
    var calculateTotalLodgingAmount = function(){
        var lodgingRate = $scope.getRate('offduty', 'lodging');
        var totalDays = get2Float($scope.totalDays);
        var grossAmount = parseFloat(lodgingRate) * parseFloat(totalDays);
        $scope.grossAmount = get2Float(grossAmount);
        changeItemVal('totalAmount');
        calculateGrandTotal();
    };

    var calculateGrandTotal = function () {
        var trip = getTrip('lodging');
        var items = getTrip('lodgingItems');
        
        if (items) {
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
        }
    };
    /* Calculation : End */
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
        }
    };
    
    $scope.$watch('checkinDate', function (newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('checkinDate');
            calculateDiffDate(newValue, $scope.checkoutDate);
        }
    });

    $scope.$watch('checkoutDate', function (newValue, oldValue) {
        if (newValue != oldValue && newValue) {
            changeItemVal('checkoutDate');
            calculateDiffDate($scope.checkinDate, newValue);
        }
    });

    $scope.$watch('travellingInfo', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('travellingInfo'); }
    });

    $scope.$watch('address', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('address'); }
    });

    $scope.$watch(function () { return DataFundType.getFundType();}, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('fundType'); }
    });

    $scope.$watch(function () { return DataLookup.getProjectCode();}, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('projectCode'); }
    });
}]);

uiBootstrapApp.controller('MileageCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormMileage',
                                          'DataFundType', 'DataLookup',
                                       function($scope, $filter, DataFormMain, DataFormMileage,
                                                DataFundType, DataLookup){

    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    /** Time : Start */
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.departTime = initTime;
    $scope.returnTime = initTime;
    /** Time : End */
    
    var getTrip = function(objName){
        var currSection = DataFormMileage.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    $('dic[id^=mileageODForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });

    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.departDate = getDateFromStr(objDB.depart_date);
            $scope.returnData = getDateFromStr(objDB.return_date);
            $scope.departTime = getTimeFromStr(objDB.depart_time);
            $scope.returnTime = getTimeFromStr(objDB.return_time);
            $scope.destinationFrom = objDB.destination_from;
            $scope.destinationTo = objDB.destination_to;
            $scope.description = objDB.travelling_info;
            $scope.tripType = objDB.trip_type;
            $scope.vehicleType = DataFormMain.getVehicleTypeByCode(objDB.vehicle_type);
            $scope.vehicleRegistrationNo = objDB.vehicle_reg_no;
            $scope.mileage = objDB.mileage;
            $scope.grossAmount = objDB.amount;
            $scope.corporateCard = objDB.corporate_card;
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            departDate: $scope.departDate, departDateTxt: getDateStr($filter, $scope.departDate),
            departTime: $scope.departTime, departTimeTxt: getTimeStr($scope.departTime),
            returnDate: $scope.returnDate, returnDateTxt: getDateStr($filter, $scope.returnDate),
            returnTime: $scope.returnTime, returnTimeTxt: getTimeStr($scope.returnTime),
            destinationFrom: $scope.destinationFrom, destinationTo: $scope.destinationTo,
            description: $scope.description,
            tripType: $scope.tripType,
            vehicleCC: $scope.vehicleCC, vehicleType: $scope.vehicleType,
            vehicleRegistrationNo: $filter('uppercase')($scope.vehicleRegistrationNo),
            mileage: get1Float($scope.mileage),
            cumulativeMileage: get1Float($scope.cumulativeMileage),
            grossAmount: get2Float($scope.grossAmount),
            corporateCard: $scope.corporateCard,
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        $scope.departDate = currItem.departDate;
        $scope.departTime = currItem.departTime;
        $scope.returnDate = currItem.returnDate;
        $scope.returnTime = currItem.returnTime;
        $scope.destinationFrom = currItem.destinationFrom;
        $scope.destinationTo = currItem.destinationTo;
        $scope.description = currItem.description;
        $scope.tripType = currItem.tripType;
        $scope.vehicleCC = currItem.vehicleCC;
        $scope.vehicleType = currItem.vehicleType;
        $scope.vehicleRegistrationNo = currItem.vehicleRegistrationNo;
        $scope.mileage = currItem.mileage;
        $scope.grossAmount = currItem.grossAmount;
        $scope.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var resetForm = function(){
        DataLookup.setProjectCode('');
        DataLookup.setDisabled(true);
        $scope.destinationFrom = '';
        $scope.destinationTo = '';
        $scope.description = '';
        $scope.mileage = '';
        $scope.grossAmount = '';
        $scope.corporateCard = false;
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormMileage.getCurrSection();

        if (currSection == 'OD') {
            var trip = getTrip();
            obj = trip.mileageItems;
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    var changeItemVal = function(obj) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                if (obj == 'departDate') {
                    currItem.departDate = $scope.departDate;
                    currItem.departDateTxt = getDateStr($filter, $scope.departDate);
                }else if (obj == 'departTime') {
                    currItem.departTime = $scope.departTime;
                    currItem.departTimeTxt = getTimeStr($scope.departTime);
                }else if (obj == 'returnDate') {
                    currItem.returnDate = $scope.returnDate;
                    currItem.returnDateTxt = getDateStr($filter, $scope.returnDate);
                }else if (obj == 'returnTime') {
                    currItem.returnTime = $scope.returnTime;
                    currItem.returnTimeTxt = getTimeStr($scope.returnTime);
                }else if (obj == 'destinationFrom') {
                    currItem.destinationFrom = $scope.destinationFrom;
                }else if (obj == 'destinationTo') {
                    currItem.destinationTo = $scope.destinationTo;
                }else if (obj == 'description') {
                    currItem.description = $scope.description;
                }else if (obj == 'vehicleCC') {
                    currItem.vehicleCC = $scope.vehicleCC;
                }else if (obj == 'vehicleType') {
                    currItem.vehicleType = $scope.vehicleType;
                }else if (obj == 'vehicleRegistrationNo') {
                    currItem.vehicleRegistrationNo = $filter('uppercase')($scope.vehicleRegistrationNo);
                }else if (obj == 'mileage') {
                    currItem.mileage = get1Float($scope.mileage);
                }else if (obj == 'totalAmount') {
                    currItem.grossAmount = get2Float($scope.grossAmount);
                }else if (obj == 'corporateCard') {
                    currItem.corporateCard = $scope.corporateCard;
                }else if (obj == 'fundType') {
                    currItem.fundType = DataFundType.getFundType();
                }else if (obj == 'projectCode') {
                    currItem.projectCode = DataLookup.getProjectCode();
                }
            }
        }
    };

    $scope.openModal = function(section, mode){
        DataFormMileage.setCurrSection(section);
        if (section == 'OD') {
            var trip = getTrip();
            $('#mileageODModalForm_trip_'+trip.id).modal('show');
        }

        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        //resetForm();
        calculateAll();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormMileage.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAll();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                currItem = items[$scope.directIndex];
                setForm(currItem);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                currItem = items[$scope.directIndex];
                setForm(currItem);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };

    /* Start : Calculation (Summary) */
    var calculateCumulativeMileageEachRow = function(){
        var index = 1;
        var rowCumulativeMileage = 0;
        var prevCumulativeMileage = 0;
        var grossAmount = 0;
        var items = getItems();
        angular.forEach(items, function(obj){
            var vehicleCCRates = obj['vehicleCC'];
            var rowMileage = parseFloat(obj['mileage']);
            if (index == 1) {
                rowCumulativeMileage = parseFloat($scope.prevCumulativeMileage) + rowMileage;
            }else{
                rowCumulativeMileage = rowCumulativeMileage + rowMileage;
            }
            obj['cumulativeMileage'] = get1Float(rowCumulativeMileage);
            grossAmount = calculateAmountBaseOnCumulative(prevCumulativeMileage, rowMileage, rowCumulativeMileage, vehicleCCRates);
            prevCumulativeMileage = prevCumulativeMileage + rowMileage;
            obj['grossAmount'] = get2Float(grossAmount);
            index++;
        });
    };

    var calculateAmountBaseOnCumulative = function(prevCumulativeMileage, rowMileage, rowCumulativeMileage, vehicleCCRates){
        var isNextCheck = false;
        var index = 1;
        var currCumulative = rowCumulativeMileage;
        var finalAmount = 0;
        var prevBalMileage = 0;
        var prevRate = 0;
        var prevRangeEnd = 0;
        var prevTotalBalMileage = 0;
        var prevAmount = 0;
        var prevTotalAmount = 0;
        var ratesLastIndex = vehicleCCRates['rates_bycc'].length;
        var totalFinalCumulative = 0;

        angular.forEach(vehicleCCRates['rates_bycc'], function(obj){
            var rangeStart = obj['range_start'];
            var rangeEnd = obj['range_end'];
            var rateCC = get2Float(obj['rate']);
            var rateSalary = get2Float(obj['rate_bysalary']);
        });

        angular.forEach(vehicleCCRates['rates_bycc'], function(obj){
            var rangeStart = obj['range_start'];
            var rangeEnd = obj['range_end'];
            var rateCC = get2Float(obj['rate']);
            var rateSalary = get2Float(obj['rate_bysalary']);
            var rate = 0;
            var rowAmount = 0;
            var finalCumulative = 0;

            if (index == 1) {
                isNextCheck = true;
            }
            if (isNextCheck) {
                /* Get lower rate : Start */
                if (rateCC <= rateSalary) {
                    rate = rateCC;
                }else{
                    rate = rateSalary;
                }
                /* Get lower rate : End */
                if (currCumulative <= rangeEnd) {
                    if (prevBalMileage > 0) {
                        rowMileage = rowMileage - prevTotalBalMileage;
                    }
                    finalAmount = (rowMileage * rate) + prevTotalAmount;
                    isNextCheck = false;
                }else if (currCumulative > rangeEnd && prevCumulativeMileage < rangeEnd) {
                    if (prevCumulativeMileage == 0) {
                        if (index == 1) {
                            prevBalMileage = rangeEnd - rangeStart;
                        }else if (index > 1){
                            prevBalMileage = rangeEnd - rangeStart + 1;
                        }
                    }else{
                        prevBalMileage = rangeEnd - prevCumulativeMileage;
                        if (prevBalMileage > rangeEnd) {
                            if (index == 1) {
                                prevBalMileage = rangeEnd - rangeStart;
                            }else if (index > 1){
                                prevBalMileage = rangeEnd - rangeStart + 1;
                            }
                        }else if (prevBalMileage < rangeEnd && prevBalMileage < prevCumulativeMileage) {
                            /*
                            if (index == 1) {
                                prevBalMileage = rangeEnd - rangeStart;
                            }else if (index > 1){
                                prevBalMileage = rangeEnd - rangeStart + 1;
                            }*/
                        }
                    }
                    prevRate = rate;
                    prevTotalAmount = prevTotalAmount + (prevBalMileage * prevRate);
                    prevTotalBalMileage = prevTotalBalMileage + prevBalMileage;
                }
                index++;
            }
        });
        return finalAmount;
    };
    
    var calculateMileageAmount = function () {
        var mileage = $scope.mileage;
        var grossAmount = 0;
        var rate = 0;
        if ($scope.isConfVEHICLETYPE) {
            var vehicleType = $scope.vehicleType;
            rate = $scope.getVehicleRateByTypeID(vehicleType.id);
        }else{
            var cumulativeMileage = 0;
            cumulativeMileage = parseFloat(mileage) + parseFloat($scope.grandTotalMileage);
            if ($scope.vehicleCC.rates_bycc) {
                rate = $scope.vehicleCC.rates_bycc[0].rate;
            }
        };
        grossAmount = parseFloat(mileage) * parseFloat(rate);
        $scope.grossAmount = get2Float(grossAmount);
    };

    var calculateAll = function(){
        if (!$scope.isConfVEHICLETYPE) {
            calculateCumulativeMileageEachRow();
        }
        calculateGrandTotal();
    };

    var calculateGrandTotal =  function(){
        var trip = getTrip('mileage');
        var items = getTrip('mileageItems');
        
        if (items) {
            trip['grandTotalMileage'] = get1Float(getListTotalAmount(items, 'mileage'));
            trip['grandTotalCumulativeMileage'] = get1Float(getListTotalAmount(items, 'cumulativeMileage'));
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
        }
    };
    /* End : Calculation (Summary) */

    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
            $scope.grandTotalMileage = get2Float(0);
            $scope.grandTotalCumulativeMileage = get2Float(0);
            $scope.grandTotalGrossAmount = get2Float(0);
            $scope.prevCumulativeMileage = get2Float(0);
            $scope.vehicleCC = [];
        }
    };
    
    $scope.$watch('destinationFrom',function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('destinationFrom');}
    });

	$scope.$watch('destinationTo',function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('destinationTo');}
    });

	$scope.$watch('description',function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('description');};
    });

	$scope.$watch('vehicleCC',function(newValue, oldValue) {
        if (newValue != oldValue && newValue != null) {
            changeItemVal('vehicleCC');
            calculateMileageAmount();
        };
    });

	$scope.$watch('vehicleType',function(newValue, oldValue) {
        if (newValue != oldValue && newValue != null) {
            $scope.mileageVehicleRate = $scope.vehicleType.rate;
            changeItemVal('vehicleType');
            calculateMileageAmount();
        }
    });

    $scope.$watch('vehicleRegistrationNo', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('vehicleRegistrationNo');};
    });

    $scope.$watch('mileage', function(newValue, oldValue) {
        if (newValue != oldValue && newValue != '') {
            changeItemVal('mileage');
            calculateMileageAmount();
        };
    });

    $scope.$watch('grossAmount', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('grossAmount');};
    });

    $scope.$watch('corporateCard', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('corporateCard');};
    });

    $scope.$watch('departDate', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('departDate');}
    });

    $scope.$watch('departTime', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('departTime');}
    });

    $scope.$watch('returnDate', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('returnDate');}
    });

    $scope.$watch('returnTime', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('returnTime');}
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('fundType');
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('projectCode');
    });
}]);

uiBootstrapApp.controller('PublicTransportCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormPublicTransport',
                                                  'DataFundType', 'DataLookup', 'DataGST',
                                                  function($scope, $filter, DataFormMain, DataFormPublicTransport,
                                                           DataFundType, DataLookup, DataGST){
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };
    $scope.openReturnDate = function($event) {
        $scope.statusReturnDate.opened = true;
    };

    $scope.statusDepartDate = {
        opened: false
    };
    $scope.statusReturnDate = {
        opened: false
    };
    /** Date : End */
    
    /** Time : Start */
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.departTime = initTime;
    $scope.returnTime = initTime;
    /** Time : End */
    
    $('div[id^=publicTransportODModalForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getTrip = function(objName){
        var currSection = DataFormPublicTransport.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.departDate = getDateFromStr(objDB.depart_date);
            $scope.returnDate = getDateFromStr(objDB.return_date);
            $scope.departTime = getTimeFromStr(objDB.depart_time);
            $scope.returnTime = getTimeFromStr(objDB.return_time);
            $scope.destinationType = objDB.destination_type;
            $scope.destinationFrom = objDB.destination_from;
            $scope.destinationTo = objDB.destination_to;
            $scope.description = objDB.travelling_info;
            $scope.publicTransportType = DataFormMain.getPublicTransportTypeByCode(objDB.type);
            $scope.receiptNo = objDB.receipt_no;
            $scope.foreignCurrencyAmount = objDB.foreign_currency_amount;
            $scope.grossAmount = objDB.amount;
            $scope.gstAmount = objDB.gst_amount;
            $scope.nettAmount = objDB.nett_amount;
            $scope.corporateCard = objDB.corporate_card;
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            departDate: $scope.departDate, departDateTxt: getDateStr($filter, $scope.departDate),
            departTime: $scope.departTime, departTimeTxt: getTimeStr($scope.departTime),
            returnDate: $scope.returnDate, returnDateTxt: getDateStr($filter, $scope.returnDate),
            returnTime: $scope.returnTime, returnTimeTxt: getTimeStr($scope.returnTime),
            destinationType: $scope.destinationType,
            destinationFrom: $scope.destinationFrom, destinationTo: $scope.destinationTo,
            description: $scope.description,
            publicTransportType: $scope.publicTransportType, publicTransportTypeTxt: $scope.publicTransportType.label,
            receiptNo: $filter('uppercase')($scope.receiptNo),
            foreignCurrencyAmount: get2Float($scope.foreignCurrencyAmount),
            grossAmount: get2Float($scope.grossAmount),
            gstType: DataGST.getGSTType(),
            gstAmount: get2Float($scope.gstAmount),
            nettAmount: get2Float($scope.nettAmount),
            corporateCard: $scope.corporateCard,
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        $scope.departDate = currItem.departDate;
        $scope.departTime = currItem.departTime;
        $scope.returnDate = currItem.returnDate;
        $scope.returnTime = currItem.returnTime;
        $scope.destinationType = currItem.destinationType;
        $scope.destinationFrom = currItem.destinationFrom;
        $scope.destinationTo = currItem.destinationTo;
        $scope.description = currItem.description;
        $scope.publicTransportType = currItem.publicTransportType;
        $scope.receiptNo = currItem.receiptNo;
        $scope.grossAmount = currItem.grossAmount;
        $scope.gstAmount = currItem.gstAmount;
        $scope.foreignCurrencyAmount = currItem.foreignCurrencyAmount;
        $scope.nettAmount = currItem.nettAmount;
        $scope.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        DataGST.setGSTType(currItem.gstType);
    };

    var resetForm = function(){

    };

    var changeItemVal = function(objName, val) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                currItem[objName] = val;
                if (objName == 'departDate') {
                    currItem.departDateTxt = getDateStr($filter, $scope.departDate);
                }else if (objName == 'departTime') {
                    currItem.departTimeTxt = getTimeStr($scope.departTime);
                }else if (objName == 'returnDate') {
                    currItem.returnDateTxt = getDateStr($filter, $scope.returnDate);
                }else if (objName == 'returnTime') {
                    currItem.returnTimeTxt = getTimeStr($scope.returnTime);
                }
            }
        }
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormPublicTransport.getCurrSection();

        if (currSection == 'OD') {
            obj = getTrip('publicTransportItems');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    var changeCurrencyDisplay = function(){
        var currencyType = getTrip('currencyType');
        if (!currencyType) {
            currencyType = '?';
        }
        $scope.currencyType = currencyType;
    };
    
    var switchTypeMode = function(typeCode){
        if (typeCode == 'Oversea') {
            $scope.isTypeOversea = true;
            $scope.foreignCurrencyAmount = '';
            DataGST.setGSTType([]);
        }else{
            $scope.isTypeOversea = false;
            $scope.grossAmount = '';
            $scope.foreignCurrencyAmount = get2Float(0);
        }
    };
    
    $scope.openModal = function(section, mode){
        DataFormPublicTransport.setCurrSection(section);
        changeCurrencyDisplay();
        if (section == 'OD') {
            var tripID = getTrip('id');
            $('#publicTransportODModalForm_trip_'+tripID).modal('show');
        }

        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormPublicTransport.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };
    
    /* Start : Calculation */
    var convertToRM = function(){
        var currencyRate = getTrip('currencyRate');
        var destinationType = $scope.destinationType.code;
        if (destinationType == 'Oversea') {
            var rmAmount = parseFloat($scope.foreignCurrencyAmount) * parseFloat(currencyRate);
            $scope.grossAmount = get2Float(rmAmount);
            calculateNettAmount();
        }
    };
    
    var calculateNettAmount = function(){
        var amountOri = $scope.grossAmount;
        var amountGST = calculateGSTAmount(amountOri);
        var amountFinal = parseFloat(amountOri) + parseFloat(amountGST);
        
        $scope.gstAmount = get2Float(amountGST);
        $scope.nettAmount = get2Float(amountFinal);
        calculateGrandTotal();
        changeItemVal('grossAmount', get2Float($scope.grossAmount));
        changeItemVal('gstAmount', get2Float($scope.gstAmount));
        changeItemVal('nettAmount', get2Float($scope.nettAmount));
    };
    
    var calculateGSTAmount = function(oriAmount){
        return get2Float((parseFloat(oriAmount) * parseFloat(DataGST.getGSTFloat())));
    };

    var calculateGrandTotal = function(){
        var trip = getTrip('publicTransport');
        var items = getTrip('publicTransportItems');
        
        if (items) {
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
            trip['grandTotalGSTAmount'] = getListTotalAmount(items, 'gstAmount');
            trip['grandTotalNettAmount'] = getListTotalAmount(items, 'nettAmount');
        }
    };
    /* End : Calculation */
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
            $scope.grandTotalGrossAmount = get2Float(0);
            $scope.grandTotalGSTAmount = get2Float(0);
            $scope.grandTotalNettAmount = get2Float(0);
            $scope.isTypeOversea = false;
            $scope.currencyType = '?';
        }
    };
    
    $scope.$watch('departDate', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('departDate', newValue);};
    });

    $scope.$watch('departTime', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('departTime', newValue);};
    });

    $scope.$watch('returnDate', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('returnDate', newValue);};
    });

    $scope.$watch('returnTime', function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('returnTime', newValue);};
    });
    
	$scope.$watch('destinationFrom', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('destinationFrom', newValue);};
    });

	$scope.$watch('destinationTo', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('destinationTo', newValue);};
    });

	$scope.$watch('description', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('description', newValue);};
    });
    
    $scope.$watch('destinationType', function(newValue, oldValue){
        if (newValue != oldValue) {
            changeItemVal('destinationType', newValue);
            switchTypeMode(newValue.code);
        }
    });
    
	$scope.$watch('publicTransportType', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('publicTransportType', newValue);};
    });

	$scope.$watch('receiptNo', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('receiptNo', newValue);};
    });

    $scope.$watch('grossAmount', function(newValue, oldValue){
        if (newValue != oldValue) {calculateNettAmount();};
    });
    
    $scope.$watch('foreignCurrencyAmount', function(newValue, oldValue){
        if (newValue != oldValue) {
            convertToRM();
        }
    });

    $scope.$watch('corporateCard', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('corporateCard', newValue);};
    });

    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('fundType', newValue);};
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('projectCode', newValue);};
    });

    $scope.$watch(function () { return DataGST.getGSTType(); }, function (newValue, oldValue) {
        if (newValue != oldValue && newValue != null) {
            changeItemVal('gstType', newValue);
            calculateNettAmount();
        }
    });
}]);

uiBootstrapApp.controller('TransitCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormTransit',
                                          'DataFundType', 'DataLookup',
                                          function($scope, $filter, DataFormMain, DataFormTransit,
                                                   DataFundType, DataLookup){
    
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openArrivalDate = function($event) {
        $scope.statusArrivalDate.opened = true;
    };
    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };

    $scope.statusArrivalDate = {
        opened: false
    };
    $scope.statusDepartDate = {
        opened: false
    };
    /** Date : End */
    
    /** Time : Start */
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.arrivalTime = initTime;
    $scope.departTime = initTime;
    /** Time : End */
    
    $('div[id^=transitODForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getTrip = function(objName){
        var currSection = DataFormTransit.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.departDate = getDateFromStr(objDB.depart_date);
            $scope.returnDate = getDateFromStr(objDB.return_date);
            $scope.departTime = getTimeFromStr(objDB.depart_time);
            $scope.returnTime = getTimeFromStr(objDB.return_time);
            $scope.destinationType = objDB.destination_type;
            $scope.destinationFrom = objDB.destination_from;
            $scope.destinationTo = objDB.destination_to;
            $scope.description = objDB.travelling_info;
            //$scope.publicTransportType = DataFormMain.getPublicTransportTypeByCode(objDB.type);
            $scope.receiptNo = objDB.receipt_no;
            $scope.foreignCurrencyAmount = objDB.foreign_currency_amount;
            $scope.grossAmount = objDB.amount;
            $scope.gstAmount = objDB.gst_amount;
            $scope.nettAmount = objDB.nett_amount;
            $scope.corporateCard = objDB.corporate_card;
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            arrivalDate: $scope.arrivalDate, arrivalDateTxt: getDateStr($filter, $scope.arrivalDate),
            arrivalTime: $scope.arrivalTime, arrivalTimeTxt: getTimeStr($scope.arrivalTime),
            departDate: $scope.departDate, departDateTxt: getDateStr($filter, $scope.departDate),
            departTime: $scope.departTime, departTimeTxt: getTimeStr($scope.departTime),
            description: $scope.description,
            transitType: $scope.transitType,
            accommodationType: $scope.accommodationType,
            receiptNo: $filter('uppercase')($scope.receiptNo),
            foreignCurrencyAmount: get2Float($scope.foreignCurrencyAmount),
            hotelAmount: get2Float($scope.hotelAmount),
            lodgingAddress: $scope.lodgingAddress,
            lodgingAmount: get2Float($scope.lodgingAmount),
            dailyAmount: get2Float($scope.dailyAmount),
            mealAmount: get2Float($scope.mealAmount),
            totalMealAmount: get2Float(parseFloat($scope.dailyAmount) + parseFloat($scope.mealAmount)),
            grossAmount: get2Float($scope.grossAmount),
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        $scope.arrivalDate = currItem.arrivalDate;
        $scope.arrivalTime = currItem.arrivalTime;
        $scope.departDate = currItem.departDate;
        $scope.departTime = currItem.departTime;
        $scope.description = currItem.description;
        $scope.transitType = currItem.transitType;
        $scope.accommodationType = currItem.accommodationType;
        $scope.receiptNo = currItem.receiptNo;
        $scope.foreignCurrencyAmount = currItem.foreignCurrencyAmount;
        $scope.hotelAmount = currItem.hotelAmount;
        $scope.lodgingAddress = currItem.lodgingAddress;
        $scope.lodgingAmount = currItem.lodgingAmount;
        $scope.dailyAmount = currItem.dailyAmount;
        $scope.mealAmount = currItem.mealAmount;
        $scope.totalMealAmount = currItem.totalMealAmount;
        $scope.grossAmount = currItem.grossAmount;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var resetForm = function(){

    };

    var changeItemVal = function(objName, val) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                currItem[objName] = val;
                if (objName == 'arrivalDate') {
                    currItem.arrivalDateTxt = getDateStr($filter, $scope.arrivalDate);
                }else if (objName == 'arrivalTime') {
                    currItem.arrivalTimeTxt = getTimeStr($scope.arrivalTime);
                }else if (objName == 'departDate') {
                    currItem.departDateTxt = getDateStr($filter, $scope.departDate);
                }else if (objName == 'departTime') {
                    currItem.departTimeTxt = getTimeStr($scope.departTime);
                }
            }
        }
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormTransit.getCurrSection();

        if (currSection == 'OD') {
            obj = getTrip('transitItems');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    var changeCurrencyDisplay = function(){
        var currencyType = getTrip('currencyType');
        if (!currencyType) {
            currencyType = '?';
        }
        $scope.currencyType = currencyType;
    };
    
    $scope.openModal = function(section, mode){
        DataFormTransit.setCurrSection(section);
        changeCurrencyDisplay();
        if (section == 'OD') {
            var tripID = getTrip('id');
            $('#transitODModalForm_trip_'+tripID).modal('show');
        }

        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };

    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormTransit.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };
    
    /** Calculation : Start */
    $scope.intDays = 0;
    $scope.intDaily = 0;
    
    var calculateIntDaily = function (timeStart, timeEnd) {
        /** Follow MealCtrl calculation */
        var diff = getTimeDiff(timeStart, timeEnd);
        if (diff > 8) {
            /** Greater than 8 hours */
            $scope.intDaily = 1;
        }else{
            /** Lower than 8 hours */
            $scope.intDaily = 0;
        }
        calculateMealDailyAmount();
    };
    
    var calculateMealDailyAmount = function(){
        var rate = $scope.getRate('offduty', 'meal');
        var intDays = getNumber($scope.intDays);
        var intDaily = getNumber($scope.intDaily);
        var mealAmount = 0;
        var dailyAmount = 0;
        var totalMealAmount = 0;
        
        /*  Based on the RA on Transit form
         *  1) Meal amount is only applicable for Flight > 12 hours & Stranded.
         */
        var transitType = $scope.transitType;
        if (transitType) {
            // Only calculate meal amount if the type is other than Transit.
            if (transitType.code != 'Transit') {
                mealAmount = parseFloat(rate) * parseFloat(intDays);
            }
            dailyAmount = parseFloat(rate) * 0.5 * parseFloat(intDaily);
        }else{
            mealAmount = 0;
            dailyAmount = 0;
        }
        totalMealAmount = parseFloat(dailyAmount) + parseFloat(mealAmount);
        
        $scope.mealAmount = get2Float(mealAmount);
        $scope.dailyAmount = get2Float(dailyAmount);
        $scope.totalMealAmount = get2Float(totalMealAmount);
        changeItemVal('mealAmount', get2Float(mealAmount));
        changeItemVal('dailyAmount', get2Float(dailyAmount));
        changeItemVal('totalMealAmount', get2Float(totalMealAmount));
        calculateTotalAmount();
    };
    
    var convertToRM = function(){
        var currencyRate = getTrip('currencyRate');
        var rmAmount = parseFloat($scope.foreignCurrencyAmount) * parseFloat(currencyRate);
        $scope.hotelAmount = get2Float(rmAmount);
        changeItemVal('hotelAmount', get2Float(rmAmount));
        calculateTotalAmount();
    };
    
    var calculateDiffDate = function(dateStart, dateEnd){
        if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
            $scope.intDays = getNightDiffDate(dateStart, dateEnd);
            //changeItemVal('totalDays');
            calculateMealDailyAmount();
            calculateLodgingAmount();
        }
    };
    
    var calculateLodgingAmount = function(){
        var lodgingRate = $scope.getRate('offduty', 'lodging');
        var intDays = get2Float($scope.intDays);
        var lodgingAmount = 0;
        
        var accommodationType = $scope.accommodationType;
        if (accommodationType && accommodationType.code == 'Lodging') {
            lodgingAmount = parseFloat(lodgingRate) * parseFloat(intDays);
        }
        $scope.lodgingAmount = get2Float(lodgingAmount);
        changeItemVal('lodgingAmount', get2Float(lodgingAmount));
        calculateTotalAmount();
    };
    
    var calculateTotalAmount = function(){
        var lodgingAmount = get2Float($scope.lodgingAmount);
        var hotelAmount = get2Float($scope.hotelAmount);
        var dailyAmount = get2Float($scope.dailyAmount);
        var mealAmount = get2Float($scope.mealAmount);
        var grossAmount = 0;
        
        grossAmount = parseFloat(lodgingAmount) + parseFloat(hotelAmount) + parseFloat(dailyAmount) +
        parseFloat(mealAmount);
        $scope.grossAmount = get2Float(grossAmount);
        changeItemVal('grossAmount', get2Float(grossAmount));
        calculateGrandTotal();
    };
    
    var calculateGrandTotal = function(){
        var trip = getTrip('transit');
        var items = getTrip('transitItems');
        
        if (items) {
            trip['grandTotalForeignCurrencyAmount'] = getListTotalAmount(items, 'foreignCurrencyAmount');
            trip['grandTotalHotelAmount'] = getListTotalAmount(items, 'hotelAmount');
            trip['grandTotalLodgingAmount'] = getListTotalAmount(items, 'lodgingAmount');
            trip['grandTotalMealAmount'] = getListTotalAmount(items, 'mealAmount');
            trip['grandTotalDailyAmount'] = getListTotalAmount(items, 'dailyAmount');
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
        }
    };
    /** Calculation : End */
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
        }
    };
    
    $scope.$watch('arrivalDate', function(newValue, oldValue){
        if (newValue!=oldValue) {
            calculateDiffDate(newValue, $scope.departDate);
            changeItemVal('arrivalDate', newValue);
        }
    });
    $scope.$watch('departDate', function(newValue, oldValue){
        if (newValue!=oldValue) {
            calculateDiffDate($scope.arrivalDate, newValue);
            changeItemVal('departDate', newValue);
        }
    });
    
    $scope.$watch('arrivalTime', function(newValue, oldValue){
        if (newValue!=oldValue) {
            calculateIntDaily(newValue, $scope.departTime);
            changeItemVal('arrivalTime', newValue);
        }
    });
    $scope.$watch('departTime', function(newValue, oldValue){
        if (newValue!=oldValue) {
            calculateIntDaily($scope.arrivalTime, newValue);
            changeItemVal('departTime', newValue);
        }
    });
    
    $scope.$watch('transitType', function(newValue, oldValue){
        if (newValue && newValue != oldValue) {
            var type = newValue.code;
            if (type == 'Transit') {
                $scope.accommodationType = {};
                $scope.isEnableAccommodationType = false;
                $scope.isEnableHotel = false;
                $scope.isEnableLodging = false;
            }else if (type == 'Flight') {
                $scope.isEnableAccommodationType = true;
            }else if (type == 'Stranded') {
                $scope.isEnableAccommodationType = true;
            };
            calculateMealDailyAmount();
            changeItemVal('transitType', newValue);
        }
    });
    
    $scope.$watch('accommodationType', function(newValue, oldValue){
        if (newValue && newValue != oldValue) {
            var type = newValue.code;
            if (type == 'Hotel') {
                $scope.isEnableHotel = true;
                $scope.isEnableLodging = false;
                $scope.lodgingAmount = '';
            }else if (type == 'Lodging'){
                $scope.isEnableHotel = false;
                $scope.isEnableLodging = true;
                $scope.foreignCurrencyAmount = '';
                $scope.grossAmount = '';
            };
            calculateLodgingAmount();
            changeItemVal('accommodationType', newValue);
        }
    });
    
    $scope.$watch('foreignCurrencyAmount', function(newValue, oldValue){
        if (newValue != oldValue) {
            convertToRM();
            changeItemVal('foreignCurrencyAmount', get2Float(newValue));
        }
    });
    
    $scope.$watch('lodgingAddress', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('lodgingAddress', newValue); }
    });
    
    $scope.$watch('receiptNo', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('receiptNo', $filter('uppercase')(newValue)); }
    });
    
    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('fundType', newValue); }
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('projectCode', newValue); }
    });
}]);

uiBootstrapApp.controller('FixedReplacementCtrl', ['$scope', '$filter', '$uibModal', 'DataFormMain',
                                                   'DataFormFixedReplacement', 'DataFundType', 'DataLookup',
                                                   function($scope, $filter, $uibModal, DataFormMain,
                                                            DataFormFixedReplacement, DataFundType, DataLookup){
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openArrivalDate = function($event) {
        $scope.statusArrivalDate.opened = true;
    };
    $scope.openDepartDate = function($event) {
        $scope.statusDepartDate.opened = true;
    };

    $scope.statusArrivalDate = {
        opened: false
    };
    $scope.statusDepartDate = {
        opened: false
    };
    /** Date : End */
    
    /** Time : Start */
    var initTime = new Date();
    initTime.setHours(0);
    initTime.setMinutes(0);
    
    $scope.departTime = initTime;
    /** Time : End */
    
    $('div[id^=fixedReplacementODForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getTrip = function(objName){
        var currSection = DataFormFixedReplacement.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var setEditMode = function(itemIndex){
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };
    
    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.departDate = getDateFromStr(objDB.depart_date);
            $scope.returnDate = getDateFromStr(objDB.return_date);
            $scope.returnTime = getTimeFromStr(objDB.return_time);
            $scope.mealAmount = get2Float(objDB.meal_amount);
            $scope.lodgingAmount = get2Float(objDB.lodging_amount);
            $scope.totalAmount = get2Float(objDB.total_amount);
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            arrivalDate: $scope.arrivalDate,
            arrivalDateTxt: getDateStr($filter, $scope.arrivalDate),
            departDate: $scope.departDate,
            departDateTxt: getDateStr($filter, $scope.departDate),
            departTime: $scope.departTime,
            departTimeTxt: getTimeStr($scope.departTime),
            description: $scope.description,
            chkDistribution: $scope.chkDistribution,
            mealDistribution: $scope.mealDistribution,
            mealAmount: $scope.mealAmount,
            chkLodgingDistribution: $scope.chkLodgingDistribution,
            lodgingDistribution: $scope.lodgingDistribution,
            lodgingAmount: $scope.lodgingAmount,
            grossAmount: get2Float($scope.grossAmount),
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        $scope.arrivalDate = currItem.arrivalDate;
        $scope.departDate = currItem.departDate;
        $scope.departTime = currItem.departTime;
        $scope.description = currItem.description;
        $scope.chkDistribution = currItem.chkDistribution;
        $scope.mealDistribution = currItem.mealDistribution;
        $scope.mealAmount = currItem.mealAmount;
        $scope.chkLodgingDistribution = currItem.chkLodgingDistribution;
        $scope.lodgingDistribution = currItem.lodgingDistribution;
        $scope.lodgingAmount = currItem.lodgingAmount;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var resetForm = function(){

    };

    var changeItemVal = function(objName, val) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                currItem[objName] = val;
                if (objName == 'arrivalDate') {
                    currItem.arrivalDateTxt = getDateStr($filter, $scope.arrivalDate);
                }else if (objName == 'departDate') {
                    currItem.departDateTxt = getDateStr($filter, $scope.departDate);
                }else if (objName == 'departTime') {
                    currItem.departTimeTxt = getTimeStr($scope.departTime);
                }
            }
        }
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormFixedReplacement.getCurrSection();

        if (currSection == 'OD') {
            obj = getTrip('fixedReplacementItems');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    /* Calculation : Start */
    var calculateDiffDate = function(dateStart, dateEnd){
        if (angular.isDate(dateStart) && angular.isDate(dateEnd)) {
            $scope.intTotalDays = getNightDiffDate(dateStart, dateEnd) + 1;
            changeItemVal('intTotalDays');
            calculateTotalAmount();
        }
    };
    
    var calculateTotalAmount = function(){
        /**
         *  Based on RA below:
         *  Total Amount = (Meal Rate + Lodging Rate) * Total days of official duty.
         */
        var intTotalDays = $scope.intTotalDays;
        var mealAmount = 0;
        var lodgingAmount = 0; 
        if (!$scope.chkDistribution) {
            mealAmount = parseFloat($scope.mealRate) * parseFloat(intTotalDays);
            $scope.mealAmount = get2Float(mealAmount);
            changeItemVal('mealAmount', get2Float(mealAmount));
        }else{
            mealAmount = $scope.mealAmount;
        }
        
        if (!$scope.chkLodgingDistribution) {
            lodgingAmount = parseFloat($scope.lodgingRate) * parseFloat(intTotalDays);
            $scope.lodgingAmount = get2Float(lodgingAmount);
            changeItemVal('lodgingAmount', get2Float(lodgingAmount));
        }else{
            lodgingAmount = $scope.lodgingAmount;
        }
        var grossAmount = parseFloat(mealAmount) + parseFloat(lodgingAmount);
        $scope.grossAmount = get2Float(grossAmount);
        changeItemVal('grossAmount', get2Float(grossAmount));
        calculateGrandTotal();
    };
    
    var calculateGrandTotal = function(){
        var trip = getTrip('fixedReplacement');
        var items = getTrip('fixedReplacementItems');
        
        if (items) {
            trip['grandTotalMealAmount'] = getListTotalAmount(items, 'mealAmount');
            trip['grandTotalLodgingAmount'] = getListTotalAmount(items, 'lodgingAmount');
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
        }
    };
    /* Calculation : End */
    
    $scope.openModal = function(section, mode){
        DataFormFixedReplacement.setCurrSection(section);
        if (section == 'OD') {
            var tripID = getTrip('id');
            $scope.mealRate = $scope.getRate('offduty', 'meal');
            $scope.lodgingRate = $scope.getRate('offduty', 'lodging');
            $('#fixedReplacementODModalForm_trip_'+tripID).modal('show');
        }
        
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };
    
    $scope.openModalDistribution = function(section, type, itemIndex){
        var arrivalDate = $scope.arrivalDate;
        var departDate = $scope.departDate;
        var chk = false;
        var distribution = [];
        var rate = 0;
        
        if (type == 'MEAL') {
            chk = $scope.chkDistribution;
            distribution = $scope.mealDistribution;
            rate = $scope.mealRate;
            instance_controller = 'FixedReplacementMealDistributionModalCtrl';
            ng_template = 'FixedReplacementMealDistribution.html';
        }else if (type == 'LODGING') {
            chk = $scope.chkLodgingDistribution;
            distribution = $scope.lodgingDistribution;
            rate = $scope.lodgingRate;
            instance_controller = 'FixedReplacementLodgingDistributionModalCtrl';
            ng_template = 'FixedReplacementLodgingDistribution.html';
        }
        
        if (itemIndex != undefined) {
            DataFormFixedReplacement.setCurrSection(section);
            setEditMode(itemIndex);
        }
        
        $scope.animationsEnabled = true;
        if (chk) {
            if (angular.isDate(arrivalDate) && angular.isDate(departDate)) {
                var dataModal = {dateFrom: arrivalDate, dateTo: departDate, rate: rate, distribution: distribution};
                var modalInstance = $uibModal.open({
                    animation: $scope.animationsEnabled,
                    templateUrl: ng_template,
                    controller: instance_controller,
                    size: '',
                    resolve: {
                        data: function () {
                            return dataModal;
                        }
                    }
                });
                
                modalInstance.result.then(
                    function (returnData) {
                        // OK, box closed
                        if (type == 'MEAL') {
                            $scope.mealDistribution = returnData.mealDistribution;
                            $scope.mealAmount = get2Float(returnData.totalMealAmount);
                            changeItemVal('mealDistribution', returnData.mealDistribution);
                            changeItemVal('mealAmount', returnData.totalMealAmount);
                        }else if (type == 'LODGING') {
                            $scope.lodgingDistribution = returnData.lodgingDistribution;
                            $scope.lodgingAmount = get2Float(returnData.totalLodgingAmount);
                            changeItemVal('lodgingDistribution', returnData.lodgingDistribution);
                            changeItemVal('lodgingAmount', returnData.totalLodgingAmount);
                        }
                        //$scope.intTotalDays= 0;
                        calculateTotalAmount();
                    },
                    function () {
                        // Cancel, box closed
                    }
                );
            }
        }else{
            // Reset amount based on selected Date.
            calculateDiffDate(arrivalDate, departDate);
        };
        if (type == 'MEAL') {
            changeItemVal('chkDistribution', chk);
        }else if (type == 'LODGING') {
            changeItemVal('chkLodgingDistribution', chk);
        }
    };
    
    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormFixedReplacement.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
        }
    };
    
    $scope.$watch('arrivalDate', function(newValue, oldValue){
        if (newValue != oldValue) {
            calculateDiffDate(newValue, $scope.departDate);
            changeItemVal('arrivalDate', newValue);
        }
    });
    $scope.$watch('departDate', function(newValue, oldValue){
        if (newValue != oldValue) {
            calculateDiffDate($scope.arrivalDate, newValue);
            changeItemVal('departDate', newValue);
        }
    });
    
    $scope.$watch('departTime', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('departTime', newValue); };
    });
    
    $scope.$watch('description', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('description', newValue); };
    });
    
    $scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('fundType', newValue); }
    });

    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        if (newValue != oldValue) { changeItemVal('projectCode', newValue); }
    });
}]);

uiBootstrapApp.controller('FixedReplacementMealDistributionModalCtrl', ['$scope', '$filter', '$modalInstance', 'data',
                                                        function ($scope, $filter, $uibModalInstance, data) {
    /* Config for table pagination : Start */
    $scope.pageSize = 10;
    $scope.currentPage = 1;
    /* Config for table pagination : End */
    
    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var mealRate = parseFloat(data.rate);
    var mealDistribution = data.distribution;
    var totalMealAmount = 0;

    $scope.mealRate = get2Float(mealRate);

    var generateDays = function (dateFrom, dateTo) {
        var mealDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            mealDistribution.push({date:objMinDate, meal:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return mealDistribution;
    };

    if (mealDistribution && mealDistribution.length) {
        $scope.mealDistribution = mealDistribution;
    }else{
        $scope.mealDistribution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {totalMealAmount:$scope.totalMealAmount, mealDistribution:$scope.mealDistribution}
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('mealDistribution', function() {
        var totalIntMeal = 0;

        $scope.mealDistribution.forEach(function(obj){
            if(obj.meal){
                totalIntMeal++;
            }
        });
        
        totalMealAmount = totalIntMeal * mealRate;
        $scope.totalIntMeal = totalIntMeal;
        $scope.totalMealAmount = get2Float(totalMealAmount);
    }, true);
}]);

uiBootstrapApp.controller('FixedReplacementLodgingDistributionModalCtrl', ['$scope', '$filter', '$modalInstance', 'data',
                                                        function ($scope, $filter, $uibModalInstance, data) {
    /* Config for table pagination : Start */
    $scope.pageSize = 10;
    $scope.currentPage = 1;
    /* Config for table pagination : End */
    
    var dateFrom = data.dateFrom;
    var dateTo = data.dateTo;
    var lodgingRate = parseFloat(data.rate);
    var lodgingDistribution = data.distribution;
    var totalLodgingAmount = 0;

    $scope.lodgingRate = get2Float(lodgingRate);

    var generateDays = function (dateFrom, dateTo) {
        var lodgingDistribution = [];

        Date.prototype.addDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() + parseInt(days));
            return this;
        };

        Date.prototype.deductDays = function(days) {
            /* beware as this function will change it global value */
            this.setDate(this.getDate() - parseInt(days));
            return this;
        };

        var currentDate = dateFrom;
        var counter = 1;
        while (dateFrom <=  dateTo) {
            objDate = new Date (currentDate);
            objMinDate = $filter('date')(objDate, 'dd-M-yyyy');
            lodgingDistribution.push({date:objMinDate, lodging:false});
            currentDate.addDays(1);
            counter++;
        };
        currentDate.deductDays(counter-1); /* This will reset its global value */
        return lodgingDistribution;
    };

    if (lodgingDistribution && lodgingDistribution.length) {
        $scope.lodgingDistribution = lodgingDistribution;
    }else{
        $scope.lodgingDistribution = generateDays(dateFrom, dateTo);
    }

	$scope.ok = function () {
        var returnData = {
            totalLodgingAmount:$scope.totalLodgingAmount,
            lodgingDistribution:$scope.lodgingDistribution
        }
		$uibModalInstance.close(returnData);
	};

	$scope.cancel = function () {
		$uibModalInstance.dismiss('cancel');
	};

    $scope.$watch('lodgingDistribution', function() {
        var totalIntLodging = 0;

        $scope.lodgingDistribution.forEach(function(obj){
            if(obj.lodging){
                totalIntLodging++;
            }
        });
        
        totalLodgingAmount = totalIntLodging * lodgingRate;
        $scope.totalIntLodging = totalIntLodging;
        $scope.totalLodgingAmount = get2Float(totalLodgingAmount);
    }, true);
}]);

uiBootstrapApp.controller('MiscellaneousCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormMiscellaneous',
                                                'DataFundType', 'DataLookup',
                                             function($scope, $filter, DataFormMain, DataFormMiscellaneous,
                                                      DataFundType, DataLookup){
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openDate = function($event) {
        $scope.statusDate.opened = true;
    };

    $scope.statusDate = {
        opened: false
    };
    /** Date : End */
    
    $('div[id^=miscellaneousODForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getTrip = function(objName){
        var currSection = DataFormMiscellaneous.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var setEditMode = function(itemIndex){
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };
    
    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.date = getDateFromStr(objDB.date);
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            date: $scope.date,
            dateTxt: getDateStr($filter, $scope.date),
            miscellaneousType: $scope.miscellaneousType,
            chkReceiptNo: $scope.chkReceiptNo,
            receiptNo: $filter("uppercase")($scope.receiptNo),
            grossAmount: get2Float($scope.grossAmount),
            corporateCard: $scope.corporateCard,
            fundType: DataFundType.getFundType(),
            projectCode: DataLookup.getProjectCode()
        };
    };

    var setForm = function(currItem){
        $scope.date = currItem.date;
        $scope.miscellaneousType = currItem.miscellaneousType;
        $scope.chkReceiptNo = currItem.chkReceiptNo;
        $scope.receiptNo = currItem.receiptNo;
        $scope.grossAmount = currItem.grossAmount;
        $scope.corporateCard = currItem.corporateCard;
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
    };

    var resetForm = function(){
        $scope.chkReceiptNo = false;
        $scope.receiptNo = '';
    };

    var changeItemVal = function(objName, val) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                currItem[objName] = val;
                if (objName == 'date') {
                    currItem.dateTxt = getDateStr($filter, $scope.date);
                }
            }
        }
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormMiscellaneous.getCurrSection();

        if (currSection == 'OD') {
            obj = getTrip('miscellaneousItems');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    /* Calculation : Start */
    var calculateGrandTotal = function(){
        var trip = getTrip('miscellaneous');
        var items = getTrip('miscellaneousItems');
        
        if (items) {
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
        }
    };
    /* Calculation : End */
    
    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
        resetForm();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormMiscellaneous.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };
    
    $scope.openModal = function(section, mode){
        DataFormMiscellaneous.setCurrSection(section);
        if (section == 'OD') {
            var trip = getTrip();
            $('#miscellaneousODModalForm_trip_'+trip.id).modal('show');
        }
        
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
        }
    };
    
    $scope.$watch('date', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('date', newValue); }
    });
    
    $scope.$watch('miscType', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('miscType', newValue); }
    });
    
    $scope.$watch('chkReceiptNo', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('chkReceiptNo', newValue); }
    });
    
    $scope.$watch('receiptNo', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('receiptNo', newValue); }
    });
    
    $scope.$watch('grossAmount', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('grossAmount', get2Float(newValue)); }
    });
    
    $scope.$watch('corporateCard', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('corporateCard', newValue); }
    });
    
    $scope.$watch(function () { return DataFundType.getFundType(); }, function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('fundType', newValue); }
    });
    
    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('projectCode', newValue); }
    });
}]);

uiBootstrapApp.controller('FareReplacementCtrl', ['$scope', '$filter', 'DataFormMain', 'DataFormFareReplacement',
                                                  function($scope, $filter, DataFormMain, DataFormFareReplacement){
    
    /** Date : Start */
    $scope.format = $scope.dateFormats[0];

    $scope.openDate = function($event) {
        $scope.statusDate.opened = true;
    };

    $scope.statusDate = {
        opened: false
    };
    /** Date : End */
    
    $('div[id^=fareReplacementODForm_trip_]').on('hidden.bs.modal', function (e) {
        disableEditMode();
    });
    
    var getTrip = function(objName){
        var currSection = DataFormFareReplacement.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    }
    
    var setEditMode = function(itemIndex){
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };
    
    var disableEditMode = function(){
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };
    
    var setEmptyTable = function(){
        $scope.currIndex = '';
        disableEditMode();
    };

    var setRow = function(objDB){
        if (objDB) {
            $scope.date = getDateFromStr(objDB.date);
            DataGST.setGSTType(DataGST.getGSTTypeByCode(objDB.gst_tax_id));
            DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
        }
        return {
            date: $scope.date,
            dateTxt: getDateStr($filter, $scope.date),
            fareReplacementType: $scope.fareReplacementType,
            flightClassType: $scope.flightClassType,
            chkReceiptNo: $scope.chkReceiptNo,
            receiptNo: $filter("uppercase")($scope.receiptNo),
            grossAmount: get2Float($scope.grossAmount)
        };
    };

    var setForm = function(currItem){
        $scope.date = currItem.date;
        $scope.chkReceiptNo = currItem.chkReceiptNo;
        $scope.receiptNo = currItem.receiptNo;
        $scope.fareReplacementType = currItem.fareReplacementType;
        $scope.flightClassType = currItem.flightClassType;
        $scope.grossAmount = currItem.grossAmount;
    };

    var resetForm = function(){
        $scope.chkReceiptNo = false;
        $scope.receiptNo = '';
    };

    var changeItemVal = function(objName, val) {
        if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
                currItem[objName] = val;
                if (objName == 'date') {
                    currItem.dateTxt = getDateStr($filter, $scope.date);
                }
            }
        }
    };

    var getItems = function(index){
        var obj = [];
        var currSection = DataFormFareReplacement.getCurrSection();

        if (currSection == 'OD') {
            obj = getTrip('fareReplacementItems');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };
    
    /* Calculation : Start */
    var calculateGrandTotal = function(){
        var trip = getTrip('fareReplacement');
        var items = getTrip('fareReplacementItems');
        
        if (items) {
            trip['grandTotalGrossAmount'] = getListTotalAmount(items, 'grossAmount');
        }
    };
    /* Calculation : End */
    
    $scope.addItem = function(objDB){
        var items = getItems();
        items.push(setRow(objDB));
        calculateGrandTotal();
        resetForm();
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormFareReplacement.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateGrandTotal();
    };

    $scope.editItem = function(section, itemIndex){
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal(section, 'editForm');
        setForm(getItems(index));
    };

    $scope.gotoUpdateItem = function(direct){
        /* direct = 'before' or 'next' */
        var currItem = '';
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setForm(items[$scope.directIndex]);
                $scope.currIndex = $scope.directIndex;
                $scope.isEditMode = true;
            }
        }
    };
    
    $scope.openModal = function(section, mode){
        DataFormFareReplacement.setCurrSection(section);
        if (section == 'OD') {
            var trip = getTrip();
            $('#fareReplacementODModalForm_trip_'+trip.id).modal('show');
        }
        
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };
    
    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
        }
    };
    
    $scope.$watch('date', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('date', newValue); };
    });
    
    $scope.$watch('fareReplacementType', function(newValue, oldValue){
        if (newValue && newValue != oldValue) {
            if (newValue.code == 'Flight') {
                $scope.isEnableFlight = true;
            }else{
                $scope.isEnableFlight = false;
            }
            changeItemVal('fareReplacementType', newValue);
        }
    });
    
    $scope.$watch('flightClassType', function(newValue, oldValue){
        if (newValue && newValue != oldValue) { changeItemVal('flightClassType', newValue); };
    });
    
    $scope.$watch('receiptNo', function(newValue, oldValue){
        if (newValue != oldValue) { changeItemVal('receiptNo', $filter("uppercase")(newValue)); };
    });
    
    $scope.$watch('grossAmount', function(newValue, oldValue){
        if (newValue != oldValue) {
            changeItemVal('grossAmount', get2Float(newValue));
            calculateGrandTotal();
        }
    });
}]);

uiBootstrapApp.controller('SupportingDocumentsCtrl', ['$scope', 'DataFormSupportingDocuments',
                                                      function($scope, DataFormSupportingDocuments){
    var getTrip = function(objName){
        var currSection = DataFormSupportingDocuments.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    };
    
    var getItems = function(index){
        var obj = [];
        var currSection = DataFormSupportingDocuments.getCurrSection();
        if (currSection == 'OD') {
            obj = getTrip('supportingDocuments');
        }

        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

    $scope.addItem = function(section, objDB){
        DataFormSupportingDocuments.setCurrSection(section);
        var items = getItems();
        if (objDB) {
            items.push({doc:DataFormDoc.getDocByID(objDB.document_list_id)});
        }else{
            items.push({});
        }
    };

    $scope.deleteItem = function(section, itemIndex){
        DataFormSupportingDocuments.setCurrSection(section);
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
    };

    $scope.initLoad = function(trip, section){
        if (section == 'OD') {
            $scope.isEditMode = false;
        }
    };
}]);

uiBootstrapApp.controller('SummaryCtrl', ['$scope', '$filter', 'DataFormMain', 'DataAdvance',
                                          function($scope, $filter, DataFormMain, DataAdvance){
    
    // Values in codeMap must exist in expenses.type_code DB Table
    
    // Oversea
    var MEAL = {codeMap: 'MEAL', items: [], objFundType: 'fundType', objAmount: 'grossAmount'};
    var ACCOMMODATION = {codeMap: 'ACCOMMODATION', itemsMix: []};
    var PUBLIC_TRANSPORT = {codeMap: 'PUBLIC_TRANSPORT', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: 'gstType', objGSTAmount: 'gstAmount'};
    var MEAL_TIPS = {codeMap: 'MEAL_TIPS', objAmount: ''};
    var MISC = {codeMap: 'MISC', items: [], objFundType: 'fundType', objAmount: 'grossAmount'};
    var FLIGHT_TAX = {codeMap: 'FLIGHT_TAX', items: [], objFundType: '', objAmount: '', objGSTType: '', objGSTAmount: ''};
    var FARE_REPLACEMENT = {codeMap: 'FARE_REPLACEMENT', items: [], objFundType: '', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};
    var FOREX_LOSS = {codeMap: 'FOREX_LOSS', objAmount: ''};
    
    // Transit - to separate meal & accommodation allowance type
    var TRANSIT = {items: [], objFundType: 'fundType', objAmount: 'grossAmount'};
    var TRANSIT_MEAL = {items: [], objFundType: 'fundType', objAmount: 'totalMealAmount'};
    var TRANSIT_HOTEL = {items: [], objFundType: 'fundType', objAmount: 'hotelAmount'};
    var TRANSIT_LODGING = {items: [], objFundType: 'fundType', objAmount: 'lodgingAmount'};
    
    // Fixed Replacement - to separate meal & accommodation allowance type.
    var FIXED_REPLACEMENT = {items: [], objFundType: 'fundType', objAmount: 'grossAmount'};
    var FIXED_REPLACEMENT_MEAL = {items: [], objFundType: 'fundType', objAmount: 'mealAmount'};
    var FIXED_REPLACEMENT_LODGING = {items: [], objFundType: 'fundType', objAmount: 'lodgingAmount'};
    
    // Local
    var MILEAGE = {codeMap: 'MILEAGE', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: '', objGSTAmount: ''};
    
    // Create Mix list of Meal
    var MEAL_MIX = {codeMap: 'MEAL'};
    MEAL_MIX.itemsMix = [MEAL, TRANSIT_MEAL, FIXED_REPLACEMENT_MEAL];
    
    // Create Mix list of Accommodation
    var HOTEL = {codeMap: '', items: [], objFundType: 'fundType', objAmount: 'grossAmount', objGSTType: 'gstType', objGSTAmount: 'gstAmount'};
    var LODGING = {codeMap: '', items: [], objFundType: 'fundType', objAmount: 'grossAmount'};
    ACCOMMODATION.itemsMix = [HOTEL, LODGING, TRANSIT_HOTEL, TRANSIT_LODGING, FIXED_REPLACEMENT_LODGING];
    
    // Set of expenses to display in Sub/Panel Summary
    $scope.setOversea = [MEAL_MIX, ACCOMMODATION, PUBLIC_TRANSPORT, MEAL_TIPS, MISC, FLIGHT_TAX, FARE_REPLACEMENT];
    $scope.setOverseaForex = [FOREX_LOSS];
    $scope.setLocal = [MILEAGE, angular.copy(PUBLIC_TRANSPORT), angular.copy(FARE_REPLACEMENT),
                       angular.copy(FLIGHT_TAX), angular.copy(MISC)];
    
    var getTrip = function(objName){
        var currSection = DataFormMain.getCurrSection();
        trip = $scope.getActiveTrip(currSection);
        if (trip && objName) {
            trip = trip[objName];
        }
        return trip;
    };
    
    /*****************
     *  Calculations *
     *****************/
    var calculateMealTips = function(setMealExpenses){
        var amount = 0;
        setMealExpenses.forEach(function (objSet) {
            if (objSet.items) {
                amount = parseFloat(amount) + parseFloat(getListTotalAmount(objSet.items, objSet.objAmount));
            }else{
                amount = parseFloat(amount) + parseFloat(objSet.objAmount);
            }
        });
        return 0.15 * amount;
    };
    
    var calculateForex = function(setExpenses){
        var total = 0;
        if (setExpenses) {
            var amount = getListTotalAmount(setExpenses, 'amount');
            total = 0.03 * amount;
        }
        return get2Float(total);
    };
    /** Calculations : End */
    
    var filterItems = function(items, itemObjToFilter, filterObj, codeToFilter){
        var filterBy = $filter("filter")(filterObj, {code: codeToFilter})[0];
        var filteredItems = [];
        items.forEach(function(itemObj){
            var compareObj = itemObj[itemObjToFilter];
            if (compareObj.code == filterBy.code) {
                filteredItems.push(itemObj);
            }
        });
        return filteredItems;
    };
    
    var loadExpensesSummary = function(type){
        var trip = getTrip();
        var expenses = [];
        var sets = [];
        
        if (type == 'Oversea') {
            expenses = angular.copy($scope.overseaExpenses);
            sets = $scope.setOversea;
            
            MEAL.items = getTrip('mealItems');
            TRANSIT_MEAL.items = getTrip('transitItems');
            FIXED_REPLACEMENT_MEAL.items = getTrip('fixedReplacementItems');
            sets[0].itemsMix = [MEAL, TRANSIT_MEAL, FIXED_REPLACEMENT_MEAL];
            
            HOTEL.items = getTrip('hotelItems');
            LODGING.items = getTrip('lodgingItems');
            TRANSIT_HOTEL.items = getTrip('transitItems');
            TRANSIT_LODGING.items = getTrip('transitItems');
            FIXED_REPLACEMENT_LODGING.items = getTrip('fixedReplacementItems');
            sets[1].itemsMix = [HOTEL, LODGING, TRANSIT_HOTEL, TRANSIT_LODGING, FIXED_REPLACEMENT_LODGING];
            
            sets[2].items = filterItems(getTrip('publicTransportItems'), 'destinationType',
                                       $scope.destinationTypes, 'Oversea');
            sets[3].objAmount = calculateMealTips([MEAL, TRANSIT_MEAL, FIXED_REPLACEMENT_MEAL]);
            sets[4].items = getTrip('miscellaneousItems');
            sets[6].items = getTrip('fareReplacementItems');
        }
        else if (type == 'Forex') {
            expenses = angular.copy($scope.overseaExpenses);
            sets = $scope.setOverseaForex;
            sets[0].objAmount = calculateForex(trip['overseaExpensesSummary']);
        }
        else if (type == 'Local') {
            expenses = angular.copy($scope.localExpenses);
            sets = $scope.setLocal;
            sets[0].items = getTrip('mileageItems');
            sets[1].items = filterItems(getTrip('publicTransportItems'), 'destinationType',
                                       $scope.destinationTypes, 'Local');
            sets[4].items = getTrip('miscellaneousItems');
        }
        
        // Load grouped Fund Type for sub expenses summary
        expensesSummary = getGroupedFundType(expenses, sets);
        
        // Get grand total
        var grandTotal = getListTotalAmount(expensesSummary, 'amount');
        
        if (type == 'Oversea') {
            trip['overseaExpensesSummary'] = expensesSummary;
            trip['overseaSubTotal'] = grandTotal;
        }
        else if (type == 'Forex') {
            trip['overseaForexSummary'] = expensesSummary;
            
            var overseaGrandTotal = (
                                     parseFloat(trip['overseaSubTotal']) +
                                     parseFloat(calculateForex(trip['overseaExpensesSummary']))
                                    );
            
            trip['overseaGrandTotal'] = get2Float(overseaGrandTotal);
        }else if (type == 'Local') {
            trip['localExpensesSummary'] = expensesSummary;
            trip['localGrandTotal'] = grandTotal;
            
            var gstSummary = getGroupedGSTType(sets);
            trip['gstSummary'] = getGroupedGSTType(sets);
            trip['gstGrandTotal'] = getListTotalAmount(gstSummary, 'amount');
        }
    };
    
    var loadTripSummary = function(section){
        DataFormMain.setCurrSection(section);
        
        loadExpensesSummary('Oversea');
        loadExpensesSummary('Forex');
        loadExpensesSummary('Local');
    };
    
    var loadMasterSummary = function(){
        var claimGrossTotal = 0;
        var claimGSTTotal = 0;
        var claimNettTotal = 0;
        var masterExpensesSummary = [];
        var masterGSTSummary = [];
        var setMasterExpenses = [$scope.ODTrips];
        
        setMasterExpenses.forEach(function(objMaster){
            objMaster.forEach(function(item){
                item.overseaExpensesSummary.forEach(function(objExpenses){
                    if (parseFloat(objExpenses.amount) > 0) {
                        masterExpensesSummary.push(objExpenses);
                    }
                });
                item.overseaForexSummary.forEach(function(objExpenses){
                    if (parseFloat(objExpenses.amount) > 0) {
                        masterExpensesSummary.push(objExpenses);
                    }
                });
                item.localExpensesSummary.forEach(function(objExpenses){
                    if (parseFloat(objExpenses.amount) > 0) {
                        masterExpensesSummary.push(objExpenses);
                    }
                });
                
                item.gstSummary.forEach(function(objExpenses){
                    if (parseFloat(objExpenses.amount) > 0) {
                        masterGSTSummary.push(objExpenses);
                    }
                });
            });
        });
        
        $scope.masterExpensesSummary = getGroupedList(masterExpensesSummary, 'account_code', 'amount');
        $scope.masterGSTSummary = getGroupedList(masterGSTSummary, 'code', 'amount');
        
        claimGrossTotal = getListTotalAmount(masterExpensesSummary, 'amount');
        claimGSTTotal = getListTotalAmount(masterGSTSummary, 'amount');
        claimNettTotal = parseFloat(claimGrossTotal) + parseFloat(claimGSTTotal);
        
        $scope.claimGrossTotal = claimGrossTotal;
        $scope.claimGSTTotal = claimGSTTotal;
        
        DataAdvance.setClaimGrandTotal(claimNettTotal);
    };
    
    $scope.initLoad = function(trip){
        var toWatchItems = ['fromDate', 'toDate', 'mealItems', 'hotelItems', 'lodgingItems',
                            'mileageItems', 'publicTransportItems', 'transitItems', 'fixedReplacementItems',
                            'miscellaneousItems', 'fareReplacementItems'];
        if (trip.id == 1 || trip == 'Master') {
            /**
             *  Trigger watch only once to prevent overlap watch.
            */
            toWatchItems.forEach(function(objToWatch){
                $scope.$watch(function() {
                    return $scope.ODTrips.map(function(obj) {
                        return obj[objToWatch];
                    });
                }, function (newVal, oldVal) {
                    if (newVal != oldVal) {
                        loadTripSummary('OD');
                        loadMasterSummary();
                    }
                }, true);
            });
        }
    };
}]);

uiBootstrapApp.factory('DataFormMain', function(){
    var data = {
        CurrSection: '',
        ActivedForm: ''
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        },
        getActivedForm: function(){
            return data.ActivedForm;
        },
        setActivedForm: function(val){
            data.ActivedForm = val;
        },
    };
});

uiBootstrapApp.factory('DataFormMeal', function(){
    var data = {
        CurrSection: '',
        GrandTotal: 0
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormHotel', function(){
    var data = {
        CurrSection: '',
        GrandTotal: 0
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormLodging', function(){
    var data = {
        CurrSection: '',
        GrandTotal: 0
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormMileage', function(){
    var data = {
        CurrSection: '',
        GrandTotal: 0
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormPublicTransport', function(){
    var data = {
        CurrSection: '',
        GrandTotal: 0
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormTransit', function(){
    var data = {
        CurrSection: ''
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormFixedReplacement', function(){
    var data = {
        CurrSection: ''
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormMiscellaneous', function(){
    var data = {
        CurrSection: ''
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormFareReplacement', function(){
    var data = {
        CurrSection: ''
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});

uiBootstrapApp.factory('DataFormSupportingDocuments', function(){
    var data = {
        CurrSection: ''
    };
    
    return {
        getCurrSection: function(){
            return data.CurrSection;
        },
        setCurrSection: function(val){
            data.CurrSection = val;
        }
    };
});
