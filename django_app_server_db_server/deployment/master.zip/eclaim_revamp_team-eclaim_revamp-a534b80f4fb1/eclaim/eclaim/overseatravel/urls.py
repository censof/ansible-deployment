# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import OverseaTravelIndexView

urlpatterns = patterns('',
    url(r'^$', OverseaTravelIndexView.as_view(), name='overseatravel_index'),
)