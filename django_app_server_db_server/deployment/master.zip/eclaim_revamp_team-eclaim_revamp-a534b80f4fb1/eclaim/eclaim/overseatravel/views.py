import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text

from eclaim.auth.authenticate import Authenticate
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.utils.common import get_json_vehiclecc_mileage_rates


class OverseaTravelIndexView(TemplateView):
    template_name = 'overseatravel/overseatravel_claim.html'
    submit_success_url = reverse_lazy('claim_list')
    
    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(OverseaTravelIndexView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')
    
    def get_context_data(self, **kwargs):
       # Call the base implementation first to get a context
       context = super(OverseaTravelIndexView, self).get_context_data(**kwargs)
       
       try:
           claimant = Claimant.objects.get(user=self.user)
       except Claimant.DoesNotExist:
           claimant = None
           
       if claimant:
           context['claimant'] = claimant
           context['jsonVehicleCCList'] = get_json_vehiclecc_mileage_rates(claimant.basic_salary)
           
       return context