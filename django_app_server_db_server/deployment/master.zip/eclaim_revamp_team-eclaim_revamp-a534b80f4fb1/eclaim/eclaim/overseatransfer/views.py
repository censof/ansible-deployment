import json
from django.http import HttpResponse
from django.shortcuts import redirect
from django.views.generic.base import TemplateView
from django.core.urlresolvers import reverse_lazy
from django.utils.encoding import force_text
from django.contrib.contenttypes.models import ContentType

from eclaim.auth.authenticate import Authenticate
from eclaim.settings.utils import create_new_states, create_selected_assignee
from eclaim.libs.views import ClaimDetailView, ClaimIndexView
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.common import SUMMARY
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory, Children
from eclaim.masterfiles.models.company import GradeLevelCategory
from eclaim.masterfiles.models.misc import FundType, OVERSEA_TRANSFER_DESTINATION_LIST, DESTINATION_TYPE
from eclaim.masterfiles.utils import get_document_list, get_document_list_item, \
                                     get_document_list_item_draft

from eclaim.utils.common import get_claim_type_code, get_claim_type_prefix, \
                                get_json_from_set_obj, get_json_from_list

from .models import OVERSEA_TRANSFER_CLAIM_TYPE, OverseaTransferClaim
from .processes import oversea_transfer_claim_process

__ClaimType__ = get_claim_type_code(OVERSEA_TRANSFER_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(OVERSEA_TRANSFER_CLAIM_TYPE)


class OverseaTransferIndexView(ClaimIndexView):
    """
    This is index page for Oversea Transfer Claims.
    """
    template_name = 'overseatransfer/oversea_transfer_claim.html'
    claim_type = ClaimType.get_claim_type(OverseaTransferClaim.CLAIM_TYPE)
    # validate_form_by_name = 'oversea_transfer_claim_form'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(OverseaTransferIndexView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['jsonChildren'] = get_json_from_set_obj(Children.objects.filter(staff=self.claimant))
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonSalaryGradeList'] = get_json_from_set_obj(GradeLevelCategory.objects.all())
        ctx['jsonTransferDestinationList'] = get_json_from_list(OVERSEA_TRANSFER_DESTINATION_LIST)
        ctx['jsonDestinationType'] = get_json_from_list(DESTINATION_TYPE)
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)
        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = oversea_transfer_claim_process(
            btn_mode, form_data, request.user)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, OverseaTransferClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaTransferClaim,
                                             claim_id, new_claim=True)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class OverseaTransferDetailView(ClaimDetailView):
    """
    This is detail view for Oversea Transfer Claims.
    """
    model = OverseaTransferClaim
    claim_type = ClaimType.get_claim_type(OverseaTransferClaim.CLAIM_TYPE)
    template_name = 'overseatransfer/oversea_transfer_claim.html'
    submit_success_url = reverse_lazy('claim_list')
    validate_form_by_name = 'oversea_transfer_claim_form'

    def get_context_data(self, **kwargs):
        # Call the base implementation first to get a context
        ctx = super(OverseaTransferDetailView, self).get_context_data(**kwargs)

        try:
            claimant = Claimant.objects.get(user=self.request.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['jsonChildren'] = get_json_from_set_obj(Children.objects.filter(staff = claimant))
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonSalaryGradeList'] = get_json_from_set_obj(GradeLevelCategory.objects.all())
        ctx['jsonTransferDestinationList'] = get_json_from_list(OVERSEA_TRANSFER_DESTINATION_LIST)
        ctx['jsonDestinationType'] = get_json_from_list(DESTINATION_TYPE)
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)

        obj_pk = self.request.GET['pk']
        claim = OverseaTransferClaim.objects.get(pk=obj_pk)
        doclist = get_document_list_item(claim.claim_no, __ClaimType__)
        document_list = get_json_from_set_obj(doclist)

        ctx['claim_no'] = claim.claim_no
        ctx['json_documentlist'] = document_list

        return ctx

    def post(self, request, *args, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = oversea_transfer_claim_process(btn_mode, form_data)

        if btn_mode in ['submit']:
            try:
                claimant = Claimant.objects.get(user=request.user)
            except Claimant.DoesNotExist:
                claimant = None

            # Send a claim to workflow.
            if claimant is not None:
                create_new_states(claimant, OverseaTransferClaim, claim_id)

                # Assign a selected claimant as a next level approver.
                staff_no = form_data.get('assignee')
                if staff_no:
                    assigned = Claimant.objects.get(pk=staff_no)
                    create_selected_assignee(assigned, OverseaTransferClaim, claim_id)

        response_data = {'errors': False, 'submit_success_url': force_text(self.submit_success_url), 'draft_id':draft_id, 'claim_id':claim_id}
        return HttpResponse(json.dumps(response_data), content_type="application/json")


class OverseaTransferDraftView(TemplateView):
    template_name = 'overseatransfer/oversea_transfer_claim.html'
    submit_success_url = reverse_lazy('claim_list')

    def get(self, request, **kwargs):
        auth = Authenticate(request)
        self.user = auth.validate_session()
        if self.user:
            return super(OverseaTransferDraftView, self).get(request, **kwargs)
        else:
            return redirect('loginAuth')

    def get_context_data(self, **kwargs):
        ctx = super(OverseaTransferDraftView, self).get_context_data(**kwargs)
        draft_id = self.kwargs['draft_id']

        try:
            claimant = Claimant.objects.get(user=self.user)
        except Claimant.DoesNotExist:
            claimant = None

        ctx['claimant'] = claimant
        ctx['jsonChildren'] = get_json_from_set_obj(Children.objects.filter(staff = claimant))
        ctx['jsonFundTypeList'] = get_json_from_set_obj(FundType.objects.all())
        ctx['jsonSalaryGradeList'] = get_json_from_set_obj(GradeLevelCategory.objects.all())
        ctx['jsonTransferDestinationList'] = get_json_from_list(OVERSEA_TRANSFER_DESTINATION_LIST)
        ctx['jsonDestinationType'] = get_json_from_list(DESTINATION_TYPE)
        ctx['DOC_LIST'] = get_document_list(__ClaimType__)

        draft = OverseaTransferClaimDraft.objects.get(id=int(draft_id))
        document_list = get_json_from_set_obj(get_document_list_item_draft(draft.id, __ClaimType__))

        ctx['draft_id'] = draft.id
        ctx['json_documentlist'] = document_list

        return ctx

    def post(self, request, **kwargs):
        form_data = json.loads(request.body)
        btn_mode = form_data.get('btn_mode')

        draft_id, claim_id = oversea_transfer_claim_process(
            btn_mode, form_data, request.user)

        response_data = {'errors': False, 'draft_id':draft_id, 'claim_id':claim_id, 'submit_success_url': force_text(self.submit_success_url)}
        return HttpResponse(json.dumps(response_data), content_type="application/json")
