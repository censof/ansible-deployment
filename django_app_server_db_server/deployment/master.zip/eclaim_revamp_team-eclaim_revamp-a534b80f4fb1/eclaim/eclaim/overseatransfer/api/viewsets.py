from rest_framework import viewsets
from .serializers import OverseaTransferClaimSerializer, OverseaTransferClaimDraftSerializer
from ..models import OverseaTransferClaim, OverseaTransferClaimDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'OverseaTransferClaimViewSet',
    'OverseaTransferClaimDraftViewSet'
    ]


class OverseaTransferClaimViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaTransferClaimSerializer
    queryset = OverseaTransferClaim.objects.all()


class OverseaTransferClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = OverseaTransferClaimDraftSerializer
    queryset = OverseaTransferClaimDraft.objects.all()