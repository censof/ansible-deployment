from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'OverseaTransferClaimSerializer',
    'OverseaTransferClaimDraftSerializer'
    ]


class OverseaTransferClaimSerializer(BaseClaimSerializer):
    claim_details = serializers.SerializerMethodField()

    class Meta:
        model = OverseaTransferClaim
        fields = BaseClaimSerializer.Meta.fields + ('claim_details',)

    def get_claim_details(self, obj):
        claim_details = obj.overseatransferclaimitem_set.all()
        claim_details_pk = claim_details.values_list('pk', flat=True)
        foreign_currency_items = ForeignCurrencyInfoItem.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        address_items = AddressItem.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        meal_items = MealItem.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        hotel_items = HotelItem.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        lodging_items = LodgingItem.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        misc_items = MiscItem.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        spouse_items = DependentItem.objects.filter(oversea_transfer_claim__in=claim_details_pk, relation='Spouse')
        children_items = DependentItem.objects.filter(oversea_transfer_claim__in=claim_details_pk, relation='Children')
        return {'claim_details': claim_details.values()
                ,'foreign_currency_items': foreign_currency_items.values()
                ,'address_items': address_items.values()
                ,'meal_items': meal_items.values()
                ,'hotel_items': hotel_items.values()
                ,'lodging_items': lodging_items.values()
                ,'misc_items': misc_items.values()
                ,'spouse_items': spouse_items.values()
                ,'children_items': children_items.values()
        }


class OverseaTransferClaimDraftSerializer(serializers.ModelSerializer):
    claim_details = serializers.SerializerMethodField()

    class Meta:
        model = OverseaTransferClaimDraft
        fields = '__all__'

    def get_claim_details(self, obj):
        claim_details = obj.overseatransferclaimitemdraft_set.all()
        claim_details_pk = claim_details.values_list('pk', flat=True)
        foreign_currency_items = ForeignCurrencyInfoItemDraft.objects.filter(oversea_transfer_claim__in=claim_details_pk)
        address_items = AddressItemDraft.objects.filter(oversea_transfer_claim_draft__in=claim_details_pk)
        meal_items = MealItemDraft.objects.filter(oversea_transfer_claim_draft__in=claim_details_pk)
        hotel_items = HotelItemDraft.objects.filter(oversea_transfer_claim_draft__in=claim_details_pk)
        lodging_items = LodgingItemDraft.objects.filter(oversea_transfer_claim_draft__in=claim_details_pk)
        misc_items = MiscItemDraft.objects.filter(oversea_transfer_claim_draft__in=claim_details_pk)
        spouse_items = DependentItemDraft.objects.filter(oversea_transfer_claim__in=claim_details_pk, relation='Spouse')
        children_items = DependentItemDraft.objects.filter(oversea_transfer_claim__in=claim_details_pk, relation='Children')
        return {'claim_details': claim_details.values()
                ,'foreign_currency_items': foreign_currency_items.values()
                ,'address_items': address_items.values()
                ,'meal_items': meal_items.values()
                ,'hotel_items': hotel_items.values()
                ,'lodging_items': lodging_items.values()
                ,'misc_items': misc_items.values()
                ,'spouse_items': spouse_items.values()
                ,'children_items': children_items.values()
        }