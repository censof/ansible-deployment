import datetime
from decimal import *

from eclaim.masterfiles.models.misc import FundType, VehicleType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.models.company import GradeLevelCategory
from eclaim.masterfiles.models.document import DocumentListItem, DocumentListItemDraft
from eclaim.masterfiles.utils import save_claimant_history, save_document_list_item_draft, save_document_list_item
from eclaim.utils.common import generate_claim_no, get_claim_type_code, get_claim_type_prefix
from .models import (OVERSEA_TRANSFER_CLAIM_TYPE, OverseaTransferClaim, OverseaTransferClaimItem, OverseaTransferClaimDraft
	, OverseaTransferClaimItemDraft, ForeignCurrencyInfoItem, ForeignCurrencyInfoItemDraft, DependentItem
	, DependentItemDraft, AddressItem, AddressItemDraft, MealItem, MealItemDraft, HotelItem, HotelItemDraft
	, LodgingItem, LodgingItemDraft, MiscItem, MiscItemDraft)


__ClaimType__ = get_claim_type_code(OVERSEA_TRANSFER_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(OVERSEA_TRANSFER_CLAIM_TYPE)


def oversea_transfer_claim_process(btn_mode, form_data, created_by=None):
    draft_id = None
    claim_id = None

    if btn_mode in ['save_draft']:
        draft_id = save_draft(form_data, created_by)
    elif btn_mode in ['submit']:
        claim_id = submit_claim(form_data)

    return draft_id, claim_id


def save_draft(form_data, created_by=None):
    draft_id = form_data.get('draft_id')

    draft_id = None if (draft_id is None or draft_id == '') else int(draft_id)
    status = '' if draft_id else 'D'
    claim.created_by = '' if (created_by is None) else created_by
    claim_draft = OverseaTransferClaimDraft(id=draft_id)
    claim_draft.apply_date = datetime.date.today()
    claim_draft.save()
    save_oversea_transfer_claim('save_draft', claim_draft, form_data)

    if draft_id:
        return draft_id
    else:
        return claim_draft.id


def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')
    draft_id = form_data.get('draft_id')

    claim = OverseaTransferClaim()
    claim.status = 'S'
    claim.apply_date = datetime.date.today()
    claim.save()

    claim.claim_no = generate_claim_no(__ClaimPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_oversea_transfer_claim('submit_claim', claim, form_data)

    if draft_id != '':
        delete_oversea_transfer_claim_draft(OverseaTransferClaimDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(ForeignCurrencyInfoItemDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(DependentItemDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(AddressItemDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(MealItemDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(HotelItemDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(LodgingItemDraft(id=int(draft_id)))
        delete_oversea_transfer_claim_draft(MiscItemDraft(id=int(draft_id)))

    return claim.id


def save_oversea_transfer_claim(mode, overseatransfer, form_data):

    if mode in ['save_draft']:
        saveObjClaim = OverseaTransferClaimItemDraft()
        saveObjForeign = ForeignCurrencyInfoItemDraft()
        saveObjAddress = AddressItemDraft()
        saveObjMeal = MealItemDraft()
        saveObjHotel = HotelItemDraft()
        saveObjLodging = LodgingItemDraft()

        saveObjClaim.oversea_transfer_claim_draft = overseatransfer
        saveObjForeign.oversea_transfer_claim_draft = overseatransfer
        saveObjAddress.oversea_transfer_claim_draft = overseatransfer
        saveObjMeal.oversea_transfer_claim_draft = overseatransfer
        saveObjHotel.oversea_transfer_claim_draft = overseatransfer
        saveObjLodging.oversea_transfer_claim_draft = overseatransfer

    elif mode in ['submit_claim']:
        saveObjClaim = OverseaTransferClaimItem()
        saveObjForeign = ForeignCurrencyInfoItem()
        saveObjAddress = AddressItem()
        saveObjMeal = MealItem()
        saveObjHotel = HotelItem()
        saveObjLodging = LodgingItem()

        saveObjClaim.oversea_transfer_claim = overseatransfer
        saveObjForeign.oversea_transfer_claim = overseatransfer
        saveObjAddress.oversea_transfer_claim = overseatransfer
        saveObjMeal.oversea_transfer_claim = overseatransfer
        saveObjHotel.oversea_transfer_claim = overseatransfer
        saveObjLodging.oversea_transfer_claim = overseatransfer

    saveObjClaim.grade_after = GradeLevelCategory.objects.get(code=form_data['transferGradeAfter'])
    saveObjClaim.transfer_date = form_data.get('transferDateTxt')
    saveObjClaim.fund_type = FundType.objects.get(code=form_data['fundType'])
    saveObjClaim.project_code = form_data.get('projectCode')
    saveObjClaim.marital_status = form_data.get('maritalStatus')
    saveObjClaim.destination = form_data.get('transferDestination')
    saveObjClaim.other_misc_total_amount = form_data.get('otherMiscTotalAmount')
    saveObjClaim.claim_amount = form_data.get('claimAmount')
    saveObjClaim.endowment_amount = form_data.get('endowmentAmount')
    saveObjClaim.net_total = form_data.get('netTotal')
    saveObjClaim.save()

    transferType = form_data.get('transferDestination');
    if transferType == 'MalaysiaToOversea':
        saveObjForeign.arrival_date = form_data.get('toDateTxt')
        saveObjForeign.to_country = form_data.get('toCountry')
        saveObjForeign.to_currency_type = form_data.get('toCurrencyType')
        saveObjForeign.to_bnm_date = form_data.get('toBNMDate')
        saveObjForeign.to_exchange_rate = form_data.get('toExchangeRate')
    elif transferType == 'OverseaToMalaysia':
        saveObjForeign.departure_date = form_data.get('fromDateTxt')
        saveObjForeign.from_country = form_data.get('fromCountry')
        saveObjForeign.from_currency_type = form_data.get('fromCurrencyType')
        saveObjForeign.from_bnm_date = form_data.get('fromBNMDate')
        saveObjForeign.from_exchange_rate = form_data.get('fromExchangeRate')
    elif transferType == 'OverseaToOversea':
        saveObjForeign.departure_date = form_data.get('fromDateTxt')
        saveObjForeign.from_country = form_data.get('fromCountry')
        saveObjForeign.from_currency_type = form_data.get('fromCurrencyType')
        saveObjForeign.from_bnm_date = form_data.get('fromBNMDate')
        saveObjForeign.from_exchange_rate = form_data.get('fromExchangeRate')
        saveObjForeign.arrival_date = form_data.get('toDateTxt')
        saveObjForeign.to_country = form_data.get('toCountry')
        saveObjForeign.to_currency_type = form_data.get('toCurrencyType')
        saveObjForeign.to_bnm_date = form_data.get('toBNMDate')
        saveObjForeign.to_exchange_rate = form_data.get('toExchangeRate')
    saveObjForeign.save()

    for status in ('old', 'new'):
        for address in ('office_line', 'home_line'):
            for repeater in ('1', '2', '3', '4'):
                exec("saveObjAddress.%s_%s%s = form_data.get('%s%s%s')" % (status, address, repeater, status, ''.join([x.capitalize() for x in address.split('_')]), repeater))
    saveObjAddress.save()

    if form_data.get('mealTotalAmount') > 0:
        for meal in ('rate_before', 'rate_after', 'no_of_person_before', 'no_of_person_after', 'total_before', 'total_after'
                    , 'total_amount'):
            exec("saveObjMeal.meal_%s = form_data.get('meal%s')" % (meal, ''.join([x.capitalize() for x in meal.split('_')])))
        saveObjMeal.save()

    if form_data.get('hotelTotalAmount') > 0:
        for hotel in ('first_3or5', 'second_3or5', 'third_3or5', 'forth_3or5', 'fifth_3or5'
                    , 'first_5', 'second_5', 'third_5', 'forth_5', 'fifth_5'):
            for repeater in ('1', '2', '3'):
                exec("saveObjHotel.room_price_%s_%s = form_data.get('roomPrice%s%s')" % (repeater, hotel, repeater, ''.join([x.capitalize() for x in hotel.split('_')])))

        for hotel2 in ('first_3or5', 'second_3or5', 'third_3or5', 'forth_3or5', 'fifth_3or5'
                    , 'first_5', 'second_5', 'third_5', 'forth_5', 'fifth_5'
                    , 'amount_3or5', 'foreign_amount_3or5', 'amount_5', 'foreign_amount_5', 'amount'):
            exec("saveObjHotel.hotel_total_%s = form_data.get('hotelTotal%s')" % (hotel2, ''.join([x.capitalize() for x in hotel2.split('_')])))

        saveObjHotel.hotel_rate_before = form_data.get('hotelRateBefore')
        saveObjHotel.hotel_rate_after = form_data.get('hotelRateAfter')
        saveObjHotel.hotel_total_gst = form_data.get('hotelTotalGST')
        saveObjHotel.hotel_receipt_no = form_data.get('hotelReceiptNo')
        saveObjHotel.save()

    if form_data.get('lodgingTotalAmount') > 0:
        for lodging in ('add_before', 'add_after', 'rate_before', 'rate_after', 'no_of_days_before', 'no_of_days_after'
                    , 'total_before', 'total_after', 'total_amount'):
            exec("saveObjLodging.lodging_%s = form_data.get('lodging%s')" % (lodging, ''.join([x.capitalize()+'ress' if x == 'add' else x.capitalize() for x in lodging.split("_")])))
        saveObjLodging.save()

    if form_data.get('maritalStatus') == 'mF':
        if form_data.get('spouseList'):
            for s in form_data.get('spouseList'):

                if mode in ['save_draft']:
                    saveObjDependent = DependentItemDraft()
                    saveObjDependent.oversea_transfer_claim_draft = overseatransfer

                elif mode in ['submit_claim']:
                    saveObjDependent = DependentItem()
                    saveObjDependent.oversea_transfer_claim = overseatransfer

                saveObjDependent.name = s['name']
                saveObjDependent.ic_birthcert = s['ic']
                saveObjDependent.relation = 'Spouse'
                saveObjDependent.grade = s['grade']
                saveObjDependent.position = s['position']
                saveObjDependent.basic_salary = s['basic_salary']
                saveObjDependent.employer_name = s['employer_name']
                saveObjDependent.save()

        if form_data.get('childrenList'):
            for c in form_data.get('childrenList'):

                if mode in ['save_draft']:
                    saveObjDependent = DependentItemDraft()
                    saveObjDependent.oversea_transfer_claim_draft = overseatransfer

                elif mode in ['submit_claim']:
                    saveObjDependent = DependentItem()
                    saveObjDependent.oversea_transfer_claim = overseatransfer

                saveObjDependent.name = c['name']
                saveObjDependent.age = c['age']
                saveObjDependent.ic_birthcert = c['ic']
                saveObjDependent.relation = 'Children'
                saveObjDependent.work_status = c['work_status']
                saveObjDependent.oku_status = c['oku_status']
                saveObjDependent.entitled = c['entitled']
                saveObjDependent.save()

    if form_data.get('miscItems'):
        for o in form_data.get('miscItems'):

            if mode in ['save_draft']:
                saveObjMisc = MiscItemDraft()
                saveObjMisc.oversea_transfer_claim_draft = overseatransfer

            elif mode in ['submit_claim']:
                saveObjMisc = MiscItem()
                saveObjMisc.oversea_transfer_claim = overseatransfer

            saveObjMisc.misc_date = o['miscDateTxt']
            saveObjMisc.misc_type = o['miscType']
            saveObjMisc.misc_expenses = o['miscExpenses']
            saveObjMisc.misc_receipt_no = o['miscReceiptNo']
            saveObjMisc.misc_foreign_amount = o['miscForeignAmount']
            saveObjMisc.misc_amount = o['miscAmount']
            saveObjClaim.misc_total_amount = o['miscGrandTotal']
            saveObjMisc.save()
            saveObjClaim.save()


def delete_oversea_transfer_claim_draft(draft):
    deleteObj = draft
    deleteObj.delete()