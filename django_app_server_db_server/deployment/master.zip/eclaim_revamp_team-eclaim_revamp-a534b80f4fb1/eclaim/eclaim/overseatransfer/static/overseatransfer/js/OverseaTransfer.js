/*
 ********************************************
 *      CREATED BY  :   MOHAMED FAUZI       *
 *      DATE        :   MARCH 2016          *
 ********************************************
*/
console.log('Oversea Transfer Claim JS Loaded!!!');

uiBootstrapApp.controller('OverseaTransferClaimCtrl', function ($scope, $log, $filter, $http, DataFormDoc, DataFundType, DataMain) {

    /*************** Initial Variable Start ***************/
	$scope.error_validation = false;
	$scope.claimant_no = '';
	$scope.draft_id = '';
	$scope.claim_no = '';
	$scope.object_pk = PK;
    $scope.showOverseaTransferForm = true;
    $scope.url_query_pdf = '';
    $scope.expenses = [];
	$scope.salary_grade = '';
	$scope.basic_salary = '';
    /*************** Initial Variable End ***************/

    /**
    *************************
    *   Start : Accordion   *
    *************************
   */
    $scope.oneAtATime = false;
    
    $scope.panels = [
        {name: 'panel1', open: false},
        {name: 'panel2', open: false},
        {name: 'panel3', open: true},
        {name: 'panel4', open: false},
        {name: 'panel5', open: false},
        {name: 'panel6', open: false},
        {name: 'panel7', open: false},
        {name: 'panel8', open: false}
    ];
    
    $scope.toggleAllPanels = function() {
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    
    $scope.closeAllPanels = function() {
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** End : Accordion */

	$scope.dateFormats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MM-yyyy'];
    
    $scope.standardDateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };
    
    $scope.formatDate = $scope.dateFormats[0];
	
	$scope.initOverseaTransferClaimCtrl = function(jsonTransferDestinationList) {
        console.log('Load initOverseaTransferClaimCtrl (Default)');

            $scope.pageSize = 5;
            $scope.currentPage = 1;

			$http({
				url: API_URL+'expenses/',
				method: 'GET',
				params: {'claim_code':'OFC'}
			})
			.success(function (data, status, headers, config) {
				$scope.expenses = data.results;
			});
			$http({
				url: API_URL+'document-list/',
				method: 'GET',
				params: {'claim_type': 'LFC'}
			})
			.success(function (data, status, headers, config) {
				$scope.docs = data.results;
				DataFormDoc.setDocList(data.results);
			});
    };

	var changeItemVal = function(obj) {
		if (obj == 'claimant_no') {
            DataMain.setClaimantNo($scope.claimant_no);
        }
		else if (obj == 'salary_grade') {
			DataMain.setSalaryGrade($scope.salary_grade);
		}
		else if (obj == 'basic_salary') {
			DataMain.setBasicSalary($scope.basic_salary);
		}
    };

	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.fundTypeSummary = newValue.description;
		}
	});
	$scope.initClaimantNo = function (claimant_no) {
		$scope.claimant_no = claimant_no;
		changeItemVal('claimant_no');
	};
	$scope.initSalaryGrade = function (salary_grade) {
		$scope.salary_grade = salary_grade;
		changeItemVal('salary_grade');
	};
	$scope.initBasicSalary = function (basic_salary) {
		$scope.basic_salary = basic_salary;
		changeItemVal('basic_salary');
	};
	
	if (PK) {  // detail view
        $http({
            url: API_URL+'oversea-transfer-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, 3, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, 3, 1);
    }

    var claim_api_url = API_URL+'oversea-transfer-claims/';
    init_workflow($scope, $http, 'overseatransfer', 'OverseaTransferClaim', PK, claim_api_url, WF_TEMPLATE);

    $scope.popup_query_pdf = function () {
        window.open($scope.url_query_pdf, '', 'width=800,height=600,left=200,resizable=0');
    }
});

uiBootstrapApp.controller('RatesCtrl', function ($scope, $log, $http, DataMain, DataRates, DataFormTransferDetails) {
	
	$scope.initRatesCtrl = function() {
		$scope.entitlement = [];

		$http({
			url: API_URL+'offduty-trip-oversea-allowance/',
			method: 'GET',
			params: {'staffNo': DataMain.getClaimantNo()}
		})
		.success(function (data, status, headers, config) {
			$scope.entitlement = data.results;
		});
		
	};

	var changeItemVal = function(obj) {
		if (obj == 'entitlement') {
		    defaultRate = get2Float(0);
			if ($scope.entitlement[0]) {
				DataRates.setMeal3Or5Day($scope.entitlement[0]['meal']);
				DataRates.setHotel3Or5Day($scope.entitlement[0]['hotel']);
				DataRates.setLodging3Or5Day($scope.entitlement[0]['lodging']);
			} else {
				DataRates.setMeal3Or5Day(defaultRate);
				DataRates.setHotel3Or5Day(defaultRate);
				DataRates.setLodging3Or5Day(defaultRate);
			}
			$scope.meal3Or5DayRates = DataRates.getMeal3Or5Day();
			$scope.hotel3Or5DayRates = DataRates.getHotel3Or5Day();
			$scope.lodging3Or5DayRates = DataRates.getLodging3Or5Day();
        }
	};

	$scope.$watch('entitlement', function(newValue, oldValue){
			changeItemVal('entitlement');
	});
	$scope.$watch(function () { return DataFormTransferDetails.getNewEntitlement(); }, function (newValue, oldValue) {
		$scope.meal5DayRates = DataRates.getMeal5Day();
		$scope.hotel5DayRates = DataRates.getHotel5Day();
		$scope.lodging5DayRates = DataRates.getLodging5Day();
		$scope.initRatesCtrl();
    });
});

uiBootstrapApp.controller('TransferDetailsCtrl', function($scope, $filter, $http, $q, DataMain, DataRates, DataFormDoc, DataClaimant, DataFundType, DataLookup, DataFormTransferDetails, DataFormClaimDetails) {

	$scope.transferDate = new Date();
	$scope.toDateMO = new Date();
	$scope.fromDateOM = new Date();
	$scope.fromDateOO = new Date();
	$scope.toDateOO = new Date();

	$scope.formatDay = $scope.dateFormats[0];

    $scope.initTransferDetailsCtrl = function(jsonTransferDestinationList, jsonChildren, draftID) {
        console.log('Load initTransferDetailsCtrl (Default)');
		
		$scope.gradeAfter = [];
		$scope.transferDestinationList = [];
		$scope.toCountryMO = [];
		$scope.toCurrenciesMO = [];
		$scope.fromCountryOM = [];
		$scope.fromCurrenciesOM = [];
		$scope.toCountryOO = [];
		$scope.toCurrenciesOO = [];
		$scope.fromCountryOO = [];
		$scope.fromCurrenciesOO = [];
		$scope.spouseList = [];
		$scope.childrenList = [];
	
		var promises = {
			salary_grade: $http({
					url: API_URL+'salary-grades/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.gradeAfter = data.results;
				}),
			country_list: $http({
					url: API_URL+'countries/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.toCountryMO = data.results;
					$scope.fromCountryOM = data.results;
					$scope.toCountryOO = data.results;
					$scope.fromCountryOO = data.results;
				}),
			currency_list: $http({
					url: API_URL+'currency-rates/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.toCurrenciesMO = data.results;
					$scope.fromCurrenciesOM = data.results;
					$scope.toCurrenciesOO = data.results;
					$scope.fromCurrenciesOO = data.results;
				}),
			claimant_spouses: $http({
					url: API_URL+'claimant-spouses/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.spouseList = data.results;
					DataMain.setTotalSpouse($scope.spouseList.length);
					changeItemVal('spouseList')
					changeItemVal('totalDependent');
				}),
		}
		getAngularObjFromJson(jsonTransferDestinationList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.transferDestinationList.push({code:code, description:description});
		});
		getAngularObjFromJson(jsonChildren).forEach(function (obj) {
			data = obj.fields;
			var name = data['name'];
			var ic = data['ic'];
			var age = data['age'];
			var work_status = data['work_status'];
			var oku_status = data['oku_status'];
			var entitled = entitle(age,work_status,oku_status);
			$scope.childrenList.push({name:name, ic:ic, age:age, work_status:work_status, oku_status:oku_status, entitled:entitled});
			changeItemVal('childrenList')
		});
		$scope.onSelectCurrencyType = function($item, $model, $label, type){
			if (type == 'MO') {
				$scope.toBNMDateMO = $item.date;
				$scope.toExchangeRateMO = $item.value;
			} else if (type == 'OM') {
				$scope.fromBNMDateOM = $item.date;
				$scope.fromExchangeRateOM = $item.value;
			} else if (type == 'fromOO') {
				$scope.fromBNMDateOO = $item.date;
				$scope.fromExchangeRateOO = $item.value;
			} else if (type == 'toOO') {
				$scope.toBNMDateOO = $item.date;
				$scope.toExchangeRateOO = $item.value;
			}
		};
		$scope.getDataByCode = function (code, dropdown) {
            var objSelect = $filter("filter")(dropdown, { code: code });
            return objSelect[0];
        };
		$scope.getDataByName = function (name, dropdown) {
            var objSelect = $filter("filter")(dropdown, { name: name });
            return objSelect[0];
        };
		$scope.getDataByCurrency = function(code, dropdown) {
			currency_info = '';
			dropdown.forEach(function(itemObj) {
				objSelect = itemObj.currency.currency
				if (objSelect == code) {
				   currency_info = objSelect;
				}
			});
			return currency_info;
		};
		$scope.getDataById = function (id, dropdown) {
            var objSelect = $filter("filter")(dropdown, { id: id });
            return objSelect[0];
        };
		
		if (draftID) { // draft view
            console.log('Load draft items for Draft [',draftID,']');
            $http({
                url: API_URL+'oversea-transfer-claim-drafts/'+draftID+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
				$q.all(promises).then(function (resolutions) {
					claim = data.claim_details.claim_details[0];
					address = data.claim_details.address_items[0];
					foreign = data.claim_details.foreign_currency_items[0];
					
					$scope.transferGradeAfter = $scope.getDataByCode(claim.grade_after_id, resolutions.salary_grade.data.results);
					changeItemVal('transferGradeAfter');
					$scope.transferDate = claim.transfer_date;
					$scope.maritalStatus = { status: claim.marital_status };
					$scope.changeMaritalStatus();
					$scope.transferDestination = $scope.getDataByCode(claim.destination, $scope.transferDestinationList);
					changeItemVal('transferDestination');
					DataFundType.setFundType(DataFundType.getFundTypeByCode(claim.fund_type_id));
					if (claim.project_code) {
						$scope.projectCode = claim.project_code;
					}
					if (claim.destination == 'MalaysiaToOversea') {
						$scope.toDateMO = foreign.arrival_date;
						$scope.toCountryAfterMO = $scope.getDataByName(foreign.to_country, resolutions.country_list.data.results);
						$scope.toCurrencyTypeMO = $scope.getDataByCurrency(foreign.to_currency_type, resolutions.currency_list.data.results);
						$scope.toBNMDateMO = foreign.to_bnm_date;
						$scope.toExchangeRateMO = foreign.to_exchange_rate;
						changeItemVal('toCountryAfterMO');
						changeItemVal('toCurrencyTypeMO');
					} else if (claim.destination == 'OverseaToMalaysia') {
						$scope.fromDateOM = foreign.arrival_date;
						$scope.fromCountryAfterOM = $scope.getDataByName(foreign.from_country, resolutions.country_list.data.results);
						$scope.fromCurrencyTypeOM = $scope.getDataByCurrency(foreign.from_currency_type, $scope.fromCurrenciesOM);
						$scope.fromBNMDateOM = foreign.from_bnm_date;
						$scope.fromExchangeRateOM = foreign.from_exchange_rate;
						changeItemVal('fromCountryAfterOM');
						changeItemVal('fromCurrencyTypeOM');
					} else if (claim.destination == 'OverseaToOversea') {
						$scope.fromDateOO = foreign.arrival_date;
						$scope.fromCountryAfterOO = $scope.getDataByName(foreign.from_country, resolutions.country_list.data.results);
						$scope.fromCurrencyTypeOO = $scope.getDataByCurrency(foreign.from_currency_type, $scope.fromCurrenciesOO);
						$scope.fromBNMDateOO = foreign.from_bnm_date;
						$scope.fromExchangeRateOO = foreign.from_exchange_rate;
						$scope.toDateOO = foreign.arrival_date;
						$scope.toCountryAfterOO = $scope.getDataByName(foreign.to_country, resolutions.country_list.data.results);
						$scope.toCurrencyTypeOO = $scope.getDataByCurrency(foreign.to_currency_type, $scope.toCurrenciesOO);
						$scope.toBNMDateOO = foreign.to_bnm_date;
						$scope.toExchangeRateOO = foreign.to_exchange_rate;
						changeItemVal('fromCountryAfterOO');
						changeItemVal('fromCurrencyTypeOO');
						changeItemVal('toCountryAfterOO');
						changeItemVal('toCurrencyTypeOO');
					}
					$scope.oldOfficeLine1 = address.old_office_line1;
					changeItemVal('oldOfficeLine1');
					$scope.oldOfficeLine2 = address.old_office_line2;
					changeItemVal('oldOfficeLine2');
					$scope.oldOfficeLine3 = address.old_office_line3;
					changeItemVal('oldOfficeLine3');
					$scope.oldOfficeLine4 = address.old_office_line4;
					changeItemVal('oldOfficeLine4');
					$scope.newOfficeLine1 = address.new_office_line1;
					changeItemVal('newOfficeLine1');
					$scope.newOfficeLine2 = address.new_office_line2;
					changeItemVal('newOfficeLine2');
					$scope.newOfficeLine3 = address.new_office_line3;
					changeItemVal('newOfficeLine3');
					$scope.newOfficeLine4 = address.new_office_line4;
					changeItemVal('newOfficeLine4');
					$scope.oldHomeLine1 = address.old_home_line1;
					changeItemVal('oldHomeLine1');
					$scope.oldHomeLine2 = address.old_home_line2;
					changeItemVal('oldHomeLine2');
					$scope.oldHomeLine3 = address.old_home_line3;
					changeItemVal('oldHomeLine3');
					$scope.oldHomeLine4 = address.old_home_line4;
					changeItemVal('oldHomeLine4');
					$scope.newHomeLine1 = address.new_home_line1;
					changeItemVal('newHomeLine1');
					$scope.newHomeLine2 = address.new_home_line2;
					changeItemVal('newHomeLine2');
					$scope.newHomeLine3 = address.new_home_line3;
					changeItemVal('newHomeLine3');
					$scope.newHomeLine4 = address.new_home_line4;
					changeItemVal('newHomeLine4');
					
					if (data.claim_details.spouse_items) {
						data.claim_details.spouse_items.forEach(function(obj) {
							$scope.addItemSpouse(obj);
						});
					};
					
					if (data.claim_details.children_items) {
						data.claim_details.children_items.forEach(function(obj) {
							$scope.addItemChildren(obj);
						});
					};
				});
            });
        };
		
		if (PK) {  // detail view
            $http({
                url: API_URL+'oversea-transfer-claims/'+PK+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
				$q.all(promises).then(function (resolutions) {
					claim = data.claim_details.claim_details[0];
					address = data.claim_details.address_items[0];
					foreign = data.claim_details.foreign_currency_items[0];
					
					$scope.transferGradeAfter = $scope.getDataByCode(claim.grade_after_id, resolutions.salary_grade.data.results);
					changeItemVal('transferGradeAfter');
					$scope.transferDate = claim.transfer_date;
					$scope.maritalStatus = { status: claim.marital_status };
					$scope.changeMaritalStatus();
					$scope.transferDestination = $scope.getDataByCode(claim.destination, $scope.transferDestinationList);
					changeItemVal('transferDestination');
					DataFundType.setFundType(DataFundType.getFundTypeByCode(claim.fund_type_id));
					if (claim.project_code) {
						$scope.projectCode = claim.project_code;
					}
					if (claim.destination == 'MalaysiaToOversea') {
						$scope.toDateMO = foreign.arrival_date;
						$scope.toCountryAfterMO = $scope.getDataByName(foreign.to_country, resolutions.country_list.data.results);
						$scope.toCurrencyTypeMO = $scope.getDataByCurrency(foreign.to_currency_type, resolutions.currency_list.data.results);
						$scope.toBNMDateMO = foreign.to_bnm_date;
						$scope.toExchangeRateMO = foreign.to_exchange_rate;
						changeItemVal('toCountryAfterMO');
						changeItemVal('toCurrencyTypeMO');
					} else if (claim.destination == 'OverseaToMalaysia') {
						$scope.fromDateOM = foreign.arrival_date;
						$scope.fromCountryAfterOM = $scope.getDataByName(foreign.from_country, resolutions.country_list.data.results);
						$scope.fromCurrencyTypeOM = $scope.getDataByCurrency(foreign.from_currency_type, $scope.fromCurrenciesOM);
						$scope.fromBNMDateOM = foreign.from_bnm_date;
						$scope.fromExchangeRateOM = foreign.from_exchange_rate;
						changeItemVal('fromCountryAfterOM');
						changeItemVal('fromCurrencyTypeOM');
					} else if (claim.destination == 'OverseaToOversea') {
						$scope.fromDateOO = foreign.arrival_date;
						$scope.fromCountryAfterOO = $scope.getDataByName(foreign.from_country, resolutions.country_list.data.results);
						$scope.fromCurrencyTypeOO = $scope.getDataByCurrency(foreign.from_currency_type, $scope.fromCurrenciesOO);
						$scope.fromBNMDateOO = foreign.from_bnm_date;
						$scope.fromExchangeRateOO = foreign.from_exchange_rate;
						$scope.toDateOO = foreign.arrival_date;
						$scope.toCountryAfterOO = $scope.getDataByName(foreign.to_country, resolutions.country_list.data.results);
						$scope.toCurrencyTypeOO = $scope.getDataByCurrency(foreign.to_currency_type, $scope.toCurrenciesOO);
						$scope.toBNMDateOO = foreign.to_bnm_date;
						$scope.toExchangeRateOO = foreign.to_exchange_rate;
						changeItemVal('fromCountryAfterOO');
						changeItemVal('fromCurrencyTypeOO');
						changeItemVal('toCountryAfterOO');
						changeItemVal('toCurrencyTypeOO');
					}
					$scope.oldOfficeLine1 = address.old_office_line1;
					changeItemVal('oldOfficeLine1');
					$scope.oldOfficeLine2 = address.old_office_line2;
					changeItemVal('oldOfficeLine2');
					$scope.oldOfficeLine3 = address.old_office_line3;
					changeItemVal('oldOfficeLine3');
					$scope.oldOfficeLine4 = address.old_office_line4;
					changeItemVal('oldOfficeLine4');
					$scope.newOfficeLine1 = address.new_office_line1;
					changeItemVal('newOfficeLine1');
					$scope.newOfficeLine2 = address.new_office_line2;
					changeItemVal('newOfficeLine2');
					$scope.newOfficeLine3 = address.new_office_line3;
					changeItemVal('newOfficeLine3');
					$scope.newOfficeLine4 = address.new_office_line4;
					changeItemVal('newOfficeLine4');
					$scope.oldHomeLine1 = address.old_home_line1;
					changeItemVal('oldHomeLine1');
					$scope.oldHomeLine2 = address.old_home_line2;
					changeItemVal('oldHomeLine2');
					$scope.oldHomeLine3 = address.old_home_line3;
					changeItemVal('oldHomeLine3');
					$scope.oldHomeLine4 = address.old_home_line4;
					changeItemVal('oldHomeLine4');
					$scope.newHomeLine1 = address.new_home_line1;
					changeItemVal('newHomeLine1');
					$scope.newHomeLine2 = address.new_home_line2;
					changeItemVal('newHomeLine2');
					$scope.newHomeLine3 = address.new_home_line3;
					changeItemVal('newHomeLine3');
					$scope.newHomeLine4 = address.new_home_line4;
					changeItemVal('newHomeLine4');
					
					if (data.claim_details.spouse_items) {
						data.claim_details.spouse_items.forEach(function(obj) {
							$scope.addItemSpouse(obj);
						});
					};
					
					if (data.claim_details.children_items) {
						data.claim_details.children_items.forEach(function(obj) {
							$scope.addItemChildren(obj);
						});
					};
				});
            });
        }
	};

	var entitledNo = 0;
	var entitle = function (age,work_status,oku_status) {
		var pass = true;
		var entitled_status;
		if (parseInt(age) < 21) {
		    if(work_status == 'Student') {
				pass = true;
		    } else if (work_status == 'Employed') {
				pass = !!oku_status;
		    }
		} else {
		    if(work_status == 'Student') {
				pass = false;
		    } else if (work_status == 'Employed') {
				pass = !!oku_status;
		    }
		}
		if(pass) {
			entitled_status = 'Layak'
			entitledNo = entitledNo + 1;
			changeItemVal('totalDependent');
		} else {
			entitled_status = 'Tidak Layak'
		}
		return entitled_status
	};
	
	var enableRoom2AndRoom3 = function () {
		angular.element(document.getElementById('hotel3Or5DaysRoom2FirstDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom3FirstDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom2SecondDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom3SecondDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom2ThirdDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom3ThirdDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom2FirstDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom3FirstDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom2SecondDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom3SecondDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom2ThirdDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom3ThirdDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom2ForthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom3ForthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom2FifthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel5DaysRoom3FifthDayPrice'))[0].disabled = false;
	};

	var disableRoom2AndRoom3 = function () {
		angular.element(document.getElementById('hotel3Or5DaysRoom2FirstDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom3FirstDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom2SecondDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom3SecondDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom2ThirdDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom3ThirdDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom2FirstDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom3FirstDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom2SecondDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom3SecondDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom2ThirdDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom3ThirdDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom2ForthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom3ForthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom2FifthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel5DaysRoom3FifthDayPrice'))[0].disabled = true;
	};

	var enableRoomForthAndFifthDay = function () {
		angular.element(document.getElementById('hotel3Or5DaysRoom1ForthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom2ForthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom3ForthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom1FifthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom2FifthDayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotel3Or5DaysRoom3FifthDayPrice'))[0].disabled = false;
	};

	var disableRoomForthAndFifthDay = function () {
		angular.element(document.getElementById('hotel3Or5DaysRoom1ForthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom2ForthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom3ForthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom1FifthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom2FifthDayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotel3Or5DaysRoom3FifthDayPrice'))[0].disabled = true;
	};

	var setExchangeRate = function () {
		destination = $scope.transferDestination.code
		if (destination == 'MalaysiaToOversea') {
			DataRates.setFromExchangeRates(1);
			DataRates.setToExchangeRates($scope.toExchangeRateMO);
		} else if (destination == 'OverseaToMalaysia') {
			DataRates.setFromExchangeRates($scope.fromExchangeRateOM);
			DataRates.setToExchangeRates(1);
		} else if (destination == 'OverseaToOversea') {
			DataRates.setFromExchangeRates($scope.fromExchangeRateOO);
			DataRates.setToExchangeRates($scope.toExchangeRateOO);
		};
	};

	$scope.openTransferDate = function($event) {
        $scope.statusTransferDate.opened = true;
    };
	$scope.openToDateMO = function($event) {
        $scope.statusToDateMO.opened = true;
    };
	$scope.openFromDateOM = function($event) {
        $scope.statusFromDateOM.opened = true;
    };
	$scope.openFromDateOO = function($event) {
        $scope.statusFromDateOO.opened = true;
    };
	$scope.openToDateOO = function($event) {
        $scope.statusToDateOO.opened = true;
    };

	$scope.statusTransferDate = {
        opened: false
    };
	$scope.statusToDateMO = {
        opened: false
    };
	$scope.statusFromDateOM = {
        opened: false
    };
	$scope.statusFromDateOO = {
        opened: false
    };
	$scope.statusToDateOO = {
        opened: false
    };

	var changeItemVal = function(obj) {
		if (obj == 'transferOverseaFundType') {
            DataFormTransferDetails.setTransferOverseaFundType(DataFundType.getFundType());
        }
		else if (obj == 'transferOverseaProjectCode') {
            DataFormTransferDetails.setTransferOverseaProjectCode(DataLookup.getProjectCode());
        }
		else if (obj == 'transferGradeAfter') {
            DataFormTransferDetails.setTransferGradeAfter($scope.transferGradeAfter);
        }
		else if (obj == 'newEntitlement') {
			defaultRate = get2Float(0);
			if ($scope.newEntitlement[0]) {
				DataRates.setMeal5Day($scope.newEntitlement[0]['meal']);
				DataRates.setHotel5Day($scope.newEntitlement[0]['hotel']);
				DataRates.setLodging5Day($scope.newEntitlement[0]['lodging']);
				DataFormTransferDetails.setNewEntitlement($scope.newEntitlement);
			} else {
				DataRates.setMeal5Day(defaultRate);
				DataRates.setHotel5Day(defaultRate);
				DataRates.setLodging5Day(defaultRate);
				DataFormTransferDetails.setNewEntitlement($scope.newEntitlement);
			}
        }
		else if (obj == 'transferDestination') {
            DataFormTransferDetails.setTransferDestination($scope.transferDestination);
        }
		else if (obj == 'maritalStatus') {
            DataFormTransferDetails.setMaritalStatus($scope.maritalStatus);
        }
		else if (obj == 'spouseList') {
			DataFormTransferDetails.setSpouseList($scope.spouseList);
		}
		else if (obj == 'childrenList') {
			DataFormTransferDetails.setChildrenList($scope.childrenList);
		}
		else if (obj == 'totalDependent') {
			DataMain.setTotalDependent($scope.totalDependent);
		}
		else if (obj == 'toCountryAfterMO') {
            DataFormTransferDetails.setToCountryAfter($scope.toCountryAfterMO);
        }
		else if (obj == 'toCurrencyTypeMO') {
            DataFormTransferDetails.setToCurrencyType($scope.toCurrencyTypeMO);
			DataFormTransferDetails.setToBNMDate($scope.toBNMDateMO);
			DataFormTransferDetails.setToExchangeRate($scope.toExchangeRateMO);
			setExchangeRate();
        }
		else if (obj == 'fromCountryAfterOM') {
            DataFormTransferDetails.setFromCountryAfter($scope.fromCountryAfterOM);
        }
		else if (obj == 'fromCurrencyTypeOM') {
            DataFormTransferDetails.setFromCurrencyType($scope.fromCurrencyTypeOM);
			DataFormTransferDetails.setFromBNMDate($scope.fromBNMDateOM);
			DataFormTransferDetails.setFromExchangeRate($scope.fromExchangeRateOM);
			setExchangeRate();
        }
		else if (obj == 'fromCountryAfterOO') {
            DataFormTransferDetails.setFromCountryAfter($scope.fromCountryAfterOO);
        }
		else if (obj == 'fromCurrencyTypeOO') {
            DataFormTransferDetails.setFromCurrencyType($scope.fromCurrencyTypeOO);
			DataFormTransferDetails.setFromBNMDate($scope.fromBNMDateOO);
			DataFormTransferDetails.setFromExchangeRate($scope.fromExchangeRateOO);
			setExchangeRate();
        }
		else if (obj == 'toCountryAfterOO') {
            DataFormTransferDetails.setToCountryAfter($scope.toCountryAfterOO);
        }
		else if (obj == 'toCurrencyTypeOO') {
            DataFormTransferDetails.setToCurrencyType($scope.toCurrencyTypeOO);
			DataFormTransferDetails.setToBNMDate($scope.toBNMDateOO);
			DataFormTransferDetails.setToExchangeRate($scope.toExchangeRateOO);
			setExchangeRate();
        }
		else if (obj == 'oldOfficeLine1') {
            DataFormTransferDetails.setOldOfficeLine1($scope.oldOfficeLine1);
        }
		else if (obj == 'oldOfficeLine2') {
            DataFormTransferDetails.setOldOfficeLine2($scope.oldOfficeLine2);
        }
		else if (obj == 'oldOfficeLine3') {
            DataFormTransferDetails.setOldOfficeLine3($scope.oldOfficeLine3);
        }
		else if (obj == 'oldOfficeLine4') {
            DataFormTransferDetails.setOldOfficeLine4($scope.oldOfficeLine4);
        }
		else if (obj == 'newOfficeLine1') {
            DataFormTransferDetails.setNewOfficeLine1($scope.newOfficeLine1);
        }
		else if (obj == 'newOfficeLine2') {
            DataFormTransferDetails.setNewOfficeLine2($scope.newOfficeLine2);
        }
		else if (obj == 'newOfficeLine3') {
            DataFormTransferDetails.setNewOfficeLine3($scope.newOfficeLine3);
        }
		else if (obj == 'newOfficeLine4') {
            DataFormTransferDetails.setNewOfficeLine4($scope.newOfficeLine4);
        }
		else if (obj == 'oldHomeLine1') {
            DataFormTransferDetails.setOldHomeLine1($scope.oldHomeLine1);
        }
		else if (obj == 'oldHomeLine2') {
            DataFormTransferDetails.setOldHomeLine2($scope.oldHomeLine2);
        }
		else if (obj == 'oldHomeLine3') {
            DataFormTransferDetails.setOldHomeLine3($scope.oldHomeLine3);
        }
		else if (obj == 'oldHomeLine4') {
            DataFormTransferDetails.setOldHomeLine4($scope.oldHomeLine4);
        }
		else if (obj == 'newHomeLine1') {
            DataFormTransferDetails.setNewHomeLine1($scope.newHomeLine1);
        }
		else if (obj == 'newHomeLine2') {
            DataFormTransferDetails.setNewHomeLine2($scope.newHomeLine2);
        }
		else if (obj == 'newHomeLine3') {
            DataFormTransferDetails.setNewHomeLine3($scope.newHomeLine3);
        }
		else if (obj == 'newHomeLine4') {
            DataFormTransferDetails.setNewHomeLine4($scope.newHomeLine4);
        }
    };

	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('transferOverseaFundType');
    });
    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('transferOverseaProjectCode');
    });
	$scope.$watch('transferGradeAfter', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('transferGradeAfter');
			$http({
				url: API_URL+'offduty-trip-oversea-allowance/',
				method: 'GET',
				params: {'salaryGrade': DataFormTransferDetails.getTransferGradeAfter().code}
			})
			.success(function (data, status, headers, config) {
				$scope.newEntitlement = data.results;
				changeItemVal('newEntitlement');
			});
		}
	});
	$scope.$watch('newEntitlement', function(newValue, oldValue) {
        if (newValue != oldValue) {
            changeItemVal('newEntitlement');
        }
    });
	$scope.$watch('transferDate', function(newValue, oldValue) {
        if (newValue != oldValue) {
            DataFormTransferDetails.setTransferDate(newValue);
        }
    });
	$scope.$watch('transferDestination', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('transferDestination');
			destination = $scope.transferDestination.code
			if (destination == 'MalaysiaToOversea') {
				$scope.showForeignCurrencyLabel = true;
				$scope.showForeignCurrencyMO1Form = true;
				$scope.showForeignCurrencyMO2Form = true;
				$scope.showForeignCurrencyOM1Form = false;
				$scope.showForeignCurrencyOM2Form = false;
				$scope.showForeignCurrencyOOLabel = false;
				$scope.showForeignCurrencyOO1Form = false;
				$scope.showForeignCurrencyOO2Form = false;
				disableRoomForthAndFifthDay();
				changeItemVal('toCountryAfterMO');
				changeItemVal('toCurrencyTypeMO');
			} else if (destination == 'OverseaToMalaysia') {
				$scope.showForeignCurrencyLabel = true;
				$scope.showForeignCurrencyMO1Form = false;
				$scope.showForeignCurrencyMO2Form = false;
				$scope.showForeignCurrencyOM1Form = true;
				$scope.showForeignCurrencyOM2Form = true;
				$scope.showForeignCurrencyOOLabel = false;
				$scope.showForeignCurrencyOO1Form = false;
				$scope.showForeignCurrencyOO2Form = false;
				disableRoomForthAndFifthDay();
				changeItemVal('fromCountryAfterOM');
				changeItemVal('fromCurrencyTypeOM');
			} else if (destination == 'OverseaToOversea') {
				$scope.showForeignCurrencyLabel = false;
				$scope.showForeignCurrencyMO1Form = false;
				$scope.showForeignCurrencyMO2Form = false;
				$scope.showForeignCurrencyOM1Form = false;
				$scope.showForeignCurrencyOM2Form = false;
				$scope.showForeignCurrencyOOLabel = true;
				$scope.showForeignCurrencyOO1Form = true;
				$scope.showForeignCurrencyOO2Form = true;
				enableRoomForthAndFifthDay();
				changeItemVal('fromCountryAfterOO');
				changeItemVal('fromCurrencyTypeOO');
				changeItemVal('toCountryAfterOO');
				changeItemVal('toCurrencyTypeOO');
			}
		}
	});
	$scope.changeMaritalStatus = function () {
		changeItemVal('maritalStatus');
		$scope.totalDependent = 0;
		if ($scope.maritalStatus.status == 'mF') {
			$scope.totalDependent = entitledNo + DataMain.getTotalSpouse() + 1;
			enableRoom2AndRoom3();
		} else {
			$scope.totalDependent = 1;
			disableRoom2AndRoom3();
		}
	}
	$scope.$watch('totalDependent', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('totalDependent');
		}
	});
	$scope.$watch('toDateMO', function(newValue, oldValue) {
        if (newValue != oldValue) {
            DataFormTransferDetails.setToDate(newValue);
        }
    });
	$scope.$watch('toCountryAfterMO', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('toCountryAfterMO');
		}
	});
	$scope.$watch('toCurrencyTypeMO', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('toCurrencyTypeMO');
		}
	});
	$scope.$watch('fromDateOM', function(newValue, oldValue) {
        if (newValue != oldValue) {
            DataFormTransferDetails.setFromDate(newValue);
        }
    });
	$scope.$watch('fromCountryAfterOM', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('fromCountryAfterOM');
		}
	});
	$scope.$watch('fromCurrencyTypeOM', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('fromCurrencyTypeOM');
		}
	});
	$scope.$watch('fromDateOO', function(newValue, oldValue) {
        if (newValue != oldValue) {
            DataFormTransferDetails.setFromDate(newValue);
        }
    });
	$scope.$watch('fromCountryAfterOO', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('fromCountryAfterOO');
		}
	});
	$scope.$watch('fromCurrencyTypeOO', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('fromCurrencyTypeOO');
		}
	});
	$scope.$watch('toDateOO', function(newValue, oldValue) {
        if (newValue != oldValue) {
            DataFormTransferDetails.setToDate(newValue);
        }
    });
	$scope.$watch('toCountryAfterOO', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('toCountryAfterOO');
		}
	});
	$scope.$watch('toCurrencyTypeOO', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('toCurrencyTypeOO');
		}
	});
	$scope.$watch('oldOfficeLine1', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldOfficeLine1');
		}
	});
	$scope.$watch('oldOfficeLine2', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldOfficeLine2');
		}
	});
	$scope.$watch('oldOfficeLine3', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldOfficeLine3');
		}
	});
	$scope.$watch('oldOfficeLine4', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldOfficeLine4');
		}
	});
	$scope.$watch('newOfficeLine1', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newOfficeLine1');
		}
	});
	$scope.$watch('newOfficeLine2', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newOfficeLine2');
		}
	});
	$scope.$watch('newOfficeLine3', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newOfficeLine3');
		}
	});
	$scope.$watch('newOfficeLine4', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newOfficeLine4');
		}
	});
	$scope.$watch('oldHomeLine1', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldHomeLine1');
		}
	});
	$scope.$watch('oldHomeLine2', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldHomeLine2');
		}
	});
	$scope.$watch('oldHomeLine3', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldHomeLine3');
		}
	});
	$scope.$watch('oldHomeLine4', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('oldHomeLine4');
		}
	});
	$scope.$watch('newHomeLine1', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newHomeLine1');
		}
	});
	$scope.$watch('newHomeLine2', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newHomeLine2');
		}
	});
	$scope.$watch('newHomeLine3', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newHomeLine3');
		}
	});
	$scope.$watch('newHomeLine4', function(newValue, oldValue){
        if (newValue != oldValue) {
			changeItemVal('newHomeLine4');
		}
	});
});

uiBootstrapApp.controller('ClaimDetailsCtrl', function($scope, $filter, $http, DataRates, DataMain, DataFormTransferDetails, DataFormClaimDetails, DataEndowment) {

	$scope.miscDate = new Date();

	$scope.formatDay = $scope.dateFormats[0];

	$scope.initClaimDetailsCtrl = function(draftID, jsonDestinationType) {
        console.log('Load initClaimDetailsCtrl (Default)');

		$scope.destinationTypeList = [];

		getAngularObjFromJson(jsonDestinationType).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.destinationTypeList.push({code:code, description:description});
		});
		
		if (draftID) { // draft view
            console.log('Load draft items for Draft [',draftID,']');
            $http({
                url: API_URL+'oversea-transfer-claim-drafts/'+draftID+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
				
				if (data.claim_details.claim_details[0]) {
					claim = data.claim_details.claim_details[0];

					$scope.otherMiscExpensesTotal = get2Float(claim.other_misc_total_amount);
					changeItemVal('otherMiscExpensesTotal');

					DataEndowment.setClaimAmount(claim.claim_amount);
					DataEndowment.setEndowmentAmount(claim.endowment_amount);
					DataEndowment.setNetTotal(claim.net_total);
				};

				if (data.claim_details.meal_items[0]) {
					meal = data.claim_details.meal_items[0];
					$scope.meal3Or5DaysRatePerDay = get2Float(meal.meal_rate_before);
					changeItemVal('meal3Or5DaysRatePerDay');
					$scope.meal3Or5DaysNoOfPerson = meal.meal_no_of_people_before;
					changeItemVal('meal3Or5DaysNoOfPerson');
					$scope.meal3Or5DaysDaysTotal = get2Float(meal.meal_total_before);
					changeItemVal('meal3Or5DaysDaysTotal');
					$scope.meal5DaysRatePerDay = get2Float(meal.meal_rate_after);
					changeItemVal('meal5DaysRatePerDay');
					$scope.meal5DaysNoOfPerson = meal.meal_no_of_people_after;
					changeItemVal('meal5DaysNoOfPerson');
					$scope.meal5DaysTotal = get2Float(meal.meal_total_after);
					changeItemVal('meal5DaysTotal');
					$scope.totalMealAllowance = get2Float(meal.meal_total_amount);
					changeItemVal('totalMealAllowance');
				};

				if (data.claim_details.hotel_items[0]) {
					hotel = data.claim_details.hotel_items[0];
					$scope.hotel3Or5DaysRoom1FirstDayPrice = get2Float(hotel.room_price_1_first_3or5);
					changeItemVal('hotel3Or5DaysRoom1FirstDayPrice');
					$scope.hotel3Or5DaysRoom2FirstDayPrice = get2Float(hotel.room_price_2_first_3or5);
					changeItemVal('hotel3Or5DaysRoom2FirstDayPrice');
					$scope.hotel3Or5DaysRoom3FirstDayPrice = get2Float(hotel.room_price_3_first_3or5);
					changeItemVal('hotel3Or5DaysRoom3FirstDayPrice');
					$scope.hotel3Or5DaysFirstDayTotal = get2Float(hotel.hotel_total_first_3or5);
					changeItemVal('hotel3Or5DaysFirstDayTotal');
					$scope.hotel3Or5DaysRoom1SecondDayPrice = get2Float(hotel.room_price_1_second_3or5);
					changeItemVal('hotel3Or5DaysRoom1SecondDayPrice');
					$scope.hotel3Or5DaysRoom2SecondDayPrice = get2Float(hotel.room_price_2_second_3or5);
					changeItemVal('hotel3Or5DaysRoom2SecondDayPrice');
					$scope.hotel3Or5DaysRoom3SecondDayPrice = get2Float(hotel.room_price_3_second_3or5);
					changeItemVal('hotel3Or5DaysRoom3SecondDayPrice');
					$scope.hotel3Or5DaysSecondDayTotal = get2Float(hotel.hotel_total_second_3or5);
					changeItemVal('hotel3Or5DaysSecondDayTotal');
					$scope.hotel3Or5DaysRoom1ThirdDayPrice = get2Float(hotel.room_price_1_third_3or5);
					changeItemVal('hotel3Or5DaysRoom1ThirdDayPrice');
					$scope.hotel3Or5DaysRoom2ThirdDayPrice = get2Float(hotel.room_price_2_third_3or5);
					changeItemVal('hotel3Or5DaysRoom2ThirdDayPrice');
					$scope.hotel3Or5DaysRoom3ThirdDayPrice = get2Float(hotel.room_price_3_third_3or5);
					changeItemVal('hotel3Or5DaysRoom3ThirdDayPrice');
					$scope.hotel3Or5DaysThirdDayTotal = get2Float(hotel.hotel_total_third_3or5);
					changeItemVal('hotel3Or5DaysThirdDayTotal');
					$scope.hotel3Or5DaysRoom1ForthDayPrice = get2Float(hotel.room_price_1_forth_3or5);
					changeItemVal('hotel3Or5DaysRoom1ForthDayPrice');
					$scope.hotel3Or5DaysRoom2ForthDayPrice = get2Float(hotel.room_price_2_forth_3or5);
					changeItemVal('hotel3Or5DaysRoom2ForthDayPrice');
					$scope.hotel3Or5DaysRoom3ForthDayPrice = get2Float(hotel.room_price_3_forth_3or5);
					changeItemVal('hotel3Or5DaysRoom3ForthDayPrice');
					$scope.hotel3Or5DaysForthDayTotal = get2Float(hotel.hotel_total_forth_3or5);
					changeItemVal('hotel3Or5DaysForthDayTotal');
					$scope.hotel3Or5DaysRoom1FifthDayPrice = get2Float(hotel.room_price_1_fifth_3or5);
					changeItemVal('hotel3Or5DaysRoom1FifthDayPrice');
					$scope.hotel3Or5DaysRoom2FifthDayPrice = get2Float(hotel.room_price_2_fifth_3or5);
					changeItemVal('hotel3Or5DaysRoom2FifthDayPrice');
					$scope.hotel3Or5DaysRoom3FifthDayPrice = get2Float(hotel.room_price_3_fifth_3or5);
					changeItemVal('hotel3Or5DaysRoom3FifthDayPrice');
					$scope.hotel3Or5DaysFifthDayTotal = get2Float(hotel.hotel_total_fifth_3or5);
					changeItemVal('hotel3Or5DaysFifthDayTotal');
					$scope.hotel3Or5DaysTotal = get2Float(hotel.hotel_total_amount_3or5);
					changeItemVal('hotel3Or5DaysTotal');
					$scope.hotel3Or5DaysTotalExchange = get2Float(hotel.hotel_total_foreign_amount_3or5);
					changeItemVal('hotel3Or5DaysTotalExchange');

					$scope.hotel5DaysRoom1FirstDayPrice = get2Float(hotel.room_price_1_first_5);
					changeItemVal('hotel5DaysRoom1FirstDayPrice');
					$scope.hotel5DaysRoom2FirstDayPrice = get2Float(hotel.room_price_2_first_5);
					changeItemVal('hotel5DaysRoom2FirstDayPrice');
					$scope.hotel5DaysRoom3FirstDayPrice = get2Float(hotel.room_price_3_first_5);
					changeItemVal('hotel5DaysRoom3FirstDayPrice');
					$scope.hotel5DaysFirstDayTotal = get2Float(hotel.hotel_total_first_5);
					changeItemVal('hotel5DaysFirstDayTotal');
					$scope.hotel5DaysRoom1SecondDayPrice = get2Float(hotel.room_price_1_second_5);
					changeItemVal('hotel5DaysRoom1SecondDayPrice');
					$scope.hotel5DaysRoom2SecondDayPrice = get2Float(hotel.room_price_2_second_5);
					changeItemVal('hotel5DaysRoom2SecondDayPrice');
					$scope.hotel5DaysRoom3SecondDayPrice = get2Float(hotel.room_price_3_second_5);
					changeItemVal('hotel5DaysRoom3SecondDayPrice');
					$scope.hotel5DaysSecondDayTotal = get2Float(hotel.hotel_total_second_5);
					changeItemVal('hotel5DaysSecondDayTotal');
					$scope.hotel5DaysRoom1ThirdDayPrice = get2Float(hotel.room_price_1_third_5);
					changeItemVal('hotel5DaysRoom1ThirdDayPrice');
					$scope.hotel5DaysRoom2ThirdDayPrice = get2Float(hotel.room_price_2_third_5);
					changeItemVal('hotel5DaysRoom2ThirdDayPrice');
					$scope.hotel5DaysRoom3ThirdDayPrice = get2Float(hotel.room_price_3_third_5);
					changeItemVal('hotel5DaysRoom3ThirdDayPrice');
					$scope.hotel5DaysThirdDayTotal = get2Float(hotel.hotel_total_third_5);
					changeItemVal('hotel5DaysThirdDayTotal');
					$scope.hotel5DaysRoom1ForthDayPrice = get2Float(hotel.room_price_1_forth_5);
					changeItemVal('hotel5DaysRoom1ForthDayPrice');
					$scope.hotel5DaysRoom2ForthDayPrice = get2Float(hotel.room_price_2_forth_5);
					changeItemVal('hotel5DaysRoom2ForthDayPrice');
					$scope.hotel5DaysRoom3ForthDayPrice = get2Float(hotel.room_price_3_forth_5);
					changeItemVal('hotel5DaysRoom3ForthDayPrice');
					$scope.hotel5DaysForthDayTotal = get2Float(hotel.hotel_total_forth_5);
					changeItemVal('hotel5DaysForthDayTotal');
					$scope.hotel5DaysRoom1FifthDayPrice = get2Float(hotel.room_price_1_fifth_5);
					changeItemVal('hotel5DaysRoom1FifthDayPrice');
					$scope.hotel5DaysRoom2FifthDayPrice = get2Float(hotel.room_price_2_fifth_5);
					changeItemVal('hotel5DaysRoom2FifthDayPrice');
					$scope.hotel5DaysRoom3FifthDayPrice = get2Float(hotel.room_price_3_fifth_5);
					changeItemVal('hotel5DaysRoom3FifthDayPrice');
					$scope.hotel5DaysFifthDayTotal = get2Float(hotel.hotel_total_fifth_5);
					changeItemVal('hotel5DaysFifthDayTotal');
					$scope.hotel5DaysTotal = get2Float(hotel.hotel_total_amount_5);
					changeItemVal('hotel5DaysTotal');
					$scope.hotel5DaysTotalExchange = get2Float(hotel.hotel_total_foreign_amount_5);
					changeItemVal('hotel5DaysTotalExchange');

					$scope.hotelTotalAmount = get2Float(hotel.hotel_total_amount);
					changeItemVal('hotelTotalAmount');
					$scope.hotelTotalGST = get2Float(hotel.hotel_total_gst);
					changeItemVal('hotelTotalGST');
					$scope.hotelReceiptNo = hotel.hotel_receipt_no;
					changeItemVal('hotelReceiptNo');
				};

				if (data.claim_details.lodging_items[0]) {
					lodging = data.claim_details.lodging_items[0];
					$scope.lodging3Or5DaysAddress = lodging.lodging_add_before;
					changeItemVal('lodging3Or5DaysAddress');
					$scope.lodging3Or5DaysNoOfDay = lodging.lodging_no_of_days_before;
					changeItemVal('lodging3Or5DaysNoOfDay');
					$scope.lodging3Or5DaysRatePerDay = get2Float(lodging.lodging_rate_before);
					changeItemVal('lodging3Or5DaysRatePerDay');
					$scope.lodging3Or5DaysTotal = get2Float(lodging.lodging_total_before);
					changeItemVal('lodging3Or5DaysTotal');
					$scope.lodging5DaysAddress = lodging.lodging_add_after;
					changeItemVal('lodging5DaysAddress');
					$scope.lodging5DaysNoOfDay = lodging.lodging_no_of_days_after;
					changeItemVal('lodging5DaysNoOfDay');
					$scope.lodging5DaysRatePerDay = get2Float(lodging.lodging_rate_after);
					changeItemVal('lodging5DaysRatePerDay');
					$scope.lodging5DaysTotal = get2Float(lodging.lodging_total_after);
					changeItemVal('lodging5DaysTotal');
					$scope.lodgingTotalAllowance = get2Float(lodging.lodging_total_amount);
					changeItemVal('lodgingTotalAllowance');
				};

				if (data.claim_details.misc_items) {
					data.claim_details.misc_items.forEach(function(obj) {
						$scope.addItem(obj);
					});
				};
            });
        };
		
		if (PK) {  // detail view
            $http({
                url: API_URL+'oversea-transfer-claims/'+PK+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
				
				if (data.claim_details.claim_details[0]) {
					claim = data.claim_details.claim_details[0];

					$scope.otherMiscExpensesTotal = get2Float(claim.other_misc_total_amount);
					changeItemVal('otherMiscExpensesTotal');

					DataEndowment.setClaimAmount(claim.claim_amount);
					DataEndowment.setEndowmentAmount(claim.endowment_amount);
					DataEndowment.setNetTotal(claim.net_total);
				};

				if (data.claim_details.meal_items[0]) {
					meal = data.claim_details.meal_items[0];
					$scope.meal3Or5DaysRatePerDay = get2Float(meal.meal_rate_before);
					changeItemVal('meal3Or5DaysRatePerDay');
					$scope.meal3Or5DaysNoOfPerson = meal.meal_no_of_people_before;
					changeItemVal('meal3Or5DaysNoOfPerson');
					$scope.meal3Or5DaysDaysTotal = get2Float(meal.meal_total_before);
					changeItemVal('meal3Or5DaysDaysTotal');
					$scope.meal5DaysRatePerDay = get2Float(meal.meal_rate_after);
					changeItemVal('meal5DaysRatePerDay');
					$scope.meal5DaysNoOfPerson = meal.meal_no_of_people_after;
					changeItemVal('meal5DaysNoOfPerson');
					$scope.meal5DaysTotal = get2Float(meal.meal_total_after);
					changeItemVal('meal5DaysTotal');
					$scope.totalMealAllowance = get2Float(meal.meal_total_amount);
					changeItemVal('totalMealAllowance');
				};

				if (data.claim_details.hotel_items[0]) {
					hotel = data.claim_details.hotel_items[0];
					$scope.hotel3Or5DaysRoom1FirstDayPrice = get2Float(hotel.room_price_1_first_3or5);
					changeItemVal('hotel3Or5DaysRoom1FirstDayPrice');
					$scope.hotel3Or5DaysRoom2FirstDayPrice = get2Float(hotel.room_price_2_first_3or5);
					changeItemVal('hotel3Or5DaysRoom2FirstDayPrice');
					$scope.hotel3Or5DaysRoom3FirstDayPrice = get2Float(hotel.room_price_3_first_3or5);
					changeItemVal('hotel3Or5DaysRoom3FirstDayPrice');
					$scope.hotel3Or5DaysFirstDayTotal = get2Float(hotel.hotel_total_first_3or5);
					changeItemVal('hotel3Or5DaysFirstDayTotal');
					$scope.hotel3Or5DaysRoom1SecondDayPrice = get2Float(hotel.room_price_1_second_3or5);
					changeItemVal('hotel3Or5DaysRoom1SecondDayPrice');
					$scope.hotel3Or5DaysRoom2SecondDayPrice = get2Float(hotel.room_price_2_second_3or5);
					changeItemVal('hotel3Or5DaysRoom2SecondDayPrice');
					$scope.hotel3Or5DaysRoom3SecondDayPrice = get2Float(hotel.room_price_3_second_3or5);
					changeItemVal('hotel3Or5DaysRoom3SecondDayPrice');
					$scope.hotel3Or5DaysSecondDayTotal = get2Float(hotel.hotel_total_second_3or5);
					changeItemVal('hotel3Or5DaysSecondDayTotal');
					$scope.hotel3Or5DaysRoom1ThirdDayPrice = get2Float(hotel.room_price_1_third_3or5);
					changeItemVal('hotel3Or5DaysRoom1ThirdDayPrice');
					$scope.hotel3Or5DaysRoom2ThirdDayPrice = get2Float(hotel.room_price_2_third_3or5);
					changeItemVal('hotel3Or5DaysRoom2ThirdDayPrice');
					$scope.hotel3Or5DaysRoom3ThirdDayPrice = get2Float(hotel.room_price_3_third_3or5);
					changeItemVal('hotel3Or5DaysRoom3ThirdDayPrice');
					$scope.hotel3Or5DaysThirdDayTotal = get2Float(hotel.hotel_total_third_3or5);
					changeItemVal('hotel3Or5DaysThirdDayTotal');
					$scope.hotel3Or5DaysRoom1ForthDayPrice = get2Float(hotel.room_price_1_forth_3or5);
					changeItemVal('hotel3Or5DaysRoom1ForthDayPrice');
					$scope.hotel3Or5DaysRoom2ForthDayPrice = get2Float(hotel.room_price_2_forth_3or5);
					changeItemVal('hotel3Or5DaysRoom2ForthDayPrice');
					$scope.hotel3Or5DaysRoom3ForthDayPrice = get2Float(hotel.room_price_3_forth_3or5);
					changeItemVal('hotel3Or5DaysRoom3ForthDayPrice');
					$scope.hotel3Or5DaysForthDayTotal = get2Float(hotel.hotel_total_forth_3or5);
					changeItemVal('hotel3Or5DaysForthDayTotal');
					$scope.hotel3Or5DaysRoom1FifthDayPrice = get2Float(hotel.room_price_1_fifth_3or5);
					changeItemVal('hotel3Or5DaysRoom1FifthDayPrice');
					$scope.hotel3Or5DaysRoom2FifthDayPrice = get2Float(hotel.room_price_2_fifth_3or5);
					changeItemVal('hotel3Or5DaysRoom2FifthDayPrice');
					$scope.hotel3Or5DaysRoom3FifthDayPrice = get2Float(hotel.room_price_3_fifth_3or5);
					changeItemVal('hotel3Or5DaysRoom3FifthDayPrice');
					$scope.hotel3Or5DaysFifthDayTotal = get2Float(hotel.hotel_total_fifth_3or5);
					changeItemVal('hotel3Or5DaysFifthDayTotal');
					$scope.hotel3Or5DaysTotal = get2Float(hotel.hotel_total_amount_3or5);
					changeItemVal('hotel3Or5DaysTotal');
					$scope.hotel3Or5DaysTotalExchange = get2Float(hotel.hotel_total_foreign_amount_3or5);
					changeItemVal('hotel3Or5DaysTotalExchange');

					$scope.hotel5DaysRoom1FirstDayPrice = get2Float(hotel.room_price_1_first_5);
					changeItemVal('hotel5DaysRoom1FirstDayPrice');
					$scope.hotel5DaysRoom2FirstDayPrice = get2Float(hotel.room_price_2_first_5);
					changeItemVal('hotel5DaysRoom2FirstDayPrice');
					$scope.hotel5DaysRoom3FirstDayPrice = get2Float(hotel.room_price_3_first_5);
					changeItemVal('hotel5DaysRoom3FirstDayPrice');
					$scope.hotel5DaysFirstDayTotal = get2Float(hotel.hotel_total_first_5);
					changeItemVal('hotel5DaysFirstDayTotal');
					$scope.hotel5DaysRoom1SecondDayPrice = get2Float(hotel.room_price_1_second_5);
					changeItemVal('hotel5DaysRoom1SecondDayPrice');
					$scope.hotel5DaysRoom2SecondDayPrice = get2Float(hotel.room_price_2_second_5);
					changeItemVal('hotel5DaysRoom2SecondDayPrice');
					$scope.hotel5DaysRoom3SecondDayPrice = get2Float(hotel.room_price_3_second_5);
					changeItemVal('hotel5DaysRoom3SecondDayPrice');
					$scope.hotel5DaysSecondDayTotal = get2Float(hotel.hotel_total_second_5);
					changeItemVal('hotel5DaysSecondDayTotal');
					$scope.hotel5DaysRoom1ThirdDayPrice = get2Float(hotel.room_price_1_third_5);
					changeItemVal('hotel5DaysRoom1ThirdDayPrice');
					$scope.hotel5DaysRoom2ThirdDayPrice = get2Float(hotel.room_price_2_third_5);
					changeItemVal('hotel5DaysRoom2ThirdDayPrice');
					$scope.hotel5DaysRoom3ThirdDayPrice = get2Float(hotel.room_price_3_third_5);
					changeItemVal('hotel5DaysRoom3ThirdDayPrice');
					$scope.hotel5DaysThirdDayTotal = get2Float(hotel.hotel_total_third_5);
					changeItemVal('hotel5DaysThirdDayTotal');
					$scope.hotel5DaysRoom1ForthDayPrice = get2Float(hotel.room_price_1_forth_5);
					changeItemVal('hotel5DaysRoom1ForthDayPrice');
					$scope.hotel5DaysRoom2ForthDayPrice = get2Float(hotel.room_price_2_forth_5);
					changeItemVal('hotel5DaysRoom2ForthDayPrice');
					$scope.hotel5DaysRoom3ForthDayPrice = get2Float(hotel.room_price_3_forth_5);
					changeItemVal('hotel5DaysRoom3ForthDayPrice');
					$scope.hotel5DaysForthDayTotal = get2Float(hotel.hotel_total_forth_5);
					changeItemVal('hotel5DaysForthDayTotal');
					$scope.hotel5DaysRoom1FifthDayPrice = get2Float(hotel.room_price_1_fifth_5);
					changeItemVal('hotel5DaysRoom1FifthDayPrice');
					$scope.hotel5DaysRoom2FifthDayPrice = get2Float(hotel.room_price_2_fifth_5);
					changeItemVal('hotel5DaysRoom2FifthDayPrice');
					$scope.hotel5DaysRoom3FifthDayPrice = get2Float(hotel.room_price_3_fifth_5);
					changeItemVal('hotel5DaysRoom3FifthDayPrice');
					$scope.hotel5DaysFifthDayTotal = get2Float(hotel.hotel_total_fifth_5);
					changeItemVal('hotel5DaysFifthDayTotal');
					$scope.hotel5DaysTotal = get2Float(hotel.hotel_total_amount_5);
					changeItemVal('hotel5DaysTotal');
					$scope.hotel5DaysTotalExchange = get2Float(hotel.hotel_total_foreign_amount_5);
					changeItemVal('hotel5DaysTotalExchange');

					$scope.hotelTotalAmount = get2Float(hotel.hotel_total_amount);
					changeItemVal('hotelTotalAmount');
					$scope.hotelTotalGST = get2Float(hotel.hotel_total_gst);
					changeItemVal('hotelTotalGST');
					$scope.hotelReceiptNo = hotel.hotel_receipt_no;
					changeItemVal('hotelReceiptNo');
				};

				if (data.claim_details.lodging_items[0]) {
					lodging = data.claim_details.lodging_items[0];
					$scope.lodging3Or5DaysAddress = lodging.lodging_add_before;
					changeItemVal('lodging3Or5DaysAddress');
					$scope.lodging3Or5DaysNoOfDay = lodging.lodging_no_of_days_before;
					changeItemVal('lodging3Or5DaysNoOfDay');
					$scope.lodging3Or5DaysRatePerDay = get2Float(lodging.lodging_rate_before);
					changeItemVal('lodging3Or5DaysRatePerDay');
					$scope.lodging3Or5DaysTotal = get2Float(lodging.lodging_total_before);
					changeItemVal('lodging3Or5DaysTotal');
					$scope.lodging5DaysAddress = lodging.lodging_add_after;
					changeItemVal('lodging5DaysAddress');
					$scope.lodging5DaysNoOfDay = lodging.lodging_no_of_days_after;
					changeItemVal('lodging5DaysNoOfDay');
					$scope.lodging5DaysRatePerDay = get2Float(lodging.lodging_rate_after);
					changeItemVal('lodging5DaysRatePerDay');
					$scope.lodging5DaysTotal = get2Float(lodging.lodging_total_after);
					changeItemVal('lodging5DaysTotal');
					$scope.lodgingTotalAllowance = get2Float(lodging.lodging_total_amount);
					changeItemVal('lodgingTotalAllowance');
				};

				if (data.claim_details.misc_items) {
					data.claim_details.misc_items.forEach(function(obj) {
						$scope.addItem(obj);
					});
				};
            });
        }
	};
	
	var calculateMeal = function () {
		$scope.meal3Or5DaysRatePerDay = DataRates.getMeal3Or5Day();
		$scope.meal3Or5DaysNoOfPerson = DataMain.getTotalDependent();
		var total3Or5DayMeal  = parseFloat($scope.meal3Or5DaysRatePerDay) * parseFloat($scope.meal3Or5DaysNoOfPerson)

		$scope.meal5DaysRatePerDay = DataRates.getMeal5Day();
		$scope.meal5DaysNoOfPerson = DataMain.getTotalDependent();
		var total5DayMeal  = parseFloat($scope.meal5DaysRatePerDay) * parseFloat($scope.meal5DaysNoOfPerson)

		if (DataFormTransferDetails.getTransferDestination().code == 'OverseaToOversea') {
			var total3or5DayMealBefore = parseFloat(total3Or5DayMeal) * 5
		} else {
			var total3or5DayMealBefore = parseFloat(total3Or5DayMeal) * 3
		}
		var total5DayMealAfter = parseFloat(total5DayMeal) * 5

		$scope.meal3Or5DaysDaysTotal = get2Float(total3or5DayMealBefore);
		$scope.meal5DaysTotal = get2Float(total5DayMealAfter);

		totalmeal = parseFloat(total3or5DayMealBefore) + parseFloat(total5DayMealAfter);
		$scope.totalMealAllowance = get2Float(totalmeal);
	};
	
	var calculateEachRoomBefore = function(userInput) {
		if (DataRates.getFromExchangeRates() != 0 && DataRates.getFromExchangeRates() != undefined) {
			var hRate = parseFloat(DataRates.getHotel3Or5Day()) * parseFloat(DataRates.getFromExchangeRates());
			if (hRate >= userInput) {
				hClaim = userInput;
			} else if (hRate < userInput) {
				hClaim = get2Float(hRate);
			} else {
				hClaim = '';
			}
			calculateHotel();
			return hClaim
		}
	}
	
	var calculateEachRoomAfter = function(userInput) {
		if (DataRates.getToExchangeRates() != 0 && DataRates.getToExchangeRates() != undefined) {
			var hRate = parseFloat(DataRates.getHotel5Day()) * parseFloat(DataRates.getToExchangeRates());
			if (hRate >= userInput) {
				hClaim = userInput;
			} else if (hRate < userInput) {
				hClaim = get2Float(hRate);
			} else {
				hClaim = '';
			}
			calculateHotel();
			return hClaim
		}
	}
	
	var calculateHotel = function () {
		var hotel311 = get2Float($scope.hotel3Or5DaysRoom1FirstDayPrice);
		var hotel321 = get2Float($scope.hotel3Or5DaysRoom2FirstDayPrice);
		var hotel331 = get2Float($scope.hotel3Or5DaysRoom3FirstDayPrice);
		var hotel31 = parseFloat(hotel311) + parseFloat(hotel321) + parseFloat(hotel331);
		$scope.hotel3Or5DaysFirstDayTotal = get2Float(hotel31);

		var hotel312 = get2Float($scope.hotel3Or5DaysRoom1SecondDayPrice);
		var hotel322 = get2Float($scope.hotel3Or5DaysRoom2SecondDayPrice);
		var hotel332 = get2Float($scope.hotel3Or5DaysRoom3SecondDayPrice);
		var hotel32 = parseFloat(hotel312) + parseFloat(hotel322) + parseFloat(hotel332);
		$scope.hotel3Or5DaysSecondDayTotal = get2Float(hotel32);

		var hotel313 = get2Float($scope.hotel3Or5DaysRoom1ThirdDayPrice);
		var hotel323 = get2Float($scope.hotel3Or5DaysRoom2ThirdDayPrice);
		var hotel333 = get2Float($scope.hotel3Or5DaysRoom3ThirdDayPrice);
		var hotel33 = parseFloat(hotel313) + parseFloat(hotel323) + parseFloat(hotel333);
		$scope.hotel3Or5DaysThirdDayTotal = get2Float(hotel33);
		
		var hotel314 = get2Float($scope.hotel3Or5DaysRoom1ForthDayPrice);
		var hotel324 = get2Float($scope.hotel3Or5DaysRoom2ForthDayPrice);
		var hotel334 = get2Float($scope.hotel3Or5DaysRoom3ForthDayPrice);
		var hotel34 = parseFloat(hotel314) + parseFloat(hotel324) + parseFloat(hotel334);
		$scope.hotel3Or5DaysForthDayTotal = get2Float(hotel34);
		
		var hotel315 = get2Float($scope.hotel3Or5DaysRoom1FifthDayPrice);
		var hotel325 = get2Float($scope.hotel3Or5DaysRoom2FifthDayPrice);
		var hotel335 = get2Float($scope.hotel3Or5DaysRoom3FifthDayPrice);
		var hotel35 = parseFloat(hotel315) + parseFloat(hotel325) + parseFloat(hotel335);
		$scope.hotel3Or5DaysFifthDayTotal = get2Float(hotel35);

		total3Or5 = parseFloat(hotel31) + parseFloat(hotel32) + parseFloat(hotel33) + parseFloat(hotel34) + parseFloat(hotel35);
		$scope.hotel3Or5DaysTotal = get2Float(total3Or5);
		
		var fromExchange = parseFloat(total3Or5) / parseFloat(DataRates.getFromExchangeRates());
		$scope.hotel3Or5DaysTotalExchange = get2Float(fromExchange);

		var hotel511 = get2Float($scope.hotel5DaysRoom1FirstDayPrice);
		var hotel521 = get2Float($scope.hotel5DaysRoom2FirstDayPrice);
		var hotel531 = get2Float($scope.hotel5DaysRoom3FirstDayPrice);
		var hotel51 = parseFloat(hotel511) + parseFloat(hotel521) + parseFloat(hotel531);
		$scope.hotel5DaysFirstDayTotal = get2Float(hotel51);

		var hotel512 = get2Float($scope.hotel5DaysRoom1SecondDayPrice);
		var hotel522 = get2Float($scope.hotel5DaysRoom2SecondDayPrice);
		var hotel532 = get2Float($scope.hotel5DaysRoom3SecondDayPrice);
		var hotel52 = parseFloat(hotel512) + parseFloat(hotel522) + parseFloat(hotel532);
		$scope.hotel5DaysSecondDayTotal = get2Float(hotel52);

		var hotel513 = get2Float($scope.hotel5DaysRoom1ThirdDayPrice);
		var hotel523 = get2Float($scope.hotel5DaysRoom2ThirdDayPrice);
		var hotel533 = get2Float($scope.hotel5DaysRoom3ThirdDayPrice);
		var hotel53 = parseFloat(hotel513) + parseFloat(hotel523) + parseFloat(hotel533);
		$scope.hotel5DaysThirdDayTotal = get2Float(hotel53);

		var hotel514 = get2Float($scope.hotel5DaysRoom1ForthDayPrice);
		var hotel524 = get2Float($scope.hotel5DaysRoom2ForthDayPrice);
		var hotel534 = get2Float($scope.hotel5DaysRoom3ForthDayPrice);
		var hotel54 = parseFloat(hotel514) + parseFloat(hotel524) + parseFloat(hotel534);
		$scope.hotel5DaysForthDayTotal = get2Float(hotel54);

		var hotel515 = get2Float($scope.hotel5DaysRoom1FifthDayPrice);
		var hotel525 = get2Float($scope.hotel5DaysRoom2FifthDayPrice);
		var hotel535 = get2Float($scope.hotel5DaysRoom3FifthDayPrice);
		var hotel55 = parseFloat(hotel515) + parseFloat(hotel525) + parseFloat(hotel535);
		$scope.hotel5DaysFifthDayTotal = get2Float(hotel55);

		var total5 = parseFloat(hotel51) + parseFloat(hotel52) + parseFloat(hotel53) + parseFloat(hotel54) + parseFloat(hotel55);
		$scope.hotel5DaysTotal = get2Float(total5);
		
		var toExchange = parseFloat(total5) / parseFloat(DataRates.getToExchangeRates());
		$scope.hotel5DaysTotalExchange = get2Float(toExchange);

		var totalHotel = parseFloat(fromExchange) + parseFloat(toExchange);
		$scope.hotelTotalAmount = get2Float(totalHotel);
	};
	
	var calculateLodging = function () {
		$scope.lodging3Or5DaysRatePerDay = DataRates.getLodging3Or5Day();
		var lodging3Or5DayNo = $scope.lodging3Or5DaysNoOfDay;
		var total3Or5Lodging = parseFloat(lodging3Or5DayNo) * parseFloat($scope.lodging3Or5DaysRatePerDay)
		$scope.lodging3Or5DaysTotal = get2Float(total3Or5Lodging);

		$scope.lodging5DaysRatePerDay = DataRates.getLodging5Day();
		var lodging5DayNo = $scope.lodging5DaysNoOfDay;
		var total5DayLodging = parseFloat(lodging5DayNo) * parseFloat($scope.lodging5DaysRatePerDay);
		$scope.lodging5DaysTotal = get2Float(total5DayLodging);

		var totalLodging = parseFloat(total3Or5Lodging) + parseFloat(total5DayLodging);
		$scope.lodgingTotalAllowance = get2Float(totalLodging);
	};

	var calculateMiscGrandTotal = function() {
		var grandTotal = 0;

		angular.forEach(getItems(), function(obj) {
			grandTotal = grandTotal + parseFloat(obj.miscAmount);
		});
		$scope.miscGrandTotal = get2Float(grandTotal);
		DataFormClaimDetails.setMiscGrandTotal($scope.miscGrandTotal);
	};
	
	var calculateClaimTotal = function() {
		var mealAllowanceTotal = 0;
		var hotelTotal = 0;
		var hotelGST = 0;
		var lodgingTotal = 0;
		var miscTotal = 0;
		var lossExchange = 0;
		var claimTotal = 0;
		var claimAmount = 0;

		mealAllowanceTotal = get2Float(DataFormClaimDetails.getMealTotalAmount());
		hotelTotal = get2Float(DataFormClaimDetails.getHotelTotalAmount());
		hotelGST = get2Float(DataFormClaimDetails.getHotelTotalGST());
		lodgingTotal = get2Float(DataFormClaimDetails.getLodgingTotalAmount());
		miscTotal = get2Float(DataFormClaimDetails.getMiscGrandTotal());

		claimTotal = parseFloat(mealAllowanceTotal) + parseFloat(hotelTotal) + parseFloat(hotelGST)
					 + parseFloat(lodgingTotal) + parseFloat(miscTotal)

		lossExchange = ((parseFloat(claimTotal) * parseFloat(3)) / 100);

		$scope.otherMiscExpensesTotal = get2Float(lossExchange);

		claimAmount = parseFloat(claimTotal) + parseFloat(lossExchange)

		$scope.claimAmount = get2Float(claimAmount);
	};
	
	$scope.initMiscCtrl = function (jsonMiscItems) {
        $scope.miscItems = [];

        setEmptyTable();
        $scope.isDBMode = false;
        if (jsonMiscItems) {
            $scope.isDBMode = true;
            getAngularObjFromJson(jsonMiscItems).forEach(function (obj) {
                $scope.addItemDB(obj);
            });
        }
		angular.element(document.getElementById('miscExpenses'))[0].disabled = true;
		angular.element(document.getElementById('miscReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('miscForeignAmount'))[0].disabled = true;
		angular.element(document.getElementById('miscAmount'))[0].disabled = true;
    };

	var setEmptyTable = function() {
        $scope.currIndex = '';
        $scope.isEmptyTable = true;
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

    var setEditMode = function(itemIndex) {
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };

    var setRow = function(objDB) {
        if (objDB) {
			DataFormClaimDetails.setMiscDate(getDateFromStr(objDB.misc_date))
			$scope.miscType = objDB.misc_type
			$scope.miscExpenses = objDB.misc_expenses
			$scope.miscReceiptNo = objDB.misc_receipt_no
			$scope.miscForeignAmount = objDB.misc_foreign_amount
			$scope.miscAmount = objDB.misc_amount
        }
        return {
            miscDate: DataFormClaimDetails.getMiscDate()
			, miscDateTxt: DataFormClaimDetails.getMiscDateTxt()
			, miscType: $scope.miscType
			, miscExpenses: $scope.miscExpenses
			, miscReceiptNo: $scope.miscReceiptNo
			, miscForeignAmount: get2Float($scope.miscForeignAmount)
			, miscAmount: get2Float($scope.miscAmount)
			, miscGrandTotal: get2Float($scope.miscGrandTotal)
        };
    };

    var setForm = function(currItem) {
        DataFormClaimDetails.setOtherMiscDate(currItem.otherMiscDate);
        $scope.miscType = currItem.miscType;
        $scope.miscExpenses = currItem.miscExpenses;
        $scope.miscReceiptNo = currItem.miscReceiptNo;
        $scope.miscForeignAmount = currItem.miscForeignAmount;
        $scope.miscAmount = get2Float(currItem.miscAmount);
        $scope.miscGrandTotal = get2Float(currItem.miscGrandTotal);
    };
	
	var getItems = function(itemIndex) {
        var obj = [];
        if (itemIndex == undefined) {
            obj = $scope.miscItems;
        }else {
            obj = $scope.miscItems[itemIndex];
        }
        return obj;
    };

    $scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var items = getItems();
        if (items.length > 0) {
            if ($scope.directIndex == items.length) {
                $scope.directIndex = items.length - 1;
            }else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            }else if (direct == 'next' && !($scope.directIndex >= items.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };
	
    $scope.addItem = function(objDB) {
        getItems().push(setRow(objDB));
        $scope.isEmptyTable = false;
        //$scope.resetForm();
        calculateMiscGrandTotal();
    };

    $scope.deleteItem = function(itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        var items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateMiscGrandTotal();
    };

    $scope.editItem = function(itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.currIndex = index;
        $scope.directIndex = index;
        var currItem = $scope.miscItems[index];
        setForm(currItem);
        $scope.isEditMode = true;
        $scope.openModal();
    };

	$scope.resetForm = function() {
		DataFormClaimDetails.reset();
        $scope.miscDate = '';
        $scope.miscType = '';
        $scope.miscExpenses = '';
        $scope.miscReceiptNo = '';
        $scope.miscForeignAmount = get2Float(0);
        $scope.miscAmount = get2Float(0);
    };
	
    $scope.openModal = function() {
        $('#miscModalForm').modal('show');
    };

	$scope.openMiscDate = function($event) {
        $scope.statusMiscDate.opened = true;
    };

	$scope.statusMiscDate = {
        opened: false
    };
	
	var changeItemVal = function(obj) {
        if ($scope.isEditMode && !$scope.isDBMode) {
            var currItem = getItems($scope.currIndex);
            if (obj == 'miscDate') {
                currItem.miscDate = DataFormClaimDetails.getMiscDate();
                currItem.miscDateTxt = DataFormClaimDetails.getMiscDateTxt();
			} else if (obj == 'miscType') {
                currItem.type = $scope.miscType;
            } else if (obj == 'miscExpenses') {
                currItem.typeOfExpenses = $scope.miscExpenses;
            } else if (obj == 'miscReceiptNo') {
                currItem.miscReceiptNo = $scope.miscReceiptNo;
			 } else if (obj == 'miscForeignAmount') {
                currItem.miscForeignAmount = $scope.miscForeignAmount;
            } else if (obj == 'miscAmount') {
                currItem.miscAmount = $scope.miscAmount;
            } else if (obj == 'miscGrandTotal') {
                currItem.miscGrandTotal = $scope.miscGrandTotal;
				calculateMiscGrandTotal();
			}
        }
		else if (obj == 'meal3Or5DaysRatePerDay') {
            DataFormClaimDetails.setMeal3Or5DaysRatePerDay($scope.meal3Or5DaysRatePerDay);
        }
		else if (obj == 'meal3Or5DaysNoOfPerson') {
            DataFormClaimDetails.setMeal3Or5DaysNoOfPerson($scope.meal3Or5DaysNoOfPerson);
        }
		else if (obj == 'meal3Or5DaysDaysTotal') {
            DataFormClaimDetails.setMeal3Or5DaysDaysTotal($scope.meal3Or5DaysDaysTotal);
        }
		else if (obj == 'meal5DaysRatePerDay') {
            DataFormClaimDetails.setMeal5DaysRatePerDay($scope.meal5DaysRatePerDay);
        }
		else if (obj == 'meal5DaysNoOfPerson') {
            DataFormClaimDetails.setMeal5DaysNoOfPerson($scope.meal5DaysNoOfPerson);
        }
		else if (obj == 'meal5DaysTotal') {
            DataFormClaimDetails.setMeal5DaysTotal($scope.meal5DaysTotal);
        }
		else if (obj == 'totalMealAllowance') {
            DataFormClaimDetails.setMealTotalAmount($scope.totalMealAllowance);
        }
		else if (obj == 'hotel3Or5DaysRoom1FirstDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1First3Or5($scope.hotel3Or5DaysRoom1FirstDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom2FirstDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2First3Or5($scope.hotel3Or5DaysRoom2FirstDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom3FirstDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3First3Or5($scope.hotel3Or5DaysRoom3FirstDayPrice);
		}
		else if (obj == 'hotel3Or5DaysFirstDayTotal') {
			DataFormClaimDetails.setHotelTotalFirst3Or5Day($scope.hotel3Or5DaysFirstDayTotal);
		}
		else if (obj == 'hotel3Or5DaysRoom1SecondDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Second3Or5($scope.hotel3Or5DaysRoom1SecondDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom2SecondDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Second3Or5($scope.hotel3Or5DaysRoom2SecondDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom3SecondDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Second3Or5($scope.hotel3Or5DaysRoom3SecondDayPrice);
		}
		else if (obj == 'hotel3Or5DaysSecondDayTotal') {
			DataFormClaimDetails.setHotelTotalSecond3Or5Day($scope.hotel3Or5DaysSecondDayTotal);
		}
		else if (obj == 'hotel3Or5DaysRoom1ThirdDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Third3Or5($scope.hotel3Or5DaysRoom1ThirdDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom2ThirdDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Third3Or5($scope.hotel3Or5DaysRoom2ThirdDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom3ThirdDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Third3Or5($scope.hotel3Or5DaysRoom3ThirdDayPrice);
		}
		else if (obj == 'hotel3Or5DaysThirdDayTotal') {
			DataFormClaimDetails.setHotelTotalThird3Or5Day($scope.hotel3Or5DaysThirdDayTotal);
		}
		else if (obj == 'hotel3Or5DaysRoom1ForthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Forth3Or5($scope.hotel3Or5DaysRoom1ForthDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom2ForthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Forth3Or5($scope.hotel3Or5DaysRoom2ForthDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom3ForthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Forth3Or5($scope.hotel3Or5DaysRoom3ForthDayPrice);
		}
		else if (obj == 'hotel3Or5DaysForthDayTotal') {
			DataFormClaimDetails.setHotelTotalForth3Or5Day($scope.hotel3Or5DaysForthDayTotal);
		}
		else if (obj == 'hotel3Or5DaysRoom1FifthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Fifth3Or5($scope.hotel3Or5DaysRoom1FifthDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom2FifthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Fifth3Or5($scope.hotel3Or5DaysRoom2FifthDayPrice);
		}
		else if (obj == 'hotel3Or5DaysRoom3FifthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Fifth3Or5($scope.hotel3Or5DaysRoom3FifthDayPrice);
		}
		else if (obj == 'hotel3Or5DaysFifthDayTotal') {
			DataFormClaimDetails.setHotelTotalFifth3Or5Day($scope.hotel3Or5DaysThirdDayTotal);
		}
		else if (obj == 'hotel3Or5DaysTotal') {
			DataFormClaimDetails.setHotelTotal3Or5Day($scope.hotel3Or5DaysTotal);
		}
		else if (obj == 'hotel3Or5DaysTotalExchange') {
			DataFormClaimDetails.setHotel3Or5DaysTotalExchange($scope.hotel3Or5DaysTotalExchange);
		}
		else if (obj == 'hotel5DaysRoom1FirstDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1First5($scope.hotel5DaysRoom1FirstDayPrice);
		}
		else if (obj == 'hotel5DaysRoom2FirstDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2First5($scope.hotel5DaysRoom2FirstDayPrice);
		}
		else if (obj == 'hotel5DaysRoom3FirstDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3First5($scope.hotel5DaysRoom3FirstDayPrice);
		}
		else if (obj == 'hotel5DaysFirstDayTotal') {
			DataFormClaimDetails.setHotelTotalFirst5Day($scope.hotel5DaysFirstDayTotal);
		}
		else if (obj == 'hotel5DaysRoom1SecondDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Second5($scope.hotel5DaysRoom1SecondDayPrice);
		}
		else if (obj == 'hotel5DaysRoom2SecondDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Second5($scope.hotel5DaysRoom2SecondDayPrice);
		}
		else if (obj == 'hotel5DaysRoom3SecondDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Second5($scope.hotel5DaysRoom3SecondDayPrice);
		}
		else if (obj == 'hotel5DaysSecondDayTotal') {
			DataFormClaimDetails.setHotelTotalSecond5Day($scope.hotel5DaysSecondDayTotal);
		}
		else if (obj == 'hotel5DaysRoom1ThirdDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Third5($scope.hotel5DaysRoom1ThirdDayPrice);
		}
		else if (obj == 'hotel5DaysRoom2ThirdDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Third5($scope.hotel5DaysRoom2ThirdDayPrice);
		}
		else if (obj == 'hotel5DaysRoom3ThirdDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Third5($scope.hotel5DaysRoom3ThirdDayPrice);
		}
		else if (obj == 'hotel5DaysThirdDayTotal') {
			DataFormClaimDetails.setHotelTotalThird5Day($scope.hotel5DaysThirdDayTotal);
		}
		else if (obj == 'hotel5DaysRoom1ForthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Forth5($scope.hotel5DaysRoom1ForthDayPrice);
		}
		else if (obj == 'hotel5DaysRoom2ForthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Forth5($scope.hotel5DaysRoom2ForthDayPrice);
		}
		else if (obj == 'hotel5DaysRoom3ForthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Forth5($scope.hotel5DaysRoom3ForthDayPrice);
		}
		else if (obj == 'hotel5DaysForthDayTotal') {
			DataFormClaimDetails.setHotelTotalForth5Day($scope.hotel5DaysForthDayTotal);
		}
		else if (obj == 'hotel5DaysRoom1FifthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Fifth5($scope.hotel5DaysRoom1FifthDayPrice);
		}
		else if (obj == 'hotel5DaysRoom2FifthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Fifth5($scope.hotel5DaysRoom2FifthDayPrice);
		}
		else if (obj == 'hotel5DaysRoom3FifthDayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Fifth5($scope.hotel5DaysRoom3FifthDayPrice);
		}
		else if (obj == 'hotel5DaysFifthDayTotal') {
			DataFormClaimDetails.setHotelTotalFifth5Day($scope.hotel5DaysFifthDayTotal);
		}
		else if (obj == 'hotel5DaysTotal') {
			DataFormClaimDetails.setHotelTotal5Day($scope.hotel5DaysTotal);
		}
		else if (obj == 'hotel5DaysTotalExchange') {
			DataFormClaimDetails.setHotel5DaysTotalExchange($scope.hotel5DaysTotalExchange);
		}
		else if (obj == 'hotelTotalAmount') {
			DataFormClaimDetails.setHotelTotalAmount($scope.hotelTotalAmount);
		}
		else if (obj == 'hotelTotalGST') {
			DataFormClaimDetails.setHotelTotalGST($scope.hotelTotalGST);
		}
		else if (obj == 'hotelReceiptNo') {
			DataFormClaimDetails.setHotelReceiptNo($scope.hotelReceiptNo);
		}
		else if (obj == 'lodging3Or5DaysAddress') {
			DataFormClaimDetails.setLodging3Or5DayAddress($scope.lodging3Or5DaysAddress);
		}
		else if (obj == 'lodging3Or5DaysNoOfDay') {
			DataFormClaimDetails.setLodging3Or5DayNoDays($scope.lodging3Or5DaysNoOfDay);
		}
		else if (obj == 'lodging3Or5DaysRatePerDay') {
			DataFormClaimDetails.setLodging3Or5DayRate($scope.lodging3Or5DaysRatePerDay);
		}
		else if (obj == 'lodging3Or5DaysTotal') {
			DataFormClaimDetails.setLodging3Or5DayTotal($scope.lodging3Or5DaysTotal);
		}
		else if (obj == 'lodging5DaysAddress') {
			DataFormClaimDetails.setLodging5DayAddress($scope.lodging5DaysAddress);
		}
		else if (obj == 'lodging5DaysNoOfDay') {
			DataFormClaimDetails.setLodging5DayNoDays($scope.lodging5DaysNoOfDay);
		}
		else if (obj == 'lodging5DaysRatePerDay') {
			DataFormClaimDetails.setLodging5DayRate($scope.lodging5DaysRatePerDay);
		}
		else if (obj == 'lodging5DaysTotal') {
			DataFormClaimDetails.setLodging5DayTotal($scope.lodging5DaysTotal);
		}
		else if (obj == 'lodgingTotalAllowance') {
			DataFormClaimDetails.setLodgingTotalAmount($scope.lodgingTotalAllowance);
		}
		else if (obj == 'otherMiscExpensesTotal') {
			DataFormClaimDetails.setOtherMiscTotalAmount($scope.otherMiscExpensesTotal);
		}
		else if (obj == 'claimAmount') {
			DataFormClaimDetails.setClaimAmount($scope.claimAmount);
			DataEndowment.setClaimAmount(DataFormClaimDetails.getClaimAmount());
        }
		else if (obj == 'endowmentAmount') {
            DataFormClaimDetails.setEndowmentAmount($scope.endowmentAmount);
        }
		else if (obj == 'netTotal') {
            DataFormClaimDetails.setNetTotal($scope.netTotal);
        }
    };

	$scope.$watch(function () { return DataFormTransferDetails.getNewEntitlement(); }, function (newValue, oldValue) {
        calculateMeal();
		changeItemVal('meal3Or5DaysRatePerDay');
		changeItemVal('meal5DaysRatePerDay');
		changeItemVal('meal3Or5DaysDaysTotal');
		changeItemVal('meal3Or5DaysNoOfPerson');
		changeItemVal('meal5DaysNoOfPerson');
		changeItemVal('meal5DaysTotal');
		changeItemVal('totalMealAllowance');
		calculateHotel();
		calculateLodging();
		calculateClaimTotal();
    });
	$scope.$watch(function () { return DataMain.getTotalDependent(); }, function (newValue, oldValue) {
        calculateMeal();
		changeItemVal('meal3Or5DaysRatePerDay');
		changeItemVal('meal5DaysRatePerDay');
		changeItemVal('meal3Or5DaysDaysTotal');
		changeItemVal('meal3Or5DaysNoOfPerson');
		changeItemVal('meal5DaysNoOfPerson');
		changeItemVal('meal5DaysTotal');
		changeItemVal('totalMealAllowance');
		calculateHotel();
		calculateLodging();
		calculateClaimTotal();
    });
	$scope.$watch(function () { return DataFormTransferDetails.getTransferDestination(); }, function (newValue, oldValue) {
        calculateMeal();
		changeItemVal('meal3Or5DaysRatePerDay');
		changeItemVal('meal5DaysRatePerDay');
		changeItemVal('meal3Or5DaysDaysTotal');
		changeItemVal('meal3Or5DaysNoOfPerson');
		changeItemVal('meal5DaysNoOfPerson');
		changeItemVal('meal5DaysTotal');
		changeItemVal('totalMealAllowance');
		calculateHotel();
		calculateLodging();
		calculateClaimTotal();
    });
	$scope.$watch(function () { return DataEndowment.getClaimAmount(); }, function (newValue, oldValue) {
        changeItemVal('claimAmount');
    });
	$scope.$watch(function () { return DataEndowment.getEndowmentAmount(); }, function (newValue, oldValue) {
        changeItemVal('endowmentAmount');
    });
	$scope.$watch(function () { return DataEndowment.getNetTotal(); }, function (newValue, oldValue) {
        changeItemVal('netTotal');
    });
	$scope.$watch('hotel3Or5DaysRoom1FirstDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom1FirstDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom1FirstDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom2FirstDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom2FirstDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom2FirstDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom3FirstDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom3FirstDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom3FirstDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysFirstDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysFirstDayTotal');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom1SecondDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom1SecondDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom1SecondDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom2SecondDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom2SecondDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom2SecondDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom3SecondDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom3SecondDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom3SecondDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysSecondDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysSecondDayTotal');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom1ThirdDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom1ThirdDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom1ThirdDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom2ThirdDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom2ThirdDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom2ThirdDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom3ThirdDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom3ThirdDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom3ThirdDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysThirdDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysThirdDayTotal');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom1ForthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom1ForthDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom1ForthDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom2ForthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom2ForthDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom2ForthDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom3ForthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom3ForthDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom3ForthDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysForthDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysForthDayTotal');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom1FifthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom1FifthDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom1FifthDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom2FifthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom2FifthDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom2FifthDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysRoom3FifthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel3Or5DaysRoom3FifthDayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotel3Or5DaysRoom3FifthDayPrice');
		}
	});
	$scope.$watch('hotel3Or5DaysFifthDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysFifthDayTotal');
		}
	});
	$scope.$watch('hotel3Or5DaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysTotal');
		}
	});
	$scope.$watch('hotel3Or5DaysTotalExchange', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel3Or5DaysTotalExchange');
		}
	});
	$scope.$watch('hotel5DaysRoom1FirstDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom1FirstDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom1FirstDayPrice');
		}
	});		
	$scope.$watch('hotel5DaysRoom2FirstDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom2FirstDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom2FirstDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom3FirstDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom3FirstDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom3FirstDayPrice');
		}
	});
	$scope.$watch('hotel5DaysFirstDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysFirstDayTotal');
		}
	});
	$scope.$watch('hotel5DaysRoom1SecondDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom1SecondDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom1SecondDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom2SecondDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom2SecondDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom2SecondDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom3SecondDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom3SecondDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom3SecondDayPrice');
		}
	});
	$scope.$watch('hotel5DaysSecondDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysSecondDayTotal');
		}
	});
	$scope.$watch('hotel5DaysRoom1ThirdDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom1ThirdDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom1ThirdDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom2ThirdDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom2ThirdDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom2ThirdDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom3ThirdDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom3ThirdDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom3ThirdDayPrice');
		}
	});
	$scope.$watch('hotel5DaysThirdDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysThirdDayTotal');
		}
	});
	$scope.$watch('hotel5DaysRoom1ForthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom1ForthDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom1ForthDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom2ForthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom2ForthDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom2ForthDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom3ForthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom3ForthDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom3ForthDayPrice');
		}
	});
	$scope.$watch('hotel5DaysForthDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysForthDayTotal');
		}
	});
	$scope.$watch('hotel5DaysRoom1FifthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom1FifthDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom1FifthDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom2FifthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom2FifthDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom2FifthDayPrice');
		}
	});
	$scope.$watch('hotel5DaysRoom3FifthDayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotel5DaysRoom3FifthDayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotel5DaysRoom3FifthDayPrice');
		}
	});
	$scope.$watch('hotel5DaysFifthDayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysFifthDayTotal');
		}
	});
	$scope.$watch('hotel5DaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysTotal');
		}
	});
	$scope.$watch('hotel5DaysTotalExchange', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotel5DaysTotalExchange');
		}
	});
	$scope.$watch('hotelTotalAmount', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotelTotalAmount');
			calculateClaimTotal();
		}
	});
	$scope.$watch('hotelTotalGST', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotelTotalGST');
			calculateClaimTotal();
		}
	});
	$scope.$watch('hotelReceiptNo', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotelReceiptNo');
		}
	});

	$scope.$watch('lodging3Or5DaysAddress', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodging3Or5DaysAddress');
		}
	});
	$scope.$watch('lodging3Or5DaysNoOfDay',function() {
		var lodging3db4 = $scope.lodging3Or5DaysNoOfDay;
		if (lodging3db4 <= 3) {
			calculateLodging();
		} else {$scope.lodging3Or5DaysNoOfDay = 0;}
		changeItemVal('lodging3Or5DaysNoOfDay');
	});
	$scope.$watch('lodging3Or5DaysRatePerDay', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodging3Or5DaysRatePerDay');
		}
	});
	$scope.$watch('lodging3Or5DaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodging3Or5DaysTotal');
		}
	});
	$scope.$watch('lodging5DaysAddress', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodging5DaysAddress');
		}
	});
	$scope.$watch('lodging5DaysNoOfDay',function() {
		var lodging5daf = $scope.lodging5DaysNoOfDay;
		if (lodging5daf <= 5) {
			calculateLodging();
		} else {$scope.lodging5DaysNoOfDay = 0;}
		changeItemVal('lodging5DaysNoOfDay');
	});
	$scope.$watch('lodging5DaysRatePerDay', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodging5DaysRatePerDay');
		}
	});
	$scope.$watch('lodging5DaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodging5DaysTotal');
		}
	});
	$scope.$watch('lodgingTotalAllowance', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodgingTotalAllowance');
			calculateClaimTotal();
		}
	});
	$scope.$watch('miscDate', function(newValue, oldValue) {
        if (newValue != oldValue) {
            DataFormClaimDetails.setMiscDate(newValue);
        }
    });
	$scope.$watch('miscType', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('miscType');
			type = $scope.miscType.code
			if (type == 'Local') {
				angular.element(document.getElementById('miscExpenses'))[0].disabled = false;
				angular.element(document.getElementById('miscReceiptNo'))[0].disabled = false;
				angular.element(document.getElementById('miscForeignAmount'))[0].disabled = true;
				angular.element(document.getElementById('miscAmount'))[0].disabled = false;
			} else if (type == 'Oversea') {
				angular.element(document.getElementById('miscExpenses'))[0].disabled = false;
				angular.element(document.getElementById('miscReceiptNo'))[0].disabled = false;
				angular.element(document.getElementById('miscForeignAmount'))[0].disabled = false;
				angular.element(document.getElementById('miscAmount'))[0].disabled = true;
			}
		}
	});
	$scope.$watch('miscExpenses', function(newValue, oldValue) {
        if (newValue != oldValue) {
			changeItemVal('miscExpenses');
		}
	});
	$scope.$watch('miscReceiptNo', function(newValue, oldValue) {
        if (newValue != oldValue) {
			changeItemVal('miscReceiptNo');
		}
	});
	$scope.$watch('miscForeignAmount', function(newValue, oldValue) {
        if (newValue != oldValue) {
			if (DataFormTransferDetails.getTransferDestination().code == 'MalaysiaToOversea') {
				to = parseFloat($scope.miscForeignAmount) * parseFloat(DataRates.getToExchangeRates());
				$scope.miscAmount = get2Float(to);
			} else if (DataFormTransferDetails.getTransferDestination().code == 'OverseaToMalaysia') {
				from = parseFloat($scope.miscForeignAmount) * parseFloat(DataRates.getFromExchangeRates());
				$scope.miscAmount = get2Float(from);
			} else if (DataFormTransferDetails.getTransferDestination().code == 'OverseaToOversea') {
				//from = parseFloat($scope.miscForeignAmount) * parseFloat(DataRates.getFromExchangeRates());
				//to = parseFloat(test) * parseFloat(DataRates.getToExchangeRates());
				//$scope.miscAmount = get2Float(from);
			}
			changeItemVal('miscForeignAmount');
		}
	});
	$scope.$watch('miscAmount', function(newValue, oldValue) {
        if (newValue != oldValue) {
			changeItemVal('miscAmount');
		}
	});
	$scope.$watch('miscGrandTotal', function(newValue, oldValue) {
        if (newValue != oldValue) {
			changeItemVal('miscGrandTotal');
			calculateClaimTotal();
		}
	});
	$scope.$watch('miscItems', function() {
        DataFormClaimDetails.setMiscItems($scope.miscItems);
    }, true);
	$scope.$watch('otherMiscExpensesTotal', function(newValue, oldValue){
		if (newValue != oldValue) {
			changeItemVal('otherMiscExpensesTotal');
		}
	});
	$scope.$watch('claimAmount', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('claimAmount');
			$scope.claimAmount = DataFormClaimDetails.getClaimAmount()
		}
	});
});

uiBootstrapApp.controller('SummaryCtrl', function($http, $scope, DataFundType, DataEndowment, DataFormClaimDetails) {
    $scope.masterExpensesSummary = [];
    $scope.claimGrandTotal = get2Float(0);
    $scope.claimNettTotal = get2Float(0);

	var MEAL			= {codeMap: 'MEAL'};
	var ACCOMMODATION  	= {codeMap: 'ACCOMMODATION'};
	var GST 			= {codeMap: 'GST'};
	var MISC  			= {codeMap: 'MISC'};

	var HOTEL   = {codeMap: ''};
    var LODGING	= {codeMap: ''};

    ACCOMMODATION.itemsMix = [HOTEL, LODGING];
	
    $scope.setExpenses = [MEAL, ACCOMMODATION, GST, MISC];

    var loadSummary = function() {
		
		var claimFundType = '';
		var claimGrandTotal = 0;
		var claimNettTotal = 0;
		
		claimFundType = DataFundType.getFundType();
		claimGrandTotal = DataFormClaimDetails.getClaimAmount();
		claimNettTotal = DataEndowment.getNetTotal();
		
		$scope.claimFundType = claimFundType;
		$scope.claimGrandTotal = get2Float(claimGrandTotal);
		$scope.claimNettTotal = get2Float(claimNettTotal);

		HOTEL.items 	= DataFormClaimDetails.getHotelTotalAmount();
        LODGING.items 	= DataFormClaimDetails.getLodgingTotalAmount();
		
        $scope.setExpenses[0].items 	= DataFormClaimDetails.getMealTotalAmount();
		$scope.setExpenses[1].itemsMix	= [HOTEL, LODGING];
		$scope.setExpenses[2].items 	= DataFormClaimDetails.getHotelTotalGST();
		$scope.setExpenses[3].items 	= DataFormClaimDetails.getMiscGrandTotal();

        $scope.masterExpensesSummary = $scope.expenses;

        $scope.masterExpensesSummary.forEach(function (obj) {
            obj.show = false;
            obj.amount = get2Float(0);

            $scope.setExpenses.forEach(function (objSet) {
				if (obj.type_code == objSet.codeMap) {
					var amount = get2Float(0);
					if (objSet.itemsMix) {
						objSet.itemsMix.forEach(function (objMix) {
							if (objMix.items) {
								amount = parseFloat(amount) + parseFloat(objMix.items);
							}
						});
					} else if (objSet.items) {
						if (objSet.items) {
							amount = objSet.items;
						}
					}
					angular.merge(obj, {show: true, amount: get2Float(amount)});
				}
            });
        });
    };
	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {
			loadSummary();
		}
	});
	$scope.$watch(function () { return DataFormClaimDetails.getClaimAmount(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {
			loadSummary();
		}
	});
	$scope.$watch(function () { return DataEndowment.getNetTotal(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {
			loadSummary();
		}
	});
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataMain', 'DataRates', 'DataEndowment', 'DataFormTransferDetails', 'DataFormClaimDetails', function ($scope, $uibModal, $http, $window, DataMain, DataRates, DataEndowment, DataFormTransferDetails, DataFormClaimDetails) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);
		form_data = {
			btn_mode:btnMode,
			transferGradeAfter:DataFormTransferDetails.getTransferGradeAfter().code,
			transferDate:DataFormTransferDetails.getTransferDate(),
			transferDateTxt:DataFormTransferDetails.getTransferDateTxt(),
			fundType:DataFormTransferDetails.getTransferOverseaFundType().code,
			projectCode:DataFormTransferDetails.getTransferOverseaProjectCode(),
			maritalStatus:DataFormTransferDetails.getMaritalStatus().status,
			transferDestination:DataFormTransferDetails.getTransferDestination().code,

			spouseList:DataFormTransferDetails.getSpouseList(),
			childrenList:DataFormTransferDetails.getChildrenList(),

			fromDate:DataFormTransferDetails.getFromDate(),
			fromDateTxt:DataFormTransferDetails.getFromDateTxt(),
			fromCountry:DataFormTransferDetails.getFromCountryAfter().name,
			fromCurrencyType:DataFormTransferDetails.getFromCurrencyType(),
			fromBNMDate:DataFormTransferDetails.getFromBNMDate(),
			fromExchangeRate:DataRates.getFromExchangeRates(),
			toDate:DataFormTransferDetails.getToDate(),
			toDateTxt:DataFormTransferDetails.getToDateTxt(),
			toCountry:DataFormTransferDetails.getToCountryAfter().name,
			toCurrencyType:DataFormTransferDetails.getToCurrencyType(),
			toBNMDate:DataFormTransferDetails.getToBNMDate(),
			toExchangeRate:DataRates.getToExchangeRates(),

			oldOfficeLine1:DataFormTransferDetails.getOldOfficeLine1(),
			oldOfficeLine2:DataFormTransferDetails.getOldOfficeLine2(),
			oldOfficeLine3:DataFormTransferDetails.getOldOfficeLine3(),
			oldOfficeLine4:DataFormTransferDetails.getOldOfficeLine4(),
			newOfficeLine1:DataFormTransferDetails.getNewOfficeLine1(),
			newOfficeLine2:DataFormTransferDetails.getNewOfficeLine2(),
			newOfficeLine3:DataFormTransferDetails.getNewOfficeLine3(),
			newOfficeLine4:DataFormTransferDetails.getNewOfficeLine4(),
			oldHomeLine1:DataFormTransferDetails.getOldHomeLine1(),
			oldHomeLine2:DataFormTransferDetails.getOldHomeLine2(),
			oldHomeLine3:DataFormTransferDetails.getOldHomeLine3(),
			oldHomeLine4:DataFormTransferDetails.getOldHomeLine4(),
			newHomeLine1:DataFormTransferDetails.getNewHomeLine1(),
			newHomeLine2:DataFormTransferDetails.getNewHomeLine2(),
			newHomeLine3:DataFormTransferDetails.getNewHomeLine3(),
			newHomeLine4:DataFormTransferDetails.getNewHomeLine4(),

			mealRateBefore:DataRates.getMeal3Or5Day(),
			mealRateAfter:DataRates.getMeal5Day(),
			mealNoOfPersonBefore:DataFormClaimDetails.getMeal3Or5DaysNoOfPerson(),
			mealNoOfPersonAfter:DataFormClaimDetails.getMeal5DaysNoOfPerson(),
			mealTotalBefore:DataFormClaimDetails.getMeal3Or5DaysDaysTotal(),
			mealTotalAfter:DataFormClaimDetails.getMeal5DaysTotal(),
			mealTotalAmount:DataFormClaimDetails.getMealTotalAmount(),

			hotelRateBefore:DataRates.getHotel3Or5Day(),
			hotelRateAfter:DataRates.getHotel5Day(),
			roomPrice1First3or5:DataFormClaimDetails.getHotelRoomPrice1First3Or5(),
			roomPrice2First3or5:DataFormClaimDetails.getHotelRoomPrice2First3Or5(),
			roomPrice3First3or5:DataFormClaimDetails.getHotelRoomPrice3First3Or5(),
			hotelTotalFirst3or5:DataFormClaimDetails.getHotelTotalFirst3Or5Day(),
			roomPrice1Second3or5:DataFormClaimDetails.getHotelRoomPrice1Second3Or5(),
			roomPrice2Second3or5:DataFormClaimDetails.getHotelRoomPrice2Second3Or5(),
			roomPrice3Second3or5:DataFormClaimDetails.getHotelRoomPrice3Second3Or5(),
			hotelTotalSecond3or5:DataFormClaimDetails.getHotelTotalSecond3Or5Day(),
			roomPrice1Third3or5:DataFormClaimDetails.getHotelRoomPrice1Third3Or5(),
			roomPrice2Third3or5:DataFormClaimDetails.getHotelRoomPrice2Third3Or5(),
			roomPrice3Third3or5:DataFormClaimDetails.getHotelRoomPrice3Third3Or5(),
			hotelTotalThird3or5:DataFormClaimDetails.getHotelTotalThird3Or5Day(),
			roomPrice1Forth3or5:DataFormClaimDetails.getHotelRoomPrice1Forth3Or5(),
			roomPrice2Forth3or5:DataFormClaimDetails.getHotelRoomPrice2Forth3Or5(),
			roomPrice3Forth3or5:DataFormClaimDetails.getHotelRoomPrice3Forth3Or5(),
			hotelTotalForth3or5:DataFormClaimDetails.getHotelTotalForth3Or5Day(),
			roomPrice1Fifth3or5:DataFormClaimDetails.getHotelRoomPrice1Fifth3Or5(),
			roomPrice2Fifth3or5:DataFormClaimDetails.getHotelRoomPrice2Fifth3Or5(),
			roomPrice3Fifth3or5:DataFormClaimDetails.getHotelRoomPrice3Fifth3Or5(),
			hotelTotalFifth3or5:DataFormClaimDetails.getHotelTotalFifth3Or5Day(),
			hotelTotalAmount3or5:DataFormClaimDetails.getHotelTotal3Or5Day(),
			hotelTotalForeignAmount3or5:DataFormClaimDetails.getHotel3Or5DaysTotalExchange(),
			roomPrice1First5:DataFormClaimDetails.getHotelRoomPrice1First5(),
			roomPrice2First5:DataFormClaimDetails.getHotelRoomPrice2First5(),
			roomPrice3First5:DataFormClaimDetails.getHotelRoomPrice3First5(),
			hotelTotalFirst5:DataFormClaimDetails.getHotelTotalFirst5Day(),
			roomPrice1Second5:DataFormClaimDetails.getHotelRoomPrice1Second5(),
			roomPrice2Second5:DataFormClaimDetails.getHotelRoomPrice2Second5(),
			roomPrice3Second5:DataFormClaimDetails.getHotelRoomPrice3Second5(),
			hotelTotalSecond5:DataFormClaimDetails.getHotelTotalSecond5Day(),
			roomPrice1Third5:DataFormClaimDetails.getHotelRoomPrice1Third5(),
			roomPrice2Third5:DataFormClaimDetails.getHotelRoomPrice2Third5(),
			roomPrice3Third5:DataFormClaimDetails.getHotelRoomPrice3Third5(),
			hotelTotalThird5:DataFormClaimDetails.getHotelTotalThird5Day(),
			roomPrice1Forth5:DataFormClaimDetails.getHotelRoomPrice1Forth5(),
			roomPrice2Forth5:DataFormClaimDetails.getHotelRoomPrice2Forth5(),
			roomPrice3Forth5:DataFormClaimDetails.getHotelRoomPrice3Forth5(),
			hotelTotalForth5:DataFormClaimDetails.getHotelTotalForth5Day(),
			roomPrice1Fifth5:DataFormClaimDetails.getHotelRoomPrice1Fifth5(),
			roomPrice2Fifth5:DataFormClaimDetails.getHotelRoomPrice2Fifth5(),
			roomPrice3Fifth5:DataFormClaimDetails.getHotelRoomPrice3Fifth5(),
			hotelTotalFifth5:DataFormClaimDetails.getHotelTotalFifth5Day(),
			hotelTotalAmount5:DataFormClaimDetails.getHotelTotal5Day(),
			hotelTotalForeignAmount5:DataFormClaimDetails.getHotel5DaysTotalExchange(),
			hotelTotalAmount:DataFormClaimDetails.getHotelTotalAmount(),
			hotelTotalGST:DataFormClaimDetails.getHotelTotalGST(),
			hotelReceiptNo:DataFormClaimDetails.getHotelReceiptNo(),

			lodgingRateBefore:DataRates.getLodging3Or5Day(),
			lodgingRateAfter:DataRates.getLodging5Day(),
			lodgingAddressBefore:DataFormClaimDetails.getLodging3Or5DayAddress(),
			lodgingNoOfDaysBefore:DataFormClaimDetails.getLodging3Or5DayNoDays(),
			lodgingTotalBefore:DataFormClaimDetails.getLodging3Or5DayTotal(),
			lodgingAddressAfter:DataFormClaimDetails.getLodging5DayAddress(),
			lodgingNoOfDaysAfter:DataFormClaimDetails.getLodging5DayNoDays(),
			lodgingTotalAfter:DataFormClaimDetails.getLodging5DayTotal(),
			lodgingTotalAmount:DataFormClaimDetails.getLodgingTotalAmount(),

			miscItems: DataFormClaimDetails.getMiscItems(),

			otherMiscTotalAmount: DataFormClaimDetails.getOtherMiscTotalAmount(),

			claimAmount: DataEndowment.getClaimAmount(),
			endowmentAmount: DataEndowment.getEndowmentAmount(),
			netTotal: DataEndowment.getNetTotal(),
			
			//supportingDocs: DataFormDoc.getDBItems(),

			claimant_no:DataMain.getClaimantNo(),
			draft_id:DataMain.getDraftID()
		}

		if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

				if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                }
				else
				{
					$http({
						url: '',
						method: 'POST',
						data: form_data
					})
					.success(function (data, status, headers, config) {
                        enable_claim_controls();
						var submit_success_url = data.submit_success_url;

						if (btnMode == 'submit') {
							$window.location.href = submit_success_url;
						} else if (btnMode == 'save_draft') {
							$scope.initSubmitCtrl(data.draft_id);
							$uibModal.open({
								animation: $scope.animationsEnabled,
								templateUrl: 'SaveSuccess.html',
								controller: 'ModalInstanceInfoCtrl',
								size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
								resolve: {
								  data: function () {
									return data;
								  }
								}
							});
                            $window.location.href = submit_success_url;
						}
					}).error(function () {
                        enable_claim_controls();
                    });
				}
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id){
		$scope.draft_id = draft_id;
		DataMain.setDraftID(draft_id);
	};
}]);

uiBootstrapApp.factory('DataMain', function ($filter) {
	var data = {
			error_validation : '',
			claimant_no : '',
			salary_grade : '',
			basic_salary : '',
			total_spouse : 0,
			totalDependent : 0,
			draft_id : '',
			claim_id : ''
		};
	return {
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (obj) {
            data.error_validation = obj;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
		getSalaryGrade: function () {
            return data.salary_grade;
        },
        setSalaryGrade: function (obj) {
            data.salary_grade = obj;
        },
		getBasicSalary: function () {
            return data.basic_salary;
        },
        setBasicSalary: function (obj) {
            data.basic_salary = obj;
        },
		getTotalSpouse: function () {
            return data.total_spouse;
        },
        setTotalSpouse: function (obj) {
            data.total_spouse = obj;
        },
		getTotalDependent: function () {
            return data.totalDependent;
        },
        setTotalDependent: function (obj) {
            data.totalDependent = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        }
	};
});

uiBootstrapApp.factory('DataRates', function () {
	var data = {
		fromExchangeRates : 0,
		toExchangeRates : 0,
		meal3Or5Day : 0,
		hotel3Or5Day : 0,
		lodging3Or5Day : 0,
		meal5Day : 0,
		hotel5Day : 0,
		lodging5Day : 0,
	};

	return {
		getFromExchangeRates : function() {
			return data.fromExchangeRates;
		},
		setFromExchangeRates : function(obj) {
			return data.fromExchangeRates = obj;
		},
		getToExchangeRates : function() {
			return data.toExchangeRates;
		},
		setToExchangeRates : function(obj) {
			return data.toExchangeRates = obj;
		},
		getMeal3Or5Day : function() {
			return data.meal3Or5Day;
		},
		setMeal3Or5Day : function(obj) {
			return data.meal3Or5Day = obj;
		},
		getHotel3Or5Day : function() {
			return data.hotel3Or5Day;
		},
		setHotel3Or5Day : function(obj) {
			return data.hotel3Or5Day = obj;
		},
		getLodging3Or5Day : function() {
			return data.lodging3Or5Day;
		},
		setLodging3Or5Day : function(obj) {
			return data.lodging3Or5Day = obj;
		},
		getMeal5Day : function() {
			return data.meal5Day;
		},
		setMeal5Day : function(obj) {
			return data.meal5Day = obj;
		},
		getHotel5Day : function() {
			return data.hotel5Day;
		},
		setHotel5Day : function(obj) {
			return data.hotel5Day = obj;
		},
		getLodging5Day : function() {
			return data.lodging5Day;
		},
		setLodging5Day : function(obj) {
			return data.lodging5Day = obj;
		},
	};
});

uiBootstrapApp.factory('DataFormTransferDetails', function ($filter) {

    var data = {
		transferOverseaFundType : '',
		transferOverseaProjectCode : '',
		transferGradeAfter : '',
		newEntitlement : [],
		transferDate : '',
		transferDateTxt : '-',
		transferDestination : '',
		maritalStatus : '',
		spouseList : [],
		childrenList : [],
		fromDate : '',
		fromDateTxt : '-',
		fromCountryAfter : '',
		fromCurrencyType : '',
		fromBNMDate : '',
		fromExchangeRate : 0,
		toDate : '',
		toDateTxt : '-',
		toCountryAfter : '',
		toCurrencyType : '',
		toBNMDate : '',
		toExchangeRate : 0,
		oldOfficeLine1 : '',
		oldOfficeLine2 : '',
		oldOfficeLine3 : '',
		oldOfficeLine4 : '',
		newOfficeLine1 : '',
		newOfficeLine2 : '',
		newOfficeLine3 : '',
		newOfficeLine4 : '',
		oldHomeLine1 : '',
		oldHomeLine2 : '',
		oldHomeLine3 : '',
		oldHomeLine4 : '',
		newHomeLine1 : '',
		newHomeLine2 : '',
		newHomeLine3 : '',
		newHomeLine4 : '',
    };

    return {
        getTransferOverseaFundType: function () {
            return data.transferOverseaFundType;
        },
        setTransferOverseaFundType: function (obj) {
            data.transferOverseaFundType = obj;
        },
		getTransferOverseaProjectCode: function () {
            return data.transferOverseaProjectCode;
        },
        setTransferOverseaProjectCode: function (obj) {
            data.transferOverseaProjectCode = obj;
        },
		getTransferGradeAfter: function () {
            return data.transferGradeAfter;
        },
        setTransferGradeAfter: function (obj) {
            data.transferGradeAfter = obj;
        },
		getNewEntitlement: function () {
            return data.newEntitlement;
        },
        setNewEntitlement: function (obj) {
            data.newEntitlement = obj;
        },
		getTransferDate: function () {
            return data.transferDate;
        },
        setTransferDate: function (obj) {
            data.transferDate = obj;
        },
		getTransferDateTxt: function () {
            return data.transferDateTxt;
        },
        setTransferDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.transferDate = obj;
            data.transferDateTxt = minDate;
        },
		getTransferDestination: function () {
            return data.transferDestination;
        },
        setTransferDestination: function (obj) {
            data.transferDestination = obj;
        },
        getMaritalStatus: function () {
            return data.maritalStatus;
        },
        setMaritalStatus: function (obj) {
            data.maritalStatus = obj;
        },
		getSpouseList: function () {
            return data.spouseList;
        },
        setSpouseList: function (obj) {
            data.spouseList = obj;
        },
		getChildrenList: function () {
            return data.childrenList;
        },
        setChildrenList: function (obj) {
            data.childrenList = obj;
        },		
		getFromDate: function () {
            return data.fromDate;
        },
        setFromDate: function (obj) {
            data.fromDate = obj;
        },
		getFromDateTxt: function () {
            return data.fromDateTxt;
        },
        setFromDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.fromDate = obj;
            data.fromDateTxt = minDate;
        },
		getFromCountryAfter: function () {
            return data.fromCountryAfter;
        },
        setFromCountryAfter: function (obj) {
            data.fromCountryAfter = obj;
        },
		getFromCurrencyType: function () {
            return data.fromCurrencyType;
        },
        setFromCurrencyType: function (obj) {
            data.fromCurrencyType = obj;
        },
		getFromBNMDate: function () {
            return data.fromBNMDate;
        },
        setFromBNMDate: function (obj) {
            data.fromBNMDate = obj;
        },
		getFromExchangeRate: function () {
            return data.fromExchangeRate;
        },
        setFromExchangeRate: function (obj) {
            data.fromExchangeRate = obj;
        },
		getToDate: function () {
            return data.toDate;
        },
        setToDate: function (obj) {
            data.toDate = obj;
        },
		getToDateTxt: function () {
            return data.toDateTxt;
        },
        setToDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.toDate = obj;
            data.toDateTxt = minDate;
        },
		getToCountryAfter: function () {
            return data.toCountryAfter;
        },
        setToCountryAfter: function (obj) {
            data.toCountryAfter = obj;
        },
		getToCurrencyType: function () {
            return data.toCurrencyType;
        },
        setToCurrencyType: function (obj) {
            data.toCurrencyType = obj;
        },
		getToBNMDate: function () {
            return data.toBNMDate;
        },
        setToBNMDate: function (obj) {
            data.toBNMDate = obj;
        },
		getToExchangeRate: function () {
            return data.toExchangeRate;
        },
        setToExchangeRate: function (obj) {
            data.toExchangeRate = obj;
        },
		getOldOfficeLine1: function () {
            return data.oldOfficeLine1;
        },
        setOldOfficeLine1: function (obj) {
            data.oldOfficeLine1 = obj;
        },
		getOldOfficeLine2: function () {
            return data.oldOfficeLine2;
        },
        setOldOfficeLine2: function (obj) {
            data.oldOfficeLine2 = obj;
        },
		getOldOfficeLine3: function () {
            return data.oldOfficeLine3;
        },
        setOldOfficeLine3: function (obj) {
            data.oldOfficeLine3 = obj;
        },
		getOldOfficeLine4: function () {
            return data.oldOfficeLine4;
        },
        setOldOfficeLine4: function (obj) {
            data.oldOfficeLine4 = obj;
        },
		getNewOfficeLine1: function () {
            return data.newOfficeLine1;
        },
        setNewOfficeLine1: function (obj) {
            data.newOfficeLine1 = obj;
        },
		getNewOfficeLine2: function () {
            return data.newOfficeLine2;
        },
        setNewOfficeLine2: function (obj) {
            data.newOfficeLine2 = obj;
        },
		getNewOfficeLine3: function () {
            return data.newOfficeLine3;
        },
        setNewOfficeLine3: function (obj) {
            data.newOfficeLine3 = obj;
        },
		getNewOfficeLine4: function () {
            return data.newOfficeLine4;
        },
        setNewOfficeLine4: function (obj) {
            data.newOfficeLine4 = obj;
        },
		getOldHomeLine1: function () {
            return data.oldHomeLine1;
        },
        setOldHomeLine1: function (obj) {
            data.oldHomeLine1 = obj;
        },
		getOldHomeLine2: function () {
            return data.oldHomeLine2;
        },
        setOldHomeLine2: function (obj) {
            data.oldHomeLine2 = obj;
        },
		getOldHomeLine3: function () {
            return data.oldHomeLine3;
        },
        setOldHomeLine3: function (obj) {
            data.oldHomeLine3 = obj;
        },
		getOldHomeLine4: function () {
            return data.oldHomeLine4;
        },
        setOldHomeLine4: function (obj) {
            data.oldHomeLine4 = obj;
        },
		getNewHomeLine1: function () {
            return data.newHomeLine1;
        },
        setNewHomeLine1: function (obj) {
            data.newHomeLine1 = obj;
        },
		getNewHomeLine2: function () {
            return data.newHomeLine2;
        },
        setNewHomeLine2: function (obj) {
            data.newHomeLine2 = obj;
        },
		getNewHomeLine3: function () {
            return data.newHomeLine3;
        },
        setNewHomeLine3: function (obj) {
            data.newHomeLine3 = obj;
        },
		getNewHomeLine4: function () {
            return data.newHomeLine4;
        },
        setNewHomeLine4: function (obj) {
            data.newHomeLine4 = obj;
        },
    };
});

uiBootstrapApp.factory('DataFormClaimDetails', function ($filter) {

    var data = {
		miscItems : [],

		dependent : 0,
		meal3Or5DaysRatePerDay : 0,
		meal3Or5DaysNoOfPerson : 0,
		meal3Or5DaysDaysTotal : 0,
		meal5DaysRatePerDay : 0,
		meal5DaysNoOfPerson : 0,
		meal5DaysTotal : 0,
		mealTotalAmount : 0,

		hotel3Day : 0,
		hotel5Day : 0,
		hotelRoomPrice1First3Or5 : 0,
		hotelRoomPrice2First3Or5 : 0,
		hotelRoomPrice3First3Or5 : 0,
		hotelTotalFirst3Or5Day : 0,
		hotelRoomPrice1Second3Or5 : 0,
		hotelRoomPrice2Second3Or5 : 0,
		hotelRoomPrice3Second3Or5 : 0,
		hotelTotalSecond3Or5Day : 0,
		hotelRoomPrice1Third3Or5 : 0,
		hotelRoomPrice2Third3Or5 : 0,
		hotelRoomPrice3Third3Or5 : 0,
		hotelTotalThird3Or5Day : 0,
		hotelRoomPrice1Forth3Or5 : 0,
		hotelRoomPrice2Forth3Or5 : 0,
		hotelRoomPrice3Forth3Or5 : 0,
		hotelTotalForth3Or5Day : 0,
		hotelRoomPrice1Fifth3Or5 : 0,
		hotelRoomPrice2Fifth3Or5 : 0,
		hotelRoomPrice3Fifth3Or5 : 0,
		hotelTotalFifth3Or5Day : 0,
		hotelTotal3Or5Day : 0,
		hotel3Or5DaysTotalExchange : 0,
		hotelRoomPrice1First5 : 0,
		hotelRoomPrice2First5 : 0,
		hotelRoomPrice3First5 : 0,
		hotelTotalFirst5Day : 0,
		hotelRoomPrice1Second5 : 0,
		hotelRoomPrice2Second5 : 0,
		hotelRoomPrice3Second5 : 0,
		hotelTotalSecond5Day : 0,
		hotelRoomPrice1Third5 : 0,
		hotelRoomPrice2Third5 : 0,
		hotelRoomPrice3Third5 : 0,
		hotelTotalThird5Day : 0,
		hotelRoomPrice1Forth5 : 0,
		hotelRoomPrice2Forth5 : 0,
		hotelRoomPrice3Forth5 : 0,
		hotelTotalForth5Day : 0,
		hotelRoomPrice1Fifth5 : 0,
		hotelRoomPrice2Fifth5 : 0,
		hotelRoomPrice3Fifth5 : 0,
		hotelTotalFifth5Day : 0,
		hotelTotal5Day : 0,
		hotel5DaysTotalExchange : 0,
		hotelTotalAmount : 0,
		hotelTotalGST : 0,
		hotelReceiptNo : 0,

		lodging3Or5Day : 0,
		lodging5Day : 0,
		lodging3Or5DayAddress : '',
		lodging3Or5DayNoDays : 0,
		lodging3Or5DayRates : 0,
		lodging3Or5DayTotal : 0,
		lodging5DayAddress : '',
		lodging5DayNoDays : 0,
		lodging5DayRates : 0,
		lodging5DayTotal : 0,
		lodgingTotalAmount : 0,

		miscDate : '',
		miscDateTxt : '-',
		miscType : '',
		miscExpenses : '',
		miscReceiptNo : '',
		miscForeignAmount : 0,
		miscAmount : 0,
		miscGrandTotal : 0,

		otherMiscTotalAmount : 0,
		
		claimAmount : 0,
		endowmentAmount : 0,
		netTotal : 0,
    };

    return {
		getMiscItems: function () {
            return data.miscItems;
        },
        setMiscItems: function (obj) {
            data.miscItems = obj;
        },
		getDependent: function () {
            return data.dependent;
        },
        setDependent: function (obj) {
            data.dependent = obj;
        },
		getMeal3Or5DaysRatePerDay: function () {
            return data.meal3Or5DaysRatePerDay;
        },
        setMeal3Or5DaysRatePerDay: function (obj) {
            data.meal3Or5DaysRatePerDay = obj;
        },
		getMeal3Or5DaysNoOfPerson: function () {
            return data.meal3Or5DaysNoOfPerson;
        },
        setMeal3Or5DaysNoOfPerson: function (obj) {
            data.meal3Or5DaysNoOfPerson = obj;
        },
		getMeal3Or5DaysDaysTotal: function () {
            return data.meal3Or5DaysDaysTotal;
        },
        setMeal3Or5DaysDaysTotal: function (obj) {
            data.meal3Or5DaysDaysTotal = obj;
        },
		getMeal5DaysRatePerDay: function () {
            return data.meal5DaysRatePerDay;
        },
        setMeal5DaysRatePerDay: function (obj) {
            data.meal5DaysRatePerDay = obj;
        },
		getMeal5DaysNoOfPerson: function () {
            return data.meal5DaysNoOfPerson;
        },
        setMeal5DaysNoOfPerson: function (obj) {
            data.meal5DaysNoOfPerson = obj;
        },
		getMeal5DaysTotal: function () {
            return data.meal5DaysTotal;
        },
        setMeal5DaysTotal: function (obj) {
            data.meal5DaysTotal = obj;
        },
		getMealTotalAmount: function () {
            return data.mealTotalAmount;
        },
        setMealTotalAmount: function (obj) {
            data.mealTotalAmount = obj;
        },
		getHotelRoomPrice1First3Or5: function () {
            return data.hotelRoomPrice1First3Or5;
        },
        setHotelRoomPrice1First3Or5: function (obj) {
            data.hotelRoomPrice1First3Or5 = obj;
        },
		getHotelRoomPrice2First3Or5: function () {
            return data.hotelRoomPrice2First3Or5;
        },
        setHotelRoomPrice2First3Or5: function (obj) {
            data.hotelRoomPrice2First3Or5 = obj;
        },
		getHotelRoomPrice3First3Or5: function () {
            return data.hotelRoomPrice3First3Or5;
        },
        setHotelRoomPrice3First3Or5: function (obj) {
            data.hotelRoomPrice3First3Or5 = obj;
        },
		getHotelTotalFirst3Or5Day: function () {
            return data.hotelTotalFirst3Or5Day;
        },
        setHotelTotalFirst3Or5Day: function (obj) {
            data.hotelTotalFirst3Or5Day = obj;
        },
		getHotelRoomPrice1Second3Or5: function () {
            return data.hotelRoomPrice1Second3Or5;
        },
        setHotelRoomPrice1Second3Or5: function (obj) {
            data.hotelRoomPrice1Second3Or5 = obj;
        },
		getHotelRoomPrice2Second3Or5: function () {
            return data.hotelRoomPrice2Second3Or5;
        },
        setHotelRoomPrice2Second3Or5: function (obj) {
            data.hotelRoomPrice2Second3Or5 = obj;
        },
		getHotelRoomPrice3Second3Or5: function () {
            return data.hotelRoomPrice3Second3Or5;
        },
        setHotelRoomPrice3Second3Or5: function (obj) {
            data.hotelRoomPrice3Second3Or5 = obj;
        },
		getHotelTotalSecond3Or5Day: function () {
            return data.hotelTotalSecond3Or5Day;
        },
        setHotelTotalSecond3Or5Day: function (obj) {
            data.hotelTotalSecond3Or5Day = obj;
        },
		getHotelRoomPrice1Third3Or5: function () {
            return data.hotelRoomPrice1Third3Or5;
        },
        setHotelRoomPrice1Third3Or5: function (obj) {
            data.hotelRoomPrice1Third3Or5 = obj;
        },
		getHotelRoomPrice2Third3Or5: function () {
            return data.hotelRoomPrice2Third3Or5;
        },
        setHotelRoomPrice2Third3Or5: function (obj) {
            data.hotelRoomPrice2Third3Or5 = obj;
        },
		getHotelRoomPrice3Third3Or5: function () {
            return data.hotelRoomPrice3Third3Or5;
        },
        setHotelRoomPrice3Third3Or5: function (obj) {
            data.hotelRoomPrice3Third3Or5 = obj;
        },
		getHotelTotalThird3Or5Day: function () {
            return data.hotelTotalThird3Or5Day;
        },
        setHotelTotalThird3Or5Day: function (obj) {
            data.hotelTotalThird3Or5Day = obj;
        },
		getHotelRoomPrice1Forth3Or5: function () {
            return data.hotelRoomPrice1Forth3Or5;
        },
        setHotelRoomPrice1Forth3Or5: function (obj) {
            data.hotelRoomPrice1Forth3Or5 = obj;
        },
		getHotelRoomPrice2Forth3Or5: function () {
            return data.hotelRoomPrice2Forth3Or5;
        },
        setHotelRoomPrice2Forth3Or5: function (obj) {
            data.hotelRoomPrice2Forth3Or5 = obj;
        },
		getHotelRoomPrice3Forth3Or5: function () {
            return data.hotelRoomPrice3Forth3Or5;
        },
        setHotelRoomPrice3Forth3Or5: function (obj) {
            data.hotelRoomPrice3Forth3Or5 = obj;
        },
		getHotelTotalForth3Or5Day: function () {
            return data.hotelTotalForth3Or5Day;
        },
        setHotelTotalForth3Or5Day: function (obj) {
            data.hotelTotalForth3Or5Day = obj;
        },
		getHotelRoomPrice1Fifth3Or5: function () {
            return data.hotelRoomPrice1Fifth3Or5;
        },
        setHotelRoomPrice1Fifth3Or5: function (obj) {
            data.hotelRoomPrice1Fifth3Or5 = obj;
        },
		getHotelRoomPrice2Fifth3Or5: function () {
            return data.hotelRoomPrice2Fifth3Or5;
        },
        setHotelRoomPrice2Fifth3Or5: function (obj) {
            data.hotelRoomPrice2Fifth3Or5 = obj;
        },
		getHotelRoomPrice3Fifth3Or5: function () {
            return data.hotelRoomPrice3Fifth3Or5;
        },
        setHotelRoomPrice3Fifth3Or5: function (obj) {
            data.hotelRoomPrice3Fifth3Or5 = obj;
        },
		getHotelTotalFifth3Or5Day: function () {
            return data.hotelTotalFifth3Or5Day;
        },
        setHotelTotalFifth3Or5Day: function (obj) {
            data.hotelTotalFifth3Or5Day = obj;
        },
		getHotelTotal3Or5Day: function () {
            return data.hotelTotal3Or5Day;
        },
        setHotelTotal3Or5Day: function (obj) {
            data.hotelTotal3Or5Day = obj;
        },
		getHotel3Or5DaysTotalExchange: function () {
            return data.hotel3Or5DaysTotalExchange;
        },
        setHotel3Or5DaysTotalExchange: function (obj) {
            data.hotel3Or5DaysTotalExchange = obj;
        },
		getHotelRoomPrice1First5: function () {
            return data.hotelRoomPrice1First5;
        },
        setHotelRoomPrice1First5: function (obj) {
            data.hotelRoomPrice1First5 = obj;
        },
		getHotelRoomPrice2First5: function () {
            return data.hotelRoomPrice2First5;
        },
        setHotelRoomPrice2First5: function (obj) {
            data.hotelRoomPrice2First5 = obj;
        },
		getHotelRoomPrice3First5: function () {
            return data.hotelRoomPrice3First5;
        },
        setHotelRoomPrice3First5: function (obj) {
            data.hotelRoomPrice3First5 = obj;
        },
		getHotelTotalFirst5Day: function () {
            return data.hotelTotalFirst5Day;
        },
        setHotelTotalFirst5Day: function (obj) {
            data.hotelTotalFirst5Day = obj;
        },
		getHotelRoomPrice1Second5: function () {
            return data.hotelRoomPrice1Second5;
        },
        setHotelRoomPrice1Second5: function (obj) {
            data.hotelRoomPrice1Second5 = obj;
        },
		getHotelRoomPrice2Second5: function () {
            return data.hotelRoomPrice2Second5;
        },
        setHotelRoomPrice2Second5: function (obj) {
            data.hotelRoomPrice2Second5 = obj;
        },
		getHotelRoomPrice3Second5: function () {
            return data.hotelRoomPrice3Second5;
        },
        setHotelRoomPrice3Second5: function (obj) {
            data.hotelRoomPrice3Second5 = obj;
        },
		getHotelTotalSecond5Day: function () {
            return data.hotelTotalSecond5Day;
        },
        setHotelTotalSecond5Day: function (obj) {
            data.hotelTotalSecond5Day = obj;
        },
		getHotelRoomPrice1Third5: function () {
            return data.hotelRoomPrice1Third5;
        },
        setHotelRoomPrice1Third5: function (obj) {
            data.hotelRoomPrice1Third5 = obj;
        },
		getHotelRoomPrice2Third5: function () {
            return data.hotelRoomPrice2Third5;
        },
        setHotelRoomPrice2Third5: function (obj) {
            data.hotelRoomPrice2Third5 = obj;
        },
		getHotelRoomPrice3Third5: function () {
            return data.hotelRoomPrice3Third5;
        },
        setHotelRoomPrice3Third5: function (obj) {
            data.hotelRoomPrice3Third5 = obj;
        },
		getHotelTotalThird5Day: function () {
            return data.hotelTotalThird5Day;
        },
        setHotelTotalThird5Day: function (obj) {
            data.hotelTotalThird5Day = obj;
        },
		getHotelRoomPrice1Forth5: function () {
            return data.hotelRoomPrice1Forth5;
        },
        setHotelRoomPrice1Forth5: function (obj) {
            data.hotelRoomPrice1Forth5 = obj;
        },
		getHotelRoomPrice2Forth5: function () {
            return data.hotelRoomPrice2Forth5;
        },
        setHotelRoomPrice2Forth5: function (obj) {
            data.hotelRoomPrice2Forth5 = obj;
        },
		getHotelRoomPrice3Forth5: function () {
            return data.hotelRoomPrice3Forth5;
        },
        setHotelRoomPrice3Forth5: function (obj) {
            data.hotelRoomPrice3Forth5 = obj;
        },
		getHotelTotalForth5Day: function () {
            return data.hotelTotalForth5Day;
        },
        setHotelTotalForth5Day: function (obj) {
            data.hotelTotalForth5Day = obj;
        },
		getHotelRoomPrice1Fifth5: function () {
            return data.hotelRoomPrice1Fifth5;
        },
        setHotelRoomPrice1Fifth5: function (obj) {
            data.hotelRoomPrice1Fifth5 = obj;
        },
		getHotelRoomPrice2Fifth5: function () {
            return data.hotelRoomPrice2Fifth5;
        },
        setHotelRoomPrice2Fifth5: function (obj) {
            data.hotelRoomPrice2Fifth5 = obj;
        },
		getHotelRoomPrice3Fifth5: function () {
            return data.hotelRoomPrice3Fifth5;
        },
        setHotelRoomPrice3Fifth5: function (obj) {
            data.hotelRoomPrice3Fifth5 = obj;
        },
		getHotelTotalFifth5Day: function () {
            return data.hotelTotalFifth5Day;
        },
        setHotelTotalFifth5Day: function (obj) {
            data.hotelTotalFifth5Day = obj;
        },
		getHotelTotal5Day: function () {
            return data.hotelTotal5Day;
        },
        setHotelTotal5Day: function (obj) {
            data.hotelTotal5Day = obj;
        },
		getHotel5DaysTotalExchange: function () {
            return data.hotel5DaysTotalExchange;
        },
        setHotel5DaysTotalExchange: function (obj) {
            data.hotel5DaysTotalExchange = obj;
        },
		getHotelTotalAmount: function () {
            return data.hotelTotalAmount;
        },
        setHotelTotalAmount: function (obj) {
            data.hotelTotalAmount = obj;
        },
		getHotelTotalGST: function () {
            return data.hotelTotalGST;
        },
        setHotelTotalGST: function (obj) {
            data.hotelTotalGST = obj;
        },
		getHotelReceiptNo: function () {
            return data.hotelReceiptNo;
        },
        setHotelReceiptNo: function (obj) {
            data.hotelReceiptNo = obj;
        },
		getLodging3Or5DayAddress: function () {
            return data.lodging3Or5DayAddress;
        },
        setLodging3Or5DayAddress: function (obj) {
            data.lodging3Or5DayAddress = obj;
        },
		getLodging3Or5DayNoDays: function () {
            return data.lodging3Or5DayNoDays;
        },
        setLodging3Or5DayNoDays: function (obj) {
            data.lodging3Or5DayNoDays = obj;
        },
		getLodging3Or5DayRate: function () {
            return data.lodging3Or5DayRate;
        },
        setLodging3Or5DayRate: function (obj) {
            data.lodging3Or5DayRate = obj;
        },
		getLodging3Or5DayTotal: function () {
            return data.lodging3Or5DayTotal;
        },
        setLodging3Or5DayTotal: function (obj) {
            data.lodging3Or5DayTotal = obj;
        },
		getLodging5DayAddress: function () {
            return data.lodging5DayAddress;
        },
        setLodging5DayAddress: function (obj) {
            data.lodging5DayAddress = obj;
        },
		getLodging5DayNoDays: function () {
            return data.lodging5DayNoDays;
        },
        setLodging5DayNoDays: function (obj) {
            data.lodging5DayNoDays = obj;
        },
		getLodging5DayRate: function () {
            return data.lodging5DayRate;
        },
        setLodging5DayRate: function (obj) {
            data.lodging5DayRate = obj;
        },
		getLodging5DayTotal: function () {
            return data.lodging5DayTotal;
        },
        setLodging5DayTotal: function (obj) {
            data.lodging5DayTotal = obj;
        },
		getLodgingTotalAmount: function () {
            return data.lodgingTotalAmount;
        },
        setLodgingTotalAmount: function (obj) {
            data.lodgingTotalAmount = obj;
        },
		getMiscDate: function () {
            return data.miscDate;
        },
		getMiscDateTxt: function () {
            return data.miscDateTxt;
        },
        setMiscDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.miscDate = obj;
            data.miscDateTxt = minDate;
        },
		getMiscType: function () {
            return data.miscType;
        },
        setMiscType: function (obj) {
            data.miscType = obj;
        },
		getMiscExpenses: function () {
            return data.miscExpenses;
        },
        setMiscExpenses: function (obj) {
            data.miscExpenses = obj;
        },
		getMiscReceiptNo: function () {
            return data.miscReceiptNo;
        },
        setMiscReceiptNo: function (obj) {
            data.miscReceiptNo = obj;
        },
		getMiscForeignAmount: function () {
            return data.miscForeignAmount;
        },
        setMiscForeignAmount: function (obj) {
            data.miscForeignAmount = obj;
        },
		getMiscAmount: function () {
            return data.miscAmount;
        },
        setMiscAmount: function (obj) {
            data.miscAmount = obj;
        },
		getMiscGrandTotal: function () {
            return data.miscGrandTotal;
        },
        setMiscGrandTotal: function (obj) {
            data.miscGrandTotal = obj;
        },
		getOtherMiscTotalAmount: function () {
            return data.otherMiscTotalAmount;
        },
        setOtherMiscTotalAmount: function (obj) {
            data.otherMiscTotalAmount = obj;
        },
		getClaimAmount: function () {
            return data.claimAmount;
        },
        setClaimAmount: function (obj) {
            data.claimAmount = obj;
        },
		getEndowmentAmount: function () {
            return data.endowmentAmount;
        },
        setEndowmentAmount: function (obj) {
            data.endowmentAmount = obj;
        },
		getNetTotal: function () {
            return data.netTotal;
        },
        setNetTotal: function (obj) {
            data.netTotal = obj;
        },
		reset: function () {

        },
    };
});