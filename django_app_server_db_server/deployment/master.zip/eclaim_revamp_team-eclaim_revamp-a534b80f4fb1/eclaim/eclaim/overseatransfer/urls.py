from django.conf.urls import patterns, url

from .views import OverseaTransferIndexView, OverseaTransferDetailView, OverseaTransferDraftView

urlpatterns = patterns('',
    url(r'^$', OverseaTransferIndexView.as_view(), name='overseatransfer_index'),
    url(r'^detail/$', OverseaTransferDetailView.as_view(), name='overseatransfer_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', OverseaTransferDraftView.as_view(), name='overseatransfer_draft')
)