/*
 ********************************************
 *      CREATED BY  :   MOHAMED FAUZI       *
 *      DATE        :   MAY 2016          *
 ********************************************
*/
console.log('Local Transfer Advance JS Loaded!!!');

uiBootstrapApp.controller('LocalTransferAdvanceCtrl', function ($scope, $http) {
	/**
    *************************
    *   Start : Accordion   *
    *************************
   */
    $scope.oneAtATime = false;
    
    $scope.panels = [
        {name: 'panel1', open: false},
        {name: 'panel2', open: true},
        {name: 'panel3', open: false},
        {name: 'panel4', open: false},
        {name: 'panel5', open: false},
        {name: 'panel6', open: false}
    ];
    $scope.toggleAllPanels = function() {
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    $scope.closeAllPanels = function() {
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** End : Accordion */
	
	if (PK) {  // detail view
        $http({
            url: API_URL+'local-transfer-advances/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, 3, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, 3, 1);
    }

    var claim_api_url = API_URL+'local-transfer-advances/';
    init_workflow($scope, $http, 'localtransferadvance', 'LocalTransferAdvance', PK, claim_api_url, WF_TEMPLATE);

    $scope.popup_query_pdf = function () {
        window.open($scope.url_query_pdf, '', 'width=800,height=600,left=200,resizable=0');
    }
});

uiBootstrapApp.controller('AdvanceDetailsCtrl', function ($scope, $filter, $http, $q, DataClaimant, DataFundType, DataLookup, DataFormAdvanceDetails) {

    $scope.initAdvanceDetailsCtrl = function (jsonTypeOfAdvanceList, jsonRegionList, jsonTypeOfExpensesList, draftID) {
		
		$scope.pageSize = 5;
        $scope.currentPage = 1;
		
		$scope.dateFormats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MM-yyyy'];
		$scope.standardDateOptions = {
			formatYear: 'yy',
			startingDay: 1
		};
		$scope.formatDate = $scope.dateFormats[0];

		$scope.dutyEntitlement = [];
		$scope.courseEntitlement = [];
		$scope.claimantGrade = [];
		$scope.typeOfAdvanceList = [];
		$scope.regionList = [];
		$scope.typeOfExpensesList = [];
        $scope.advanceDetailsItems = [];
		setEmptyTable();
		
		getAngularObjFromJson(jsonTypeOfAdvanceList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.typeOfAdvanceList.push({code:code, description:description});
		});
		getAngularObjFromJson(jsonRegionList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.regionList.push({code:code, description:description});
		});
		getAngularObjFromJson(jsonTypeOfExpensesList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.typeOfExpensesList.push({code:code, description:description});
		});

		if (draftID || PK) {
			if (draftID) { // draft view
				$http({
					url: API_URL+'local-transfer-advance-drafts/'+draftID+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					if (data.advance_details.advance_details[0]) {
						dataSet = data.advance_details

						$scope.transferDate = getDateStr($filter, dataSet.advance_details[0].transfer_date)
						dataSet.child_items.forEach(function(obj) {
							$scope.addItem(obj);
						});
					};
				});
			} else if (PK) { // detail view
				$http({
					url: API_URL+'local-transfer-advances/'+PK+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					if (data.advance_details.advance_details[0]) {
						dataSet = data.advance_details

						$scope.transferDate = getDateStr($filter, dataSet.advance_details[0].transfer_date)
						dataSet.child_items.forEach(function(obj) {
							$scope.addItem(obj);
						});
					};
				});
			}
        }
    };
	
	var promises = {
		claimant_grade: $http({
				url: API_URL+'salary-grades/',
				method: 'GET'
			})
			.success(function (data, status, headers, config) {
				$scope.claimantGrade = data.results;
			}),
		duty_entitlement: $http({
				url: API_URL+'offduty-trip-allowance/',
				method: 'GET',
				params: {'staffNo': DataClaimant.getStaffNo()}
			})
			.success(function (data, status, headers, config) {
				$scope.dutyEntitlement = data.results;
			}),
		course_entitlement: $http({
				url: API_URL+'course-trip-allowance/',
				method: 'GET',
				params: {'staffNo': DataClaimant.getStaffNo()}
			})
			.success(function (data, status, headers, config) {
				$scope.courseEntitlement = data.results;
			}),
	};

	$scope.getDataByCode = function (code, dropdown) {
		var objSelect = $filter("filter")(dropdown, { code: code });
		return objSelect[0];
	};

	var disableEditMode = function() {
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

	var setEmptyTable = function() {
        $scope.currIndex = '';
        $scope.isEmptyTable = true;
        disableEditMode();
    };
	
	var setEditMode = function(itemIndex) {
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };

	var getItems = function(index) {
        var obj = [];
        obj = $scope.advanceDetailsItems;
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

	$scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var currItem = '';
        var list = getItems();
        if (list.length > 0) {
            if ($scope.directIndex == list.length) {
                $scope.directIndex = list.length - 1;
            } else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            } else if (direct == 'next' && !($scope.directIndex >= list.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

	$scope.addItem = function(objDB) {
		if (objDB) {
			var items = getItems();
			items.push(setRow(objDB));
			$scope.isEmptyTable = false;
			resetForm();
			calculateAdvanceTotal();
		} else {
			var totaltest = 0;
			angular.forEach(getItems(), function(obj) {
				totaltest = totaltest + getNumber(obj.allowanceNoOfDays);
			});
			totaltest =  totaltest + getNumber($scope.allowanceNoOfDays);
			if (totaltest <= 8) {
				var items = getItems();
				items.push(setRow(objDB));
				$scope.isEmptyTable = false;
				resetForm();
				calculateAdvanceTotal();
				$scope.testing = '';
			} else {
				$scope.testing = 'Only entitled for 8 days allowance!!!';
			}
		}
    };
	
    $scope.deleteItem = function(itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
		var items = [];
        items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateAdvanceTotal();
    };

    $scope.editItem = function(itemIndex) {
		var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal('editForm');
        setForm(getItems(index));
    };

	$scope.openModal = function(mode) {
        $('#localTransferAdvanceModalForm').modal('show');
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        }else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };
	
    var setRow = function(objDB) {
        if (objDB) {
			DataFundType.setFundType(DataFundType.getFundTypeByCode(objDB.fund_type_id));
			$scope.fromDate = getDateFromStr(objDB.from_date);
			$scope.toDate = getDateFromStr(objDB.to_date);
			$scope.gradeBefore = $scope.getDataByCode(objDB.grade_before, $scope.claimantGrade);
			$scope.gradeAfter = $scope.getDataByCode(objDB.grade_after, $scope.claimantGrade);
			$scope.typeOfAdvance = $scope.getDataByCode(objDB.type_of_advance, $scope.typeOfAdvanceList);
			$scope.destination = $scope.getDataByCode(objDB.destination, $scope.regionList);
			$scope.place = objDB.place;
			$scope.noOfDependant = objDB.no_of_dependant;
			$scope.typeOfExpenses = $scope.getDataByCode(objDB.type_of_expenses, $scope.typeOfExpensesList);
			$scope.allowanceNoOfDays = objDB.allowance_no_of_days;
			$scope.hotelRate = objDB.hotel_rate;
			$scope.lodgingRate = objDB.lodging_rate;
			$scope.mealRate = objDB.meal_rate;
			$scope.totalHotelAllowance = objDB.total_hotel_allowance;
			$scope.totalLodgingAllowance = objDB.total_lodging_allowance;
			$scope.totalMealAllowance = objDB.total_meal_allowance;
			$scope.grandTotal = objDB.grand_total;
			$scope.totalAdvanceAllowed = objDB.total_advance_allowed;
        }
        return {
            fundType: DataFundType.getFundType()
            , projectCode: DataLookup.getProjectCode()
            , fromDate: $scope.fromDate
			, fromDateTxt: getDateStr($filter, $scope.fromDate)
			, toDate: $scope.toDate
			, toDateTxt: getDateStr($filter, $scope.toDate)
			, gradeBefore: $scope.gradeBefore
			, gradeAfter: $scope.gradeAfter 
			, typeOfAdvance: $scope.typeOfAdvance 
			, destination: $scope.destination
			, place: $scope.place
			, noOfDependant: $scope.noOfDependant
			, typeOfExpenses: $scope.typeOfExpenses
			, allowanceNoOfDays: $scope.allowanceNoOfDays
			, hotelRate: get2Float($scope.hotelRate)
			, lodgingRate: get2Float($scope.lodgingRate)
			, mealRate: get2Float($scope.mealRate)
			, totalHotelAllowance: $scope.totalHotelAllowance
			, totalLodgingAllowance: $scope.totalLodgingAllowance
			, totalMealAllowance: $scope.totalMealAllowance
			, grandTotal: $scope.grandTotal
			, totalAdvanceAllowed: $scope.totalAdvanceAllowed
        };
    };

    var setForm = function(currItem) {
        DataFundType.setFundType(currItem.fundType);
        DataLookup.setProjectCode(currItem.projectCode);
        $scope.fromDate = currItem.fromDate;
		$scope.toDate = currItem.toDate;
		$scope.gradeBefore = currItem.gradeBefore;
		$scope.gradeAfter = currItem.gradeAfter;
		$scope.typeOfAdvance = currItem.typeOfAdvance
		$scope.destination = currItem.destination
		$scope.place = currItem.place
		$scope.noOfDependant = currItem.noOfDependant
		$scope.typeOfExpenses = currItem.typeOfExpenses
		$scope.allowanceNoOfDays = currItem.allowanceNoOfDays
		$scope.hotelRate = currItem.hotelRate
		$scope.lodgingRate = currItem.lodgingRate
		$scope.mealRate = currItem.mealRate
    }
	
	var resetForm = function(){
        DataFormAdvanceDetails.reset();
		DataFundType.setFundType({});
        DataLookup.setProjectCode('');
        $scope.fromDate = '';
        $scope.toDate = '';
		$scope.gradeBefore = $scope.getDataByCode(DataClaimant.getSalaryGrade(), $scope.claimantGrade);
		$scope.gradeAfter = [];
        $scope.typeOfAdvance = [];
        $scope.destination = [];
        $scope.place = '';
		$scope.noOfDependant = '';
        $scope.typeOfExpenses = [];
		$scope.allowanceNoOfDays = 0;
		$scope.hotelRate = get2Float(0);
        $scope.lodgingRate = get2Float(0);
        $scope.mealRate = get2Float(0);
    };

	var calculateDiffDays = function () {
		var intDays = 0;
		if (angular.isDate($scope.fromDate) && angular.isDate($scope.toDate)) {
			intDays = getNightDiffDate($scope.fromDate, $scope.toDate) + 1;
		}
		$scope.allowanceNoOfDays = getNumber(intDays);
		changeItemVal('allowanceNoOfDays');
	};
	
	$scope.openTransferDate = function($event) {
        $scope.statusTransferDate.opened = true;
    };
	$scope.openFromDate = function($event) {
        $scope.statusFromDate.opened = true;
    };
	$scope.openToDate = function($event) {
        $scope.statusToDate.opened = true;
    };
	$scope.statusTransferDate = {
        opened: false
    };
	$scope.statusFromDate = {
        opened: false
    };
	$scope.statusToDate = {
        opened: false
    };

	var changeItemVal = function(obj) {
		 if ($scope.isEditMode) {
            var currItem = getItems($scope.currIndex);
            if (currItem) {
				if (obj == 'fromDate') {
					currItem.fromDate = $scope.fromDate
					currItem.fromDateTxt = getDateStr($filter, $scope.fromDate);
				} else if (obj == 'toDate') {
					currItem.toDate = $scope.toDate
					currItem.toDateTxt = getDateStr($filter, $scope.toDate);
				} else if (obj == 'gradeBefore') {
					currItem.gradeBefore = $scope.gradeBefore;
				} else if (obj == 'gradeAfter') {
					currItem.gradeAfter = $scope.gradeAfter;
				} else if (obj == 'typeOfAdvance') {
					currItem.typeOfAdvance = $scope.typeOfAdvance;
				} else if (obj == 'destination') {
					currItem.destination = $scope.destination;
				} else if (obj == 'place') {
					currItem.place = $scope.place;
				} else if (obj == 'noOfDependant') {
					currItem.noOfDependant = $scope.noOfDependant;
				} else if (obj == 'typeOfExpenses') {
					currItem.typeOfExpenses = $scope.typeOfExpenses;
				} else if (obj == 'allowanceNoOfDays') {
					currItem.allowanceNoOfDays = $scope.allowanceNoOfDays;
				} else if (obj == 'hotelRate') {
					currItem.hotelRate = get2Float($scope.hotelRate);
				} else if (obj == 'lodgingRate') {
					currItem.lodgingRate = get2Float($scope.lodgingRate);
				} else if (obj == 'mealRate') {
					currItem.mealRate = get2Float($scope.mealRate);
				}
			}
		} else if (obj == 'dutyEntitlement') {
			if ($scope.dutyEntitlement) {
				$scope.dutyEntitlement.forEach(function (obj) {
					if (obj.region == 'West') {
						$scope.westDutyMeal = obj.meal;
						$scope.westDutyHotel = obj.hotel;
						$scope.westDutyLodging = obj.lodging;
					} else if (obj.region == 'East') {
						$scope.eastDutyMeal = obj.meal;
						$scope.eastDutyHotel = obj.hotel;
						$scope.eastDutyLodging = obj.lodging;
					}
				})
			} else {
				$scope.westDutyMeal = get2Float(0);
				$scope.westDutyHotel = get2Float(0);
				$scope.westDutyLodging = get2Float(0);
				$scope.eastDutyMeal = get2Float(0);
				$scope.eastDutyHotel = get2Float(0);
				$scope.eastDutyLodging = get2Float(0);
			}
		} else if (obj == 'courseEntitlement') {
			if ($scope.courseEntitlement) {
				$scope.courseEntitlement.forEach(function (obj) {
					if (obj.region == 'West') {
						$scope.westCourseMeal = obj.meal;
						$scope.westCourseHotel = obj.hotel;
						$scope.westCourseLodging = obj.lodging;
					} else if (obj.region == 'East') {
						$scope.eastCourseMeal = obj.meal;
						$scope.eastCourseHotel = obj.hotel;
						$scope.eastCourseLodging = obj.lodging;
					}
				})
			} else {
				$scope.westCourseMeal = get2Float(0);
				$scope.westCourseHotel = get2Float(0);
				$scope.westCourseLodging = get2Float(0);
				$scope.eastCourseMeal = get2Float(0);
				$scope.eastCourseHotel = get2Float(0);
				$scope.eastCourseLodging = get2Float(0);
			}
		} else if (obj == 'transferDate') {
			DataFormAdvanceDetails.setTransferDate($scope.transferDate);
			DataFormAdvanceDetails.setTransferDateTxt(getDateStr($filter, $scope.transferDate));
		}
	};

	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
		changeItemVal('localAdvanceFundType');
	});
	$scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
		changeItemVal('localAdvanceProjectCode');
	});
	$scope.$watch('transferDate', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('transferDate');}
	});
	$scope.$watch('fromDate', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('fromDate');
			calculateDiffDays();
			setTriggerRateFunction();
		}
	});
	$scope.$watch('toDate', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('toDate');
			calculateDiffDays();
			setTriggerRateFunction();
		}
	});
	$scope.$watch('typeOfAdvance', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('typeOfAdvance');
			setTriggerRateFunction();
		}
	});
	$scope.$watch('destination', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('destination');
			setTriggerRateFunction();
		}
	});
	$scope.$watch('place', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('place');
		}
	});
	$scope.$watch('typeOfExpenses', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('typeOfExpenses');
			setTriggerRateFunction();
		}
	});
	$scope.$watch('noOfDependant', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('noOfDependant');
			setTriggerRateFunction();
		}
	});
	$scope.$watch('advanceDetailsItems', function() {
        DataFormAdvanceDetails.setAdvanceDetailsItems($scope.advanceDetailsItems);
    }, true);

	$scope.$watch('dutyEntitlement', function(newValue, oldValue) {
		changeItemVal('dutyEntitlement');
	});
	$scope.$watch('courseEntitlement', function(newValue, oldValue) {
		changeItemVal('courseEntitlement');
	});
	
	var setTriggerRateFunction = function() {
		if ($scope.typeOfAdvance != undefined && $scope.destination != undefined && $scope.typeOfExpenses != undefined) {
			setRateByTypeAndRegion($scope.typeOfAdvance.code, $scope.destination.code);
			setRateByTypeExpenses($scope.typeOfExpenses.code);
			calculateEachRate();
			changeItemVal('hotelRate');
			changeItemVal('lodgingRate');
			changeItemVal('mealRate');
			calculateAdvanceTotal();
		}
	}

	var setRateByTypeAndRegion = function(typeAdvance, typeRegion) {
		if (typeAdvance == 'OfficialDuty') {
			if (typeRegion == 'West') {
				$scope.hotelRate = $scope.westDutyHotel;
				$scope.lodgingRate = $scope.westDutyLodging;
				$scope.mealRate = $scope.westDutyMeal;
			} else {
				$scope.hotelRate = $scope.eastDutyHotel;
				$scope.lodgingRate = $scope.eastDutyLodging;
				$scope.mealRate = $scope.eastDutyMeal;
			}
		} else if (typeAdvance == 'Course') {
			if (typeRegion == 'West') {
				$scope.hotelRate = $scope.westCourseHotel;
				$scope.lodgingRate = $scope.westCourseLodging;
				$scope.mealRate = $scope.westCourseMeal;
			} else {
				$scope.hotelRate = $scope.eastCourseHotel;
				$scope.lodgingRate = $scope.eastCourseLodging;
				$scope.mealRate = $scope.eastCourseMeal;
			}
		}
	};
	
	var setRateByTypeExpenses = function(typeExpenses) {
		if (typeExpenses == 'MealHotel') {
			$scope.hotelEntitle = $scope.hotelRate;
			$scope.lodgingEntitle = get2Float(0);
			$scope.mealEntitle = $scope.mealRate;
		} else if (typeExpenses == 'MealLodging') {
			$scope.hotelEntitle = get2Float(0);
			$scope.lodgingEntitle = $scope.lodgingRate;
			$scope.mealEntitle = $scope.mealRate;
		} else if (typeExpenses == 'MealOnly') {
			$scope.hotelEntitle = get2Float(0);
			$scope.lodgingEntitle = get2Float(0);
			$scope.mealEntitle = $scope.mealRate;
		} else if (typeExpenses == 'HotelOnly') {
			$scope.hotelEntitle = $scope.hotelRate;
			$scope.lodgingEntitle = get2Float(0);
			$scope.mealEntitle = get2Float(0);
		} else if (typeExpenses == 'LodgingOnly') {
			$scope.hotelEntitle = get2Float(0);
			$scope.lodgingEntitle = $scope.lodgingRate;
			$scope.mealEntitle = get2Float(0);
		}
	};

	var calculateEachRate = function() {
		var totalHotel = 0;
		var totalLodging = 0;
		var totalMeal = 0;

		totalHotel = parseFloat($scope.hotelEntitle) * parseFloat($scope.allowanceNoOfDays) * parseFloat($scope.noOfDependant);
		totalLodging = parseFloat($scope.lodgingEntitle) * parseFloat($scope.allowanceNoOfDays) * parseFloat($scope.noOfDependant);
		totalMeal = parseFloat($scope.mealEntitle) * parseFloat($scope.allowanceNoOfDays) * parseFloat($scope.noOfDependant);

		$scope.hotelRate = get2Float(totalHotel);
		$scope.lodgingRate = get2Float(totalLodging);
		$scope.mealRate = get2Float(totalMeal);
	};

	var calculateAdvanceTotal = function() {
		var totalHotelAllowance = 0;
		var totalLodgingAllowance = 0;
		var totalMealAllowance = 0;
		var grandTotal = 0;
		var totalAdvanceAllowed = 0;

		angular.forEach(getItems(), function(obj) {
			totalHotelAllowance = totalHotelAllowance + parseFloat(obj.hotelRate);
			totalLodgingAllowance = totalLodgingAllowance + parseFloat(obj.lodgingRate);
			totalMealAllowance = totalMealAllowance + parseFloat(obj.mealRate);
			grandTotal = grandTotal + parseFloat(obj.hotelRate) + parseFloat(obj.lodgingRate) + parseFloat(obj.mealRate);
		});

		totalAdvanceAllowed = (parseFloat(grandTotal) * 90) / 100;

		$scope.totalHotelAllowance = get2Float(totalHotelAllowance);
		$scope.totalLodgingAllowance = get2Float(totalLodgingAllowance);
		$scope.totalMealAllowance = get2Float(totalMealAllowance);
		$scope.grandTotal = get2Float(grandTotal);
		$scope.totalAdvanceAllowed = get2Float(totalAdvanceAllowed);
		
		DataFormAdvanceDetails.setTotalHotelAllowance($scope.totalHotelAllowance);
		DataFormAdvanceDetails.setTotalLodgingAllowance($scope.totalLodgingAllowance);
		DataFormAdvanceDetails.setTotalMealAllowance($scope.totalMealAllowance);
		DataFormAdvanceDetails.setGrandTotal($scope.grandTotal);
		DataFormAdvanceDetails.setTotalAdvanceAllowed($scope.totalAdvanceAllowed);
	};
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataClaimant', 'DataFormAdvanceDetails', function ($scope, $uibModal, $http, $window, DataClaimant, DataFormAdvanceDetails) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);

		form_data = {
			btn_mode:btnMode,
			advanceDetailsItems: DataFormAdvanceDetails.getAdvanceDetailsItems(),
			transferDate:DataFormAdvanceDetails.getTransferDate(),
			totalHotelAllowance:DataFormAdvanceDetails.getTotalHotelAllowance(),
			totalLodgingAllowance:DataFormAdvanceDetails.getTotalLodgingAllowance(),
			totalMealAllowance:DataFormAdvanceDetails.getTotalMealAllowance(),
			grandTotal:DataFormAdvanceDetails.getGrandTotal(),
			totalAdvanceAllowed:DataFormAdvanceDetails.getTotalAdvanceAllowed(),
			claimant_no:DataClaimant.getStaffNo(),
			draft_id:DataFormAdvanceDetails.getDraftID()
		}

		if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

				if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                }
				else
				{
					$http({
						url: '',
						method: 'POST',
						data: form_data
					})
					.success(function (data, status, headers, config) {
                        enable_claim_controls();
						var submit_success_url = data.submit_success_url;

						if (btnMode == 'submit') {
							$window.location.href = submit_success_url;
						} else if (btnMode == 'save_draft') {
							$scope.initSubmitCtrl(data.draft_id);
							$uibModal.open({
								animation: $scope.animationsEnabled,
								templateUrl: 'SaveSuccess.html',
								controller: 'ModalInstanceInfoCtrl',
								size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
								resolve: {
								  data: function () {
									return data;
								  }
								}
							});
                            $window.location.href = submit_success_url;
						}
					}).error(function () {
                        enable_claim_controls();
                    });
				}
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id){
		$scope.draft_id = draft_id;
		DataFormAdvanceDetails.setDraftID(draft_id);
	};
}]);

uiBootstrapApp.factory('DataFormAdvanceDetails', function ($filter) {

    var data = {
		advanceDetailsItems : [],
		draft_id : '',
		transferDate : '',
		transferDateTxt : '-',
		totalHotelAllowance : 0,
		totalLodgingAllowance : 0,
		totalMealAllowance : 0,
		grandTotal : 0,
		totalAdvanceAllowed : 0,
    };

    return {
		getAdvanceDetailsItems: function () {
            return data.advanceDetailsItems;
        },
        setAdvanceDetailsItems: function (obj) {
            data.advanceDetailsItems = obj;
        },
		getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
		getTransferDate: function () {
            return data.transferDate;
        },
        setTransferDate: function (obj) {
            data.transferDate = obj;
        },
		getTransferDateTxt: function () {
            return data.transferDateTxt;
        },
        setTransferDateTxt: function (obj) {
            data.transferDateTxt = obj;
        },
		getTotalHotelAllowance: function () {
            return data.totalHotelAllowance;
        },
        setTotalHotelAllowance: function (obj) {
            data.totalHotelAllowance = obj;
        },
		getTotalLodgingAllowance: function () {
            return data.totalLodgingAllowance;
        },
        setTotalLodgingAllowance: function (obj) {
            data.totalLodgingAllowance = obj;
        },
		getTotalMealAllowance: function () {
            return data.totalMealAllowance;
        },
        setTotalMealAllowance: function (obj) {
            data.totalMealAllowance = obj;
        },
		getGrandTotal: function () {
            return data.grandTotal;
        },
        setGrandTotal: function (obj) {
            data.grandTotal = obj;
        },
		getTotalAdvanceAllowed: function () {
            return data.totalAdvanceAllowed;
        },
        setTotalAdvanceAllowed: function (obj) {
            data.totalAdvanceAllowed = obj;
        },
		reset: function (){

        }
    };
});