from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTransferAdvanceSerializer',
    'LocalTransferAdvanceDraftSerializer'
    ]


class LocalTransferAdvanceSerializer(BaseClaimSerializer):
    advance_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTransferAdvance
        fields = BaseClaimSerializer.Meta.fields + ('advance_details',)

    def get_advance_details(self, obj):
        advance_details = obj.localtransferadvanceparentitem_set.all()
        advance_details_pk = advance_details.values_list('local_transfer_advance', flat=True)
        child_items = LocalTransferAdvanceChildItem.objects.filter(local_transfer_advance__in=advance_details_pk)
        return {'advance_details': advance_details.values()
                , 'child_items': child_items.values()}


class LocalTransferAdvanceDraftSerializer(serializers.ModelSerializer):
    advance_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTransferAdvanceDraft
        fields = '__all__'

    def get_advance_details(self, obj):
        advance_details = obj.localtransferadvanceparentitemdraft_set.all()
        advance_details_pk = advance_details.values_list('local_transfer_advance_draft', flat=True)
        child_items = LocalTransferAdvanceChildItemDraft.objects.filter(local_transfer_advance_draft__in=advance_details_pk)
        return {'advance_details': advance_details.values()
                , 'child_items': child_items.values()}