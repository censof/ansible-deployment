from rest_framework import viewsets
from .serializers import LocalTransferAdvanceSerializer, LocalTransferAdvanceDraftSerializer
from ..models import LocalTransferAdvance, LocalTransferAdvanceDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTransferAdvanceViewSet',
    'LocalTransferAdvanceDraftViewSet'
    ]


class LocalTransferAdvanceViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTransferAdvanceSerializer
    queryset = LocalTransferAdvance.objects.all()


class LocalTransferAdvanceDraftViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTransferAdvanceDraftSerializer
    queryset = LocalTransferAdvanceDraft.objects.all()
