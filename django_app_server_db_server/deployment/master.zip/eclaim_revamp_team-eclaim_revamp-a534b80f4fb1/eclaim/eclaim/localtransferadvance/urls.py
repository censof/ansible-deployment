from django.conf.urls import patterns, url

from .views import LocalTransferAdvanceIndexView, LocalTransferAdvanceDetailView, LocalTransferAdvanceDraftView

urlpatterns = patterns('',
    url(r'^$', LocalTransferAdvanceIndexView.as_view(), name='localtransferadvance_index'),
    url(r'^detail/$', LocalTransferAdvanceDetailView.as_view(), name='localtransferadvance_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', LocalTransferAdvanceDraftView.as_view(), name='localtransferadvance_draft')
)
