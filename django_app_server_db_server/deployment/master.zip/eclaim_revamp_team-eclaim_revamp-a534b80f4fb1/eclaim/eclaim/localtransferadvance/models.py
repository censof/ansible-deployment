from decimal import *
from django.db import models
from django.core.urlresolvers import reverse_lazy
from eclaim.claim.models import ClaimType
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import FundType, TYPE_OF_ADVANCE, TYPE_OF_EXPENSES, REGION_LIST
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.models.company import GradeLevelCategory
from eclaim.masterfiles.common import CLAIM_STATUS


# claim_type pk for Local Transfer Advance is 13
LOCAL_TRANSFER_ADVANCE_TYPE = 13


class LocalTransferAdvanceAbstract(BaseModel):
    status = models.CharField(max_length=CLAIM_STATUS.DEFAULT_LENGTH)
    apply_date = models.DateField()

    class Meta:
        app_label = 'localtransferadvance'
        abstract = True

    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=LOCAL_TRANSFER_ADVANCE_TYPE)


class LocalTransferAdvanceParentItemAbstract(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    transfer_date = models.DateField(null=True)
    for parent in ('total_hotel_allowance', 'total_lodging_allowance', 'total_meal_allowance', 'grand_total'
                   , 'total_advance_allowed'):
        exec("%s = models.DecimalField(**default_arguments)" % parent)

    class Meta:
        app_label = 'localtransferadvance'
        abstract = True


class LocalTransferAdvance(LocalTransferAdvanceAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    class Meta(LocalTransferAdvanceAbstract.Meta):
        app_label = 'localtransferadvance'
        verbose_name = 'Local Transfer Advance'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('localtransferadvance_detail'), self.pk)


class LocalTransferAdvanceParentItem(LocalTransferAdvanceParentItemAbstract):
    local_transfer_advance = models.ForeignKey(LocalTransferAdvance)

    class Meta(LocalTransferAdvanceParentItemAbstract.Meta):
        app_label = 'localtransferadvance'
        verbose_name = 'Local Transfer Advance Parent Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class LocalTransferAdvanceDraft(LocalTransferAdvanceAbstract):

    class Meta(LocalTransferAdvanceAbstract.Meta):
        app_label = 'localtransferadvance'
        verbose_name = 'Local Transfer Advance Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('localtransferadvance_draft', args=[self.pk])


class LocalTransferAdvanceParentItemDraft(LocalTransferAdvanceParentItemAbstract):
    local_transfer_advance_draft = models.ForeignKey(LocalTransferAdvanceDraft)

    class Meta(LocalTransferAdvanceParentItemAbstract.Meta):
        app_label = 'localtransferadvance'
        verbose_name = 'Local Transfer Advance Parent Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class LocalTransferAdvanceChildItemAbstract(models.Model):
    fund_type = models.ForeignKey(FundType)
    project_code = models.CharField(max_length=125)
    from_date = models.DateField(null=True)
    to_date = models.DateField(null=True)
    grade_before = models.ForeignKey(GradeLevelCategory, related_name='gradebefore_%(class)s')
    grade_after = models.ForeignKey(GradeLevelCategory, related_name='gradeafter_%(class)s')
    type_of_advance = models.CharField(max_length=30, choices=TYPE_OF_ADVANCE, null=True)
    destination = models.CharField(max_length=30, choices=REGION_LIST, null=True)
    place = models.TextField(null=True)
    no_of_dependant = models.IntegerField(null=True, default=0)
    type_of_expenses = models.CharField(max_length=30, choices=TYPE_OF_EXPENSES, null=True)
    allowance_no_of_days = models.IntegerField(null=True, default=0)
    hotel_rate = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))
    lodging_rate = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))
    meal_rate = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    class Meta:
        app_label = 'localtransferadvance'
        abstract = True


class LocalTransferAdvanceChildItem(LocalTransferAdvanceChildItemAbstract):
    local_transfer_advance = models.ForeignKey(LocalTransferAdvance)

    class Meta(LocalTransferAdvanceChildItemAbstract.Meta):
        app_label = 'localtransferadvance'
        verbose_name = 'Local Transfer Advance Child Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class LocalTransferAdvanceChildItemDraft(LocalTransferAdvanceChildItemAbstract):
    local_transfer_advance_draft = models.ForeignKey(LocalTransferAdvanceDraft)

    class Meta(LocalTransferAdvanceChildItemAbstract.Meta):
        app_label = 'localtransferadvance'
        verbose_name = 'Local Transfer Advance Child Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']