# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import DentalIndexView, DentalDetailView, DentalDraftView

urlpatterns = patterns('',
    url(r'^dental/$', DentalIndexView.as_view(), name='dental_index'),
    url(r'^dental/detail/$', DentalDetailView.as_view(), name='dental_detail'),
    url(r'^dental/draft/(?P<draft_id>[0-9]+)/$', DentalDraftView.as_view(), name='dental_draft')
)
