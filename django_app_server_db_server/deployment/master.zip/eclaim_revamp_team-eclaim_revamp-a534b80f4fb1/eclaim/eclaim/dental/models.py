from django.db import models
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import MiscellaneousType, FundType, GSTTax


class DentalClaimAbstract(BaseModel):
    net_total = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    grand_total = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    status = models.CharField(max_length=1)

    class Meta:
        app_label = 'dental'
        abstract = True

class DentalClaimItemAbstract(models.Model):

    SELF = 'SELF'
    DPNDT = 'DPNDT'

    CLAIM_FOR_TYPE = (
        (SELF, _(u'Self')),
        (DPNDT, _(u'Dependent')),
    )

    date = models.DateField(null=True)
    receiptNumber = models.CharField(max_length=125)
    expensesType = models.ForeignKey(MiscellaneousType)
    fundType = models.ForeignKey(FundType)
    projectCode = models.CharField(max_length=125)
    clinicName = models.CharField(max_length=125)
    treatmentDetails = models.CharField(max_length=255)
    claimFor = models.CharField(max_length=21, choices=CLAIM_FOR_TYPE)
    patientName = models.CharField(max_length=125)
    patientIC = models.CharField(_(u'IC / Passport No'), max_length=14)
    totalBeforeGST = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    gstType = models.ForeignKey(GSTTax)
    totalAfterGST = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)

    def getTotal(self):
        return self.gstType.rate / 100 * self.totalBeforeGST + self.totalBeforeGST

    class Meta:
        app_label = 'dental'
        abstract = True

class DentalClaim(DentalClaimAbstract):
    claim_no = models.CharField(max_length=30, blank=True)

    class Meta:
        app_label = 'dental'
        verbose_name = 'dental Claim'
        verbose_name_plural = verbose_name
        ordering = ['id']

class DentalClaimItem(DentalClaimItemAbstract):
    dentalClaim = models.ForeignKey(DentalClaim)

    class Meta:
        app_label = 'dental'
        verbose_name = 'dental Claim Item'
        verbose_name_plural = verbose_name
        ordering = ['id']

class DentalClaimDraft(DentalClaimAbstract):

    class Meta:
        app_label = 'dental'
        verbose_name = 'dental Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('dental_draft', args=[self.pk])

class DentalClaimItemDraft(DentalClaimItemAbstract):
    dentalClaimDraft = models.ForeignKey(DentalClaimDraft)

    class Meta:
        app_label = 'dental'
        verbose_name = 'dental Claim Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
