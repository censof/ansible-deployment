from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *


# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'DentalClaimSerializer',
    'DentalClaimDraftSerializer'
    ]


class DentalClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = DentalClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        draftList = obj.dentalclaimitem_set.all()
        return list(draftList.values())


class DentalClaimDraftSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()


    class Meta:
        model = DentalClaimDraft
        fields = ('id', 'items')

    def get_items(self, obj):
        draftList = obj.dentalclaimitemdraft_set.all()
        return list(draftList.values())
