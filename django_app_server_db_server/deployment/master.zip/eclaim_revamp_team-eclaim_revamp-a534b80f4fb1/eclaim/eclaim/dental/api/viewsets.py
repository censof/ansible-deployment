from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)

from .serializers import *
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'DentalClaimViewSet',
    'DentalClaimDraftViewSet'
    ]



class DentalClaimViewSet(viewsets.ModelViewSet):
    serializer_class = DentalClaimSerializer
    queryset = DentalClaim.objects.all()


class DentalClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = DentalClaimDraftSerializer
    queryset = DentalClaimDraft.objects.all()
