console.log('dentalClaimCtrl Loaded!!!');

uiBootstrapApp.controller('dentalClaimCtrl', function ($scope, $http) {

    /*************** Accordion Start ***************/
    $scope.oneAtATime = false;
    $scope.panel = {};
    $scope.panel.p2 = true;

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panel.p1 = true;
        $scope.panel.p2 = true;
        $scope.panel.p3 = true;
        $scope.panel.p4 = true;
        $scope.panel.p5 = true;
        $scope.panel.p6 = true;
        $scope.panel.p7 = true;
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panel.p1 = false;
        $scope.panel.p2 = false;
        $scope.panel.p3 = false;
        $scope.panel.p4 = false;
        $scope.panel.p5 = false;
        $scope.panel.p6 = false;
        $scope.panel.p7 = false;
    };
    /*************** Accordion End ***************/


    /**
     * Detail view
     */
    if (PK) {
        // Initialize variables.
        $scope.viewClaim = false;
        $scope.grandColspan = 12;

        $http({
            url: API_URL+'dental-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            // Add a form declaration to the scope.
            add_form_declaration($scope, 6, data.current_level_ordering);
        });
    } else {
        $scope.viewClaim = true;
        $scope.grandColspan = 13;
        // Add a form declaration to the scope.
        add_form_declaration($scope, 6, 1);
    }

    var claim_api_url = API_URL+'dental-claims/';
    init_workflow($scope, $http, 'dental', 'DentalClaim', PK, claim_api_url, WF_TEMPLATE);

});

uiBootstrapApp.controller('dentalLocalClaimCtrl', function ($scope, $http, DataGST, DataFundType, $q, DataLookup, DataClaimant, DentalLocalData, DataAdvance) {

    $scope.ng_form = {};
    $scope.gst_amount = 0;
    $scope.ng_form.ngDescription = '';

    $scope.dentalClaimList = [];
    $scope.isEmptyTable = true;
    $scope.grandTotal = 0;
    DentalLocalData.setClaimantNo($scope.claimant_no);
    var indxOfChangedItem;

    $scope.expenditure_list = [];
    $scope.fundType_list = [];
    $scope.gstType_list = [];

    var _promises = {};

    _promises['misc_type'] =
        $http({
            url: API_URL+'miscellaneous-type/',
            method: 'GET'
        });

    _promises['fund_type'] =
        $http({
            url: API_URL+'fund-type/',
            method: 'GET'
        });

    _promises['gst'] =
        $http({
            url: API_URL+'gst-tax/',
            method: 'GET'
        });

    if(PK){
        _promises['claim_details'] =
            $http({
                url: API_URL+'dental-claims/'+PK+'/',
                method: 'GET'
            });
    }

    $q.all(_promises).then(function (resolutions) {
        var _expenditure_list = resolutions.misc_type.data.results;
        for (var i=0; i<_expenditure_list.length; i++){
            if(_expenditure_list[i].claim_type == 'DEN')
                $scope.expenditure_list.push(_expenditure_list[i]);
        }
    });

    $scope.getDraft_id = function(draft_id){

        $q.all(_promises).then(function (resolutions) {
                // Misc type
            if($scope.expenditure_list.length<1){
                var _expenditure_list = resolutions.misc_type.data.results;
                for (var i=0; i<_expenditure_list.length; i++){
                    if(_expenditure_list[i].claim_type == 'DEN'){
                        $scope.expenditure_list.push(_expenditure_list[i]);
                    }
                }
            }
            // GST
            $scope.gstType_list = resolutions.gst.data.results;

            // Fund type
            $scope.fundType_list = resolutions.fund_type.data.results;

            //claim details
            if(PK)
                $scope.claim_details = resolutions.claim_details.data.results;

            if(draft_id){
                $http({
                        url: API_URL+'dental-claim-drafts/'+draft_id+'/',
                        method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    DentalLocalData.setDentalItems(data.items);
                    takeItems();
                });
            }else{
                if(PK){
                    DentalLocalData.setDentalItems($scope.claim.items);
                    takeItems();
                }
            }
        });

    }

    function takeItems(){
        $scope.dentalClaimList = DentalLocalData.getDentalItems();
        if($scope.dentalClaimList.length)
            $scope.isEmptyTable = false;
        $scope.grandTotal = getGrandTotal();

        for(var i=0; i<$scope.dentalClaimList.length; i++){

            $scope.dentalClaimList[i].dateToUpdate = getDateFromStr($scope.dentalClaimList[i].date);

            for (var ft=0; ft<$scope.fundType_list.length; ft++){
                if ($scope.dentalClaimList[i].fundType_id == $scope.fundType_list[ft].code){
                    $scope.dentalClaimList[i].fundType = $scope.fundType_list[ft];
                }
            }

            for (var gs=0; gs<$scope.gstType_list.length; gs++){
                if ($scope.dentalClaimList[i].gstType_id == $scope.gstType_list[gs].code){
                    $scope.dentalClaimList[i].gstType = $scope.gstType_list[gs];
                }
            }

            for (var ex=0; ex<$scope.expenditure_list.length; ex++){
                if ($scope.dentalClaimList[i].expensesType_id == $scope.expenditure_list[ex].id){
                    $scope.dentalClaimList[i].expensesType = $scope.expenditure_list[ex];
                }
            }
        }
    }

    $scope.getToUpdate = function(indx){
        var currentItem = $scope.dentalClaimList[indx];
        $scope.openModal();
        $scope.btnUpdate = true;
        $scope.total_after_gst = 0;
        $scope.totalBeforeGST = 0;
        indxOfChangedItem = indx;

        DentalLocalData.setDate(currentItem.dateToUpdate);
        $scope.ng_form.ngReceipt = currentItem.receiptNumber;
        $scope.ng_form.expenditure = currentItem.expensesType;
        DataFundType.setFundType(currentItem.fundType);
        DataLookup.setProjectCode(currentItem.projectCode);
        $scope.ng_form.ngClinicName = currentItem.clinicName;
        $scope.ng_form.ngClaimFor = currentItem.claimFor;

        if(currentItem.claimFor=='Self')
            $scope.ng_form.patient = $scope.claimantObj[0];

        if(currentItem.claimFor=='Children')
            for (var i=0; i<$scope.children_list.length; i++)
                if (currentItem.patientName == $scope.children_list[i].name)
                    $scope.ng_form.patient = $scope.children_list[i];

        if(currentItem.claimFor=='Spouses')
            for (var i=0; i<$scope.sposes_list.length; i++)
                if(currentItem.patientName == $scope.sposes_list[i].name)
                    $scope.ng_form.patient = $scope.sposes_list[i];

        $scope.ng_form.total_before_gst = currentItem.totalBeforeGST;
        $scope.updateTotal();
        DataGST.setGSTType(currentItem.gstType);
        $scope.gst_amount = currentItem.totalBeforeGST*(currentItem.gstType.rate/100);
        $scope.ng_form.ngDescription = currentItem.treatmentDetails;
    }

    $scope.updateTotal = function(){
        $scope.total_after_gst = Number($scope.ng_form.total_before_gst) + Number($scope.ng_form.total_before_gst) * DataGST.getGSTFloat();
        $scope.gst_amount = Number($scope.ng_form.total_before_gst) * DataGST.getGSTFloat();

        $scope.total_after_gst = get2Float($scope.total_after_gst);
        $scope.gst_amount = get2Float($scope.gst_amount);

        if(isNaN($scope.total_after_gst))
            $scope.total_after_gst = 0;
        if(isNaN($scope.gst_amount))
           gst_amount = 0;
    }

    $scope.$watch(function () { return DataGST.getGSTFloat(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.total_after_gst = Number($scope.ng_form.total_before_gst)
                                     + Number($scope.ng_form.total_before_gst) * newValue;
            $scope.gst_amount = Number($scope.ng_form.total_before_gst) * newValue;
        }

        $scope.total_after_gst = get2Float($scope.total_after_gst);
        $scope.gst_amount = get2Float($scope.gst_amount);

        if(isNaN($scope.total_after_gst))
            $scope.total_after_gst = 0;
        if(isNaN($scope.gst_amount))
           gst_amount = 0;
    });

    $scope.deleteMiscLocalItem = function(indx){
        $scope.dentalClaimList.splice(indx, 1);
        if( !$scope.dentalClaimList.length)
            $scope.isEmptyTable = true;

        $scope.grandTotal = getGrandTotal();

        $scope.$watch('DentalLocalData', function() {
            DentalLocalData.setDentalItems($scope.dentalClaimList);
        }, true);
    }

    $scope.addClaimItem = function(indx){
        var item = {}, gstType = {},
            gstType = DataGST.getGSTType();

        item.dateToUpdate   = DentalLocalData.getDate();
        item.date           = DentalLocalData.getDateTxt();
        item.receiptNumber  = $scope.ng_form.ngReceipt;
        item.expensesType   = $scope.ng_form.expenditure;
        item.fundType       = DataFundType.getFundType();
        item.projectCode    = DataLookup.getProjectCode();
        item.clinicName     = $scope.ng_form.ngClinicName;
        item.claimFor       = $scope.ng_form.ngClaimFor;
        item.patientName    = $scope.ng_form.patient.name;
        item.totalBeforeGST = $scope.ng_form.total_before_gst;
        item.gstType        = gstType;
        item.totalAfterGST  = Number(item.totalBeforeGST) + Number(item.totalBeforeGST) * DataGST.getGSTFloat();
        item.treatmentDetails = $scope.ng_form.ngDescription;

        if(Number(indx) > -1){
            $scope.dentalClaimList[indx] = item;
        }
        else{
            $scope.dentalClaimList.push(item);
        }

        $scope.grandTotal = getGrandTotal();

        if( $scope.dentalClaimList.length)
             $scope.isEmptyTable = false;


        DataFundType.setFundType({});
        DentalLocalData.setDate('');
        DataGST.setGSTType({});
        $scope.ng_form = {};
        $scope.ng_form.ngDescription = '';
    }

    function getGrandTotal(){
        var total = 0;
        for (var i=0; i<$scope.dentalClaimList.length; i++)
            total += Number($scope.dentalClaimList[i].totalAfterGST);
        total = total.toFixed(2);
        DataAdvance.setClaimGrandTotal(total);
        DentalLocalData.setGrandTotal(total);
        return total;
    }

    $scope.$watch('dentalClaimList', function() {
        DentalLocalData.setDentalItems($scope.dentalClaimList);
    }, true);

    $scope.$watch('ng_form.ngClaimFor', function() {

        if($scope.ng_form.ngClaimFor == 'Self')
            $scope.patient_list = $scope.claimantObj;

        if($scope.ng_form.ngClaimFor == 'Spouses')
           $scope.patient_list = $scope.sposes_list;

        if($scope.ng_form.ngClaimFor == 'Children')
            $scope.patient_list = $scope.children_list;

    }, true);

    $scope.update = function(){
        $scope.addClaimItem(indxOfChangedItem);
        $scope.btnUpdate = false;
    }

    $scope.openModal = function(){
        $scope.btnUpdate = false;
        $('#dentalModalForm').modal('show');
    };

    $http({
        url: API_URL+'miscellaneous-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        var _expenditure_list = data.results;
        for (var i=0; i<_expenditure_list.length; i++){
            if(_expenditure_list[i].claim_type == 'DEN'){
                $scope.expenditure_list.push(_expenditure_list[i]);
            }
        }

    });

    $http({
        url: API_URL+'claimants/'+$scope.claimant_no+'/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.claimantObj = [data];
    });

    $http({
        url: API_URL+'claimant-spouses/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.sposes_list = data.results;
    });

    $http({
        url: API_URL+'claimant-children/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.children_list = data.results;
    });

});

uiBootstrapApp.factory('DentalLocalData', function ($filter) {
    var data = {
            dentalItems:[],
            error_validation:'',
            claimant_no:'',
            draft_id:'',
            claim_id:'',
            claim_date:'',
            DateTxt : '-',
            grand_total:0
        };
    return {
        getDentalItems: function () {
            return data.dentalItems;
        },
        setDentalItems: function (objt){
            data.dentalItems = objt;
        },
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (objt){
            data.error_validation = objt;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        },
        getDate: function () {
            return data.claim_date;
        },
        getDateTxt: function () {
            return data.DateTxt;
        },
        setDate: function (obj) {
            var minDate = $filter('date')(obj, 'yyyy-M-dd');
            data.claim_date = obj;
            data.DateTxt = minDate;
        },
        getGrandTotal: function () {
            return data.grand_total;
        },
        setGrandTotal: function (obj) {
            data.grand_total = obj;
        }
    };
});
//submit and draft controller

uiBootstrapApp.controller('SubmitCtrl', function ($scope, $http, DentalLocalData, $uibModal, DataAdvance) {

    $scope.animationsEnabled = true;

    $scope.submit = function(btnMode) {

        form_data = {
            btn_mode:btnMode,
            dentalItems:DentalLocalData.getDentalItems(),
            claimant_no:DentalLocalData.getClaimantNo(),
            draft_id:DentalLocalData.getDraftID(),
            net_total:DataAdvance.getClaimNettTotal(),
            grand_total:DentalLocalData.getGrandTotal()
        }

        var instance_controller = '';

        if (btnMode == 'save_draft') {
            instance_controller = 'ModalInstanceSaveCtrl';
            ng_template = 'SaveConformation.html';
        }else if (btnMode == 'submit'){
            instance_controller = 'ModalInstanceSubmitCtrl';
            ng_template = 'SubmitConformation.html';
        }
        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: ng_template,
            controller: instance_controller,
            size: 'sm',
            resolve: {
                data: function () {
                    return form_data;
                }
            }
        });

        modalInstance.result.then(function () {
                console.log('OK, conformation box closed');

                if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        console.log(data);
                        //$window.location.href = submit_success_url;
                    });
                } else {
                    $http({
                        url: '',
                        method: 'POST',
                        data: form_data
                    })
                    .success(function (data, status, headers, config) {
                        $uibModal.open({
                            animation: $scope.animationsEnabled,
                            templateUrl: 'SaveSuccess.html',
                            controller: 'ModalInstanceInfoCtrl',
                            size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
                            resolve: {
                                data: function () {
                                    return data;
                                }
                            }
                        });
                        window.location.href = URL_HOMEPAGE;
                    });
                }
            },
            function () {
                console.log('Cancel, conformation box closed');
            }
        );
    };

    $scope.initSubmitCtrl = function(draft_id){
        $scope.draft_id = draft_id;
        DentalLocalData.setDraftID(draft_id);
    };
});

uiBootstrapApp.controller('ModalInstanceSaveCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

uiBootstrapApp.controller('ModalInstanceSubmitCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
    };
}]);

uiBootstrapApp.controller('ModalInstanceInfoCtrl', ['$scope', '$modalInstance', 'data', function ($scope, $uibModalInstance, data) {

    $scope.ok = function () {
        $uibModalInstance.close();
    };
}]);

uiBootstrapApp.controller('ModalDemoCtrl', ['$scope', '$uibModal', function ($scope, $uibModal) {

    $scope.items = ['item1', 'item2', 'item3'];

    $scope.animationsEnabled = true;

    $scope.open = function (size) {

    var modalInstance = $uibModal.open({
      animation: $scope.animationsEnabled,
      templateUrl: 'myModalContent.html',
      controller: 'ModalInstanceCtrl',
      size: size,
      resolve: {
        items: function () {
          return $scope.items;
        }
      }
    });

    modalInstance.result.then(
        function (selectedItem) {
            $scope.selected = selectedItem;
        },
        function () {
            $log.info('Modal dismissed at: ' + new Date());
        }
    );
  };

  $scope.toggleAnimation = function () {
    $scope.animationsEnabled = !$scope.animationsEnabled;
  };

}]);

uiBootstrapApp.controller('ModalInstanceCtrl', ['$scope', '$modalInstance', 'items', function ($scope, $uibModalInstance, items) {

  $scope.items = items;
  $scope.selected = {
    item: $scope.items[0]
  };

  $scope.ok = function () {
    $uibModalInstance.close($scope.selected.item);
  };

  $scope.cancel = function () {
    $uibModalInstance.dismiss('cancel');
  };
}]);

uiBootstrapApp.controller('claimDateCtrl', function($scope, DentalLocalData){
    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.resetDate = function() {
        $scope.ng_form.miscDate = '';
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.status = {
        opened: false
    };

    $scope.dateChanged = function(){
        DentalLocalData.setDate($scope.ng_form.miscDate);
    };

    $scope.$watch(function () { return DentalLocalData.getDate(); }, function (newValue, oldValue) {
        if (newValue != oldValue) {
            $scope.ng_form.miscDate = newValue;
        }
    });
});

uiBootstrapApp.controller('summaryCtr', function($scope, $http, DentalLocalData){

    $scope.$watchCollection(function () { return DentalLocalData.getDentalItems(); }, function (newValue, oldValue) {
        $scope.summary_list = [];
        $scope.GSTsummary_list = [];
        $scope.grandSummaryTotal = 0;

        var miscClaim_list = $.extend(true, [], DentalLocalData.getDentalItems());

        if(miscClaim_list.length)
        {
            getGSTSummary(miscClaim_list);
            getSummaryList(getExpensesObjects(groupByExp(miscClaim_list)));
            $scope.grandSummaryTotal = $scope.grandSummaryTotal.toFixed(2);
        }
    });

    function groupByExp(miscClaim_list){
        grouped_list = [];

        while(miscClaim_list.length>0){
            grouped_list.push(miscClaim_list[0]);
            exp = miscClaim_list[0].expensesType.id;
            miscClaim_list.splice(0, 1);

            for (var i=0; i<miscClaim_list.length; i++){
                if(miscClaim_list[i].expensesType.id == exp){
                    grouped_list.push(miscClaim_list[i]);
                    miscClaim_list.splice(i, 1);
                    i--;
                 }
            }
        }

        return grouped_list;
    }

    function getExpensesObjects(expGrouped_list){
        expensesObjs = [];
        ls = [];
        var j=0;

        for (var i=0; i<expGrouped_list.length; i++){
            while(i<expGrouped_list.length){
                if(expGrouped_list[i].expensesType.id==expGrouped_list[j].expensesType.id){
                    ls.push(expGrouped_list[i]);
                    i++;
                }
                else{ j=i; i--; break; }
            }
            expensesObjs.push(ls);
            ls = [];
        }
        return expensesObjs;
    }

    function fundObjExist(fund_list, _description){
        for (var i=0; i<fund_list.length; i++){
            if(fund_list[i].description == _description)
                return i;
        }
        return -1;
    }

    function getSummaryList(expensesObjs_list){
        for (var i=0; i<expensesObjs_list.length; i++){

            sumryObj = {};
            sumryObj.fundType = [];
            sumryObj.title = expensesObjs_list[i][0].expensesType.description;
            sumryObj.expenseCode = expensesObjs_list[i][0].expensesType.exp_code;
            sumryObj.amount = 0;

            for(var j=0; j<expensesObjs_list[i].length; j++){

                sumryObj.amount +=  Number(expensesObjs_list[i][j].totalBeforeGST);

                indx = fundObjExist(sumryObj.fundType, expensesObjs_list[i][j].fundType.description);
                if(indx != -1){
                    sumryObj.fundType[indx].amount += Number(expensesObjs_list[i][j].totalBeforeGST);
                }else{
                    fundObj = {};
                    fundObj.amount = Number(expensesObjs_list[i][j].totalBeforeGST);
                    fundObj.description = expensesObjs_list[i][j].fundType.description;
                    sumryObj.fundType.push(fundObj);
                }
            }
            $scope.summary_list.push(sumryObj);
        }
    }

    // GST Summary
    function gstObjExist(gst_list, gstDescription){
        for (var i=0; i<gst_list.length; i++){
            if(gst_list[i].description == gstDescription)
                return i;
        }
        return -1;
    }

    function getGSTSummary(miscClaim_list){
        ls = [];
        for (var i=0; i<miscClaim_list.length; i++){
            gstObj = {}
            indx = (gstObjExist(ls, miscClaim_list[i].gstType.description));
            if(indx != -1){
                ls[indx].amount += miscClaim_list[i].gstType.rate * miscClaim_list[i].totalBeforeGST / 100;
                $scope.grandSummaryTotal += miscClaim_list[i].totalAfterGST;
            }
            else{
                gstObj.description = miscClaim_list[i].gstType.description;
                gstObj.amount = miscClaim_list[i].gstType.rate * miscClaim_list[i].totalBeforeGST / 100;
                ls.push(gstObj);
                $scope.grandSummaryTotal += miscClaim_list[i].totalAfterGST;
            }
        }
        $scope.GSTsummary_list = ls;
    }
});
