from decimal import *
from django.utils import timezone
from eclaim.masterfiles.models.misc import FundType, MiscellaneousType
from eclaim.masterfiles.common import CLAIM_TYPE
from eclaim.masterfiles.utils import save_claimant_history
from eclaim.utils.common import generate_claim_no
from .models import *


__ClaimType__ = CLAIM_TYPE.OMED
__ClaimNoPrefix__ = CLAIM_TYPE.MedicaloverseasNoPrefix


def process_controller(form_data):
    claim_id = None

    if form_data.get('btn_mode') in ['save_draft']:
        save_draft(form_data)

    elif form_data.get('btn_mode') in ['submit']:
        claim_id = submit_claim(form_data)

    return claim_id

def save_draft(form_data):
    draft_id = form_data.get('draft_id')

    if draft_id == '':
        claim_draft = MedicaloverseasClaimDraft()
    else:
        claim_draft = MedicaloverseasClaimDraft(id=int(draft_id))
        delete_medicaloverseas_claim_draft_item(claim_draft)

    claim_draft.status = 'D'
    claim_draft.net_total = form_data.get('net_total')
    claim_draft.grand_total = form_data.get('grand_total')
    claim_draft.save()
    save_medicaloverseas_claim_item('save_draft', claim_draft, form_data)
    #save_document_list_item_draft(claim_draft.id, __ClaimType__, form_data)

def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')

    claim = MedicaloverseasClaim()
    claim.status = 'S'
    claim.net_total = form_data.get('net_total')
    claim.grand_total = form_data.get('grand_total')
    claim.save()
    claim.claim_no = generate_claim_no(__ClaimNoPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_medicaloverseas_claim_item('submit_claim', claim, form_data)
    #save_document_list_item(claim.claim_no, __ClaimType__, form_data)
    return claim.id

def save_medicaloverseas_claim_item(mode, parent, form_data):
    for i in form_data.get('medicalItems'):
        if mode in ['save_draft']:
            saveObj = MedicaloverseasClaimItemDraft()
            saveObj.medicaloverseasClaimDraft = parent
            saveObj.medicaloverseasClaimDraft.modified = timezone.now()
            saveObj.medicaloverseasClaimDraft.save()

        elif mode in ['submit_claim']:
            saveObj = MedicaloverseasClaimItem()
            saveObj.medicaloverseasClaim = parent
            saveObj.medicaloverseasClaim.modified = timezone.now()
            saveObj.medicaloverseasClaim.save()

        saveObj.date = i['date']
        saveObj.receiptNumber = i['receiptNumber']
        saveObj.expensesType = MiscellaneousType.objects.get(code=i['expensesType'].get('code'))
        saveObj.fundType = FundType.objects.get(code=i['fundType'].get('code'))
        saveObj.projectCode = i['projectCode']
        saveObj.clinicName = i['clinicName']
        saveObj.treatmentDetails = i['treatmentDetails']
        saveObj.claimFor = i['claimFor']
        saveObj.patientName = i['patientName']
        saveObj.patientIC = i['patientIC']

        saveObj.country = i['country']
        saveObj.currencyType = i['currencyType']
        saveObj.exchangeRate = i['exchangeRate']
        saveObj.amountForeignCrncy = i['amountForeignCrncy']
        saveObj.totalPrice = i['totalPrice']
        saveObj.save()

def delete_medicaloverseas_claim_draft_item(parent):
    delObj = MedicaloverseasClaimItemDraft.objects.filter(medicaloverseasClaimDraft=parent)
    delObj.delete()
