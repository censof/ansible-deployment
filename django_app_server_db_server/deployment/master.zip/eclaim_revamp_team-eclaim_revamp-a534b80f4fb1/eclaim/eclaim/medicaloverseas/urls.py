# from Django
from django.conf.urls import patterns, url

# from eClaim
from .views import MedicaloverseasIndexView, MedicaloverseasDetailView, MedicaloverseasDraftView

urlpatterns = patterns('',
    url(r'^medicaloverseas/$', MedicaloverseasIndexView.as_view(), name='medicaloverseas_index'),
    url(r'^medicaloverseas/detail/$', MedicaloverseasDetailView.as_view(), name='medicaloverseas_detail'),
    url(r'^medicaloverseas/draft/(?P<draft_id>[0-9]+)/$', MedicaloverseasDraftView.as_view(), name='medicaloverseas_draft')
)
