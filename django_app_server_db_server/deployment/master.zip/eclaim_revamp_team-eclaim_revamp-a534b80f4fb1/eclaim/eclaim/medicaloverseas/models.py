from django.db import models
from django.core.urlresolvers import reverse_lazy
from django.utils.translation import ugettext_lazy as _
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import MiscellaneousType, FundType


class MedicaloverseasClaimAbstract(BaseModel):
    net_total = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    grand_total = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    status = models.CharField(max_length=1)

    class Meta:
        app_label = 'medicaloverseas'
        abstract = True

class MedicaloverseasClaimItemAbstract(models.Model):

    SELF = 'SELF'
    DPNDT = 'DPNDT'

    CLAIM_FOR_TYPE = (
        (SELF, _(u'Self')),
        (DPNDT, _(u'Dependent')),
    )

    date = models.DateField(null=True)
    receiptNumber = models.CharField(max_length=125)
    expensesType = models.ForeignKey(MiscellaneousType)
    fundType = models.ForeignKey(FundType)
    projectCode = models.CharField(max_length=125)
    clinicName = models.CharField(max_length=125)
    treatmentDetails = models.CharField(max_length=255)
    claimFor = models.CharField(max_length=21, choices=CLAIM_FOR_TYPE)
    patientName = models.CharField(max_length=125)
    patientIC = models.CharField(_(u'IC / Passport No'), max_length=14)

    country = models.CharField(max_length=125)
    currencyType = models.CharField(max_length=125)
    exchangeRate = models.DecimalField(max_digits=9, decimal_places=2, default=0.00)
    amountForeignCrncy = models.DecimalField(max_digits=17, decimal_places=2, default=0.00)
    totalPrice = models.DecimalField(max_digits=17, decimal_places=2, default=0.00)

    class Meta:
        app_label = 'medicaloverseas'
        abstract = True

class MedicaloverseasClaim(MedicaloverseasClaimAbstract):
    claim_no = models.CharField(max_length=30, blank=True)

    class Meta:
        app_label = 'medicaloverseas'
        verbose_name = 'medicaloverseas Claim'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('medicaloverseas_detail'), self.pk)

class MedicaloverseasClaimItem(MedicaloverseasClaimItemAbstract):
    medicaloverseasClaim = models.ForeignKey(MedicaloverseasClaim)

    class Meta:
        app_label = 'medicaloverseas'
        verbose_name = 'medicaloverseas Claim Item'
        verbose_name_plural = verbose_name
        ordering = ['id']

class MedicaloverseasClaimDraft(MedicaloverseasClaimAbstract):

    class Meta:
        app_label = 'medicaloverseas'
        verbose_name = 'medicaloverseas Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('medicaloverseas_draft', args=[self.pk])

class MedicaloverseasClaimItemDraft(MedicaloverseasClaimItemAbstract):
    medicaloverseasClaimDraft = models.ForeignKey(MedicaloverseasClaimDraft)

    class Meta:
        app_label = 'medicaloverseas'
        verbose_name = 'medicaloverseas Claim Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
