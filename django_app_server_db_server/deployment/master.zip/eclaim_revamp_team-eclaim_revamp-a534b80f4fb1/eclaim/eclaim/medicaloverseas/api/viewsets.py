from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)

from .serializers import *
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MedicaloverseasClaimViewSet',
    'MedicaloverseasClaimDraftViewSet'
    ]



class MedicaloverseasClaimViewSet(viewsets.ModelViewSet):
    serializer_class = MedicaloverseasClaimSerializer
    queryset = MedicaloverseasClaim.objects.all()


class MedicaloverseasClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = MedicaloverseasClaimDraftSerializer
    queryset = MedicaloverseasClaimDraft.objects.all()
