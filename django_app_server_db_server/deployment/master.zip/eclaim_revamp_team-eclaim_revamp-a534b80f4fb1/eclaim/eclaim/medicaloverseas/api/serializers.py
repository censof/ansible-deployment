from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'MedicaloverseasClaimSerializer',
    'MedicaloverseasClaimDraftSerializer'
    ]


class MedicaloverseasClaimSerializer(BaseClaimSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MedicaloverseasClaim
        fields = BaseClaimSerializer.Meta.fields + ('items',)

    def get_items(self, obj):
        draftList = obj.medicaloverseasclaimitem_set.all()
        return list(draftList.values())


class MedicaloverseasClaimDraftSerializer(serializers.ModelSerializer):
    items = serializers.SerializerMethodField()

    class Meta:
        model = MedicaloverseasClaimDraft
        fields = ('id', 'items')

    def get_items(self, obj):
        draftList = obj.medicaloverseasclaimitemdraft_set.all()
        return list(draftList.values())
