from .models import Settings

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = ['settings']


def settings(request):
    settings, new = Settings.objects.get_or_create()
    return {'SETTINGS': settings}
