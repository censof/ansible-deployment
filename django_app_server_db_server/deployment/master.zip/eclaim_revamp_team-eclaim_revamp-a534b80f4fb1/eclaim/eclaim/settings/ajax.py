import csv
import json

from datetime import datetime
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_POST
from django.http import HttpResponse
from moneyed import get_currency, add_currency, CurrencyDoesNotExist
from .models import Currency, CurrencyRate, Settings

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'import_currency_rate_csv',
    'lock_implementation'
    ]


@login_required
def import_currency_rate_csv(request):
    """Import a CSV file to update currency rates."""
    f = request.FILES['file']
    reader = csv.reader(f.read().splitlines(), delimiter=',')
    total = 0
    for row in reader:
        if reader.line_num == 1:
            # Index columns to assign currencies.
            _currencies = row[1:]
        else:
            date = datetime.strptime(row[0], '%d/%m/%Y').date()
            for i, curname in enumerate(_currencies):
                try:
                    curobj = get_currency(curname)
                except CurrencyDoesNotExist:
                    curobj = add_currency(curname, 'Nil', curname, [])

                currency, new = Currency.objects.get_or_create(currency=curobj)
                try:
                    rate = CurrencyRate.objects.get(
                        date=date, currency=currency)
                except CurrencyRate.DoesNotExist:
                    rate = CurrencyRate(date=date, currency=currency)

                value = row[i+1]
                rate.value = value
                rate.save()
                total += 1
    return HttpResponse(json.dumps({'count': total}))


@require_POST
@csrf_exempt
def lock_implementation(request):
    """DEPRECATED::: Allow an implementer to lock implementation setup."""
    if request.user.username == 'implementer':
        settings = Settings.objects.get()
        settings.implementation_locked = True
        settings.save()
        return JsonResponse({'success': True})
    return JsonResponse({'success': False})
