from django.utils.encoding import force_text
from eclaim.utils.common import get_claim_type_prefix, generate_claim_no
from eclaim.claim.models import ClaimType

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'workflowlevel_postsave',
    'workflowtemplatedetails_postsave',
    'selectedassignee_postsave',
    'workflowquerystate_postsave'
    ]


def workflowlevel_postsave(sender, created, **kwargs):
    from eclaim.settings.models import WorkflowTemplateLevel, WorkflowStatus

    # Make sure that the first 'Submitted' level is created.
    if created:
        level = kwargs['instance']
        WorkflowTemplateLevel.objects.get_or_create(
            status=WorkflowStatus.objects.get(ordering=1),
            query=False,
            email_notif=True,
            template=level.template,
            ordering=1
            )


def workflowtemplatedetails_postsave(sender, created, **kwargs):
    """Add an assignee to the user group once he's been created in workflow
    settings.
    """
    if created:
        obj = kwargs['instance']
        assignee = obj.assignee
        group = obj.template_level.group
        assignee.groups.add(group)
        assignee.added_via_workflow = True
        assignee.save()


def selectedassignee_postsave(sender, created, **kwargs):
    from eclaim.settings.models import WorkflowState

    # If a staff was assigned to a claim, then set the current assignee
    # label to the state log to show on a dashboard.
    obj = kwargs['instance']
    state = WorkflowState.objects.filter(
        content_type=obj.content_type,
        object_id=obj.object_id
        ).latest()
    log = state.workflowstatelog_set.latest()
    log.current_assignee = force_text(state.get_assigned_entity())
    log.save()


def workflowquerystate_postsave(sender, created, instance, **kwargs):
    from eclaim.settings.models import WorkflowQueryState

    if created:
        # Increment the last digits on a claim reference number by 1,
        # which means total number of queries performed.
        state = instance.state
        query_states = WorkflowQueryState.objects.filter(
            state__object_id=state.object_id,
            state__content_type=state.content_type
            ).distinct()
        claim = state.content_object

        try:
            claim_type = claim.get_claim_type()  # legacy
        except AttributeError:
            claim_type = ClaimType.get_claim_type(claim.CLAIM_TYPE)

        prefix = get_claim_type_prefix(claim_type.pk)
        claim.claim_no = generate_claim_no(prefix, claim.pk,
                                           query_states.count())
        claim.save()
