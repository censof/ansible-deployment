/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Workflow
 */

settingsApp.controller('workflowNewTemplateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.workflow = {};
    $scope.workflow.max_levels = 10;
    $scope.workflow.level_form = {};
    $scope.workflow.level_form.queries = {};
    $scope.workflow.level_form.email_notifs = {};
    $scope.workflow.level_form.selection_filtering = {};
    $scope.workflow.level_form.gl_distribution = {};
    $scope.workflow.level_form.budget_lock = {};
    $scope.workflow.level_form.orderings = {};
    $scope.workflow.select_target = null;

    /**
     * Define helper functions
     */
    $scope.range = function (num) {
        return new Array(Number(num));
    };

    $scope.workflow.focus_helper = function ($event) {
        if ($event.target === null)
            return;
        $scope.workflow.select_target = $event.target;
    }

    $scope.workflow.update_status_cell = function () {
        var select      = $($scope.workflow.select_target),
            group_id    = select.val(),
            status_cell = select.closest('tr').find('.status-cell');

        $http({
            url: API_URL+'usergroups/'+group_id+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            status_cell.html(data.status);
        });
    }

    /**
     * Initialize select box options
     */
    $http({
        url: API_URL+'usergroups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.workflow.usergroup_list = data.results;
    });

    $http({
        url: API_URL+'claim-types/?has_template=false&is_enabled=1',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.workflow.claim_type_list = data.results;
    });

    /**
     * POST data
     */
    $scope.workflow.submit = function ($innerscope) {
        $innerscope = this;

        function _level_form_valid() {
            return Object.size($innerscope.level_form.usergroups) == $scope.workflow.levels-1;
        }

        if (_level_form_valid()) {
            $scope.workflow.level_form.submitted = true;

            // Prepare a list of IDs of claim types.
            var claim_type_ids = [];

            for (var i = 0; i < $scope.workflow.claim_types.length; i++) {
                claim_type_ids.push($scope.workflow.claim_types[i].id);
            }

            var params = {
                integrated_to_fs: $innerscope.level_form.integrated_to_fs || false,
                claim_types: claim_type_ids,
                title: $scope.workflow.template
            };

            // Check if a selection filtering was chosen on a claimant level.
            var sel_filtering_claimant = $innerscope.level_form.selection_filtering_claimant || false;

            $http({
                url: API_URL+'workflow-templates/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                var success_num = 0;

                for (var i = 2; i <= $scope.workflow.levels; i++) {
                    var params = {
                        group: $innerscope.level_form.usergroups[i].id,
                        email_notif: $innerscope.level_form.email_notifs[i] || false,
                        gl_distribution: $innerscope.level_form.gl_distribution[i] || false,
                        selection_filtering: $innerscope.level_form.selection_filtering[i] || false,
                        query: $innerscope.level_form.queries[i] || false,
                        template: data.id,
                        ordering: i
                    };
                    params.budget_lock = $innerscope.level_form.budget_lock == i;

                    $http({
                        url: API_URL+'workflow-template-levels/',
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        success_num++;

                        if (success_num == $scope.workflow.levels-1) {
                            if (sel_filtering_claimant) {  // run only once
                                $http({
                                    url: API_URL+'workflow-template-levels/'+data.first_level_id+'/',
                                    method: 'PATCH',
                                    data: { selection_filtering: true }
                                })
                                .success(function (data, status, headers, config) {
                                    window.location.href = URL_WORKFLOW_TEMPLATES;
                                });
                            } else {
                                window.location.href = URL_WORKFLOW_TEMPLATES;
                            }
                        }
                    });
                }
            });
        } else {
            // Show a bootbox message that form is invalid
            var message = "Form is invalid. Please make sure your input is correct.";
            bootbox.alert("<span class='text-danger'><i class='fa fa-exclamation-triangle fa-fw'></i> "+message+"</span>");
        }
    }
});

settingsApp.controller('workflowSetupController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.workflow = {};
    $scope.workflow.template_list = [];
    $scope.workflow.level_list = [];
    $scope.workflow.templatedetail_list = [];
    $scope.workflow.claimtype_list = [];
    $scope.workflow.usergroups_loading = false;
    $scope.workflow.levels_loading = false;

    $scope.workflow.update_usergroups = function () {
        if ($scope.workflow.template) {
            $scope.workflow.usergroups_loading = true;
            $scope.workflow.levels_loading = true;
            $scope.workflow.usergroup_list = [];
            $http({
                url: API_URL+'usergroups/?template='+$scope.workflow.template.id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.workflow.usergroup_list = data.results;
                $scope.workflow.usergroups_loading= false;
            });
        }

        render_template_levels();
    }

    function render_template_levels () {
        /**
         * Workflow Levels
         */
        if ($scope.workflow.template && !$scope.workflow.usergroup) {
            $http({
                url: API_URL+'workflow-template-levels/?template='+$scope.workflow.template.id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.workflow.templatelevel_list = data.results;
                $scope.workflow.levels_loading = false;
            });
        }
    }

    $scope.workflow.update_content = function () {
        var template    = $scope.workflow.template,
            usergroup   = $scope.workflow.usergroup;

        if (usergroup) {
            $http({
                url: API_URL+'workflow-template-details/?group='+usergroup.id+'&template='+template.id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.workflow.templatedetail_list = data.results;
            });

            if (template) {
                $('#add-details').attr('href', URL_TEMPLATE_DETAILS+'?template='+template.id+'&group='+usergroup.id);
            }
        }
    }

    /**
     * Workflow Templates, Levels & User Groups
     */
    $http({
        url: API_URL+'workflow-templates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        var object_list = [];

        for (var i = 0; i < data.results.length; i++) {
            var obj     = data.results[i],
                add_in  = false;

            for (var x = 0; x < obj.claim_types.length; x++) {
                if (obj.claim_types[x].is_enabled)
                    add_in = true;
            }

            if (add_in)
                object_list.push(obj);
        }

        $scope.workflow.template_list = object_list;
    });

    if ($scope.workflow.template) {
        $http({
            url: API_URL+'workflow-templates/'+$scope.workflow.template+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.workflow.template = data;
        });
    }

    if ($scope.workflow.usergroup) {
        $http({
            url: API_URL+'workflow-template-levels/?usergroup='+$scope.workflow.usergroup,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.workflow.level_list = data.results;
        });

        $http({
            url: API_URL+'usergroups/'+$scope.workflow.usergroup+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.workflow.usergroup = data;
        });
    }

    $http({
        url: API_URL+'usergroups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.workflow.usergroup_list = data.results;
    });

    /**
     * Levels
     */
    $http({
        url: API_URL+'levels/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.workflow.level_list = data.results;
    });
});

settingsApp.controller('workflowTemplateDetailsController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.workflow = {};
    $scope.workflow.level_list = [];
    $scope.workflow.companylevel_list = [];
    $scope.workflow.init_companylevel_list = [];
    $scope.workflow.checkbox_checked = false;
    $scope.workflow.submitted = false;

    /**
     * Levels & Company Levels
     */
    $http({
        url: API_URL+'levels/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.workflow.level_list = data.results;
    });

    /**
     * Workflow Wizard
     */
    var wizard     = $('#workflow-wizard'),
        wiz_panes  = wizard.find('.tab-pane'),
        wiz_cboxes = wiz_panes.find('input[type="checkbox"]');

    wiz_cboxes.on('change', function () {
        var ordering = $(this).closest('.tab-pane').data('ordering');

        // Uncheck all checkboxes and hide them
        wiz_panes.each(function () {
            if ($(this).data('ordering') > ordering)
                $(this).find('input[type="checkbox"]')
                    .prop('checked', false)
                    .closest('label').addClass('hide');
        });

        // Show corresponding checkboxes in the next tabs
        $.each(wiz_cboxes, function () {
            var cb = $(this),
                pk = cb.data('pk');

            $http({
                url: API_URL+'companylevels/?parent='+pk,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                for (var i = 0; i < data.results.length; i++) {
                    var el = data.results[i];

                    wiz_cboxes.each(function () {
                        if ($(this).data('pk') == el.code) {
                            if (cb.is(':checked')) {
                                $(this).closest('label').removeClass('hide');
                            } else {
                                $(this).closest('label').addClass('hide');
                            }
                        }
                    });
                }
            });
        });
    });

    /**
     * Form submission
     */
    $scope.workflow.submit = function () {
        var $valid      = false,
            $complevels = [];

        // Perform some basic validation
        $.each(wiz_cboxes, function () {
            if ($(this).is(':checked')) {
                $complevels.push($(this).data('pk'));
                if ($(this).closest('.tab-pane').data('ordering') == 1)
                    $valid = true;
            }
        });

        if (!$valid) {
            var message = "You must choose at least one 1st level.";
            bootbox.alert("<span class='text-danger'><i class='fa fa-exclamation-triangle fa-fw'></i> "+message+"</span>");
            return;
        }

        if ($('#assignee').val().length <= 1) {
            var message = "You must select an assignee.";
            bootbox.alert("<span class='text-danger'><i class='fa fa-exclamation-triangle fa-fw'></i> "+message+"</span>");
            return;
        }

        // Form is valid
        $http({
            url: API_URL+'workflow-template-levels/?template='+TEMPLATE_ID+'&group='+USERGROUP_ID,
            method: 'GET'
        })
        .success(function (level_data, status, headers, config) {
            var claimant = $('#assignee').val();

            $http({
                url: API_URL+'claimants/'+claimant+'/',
                method: 'GET'
            })
            .success(function (claimant_data, status, headers, config) {
                if (claimant_data.assignee) {
                    var method  = 'PUT',
                        url     = API_URL+'assignees/'+claimant_data.assignee.id+'/';
                } else {
                    var method  = 'POST',
                        url     = API_URL+'assignees/';
                }

                $http({
                    url: url,
                    method: method,
                    data: { claimant: claimant, usergroups: [USERGROUP_ID] }
                })
                .success(function (assignee_data, status, headers, config) {
                    var params = {
                        assignee: assignee_data.id,
                        template_level: level_data.results[0].id,
                        levels: $complevels
                    };

                    var _grade_from = $('#grade-from').val() || '',
                        _grade_to   = $('#grade-to').val() || '';

                    if (_grade_from.length)
                        params.grade_from = _grade_from;
                    if (_grade_to.length)
                        params.grade_to = _grade_to;

                    $http({
                        url: API_URL+'workflow-template-details/',
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        window.location.href = URL_WORKFLOW_TEMPLATES;
                    });
                });
            });
        });

        $scope.workflow.submitted = true;
    }
});

settingsApp.controller('workflowGroupsController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.group_scope = {};
    $scope.group_scope.is_loading = true;
    $scope.group_scope.group_list = [];
    $scope.group_scope.total_objects = 0;
    $scope.group_scope.pagination = {current: 1};
    $scope.group_scope.status_list = [];

    var all_new_rows = [];

    $scope.add_new_group = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-group'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

     $scope.submit = function () {
        if ($scope.group_form.$valid) {
            var cleaned_data = [];

            $.each(all_new_rows, function () {
                var row  = $(this),
                    title = row.find('.group-title').val(),
                    status = row.find('.group-status').val();

                if (title.length && status.length) {
                    cleaned_data.push({
                        title: title,
                        status: status
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    title: cleaned_data[i].title,
                    status: cleaned_data[i].status
                }
                $http({
                    url: API_URL+'usergroups/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'usergroups/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.group_scope.group_list = data.results;
            $scope.group_scope.total_objects = data.count;
            $scope.group_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('workflowGroupDetailController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.is_loading = true;
    $scope.group = {};
    $scope.claimant_list = [];
    $scope.total_objects = 0;
    $scope.pagination = {current: 1};

    /**
     * The AJAX Call to render the current group details
     */
    $http({
        url: API_URL+'usergroups/'+PK+'/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.group = data;
    });

    /**
     * The AJAX Call to render claimant objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'claimants/?group='+PK+'&page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.claimant_list = data.results;
            $scope.total_objects = data.count;
            $scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * Pre-fill Select2 with claimant objects
     */
    $http({
        url: API_URL+'claimants/?exclude_group='+PK,
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.all_claimant_list = data.results;
    });

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('selectionFilteringController', function ($scope, $http, $q) {
    /**
     * Initial values
     */
    $scope.is_loading = true;
    $scope.submitted = false;
    $scope.filtering = {};
    $scope.level_list = {};
    $scope.wf_levels = {};
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push(row_counter);
        row_counter++;
    }

    /**
     * Submit newly created rows
     */
    $scope.submit = function () {
        var promises = [];
        $scope.submitted = true;

        for (var i = 0; i < row_counter; i++) {
            promises[i] = $http({
                url: API_URL+'selection-filtering/',
                method: 'POST',
                data: {
                    template:      $scope.new_objects['template_'+i].id,
                    level:         $scope.new_objects['wf_level_'+i].id,
                    company_level: $scope.new_objects['company_level_'+i].id
                }
            });
        }

        $q.all(promises).then(function (resolutions) {
            // Data submission completed.
            window.location.reload();
        });
    }

    /**
     * Render initial objects
     */
    $http({
        url: API_URL+'selection-filtering/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.filtering_list = data.results;
        $scope.is_loading = false;
    });

    /**
     * Render claim templates
     */
    $http({
        url: API_URL+'workflow-templates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.wftemplate_list = data.results;
    });

    /**
     * Render workflow levels
     */
    $scope.render_wf_levels = function (index) {
        var template = $scope.new_objects['template_'+index];

        if (template) {
            $http({
                url: API_URL+'workflow-template-levels/?has_filtering=1&template='+template.id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.wf_levels[index] = data.results;
            });
        } else {
            $scope.wf_levels[index] = [];
        }
    }

    /**
     * Render levels
     */
    $http({
        url: API_URL+'levels/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.level_list = data.results;
    });
});

settingsApp.controller('workflowQueryController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.is_loading = true;
    $scope.wfquery_list = [];
    $scope.wftemplate_list = [];
    $scope.total_objects = 0;
    $scope.pagination = {current: 1};
    $scope.querytype_modal = {};
    $scope.query_level_list = [];

    var all_new_rows = [];

    $scope.add_new_query = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-query'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.querytype_modal.submit_querytype = function () {
        if ($scope.querytype_form.$valid) {
            /**
             * The AJAX Call to submit the modal form
             */
            var params = { title: $scope.querytype_modal.title };

            $http({
                url: API_URL+'workflow-query-types/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                window.location.reload();
            });
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'workflow-query/?template='+$scope.wf_template.id+'&page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.wfquery_list = data.results;
            $scope.total_objects = data.count;
            $scope.is_loading = false;
        });
    }

    $scope.pageChanged = function (newPage) {
        fetch_objects(newPage);
    }

    /**
     * Render claim templates
     */
    $http({
        url: API_URL+'workflow-templates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.wftemplate_list = data.results;
    });

    /**
     * Render workflow levels
     */
    $scope.render_levels = function () {
        if ($scope.wf_template) {
            fetch_objects(1);

            $http({
                url: API_URL+'workflow-template-levels/?query=1&template='+$scope.wf_template.id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.query_level_list = data.results;
            });

            $http({
                url: API_URL+'workflow-template-levels/?template='+$scope.wf_template.id,
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                $scope.resubmitto_level_list = [];

                for (var i = 0; i < data.results.length; i++) {
                    var level = data.results[i];

                    if (level.ordering > 1)
                        $scope.resubmitto_level_list.push(level);
                }
            });
        }
    }

    /**
     * Render workflow query types
     */
    $http({
        url: API_URL+'workflow-query-types/?show_all=1',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.querytype_list = data.results;
    });

    /**
     * Render workflow levels
     */
    $http({
        url: API_URL+'workflow-template-levels/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.wflevel_list = data.results;
    });

    /**
     * Submit newly added rows
     */
    $scope.submit = function () {
        var cleaned_data = [];

        $.each(all_new_rows, function () {
            var row         = $(this),
                level       = row.find('.query-level').val(),
                type        = row.find('.query-type').val(),
                resubmit_to = row.find('.query-resubmitto').val();

            if (level.length && type.length && resubmit_to.length) {
                cleaned_data.push({
                    level: level,
                    query_type: type,
                    resubmit_to: resubmit_to,
                    template: $scope.wf_template.id
                });
            }
        });

        for (var i = 0; i < cleaned_data.length; i++) {
            /**
             * The AJAX Call to submit the form
             */
            var data = {
                level: cleaned_data[i].level,
                query_type: cleaned_data[i].query_type,
                resubmit_to: cleaned_data[i].resubmit_to,
                template: cleaned_data[i].template
            }

            $http({
                url: API_URL+'workflow-query/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if (cleaned_data.length == i)
                    window.location.reload();
            });
        }
    }
});

settingsApp.controller('workflowReasonsController', function ($scope, $http, $q) {
    /**
     * Initial values
     */
    $scope.is_loading = true;
    $scope.reason_list = [];
    $scope.total_objects = 0;
    $scope.pagination = {current: 1};
    $scope.wf_levels = {};
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Render claim templates
     */
    $http({
        url: API_URL+'workflow-templates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.wftemplate_list = data.results;
    });

    /**
     * Render workflow levels
     */
    $scope.render_wf_levels = function (index) {
        var template = $scope.new_objects['template_'+index];

        if (template) {
            $http({
                url: API_URL+'workflow-template-levels/',
                method: 'GET',
                params: {
                    template: template.id,
                    exclude_claimant: true
                }
            })
            .success(function (data, status, headers, config) {
                $scope.wf_levels[index] = data.results;
            });
        } else {
            $scope.wf_levels[index] = [];
        }
    }

    /**
     * The AJAX Call to render objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'workflow-reasons/',
            method: 'GET',
            params: { page: page_number }
        })
        .success(function (data, status, headers, config) {
            $scope.reason_list = data.results;
            $scope.total_objects = data.count;
            $scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push(row_counter);
        row_counter++;
    }

    /**
     * Submit newly created rows
     */
    $scope.submit = function () {
        var promises = [];

        for (var i = 0; i < row_counter; i++) {
            var params = {
                code: $scope.new_objects['code_'+i],
                template: $scope.new_objects['template_'+i].id,
                level: $scope.new_objects['wf_level_'+i].id,
                description: $scope.new_objects['desc_'+i],
                reason: $scope.new_objects['reason_'+i]
            };

            promises[i] = $http({
                url: API_URL+'workflow-reasons/',
                method: 'POST',
                data: params
            });
        }

        $q.all(promises).then(function (resolutions) {
            // Data submission completed.
            window.location.reload();
        });
    }
});

settingsApp.controller('formDeclarationController', function ($scope, $http, $q) {
    /**
     * Initial values
     */
    $scope.is_loading = true;;
    $scope.wf_levels = {};
    $scope.new_forms = [];
    $scope.new_objects = [];

    /**
     * Insert/remove new form
     */
    var form_counter = 0;

    $scope.add_new_form = function () {
        $scope.new_forms.push(form_counter);
        form_counter++;
    }
    $scope.remove_new_form = function () {
        $scope.new_forms.splice(-1, 1);
        form_counter--;
    }

    /**
     * Submit newly created rows
     */
    $scope.submit = function () {
        var promises = [];

        for (var i = 0; i < form_counter; i++) {
            var params = {
                claim_type: $scope.new_objects['claim_type_'+i].id,
                level: $scope.new_objects['wf_level_'+i].id,
                content_en: $scope.new_objects['content_en_'+i],
                content_my: $scope.new_objects['content_my_'+i]
            };

            promises[i] = $http({
                url: API_URL+'form-declaration/',
                method: 'POST',
                data: params
            });
        }

        $q.all(promises).then(function (resolutions) {
            // Data submission completed.
            window.location.reload();
        });
    }

    /**
     * Render initial objects
     */
    $http({
        url: API_URL+'form-declaration/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.declaration_list = data.results;
        $scope.is_loading = false;
    });

    /**
     * Render claim types
     */
    $http({
        url: API_URL+'claim-types/',
        method: 'GET',
        params: { is_enabled: true }
    })
    .success(function (data, status, headers, config) {
        $scope.claimtype_list = data.results;
    });

    /**
     * Render workflow levels
     */
    $scope.render_wf_levels = function (index) {
        var claim_type = $scope.new_objects['claim_type_'+index];

        $http({
            url: API_URL+'workflow-templates/?claim_type='+claim_type.id,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            if (data.results.length) {
                $http({
                    url: API_URL+'workflow-template-levels/?template='+data.results[0].id,
                    method: 'GET'
                })
                .success(function (data, status, headers, config) {
                    $scope.wf_levels[index] = data.results;
                });
            }
        });
    }
});
