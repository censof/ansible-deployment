/**
 *  Settings Angular.js App
 */

var settingsApp = angular
    .module('settingsApp', ['validation', 'validation.rule', 'ngFileUpload',
                            'angularUtils.directives.dirPagination',
                            'angularSpinner', 'ui.bootstrap'])
    .config(httpInterceptor)
    .config(function ($httpProvider, $interpolateProvider) {
        $httpProvider.defaults.xsrfCookieName = 'csrftoken';
        $httpProvider.defaults.xsrfHeaderName = 'X-CSRFToken';
        $interpolateProvider.startSymbol('[[');
        $interpolateProvider.endSymbol(']]');
    });
