/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Claimant
 */

settingsApp.controller('claimantController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.claimant_scope = {};
    $scope.claimant_scope.is_loading = true;
    $scope.claimant_scope.claimant_list = [];
    $scope.claimant_scope.total_objects = 0;
    $scope.claimant_scope.pagination = {current: 1};
    $scope.claimant_scope.detail_url = URL_DETAIL;

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'claimants/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.claimant_scope.claimant_list = data.results;
            $scope.claimant_scope.total_objects = data.count;
            $scope.claimant_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('claimantFormController', function ($scope, $http, $q) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.claimant_form = {};
    $scope.claimant_form.submitted = false;
    $scope.claimant = {};
    $scope.level_list = [];
    $scope.spouse_list = [];
    $scope.children_list = [];
    $scope.update = UPDATE;

    $scope.new_spouse_forms = [];
    $scope.new_spouses = [];
    $scope.new_children_forms = [];
    $scope.new_children = [];

    /**
     * Functions to operate with spouse objects
     */
    var spouse_form_counter     = 0,
        children_form_counter   = 0;

    $scope.add_new_spouse = function () {
        $scope.new_spouse_forms.push(spouse_form_counter);
        spouse_form_counter++;
    }
    $scope.remove_new_spouse = function () {
        $scope.new_spouse_forms.splice(-1, 1);
        spouse_form_counter--;
    }
    $scope.delete_spouse = function ($event, id) {
        $http({
            url: API_URL+'claimant-spouses/'+id+'/',
            method: 'DELETE'
        })
        .success(function (data, status, headers, config) {
            var msg = "Are you sure you want to delete the spouse?";

            bootbox.confirm("<span class='text-danger'><i class='fa fa-exclamation-triangle fa-fw'></i> "+msg+"</span>", function (result) {
                if (result)
                    $($event.target).closest('tr').remove();
            });
        });
    }

    /**
     * Functions to operate with children objects
     */
    $scope.add_new_child = function () {
        $scope.new_children_forms.push(children_form_counter);
        children_form_counter++;
    }
    $scope.remove_new_child = function () {
        $scope.new_children_forms.splice(-1, 1);
        children_form_counter--;
    }
    $scope.delete_child = function ($event, id) {
        $http({
            url: API_URL+'claimant-children/'+id+'/',
            method: 'DELETE'
        })
        .success(function (data, status, headers, config) {
            var msg = "Are you sure you want to delete the child?";

            bootbox.confirm("<span class='text-danger'><i class='fa fa-exclamation-triangle fa-fw'></i> "+msg+"</span>", function (result) {
                if (result)
                    $($event.target).closest('tr').remove();
            });
        });
    }

    /**
     * Pre-fill form data in case of an update
     */
    if (UPDATE) {
        $scope.claimant.staff_no = PK;
        $('input.form-control, select.form-control').prop('disabled', true);

        $http({
            url: API_URL+'claimants/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.claimant = data;

            for (var i = 0; i < data.company_levels_data.length; i++) {
                var el = data.company_levels_data[i];

                set_initial_companylevel(el.level, el.code);
            }

            $('input.form-control, select.form-control').not('[name="staff_no"]').prop('disabled', false);
        });

        $http({
            url: API_URL+'claimant-spouses/',
            method: 'GET',
            params: { claimant: PK }
        })
        .success(function (data, status, headers, config) {
            $scope.spouse_list = data.results;
        });

        $http({
            url: API_URL+'claimant-children/',
            method: 'GET',
            params: { claimant: PK }
        })
        .success(function (data, status, headers, config) {
            $scope.children_list = data.results;
        });
    }

    /**
     * Initialize select box options
     */
    $http({
        url: API_URL+'levels/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.level_list = data.results;
    });

    /**
     * Helper functions
     */
    function set_initial_companylevel(level, code) {
        var selects = $('.select-company-level');

        $.each(selects, function () {
            if ($(this).data('label') == level)
                $(this).val(code);
        });
    }

    function submit_dependants(staff_no) {
        // Spouses
        var spouse_promises     = [],
            children_promises   = [];

        for (var i = 0; i < spouse_form_counter; i++) {
            var spouse_params = {
                staff: staff_no,
                name: $scope.new_spouses['name_'+i],
                ic: $scope.new_spouses['ic_'+i],
                grade: $scope.new_spouses['grade_'+i],
                position: $scope.new_spouses['position_'+i],
                basic_salary: $scope.new_spouses['basic_salary_'+i],
                employer_name: $scope.new_spouses['employer_name_'+i],
                address1: $scope.new_spouses['address1_'+i],
                address2: $scope.new_spouses['address2_'+i],
                address3: $scope.new_spouses['address3_'+i]
            };

            spouse_promises[i] = $http({
                url: API_URL+'claimant-spouses/',
                method: 'POST',
                data: spouse_params
            });
        }

        // Children
        for (var i = 0; i < children_form_counter; i++) {
            var child_params = {
                staff: staff_no,
                name: $scope.new_children['name_'+i],
                ic: $scope.new_children['ic_'+i],
                age: $scope.new_children['age_'+i],
                work_status: $scope.new_children['work_status_'+i],
                oku_status: $scope.new_children['oku_status_'+i],
                parent: $scope.new_children['parent_'+i].id
            };

            children_promises[i] = $http({
                url: API_URL+'claimant-children/',
                method: 'POST',
                data: child_params
            });
        }

        $q.all(spouse_promises).then(function (spouse_resolutions) {
            $q.all(children_promises).then(function (children_resolutions) {
                // Spouses and children data submission completed.
                window.location.href = URL_CLAIMANT_LIST;
            });
        });
    }

    /**
     * Submitting the form
     */
    $scope.submit = function () {
        var params = {
            staff_no: this.claimant.staff_no,
            name: this.claimant.name,
            ic: this.claimant.ic,
            married: this.claimant.married,
            email: this.claimant.email,
            address1: this.claimant.address1,
            address2: this.claimant.address2,
            address3: this.claimant.address3,
            address4: this.claimant.address4,
            resigned: this.claimant.resigned,
            is_admin: this.claimant.is_admin,

            basic_salary: this.claimant.basic_salary,
            salary_scheme: this.claimant.salary_scheme,
            salary_group: this.claimant.salary_group,
            grade_prefix: this.claimant.grade_prefix,
            grade_level_category: this.claimant.grade_level_category,
            position: this.claimant.position,

            bank_info: this.claimant.bank_info,
            company_levels: []
        };

        $('.select-company-level').each(function () {
            var level_pk = $(this).val();

            if ($.inArray(level_pk, params.company_levels) == -1)
                params.company_levels.push(level_pk);
        });

        if (UPDATE) {
            $http({
                url: API_URL+'claimants/'+this.claimant.staff_no+'/',
                method: 'PUT',
                data: params
            })
            .success(function (data, status, headers, config) {
                submit_dependants(data.staff_no);
            });
        } else {
            $http({
                url: API_URL+'claimants/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                submit_dependants(data.staff_no);
            });
        }
    }

    /**
     * Tabs
     */
    $scope.goto_tab = function (id) {
        $('.nav-tabs a').each(function () {
            if ($(this).attr('href') == id)
                $(this).trigger('click');
        });
        return false;
    }

    $http({
        url: API_URL+'companylevels/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        var objects = {},
            selects = $('.select-company-level');

        for (var i = 0; i < data.results.length; i++) {
            var el      = data.results[i],
                level   = el.level.title;

            if (objects.hasOwnProperty(level)) {
                if ($.inArray(el, objects[level]) == -1)
                    objects[level].push(el);
            } else {
                objects[level] = [el];
            }
        }

        $.each(selects, function () {
            // Populate options in a select box
            var is_empty = true;

            for (var key in objects) {
                if (objects.hasOwnProperty(key) && key == $(this).data('label')) {
                    for (var i = 0; i < objects[key].length; i++) {
                        $(this).append("<option value='"+objects[key][i].code+"'>"+objects[key][i].title+"</option>");
                        is_empty = false;
                    }
                }
            }

            if (is_empty)
                $(this).closest('.form-group').remove();
        });

        if (UPDATE) {
            // Set initial option in acompany level select boxes
            $http({
                url: API_URL+'claimants/'+PK+'/',
                method: 'GET'
            })
            .success(function (data, status, headers, config) {
                for (var i = 0; i < data.company_levels_data.length; i++) {
                    var el = data.company_levels_data[i];

                    set_initial_companylevel(el.level, el.code);
                }
            });
        }
    });
});

settingsApp.controller('claimantDetailController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.claimant_scope = {};
    $scope.claimant_scope.is_loading = true;

    /**
     * Initialize select box options
     */
    $http({
        url: API_URL+'claimants/'+PK+'/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.claimant_scope.claimant = data;
        $scope.claimant_scope.is_loading = false;
    });

    /**
     * Get spouse information
     */
    $http({
        url: API_URL+'claimant-spouses/?claimant='+PK,
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.claimant_scope.spouses = data.results;
    });

    /**
     * Get children information
     */
    $http({
        url: API_URL+'claimant-children/?claimant='+PK,
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.claimant_scope.children = data.results;
    });
});
