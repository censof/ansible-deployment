/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Salary
 */

settingsApp.controller('salaryGroupController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.group_scope = {};
    $scope.group_scope.is_loading = true;
    $scope.group_scope.group_list = [];
    $scope.group_scope.total_objects = 0;
    $scope.group_scope.pagination = {current: 1};

    var all_new_rows = [];

    $scope.add_new_group = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-group'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

     $scope.submit = function () {
        if ($scope.group_form.$valid) {
            var cleaned_data = [];

            $.each(all_new_rows, function () {
                var row  = $(this),
                    code = row.find('.group-code').val(),
                    desc = row.find('.group-description').val();

                if (code.length && desc.length) {
                    cleaned_data.push({
                        code: code,
                        description: desc
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    code: cleaned_data[i].code,
                    description: cleaned_data[i].description
                }
                $http({
                    url: API_URL+'salary-groups/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'salary-groups/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.group_scope.group_list = data.results;
            $scope.group_scope.total_objects = data.count;
            $scope.group_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('salarySchemeController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.scheme_scope = {};
    $scope.scheme_scope.is_loading = true;
    $scope.scheme_scope.scheme_list = [];
    $scope.scheme_scope.total_objects = 0;
    $scope.scheme_scope.pagination = {current: 1};

    var all_new_rows = [];

    $scope.add_new_scheme = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-scheme'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit = function () {
        if ($scope.scheme_form.$valid) {
            var cleaned_data = [];

            $.each(all_new_rows, function () {
                var row  = $(this),
                    code = row.find('.scheme-code').val(),
                    desc = row.find('.scheme-description').val();

                if (code.length && desc.length) {
                    cleaned_data.push({
                        code: code,
                        description: desc
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    code: cleaned_data[i].code,
                    description: cleaned_data[i].description
                }

                $http({
                    url: API_URL+'salary-schemes/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'salary-schemes/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.scheme_scope.scheme_list = data.results;
            $scope.scheme_scope.total_objects = data.count;
            $scope.scheme_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('salaryGradeController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.grade_scope = {};
    $scope.grade_scope.is_loading = true;
    $scope.grade_scope.grade_list = [];
    $scope.grade_scope.total_objects = 0;
    $scope.grade_scope.pagination = {current: 1};

    var all_new_rows = [];

    $scope.add_new_grade = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-grade'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit = function () {
        if ($scope.grade_form.$valid) {
            var cleaned_data = [];

            $.each(all_new_rows, function () {
                var row  = $(this),
                    code = row.find('.grade-code').val(),
                    desc = row.find('.grade-description').val(),
                    type = row.find('.grade-code-type').val();

                if (code.length && desc.length && type.length) {
                    cleaned_data.push({
                        code: code,
                        description: desc,
                        code_type: type
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    code: cleaned_data[i].code,
                    description: cleaned_data[i].description,
                    code_type: cleaned_data[i].code_type
                }

                $http({
                    url: API_URL+'salary-grades/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'salary-grades/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.grade_scope.grade_list = data.results;
            $scope.grade_scope.total_objects = data.count;
            $scope.grade_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('positionController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.position_scope = {};
    $scope.position_scope.is_loading = true;
    $scope.position_scope.position_list = [];
    $scope.position_scope.total_objects = 0;
    $scope.position_scope.pagination = {current: 1};

    var all_new_rows = [];

    $scope.add_new_position = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-position'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit = function () {
        if ($scope.position_form.$valid) {
            var cleaned_data = [];

            $.each(all_new_rows, function () {
                var row  = $(this),
                    code = row.find('.position-code').val(),
                    desc = row.find('.position-description').val();

                if (code.length && desc.length) {
                    cleaned_data.push({
                        code: code,
                        description: desc
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    code: cleaned_data[i].code,
                    description: cleaned_data[i].description
                }

                $http({
                    url: API_URL+'positions/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'positions/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.position_scope.position_list = data.results;
            $scope.position_scope.total_objects = data.count;
            $scope.position_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});
