/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Admin Page
 */

settingsApp.controller('expenseController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.expense_scope = {};
    $scope.expense_scope.is_loading = true;
    $scope.expense_scope.expense_list = [];
    $scope.expense_scope.total_objects = 0;
    $scope.expense_scope.pagination = {current: 1};

    var all_new_rows = [];

    $scope.add_new_expense = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-expense'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);

        /**
         * Display claim types
         */
        var ngSelect2 = new_row.find('.ng-select2');

        ngSelect2.select2();
        ngSelect2.select2().on('change', function () {
            new_row.find('.country-code').html($(this).val());
        });
    }

    $scope.submit = function () {
        if ($scope.expense_form.$valid) {
            var cleaned_data = [];

            $.each(all_new_rows, function () {
                var row         = $(this),
                    title       = row.find('.expense-title').val(),
                    type_code   = row.find('.expense-type-code').val(),
                    claim_type  = row.find('.expense-claim-type').val(),
                    acc_code    = row.find('.expense-account-code').val();

                if (title.length && type_code.length && acc_code.length) {
                    cleaned_data.push({
                        title: title,
                        claim_type: claim_type,
                        type_code: type_code,
                        account_code: acc_code
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    title: cleaned_data[i].title,
                    type_code: cleaned_data[i].type_code,
                    claim_type: cleaned_data[i].claim_type,
                    account_code: cleaned_data[i].account_code,
                }

                $http({
                    url: API_URL+'expenses/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'expenses/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.expense_scope.expense_list = data.results;
            $scope.expense_scope.total_objects = data.count;
            $scope.expense_scope.is_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    }

    /**
     * The first call
     */
    fetch_objects(1);
});

settingsApp.controller('configSetupController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.config_form = {};
    $scope.config_form.is_loading = true;
    $scope.config_form.configObjects = [];
    $scope.section_list = [];

    function filterBySection(section_obj) {
        var filtered_obj = [];
        for (var i=0; i<section_obj.length; i++) {
            if (section_obj[i]== $scope.filter_model) {
                filtered_obj.push(section_obj[i]);
            }
        }
        return filtered_obj;
    }

    $scope.filter = function(){
        $scope.config_form.configObjects = $scope.section_list;
        $scope.config_form.configObjects = filterBySection($scope.config_form.configObjects);
    }

    $http({
        url: API_URL+'config-set/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.config_form.configObjects = data.results;
        $scope.config_form.is_loading = false;
        $scope.section_list = data.results;
    });
});

settingsApp.controller('gstTaxController', function ($scope, $http) {
    /**
     * Initial values
     */
    $scope.gstTax_form = {};
    $scope.gstTax_form.gstTax_list = [];
    $scope.gstTax_form.is_loading = true;

    var all_new_rows = [];

    $scope.add_new_tax = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-tax'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_gst_tax = function () {
        if ($scope.gstTax_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                code = row.find('.gst-code').val(),
                rate = row.find('.gst-rate').val(),
                description = row.find('.gst-description').val();

                if (code.length) {
                    var data = {
                        code : code,
                        rate : rate,
                        description : description
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'gst-tax/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'gst-tax/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.gstTax_form.gstTax_list = data.results;
        $scope.gstTax_form.is_loading = false;
    });
});
