/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Entitlement Setup
 */

settingsApp.controller('DateCtrl', function ($scope, $filter) {

    /*************** DatePicker Start ***************/
    $scope.today = function() {
        $scope.transferDate = new Date();
    };

    $scope.open = function($event) {
        $scope.status.opened = true;
    };

    $scope.setDate = function(year, month, day) {
        $scope.transferDate = new Date(year, month, day);
    };

    $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };

    $scope.formats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'yyyy-MM-dd', 'dd.MM.yyyy', 'shortDate'];
    $scope.format = $scope.formats[0];

    $scope.status = {
        opened: false
    };

    /*************** DatePicker End ***************/
});

settingsApp.controller('houseMovingEntitlementClassController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.houseEntitlement_form = {};
    $scope.houseEntitlement_form.houseEntitlement_list = [];
    $scope.houseEntitlement_form.salaryGroup_list = [];
    $scope.houseEntitlement_form.salaryGrade_list = [];
    $scope.houseEntitlement_loading = true;
    $scope.salaryGroup_loading = true;
    $scope.salaryGrade_loading = true;
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push(row_counter);
        row_counter++;
    }

    $scope.submit_houseEntitlement = function () {
        var promises = [];

        for (var i = 0; i < row_counter; i++) {
            var params = {
                effective_date   : getDateStr($filter, $scope.new_objects['effectiveDate_'+i]),
                ssm_salary_group : $scope.new_objects['salaryGroup_'+i],
                ssm_grade_from   : $scope.new_objects['gradeFrom_'+i],
                ssm_grade_to     : $scope.new_objects['gradeTo_'+i],
                ssm_salary_from  : $scope.new_objects['salaryFrom_'+i],
                ssm_salary_to    : $scope.new_objects['salaryTo_'+i]
            };

            promises[i] = $http({
                url: API_URL+'house-moving-entitlement/',
                method: 'POST',
                data: params
            });
        }

        $q.all(promises).then(function (resolutions) {
            // Data submission completed.
            window.location.reload();
        });
    }

    $http({
        url: API_URL+'house-moving-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.houseEntitlement_form.houseEntitlement_list = data.results;
        $scope.houseEntitlement_loading = false;
    });

    $http({
        url: API_URL+'salary-groups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.houseEntitlement_form.salaryGroup_list = data.results;
        $scope.salaryGroup_loading = false;
    });

    $http({
        url: API_URL+'salary-grades/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.houseEntitlement_form.salaryGrade_list = data.results;
        $scope.salaryGrade_loading = false;
    });
});

settingsApp.controller('houseMovingRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.houseMovingRate_form = {};
    $scope.houseMovingRate_form.houseMovingRate_list = [];
    $scope.entitlement_list_rate = [];
    $scope.houseMovingRate_form.total_objects = 0;
    $scope.houseMovingRate_form.pagination = {current: 1};
    $scope.houseMovingRate_loading = true;

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'house-moving-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.houseMovingRate_form.houseMovingRate_list = data.results;
            $scope.houseMovingRate_form.total_objects = data.count;
            $scope.houseMovingRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_house_moving_rate = function () {
        if ($scope.houseMovingRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                hmClaim_entitlement = row.find('.hmClaim-entitlement').val(),
                region              = row.find('.region-rate-add').val(),
                single_rate         = row.find('.single-rate-add').val(),
                married_rate        = row.find('.married-rate-add').val();

                if (hmClaim_entitlement.length) {
                    var data = {
                        entitlement : parseInt(hmClaim_entitlement),
                        region         : region,
                        single         : single_rate,
                        married        : married_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'house-moving-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'house-moving-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.houseMovingRate_form.houseMovingRate_list = data.results;
        $scope.houseMovingRate_loading = false;
    });

    $http({
        url: API_URL+'house-moving-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.entitlement_list_rate = data.results;
    });
});

settingsApp.controller('transferWithinStateEntitlementClassController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.transferWithinStateEntitlement_form = {};
    $scope.transferWithinStateEntitlement_form.is_loading = true;
    $scope.transferWithinStateEntitlement_form.houseEntitlement_list = [];
    $scope.transferWithinStateEntitlement_form.salaryGroup_list = [];
    $scope.transferWithinStateEntitlement_form.salaryGrade_list = [];
    $scope.transferWithinStateEntitlement_form.transferWithinStateEntitlement_list = [];
    $scope.transferWithinStateEntitlement_loading = true;
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push(row_counter);
        row_counter++;
    }

    $scope.submit_transferWithinStateEntitlement = function () {
        var promises = [];

        for (var i = 0; i < row_counter; i++) {
            var params = {
                effective_date   : getDateStr($filter, $scope.new_objects['effectiveDate_'+i]),
                ssm_salary_group : $scope.new_objects['salaryGroup_'+i],
                ssm_grade_from   : $scope.new_objects['gradeFrom_'+i],
                ssm_grade_to     : $scope.new_objects['gradeTo_'+i],
                ssm_salary_from  : $scope.new_objects['salaryFrom_'+i],
                ssm_salary_to    : $scope.new_objects['salaryTo_'+i]
            };

            promises[i] = $http({
                url: API_URL+'transfer-within-state-entitlement/',
                method: 'POST',
                data: params
            });
        }

        $q.all(promises).then(function (resolutions) {
            // Data submission completed.
            window.location.reload();
        });
    }

    $http({
        url: API_URL+'transfer-within-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transferWithinStateEntitlement_form.transferWithinStateEntitlement_list = data.results;
        $scope.transferWithinStateEntitlement_loading = false;
    });

    $http({
        url: API_URL+'salary-groups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transferWithinStateEntitlement_form.salaryGroup_list = data.results;
    });

    $http({
        url: API_URL+'salary-grades/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transferWithinStateEntitlement_form.salaryGrade_list = data.results;
    });
	
	$scope.getEntitlementByID = function(id){
        var objSelect = $filter("filter")($scope.transferWithinStateEntitlement_form.transferWithinStateEntitlement_list, {id:id});
        return objSelect[0];
    };
});

settingsApp.controller('westMalaysiaRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.westMalaysiaRate_form = {};
    $scope.westMalaysiaRate_form.westMalaysiaRate_list = [];
    $scope.westMalaysiaRate_loading = true;
    $scope.west_malaysia_entitlement_list_rate = [];
    $scope.westMalaysiaRate_form.total_objects = 0;
    $scope.westMalaysiaRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'west-malaysia-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.westMalaysiaRate_form.westMalaysiaRate_list = data.results;
            $scope.westMalaysiaRate_form.total_objects = data.count;
            $scope.westMalaysiaRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_west_malaysia = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-west-malaysia'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.westMalaysiaRate_form.westMalaysiaRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_wm = id;
        $scope.data_update.entitlement_wm = entitlement;
        $scope.data_update.rate_single_wm = single;
        $scope.data_update.rate_married_wm = married;
        $scope.data_update.rate_miscellaneous_wm = miscellaneous;

        $('#westMalaysiaUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_wm.id,
            single: $scope.data_update.rate_single_wm,
            married: $scope.data_update.rate_married_wm,
            miscellaneous: $scope.data_update.rate_miscellaneous_wm
        };
        $http({
            url: API_URL+'west-malaysia-transfer-allowance/'+$scope.data_update.id_wm+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };
	
    $scope.submit_west_malaysia_rate = function () {
        if ($scope.westMalaysiaRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                wmClaim_entitlement  = row.find('.wmClaim-entitlement').val(),
                single_rate          = row.find('.single-rate-add').val(),
                married_rate         = row.find('.married-rate-add').val(),
                miscellaneous_rate   = row.find('.miscellaneous-rate-add').val();

                if (wmClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(wmClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'west-malaysia-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'west-malaysia-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.westMalaysiaRate_form.westMalaysiaRate_list = data.results;
        $scope.westMalaysiaRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-within-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.west_malaysia_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('sarawakRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.sarawakRate_form = {};
    $scope.sarawakRate_form.sarawakRate_list = [];
    $scope.sarawakRate_loading = true;
    $scope.sarawak_entitlement_list_rate = [];
    $scope.sarawakRate_form.total_objects = 0;
    $scope.sarawakRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'sarawak-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.sarawakRate_form.sarawakRate_list = data.results;
            $scope.sarawakRate_form.total_objects = data.count;
            $scope.sarawakRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_sarawak = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-sarawak'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.sarawakRate_form.sarawakRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_srw = id;
        $scope.data_update.entitlement_srw = entitlement;
        $scope.data_update.rate_single_srw = single;
        $scope.data_update.rate_married_srw = married;
        $scope.data_update.rate_miscellaneous_srw = miscellaneous;

        $('#sarawakUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_srw.id,
            single: $scope.data_update.rate_single_srw,
            married: $scope.data_update.rate_married_srw,
            miscellaneous: $scope.data_update.rate_miscellaneous_srw
        };
        $http({
            url: API_URL+'sarawak-transfer-allowance/'+$scope.data_update.id_srw+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };
	
    $scope.submit_sarawak_rate = function () {
        if ($scope.sarawakRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                srwClaim_entitlement  = row.find('.srwClaim-entitlement').val(),
                single_rate           = row.find('.single-rate-add').val(),
                married_rate          = row.find('.married-rate-add').val(),
                miscellaneous_rate    = row.find('.miscellaneous-rate-add').val();

                if (srwClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(srwClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'sarawak-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'sarawak-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.sarawakRate_form.sarawakRate_list = data.results;
        $scope.sarawakRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-within-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.sarawak_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('sabahRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.sabahRate_form = {};
    $scope.sabahRate_form.sabahRate_list = [];
    $scope.sabahRate_loading = true;
    $scope.sabah_entitlement_list_rate = [];
    $scope.sabahRate_form.total_objects = 0;
    $scope.sabahRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'sabah-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.sabahRate_form.sabahRate_list = data.results;
            $scope.sabahRate_form.total_objects = data.count;
            $scope.sabahRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_sabah = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-sabah'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.sabahRate_form.sabahRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_sbh = id;
        $scope.data_update.entitlement_sbh = entitlement;
        $scope.data_update.rate_single_sbh = single;
        $scope.data_update.rate_married_sbh = married;
        $scope.data_update.rate_miscellaneous_sbh = miscellaneous;

        $('#sabahUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_sbh.id,
            single: $scope.data_update.rate_single_sbh,
            married: $scope.data_update.rate_married_sbh,
            miscellaneous: $scope.data_update.rate_miscellaneous_sbh
        };
        $http({
            url: API_URL+'sabah-transfer-allowance/'+$scope.data_update.id_sbh+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };
	
    $scope.submit_sabah_rate = function () {
        if ($scope.sabahRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                sbhClaim_entitlement  = row.find('.sbhClaim-entitlement').val(),
                single_rate           = row.find('.single-rate-add').val(),
                married_rate          = row.find('.married-rate-add').val(),
                miscellaneous_rate    = row.find('.miscellaneous-rate-add').val();

                if (sbhClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(sbhClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'sabah-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'sabah-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.sabahRate_form.sabahRate_list = data.results;
        $scope.sabahRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-within-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.sabah_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('transferBetweenStateEntitlementClassController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.transferBetweenStateEntitlement_form = {};
    $scope.transferBetweenStateEntitlement_form.is_loading = true;
    $scope.transferBetweenStateEntitlement_form.houseEntitlement_list = [];
    $scope.transferBetweenStateEntitlement_form.salaryGroup_list = [];
    $scope.transferBetweenStateEntitlement_form.salaryGrade_list = [];
    $scope.transferBetweenStateEntitlement_form.transferBetweenStateEntitlement_list = [];
    $scope.transferBetweenStateEntitlement_loading = true;
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push(row_counter);
        row_counter++;
    }

    $scope.submit_transferBetweenStateEntitlement = function () {
        var promises = [];

        for (var i = 0; i < row_counter; i++) {
            var params = {
                effective_date   : getDateStr($filter, $scope.new_objects['effectiveDate_'+i]),
                ssm_salary_group : $scope.new_objects['salaryGroup_'+i],
                ssm_grade_from   : $scope.new_objects['gradeFrom_'+i],
                ssm_grade_to     : $scope.new_objects['gradeTo_'+i],
                ssm_salary_from  : $scope.new_objects['salaryFrom_'+i],
                ssm_salary_to    : $scope.new_objects['salaryTo_'+i]
            };

            promises[i] = $http({
                url: API_URL+'transfer-between-state-entitlement/',
                method: 'POST',
                data: params
            });
        }

        $q.all(promises).then(function (resolutions) {
            // Data submission completed.
            window.location.reload();
        });
    }

    $http({
        url: API_URL+'transfer-between-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transferBetweenStateEntitlement_form.transferBetweenStateEntitlement_list = data.results;
        $scope.transferBetweenStateEntitlement_loading = false;
    });

    $http({
        url: API_URL+'salary-groups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transferBetweenStateEntitlement_form.salaryGroup_list = data.results;
    });

    $http({
        url: API_URL+'salary-grades/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.transferBetweenStateEntitlement_form.salaryGrade_list = data.results;
    });
	
	$scope.getEntitlementByID = function(id){
        var objSelect = $filter("filter")($scope.transferBetweenStateEntitlement_form.transferBetweenStateEntitlement_list, {id:id});
        return objSelect[0];
    };
});

settingsApp.controller('fromWestMalaysiaRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.fromWestMalaysiaRate_form = {};
    $scope.fromWestMalaysiaRate_form.fromWestMalaysiaRate_list = [];
    $scope.fromWestMalaysiaRate_loading = true;
    $scope.from_west_malaysia_entitlement_list_rate = [];
    $scope.fromWestMalaysiaRate_form.total_objects = 0;
    $scope.fromWestMalaysiaRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'from-west-malaysia-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.fromWestMalaysiaRate_form.fromWestMalaysiaRate_list = data.results;
            $scope.fromWestMalaysiaRate_form.total_objects = data.count;
            $scope.fromWestMalaysiaRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_from_west_malaysia = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-from-west-malaysia'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }
	
	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.fromWestMalaysiaRate_form.fromWestMalaysiaRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_fwm = id;
        $scope.data_update.entitlement_fwm = entitlement;
        $scope.data_update.rate_single_fwm = single;
        $scope.data_update.rate_married_fwm = married;
        $scope.data_update.rate_miscellaneous_fwm = miscellaneous;

        $('#fromWestMalaysiaUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_fwm.id,
            single: $scope.data_update.rate_single_fwm,
            married: $scope.data_update.rate_married_fwm,
            miscellaneous: $scope.data_update.rate_miscellaneous_fwm
        };
        $http({
            url: API_URL+'from-west-malaysia-transfer-allowance/'+$scope.data_update.id_fwm+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit_from_west_malaysia_rate = function () {
        if ($scope.fromWestMalaysiaRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                fwmClaim_entitlement  = row.find('.fwmClaim-entitlement').val(),
                single_rate           = row.find('.single-rate-add').val(),
                married_rate          = row.find('.married-rate-add').val(),
                miscellaneous_rate    = row.find('.miscellaneous-rate-add').val();

                if (fwmClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(fwmClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'from-west-malaysia-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'from-west-malaysia-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.fromWestMalaysiaRate_form.fromWestMalaysiaRate_list = data.results;
        $scope.fromWestMalaysiaRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-between-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.from_west_malaysia_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('fromSarawakRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.fromSarawakRate_form = {};
    $scope.fromSarawakRate_form.fromSarawakRate_list = [];
    $scope.fromSarawakRate_loading = true;
    $scope.from_sarawak_entitlement_list_rate = [];
    $scope.fromSarawakRate_form.total_objects = 0;
    $scope.fromSarawakRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'from-sarawak-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.fromSarawakRate_form.fromSarawakRate_list = data.results;
            $scope.fromSarawakRate_form.total_objects = data.count;
            $scope.fromSarawakRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_from_sarawak = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-from-sarawak'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }
	
	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.fromSarawakRate_form.fromSarawakRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_fsrw = id;
        $scope.data_update.entitlement_fsrw = entitlement;
        $scope.data_update.rate_single_fsrw = single;
        $scope.data_update.rate_married_fsrw = married;
        $scope.data_update.rate_miscellaneous_fsrw = miscellaneous;

        $('#fromSarawakUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_fsrw.id,
            single: $scope.data_update.rate_single_fsrw,
            married: $scope.data_update.rate_married_fsrw,
            miscellaneous: $scope.data_update.rate_miscellaneous_fsrw
        };
        $http({
            url: API_URL+'from-sarawak-transfer-allowance/'+$scope.data_update.id_fsrw+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit_from_sarawak_rate = function () {
        if ($scope.fromSarawakRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                fsrwClaim_entitlement  = row.find('.fsrwClaim-entitlement').val(),
                single_rate            = row.find('.single-rate-add').val(),
                married_rate           = row.find('.married-rate-add').val(),
                miscellaneous_rate     = row.find('.miscellaneous-rate-add').val();

                if (fsrwClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(fsrwClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'from-sarawak-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'from-sarawak-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.fromSarawakRate_form.fromSarawakRate_list = data.results;
        $scope.fromSarawakRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-between-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.from_sarawak_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('fromSabahRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.fromSabahRate_form = {};
    $scope.fromSabahRate_form.fromSabahRate_list = [];
    $scope.fromSabahRate_loading = true;
    $scope.from_sabah_entitlement_list_rate = [];
    $scope.fromSabahRate_form.total_objects = 0;
    $scope.fromSabahRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'from-sarawak-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.fromSabahRate_form.fromSabahRate_list = data.results;
            $scope.fromSabahRate_form.total_objects = data.count;
            $scope.fromSabahRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_from_sabah = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-from-sabah'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.fromSabahRate_form.fromSabahRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_fsbh = id;
        $scope.data_update.entitlement_fsbh = entitlement;
        $scope.data_update.rate_single_fsbh = single;
        $scope.data_update.rate_married_fsbh = married;
        $scope.data_update.rate_miscellaneous_fsbh = miscellaneous;

        $('#fromSabahUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_fsbh.id,
            single: $scope.data_update.rate_single_fsbh,
            married: $scope.data_update.rate_married_fsbh,
            miscellaneous: $scope.data_update.rate_miscellaneous_fsbh
        };
        $http({
            url: API_URL+'from-sabah-transfer-allowance/'+$scope.data_update.id_fsbh+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };
	
    $scope.submit_from_sabah_rate = function () {
        if ($scope.fromSabahRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                fsbhClaim_entitlement  = row.find('.fsbhClaim-entitlement').val(),
                single_rate            = row.find('.single-rate-add').val(),
                married_rate           = row.find('.married-rate-add').val(),
                miscellaneous_rate     = row.find('.miscellaneous-rate-add').val();

                if (fsbhClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(fsbhClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'from-sabah-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'from-sabah-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.fromSabahRate_form.fromSabahRate_list = data.results;
        $scope.fromSabahRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-between-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.from_sabah_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('betweenSabahSarawakRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.betweenSabahSarawakRate_form = {};
    $scope.betweenSabahSarawakRate_form.betweenSabahSarawakRate_list = [];
    $scope.betweenSabahSarawakRate_loading = true;
    $scope.between_sabah_sarawak_entitlement_list_rate = [];
    $scope.betweenSabahSarawakRate_form.total_objects = 0;
    $scope.betweenSabahSarawakRate_form.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'between-sabah-sarawak-transfer-allowance/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.betweenSabahSarawakRate_form.betweenSabahSarawakRate_list = data.results;
            $scope.betweenSabahSarawakRate_form.total_objects = data.count;
            $scope.betweenSabahSarawakRate_loading = false;
        });
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };

    var all_new_rows = [];

    $scope.add_new_rate_between_sabah_sarawak = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate-between-sabah-sarawak'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }
	
	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.betweenSabahSarawakRate_form.betweenSabahSarawakRate_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var single = curr_obj.single;
        var married = curr_obj.married;
        var miscellaneous = curr_obj.miscellaneous;

        $scope.data_update.id_btwss = id;
        $scope.data_update.entitlement_btwss = entitlement;
        $scope.data_update.rate_single_btwss = single;
        $scope.data_update.rate_married_btwss = married;
        $scope.data_update.rate_miscellaneous_btwss = miscellaneous;

        $('#betweenSabahSarawakUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            entitlement: $scope.data_update.entitlement_btwss.id,
            single: $scope.data_update.rate_single_btwss,
            married: $scope.data_update.rate_married_btwss,
            miscellaneous: $scope.data_update.rate_miscellaneous_btwss
        };
        $http({
            url: API_URL+'between-sabah-sarawak-transfer-allowance/'+$scope.data_update.id_btwss+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit_between_sabah_sarawak_rate = function () {
        if ($scope.betweenSabahSarawakRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                btwssClaim_entitlement  = row.find('.btwssClaim-entitlement').val(),
                single_rate             = row.find('.single-rate-add').val(),
                married_rate            = row.find('.married-rate-add').val(),
                miscellaneous_rate      = row.find('.miscellaneous-rate-add').val();

                if (btwssClaim_entitlement.length) {
                    var data = {
                        entitlement     : parseInt(btwssClaim_entitlement),
                        single          : single_rate,
                        married         : married_rate,
                        miscellaneous   : miscellaneous_rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'between-sabah-sarawak-transfer-allowance/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'between-sabah-sarawak-transfer-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.betweenSabahSarawakRate_form.betweenSabahSarawakRate_list = data.results;
        $scope.betweenSabahSarawakRate_loading = false;
    });

    $http({
        url: API_URL+'transfer-between-state-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.between_sabah_sarawak_entitlement_list_rate = data.results;
    });
});

settingsApp.controller('localTravelEntitlementSetupController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.localTravelEntitlement_form = {};
    $scope.localTravelEntitlement_form.is_loading = true;
    $scope.localTravelEntitlement_form.salaryGroup_list = [];
    $scope.localTravelEntitlement_form.salaryGrade_list = [];
    $scope.localTravelEntitlement_form.inMalaysiaEntitlement_list = [];
    $scope.regionList = [];
    $scope.courseLocationList = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push({row_counter:row_counter});
        row_counter++;
    };

    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                effective_date: getDateStr($filter, obj.effectiveDate),
                ssm_salary_group: obj.salaryGroup.code,
                ssm_grade_from: obj.salaryGradeFrom.code,
                ssm_grade_to: obj.salaryGradeTo.code,
                ssm_salary_from: obj.salaryFrom,
                ssm_salary_to: obj.salaryTo
            };

            $http({
                url: API_URL+'in-malaysia-entitlement/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };

    $http({
        url: API_URL+'in-malaysia-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.localTravelEntitlement_form.inMalaysiaEntitlement_list = data.results;
        $scope.localTravelEntitlement_form.is_loading = false;
    });

    $http({
        url: '/eclaim/masterfiles/region-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.regionList = data;
    });

    $http({
        url: '/eclaim/masterfiles/course-location-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.courseLocationList = data;
    });

    $http({
        url: API_URL+'salary-groups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.localTravelEntitlement_form.salaryGroup_list = data.results;
    });

    $http({
        url: API_URL+'salary-grades/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.localTravelEntitlement_form.salaryGrade_list = data.results;
    });

    $scope.getEntitlementByID = function(id){
        var objSelect = $filter("filter")($scope.localTravelEntitlement_form.inMalaysiaEntitlement_list, {id:id});
        return objSelect[0];
    };

    $scope.getRegionByCode = function(code){
        var objSelect = $filter("filter")($scope.regionList, {code:code});
        return objSelect[0];
    };

    $scope.getCourseLocationByCode = function(code){
        var objSelect = $filter("filter")($scope.courseLocationList, {code:code});
        return objSelect[0];
    };
});

settingsApp.controller('officialDutyTripRateController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.officialDutyTripRate_form = {};
    $scope.officialDutyTripRate_form.is_loading = true;
    $scope.officialDutyTripRate_form.rates_list = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    $http({
        url: API_URL+'offduty-trip-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.officialDutyTripRate_form.rates_list = data.results;
        $scope.officialDutyTripRate_form.is_loading = false;
    });

    /**
     * Insert new row
     */
    $scope.add_new_row = function () {
        $scope.new_rows.push({});
    };

    /**
     * Set update form
     **/
    $scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.officialDutyTripRate_form.rates_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var meal = curr_obj.meal;
        var hotel = curr_obj.hotel;
        var lodging = curr_obj.lodging;
        var region = $scope.getRegionByCode(curr_obj.region);

        $scope.data_update.id = id;
        $scope.data_update.entitlement = entitlement;
        $scope.data_update.rate_meal = meal;
        $scope.data_update.rate_hotel = hotel;
        $scope.data_update.rate_lodging = lodging;
        $scope.data_update.region = region;

        $('#offDutyTripUpdateForm').modal('show');
    };

    /**
     * Update database
     **/
    $scope.update = function(){
        var data = {
            entitlement: $scope.data_update.entitlement.id,
            meal: $scope.data_update.rate_meal,
            hotel: $scope.data_update.rate_hotel,
            lodging: $scope.data_update.rate_lodging,
            region: $scope.data_update.region.code
        };
        $http({
            url: API_URL+'offduty-trip-allowance/'+$scope.data_update.id,
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                entitlement: obj.entitlement.id,
                hotel: obj.rate_hotel,
                lodging: obj.rate_lodging,
                meal: obj.rate_meal,
                region: obj.region.code
            };

            $http({
                url: API_URL+'offduty-trip-allowance/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };
});

settingsApp.controller('courseTripRateController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.courseTripRate_form = {};
    $scope.courseTripRate_form.is_loading = true;
    $scope.courseTripRate_form.rates_list = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    $scope.add_new_row = function () {
        $scope.new_rows.push({});
    };

    $http({
        url: API_URL+'course-trip-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.courseTripRate_form.rates_list = data.results;
        $scope.courseTripRate_form.is_loading = false;
    });

    /**
     * Set update form
     **/
    $scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.courseTripRate_form.rates_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var meal = curr_obj.meal;
        var hotel = curr_obj.hotel;
        var lodging = curr_obj.lodging;
        var region = $scope.getRegionByCode(curr_obj.region);

        $scope.data_update.id = id;
        $scope.data_update.entitlement = entitlement;
        $scope.data_update.rate_meal = meal;
        $scope.data_update.rate_hotel = hotel;
        $scope.data_update.rate_lodging = lodging;
        $scope.data_update.region = region;

        $('#courseTripRateUpdateForm').modal('show');
    };

    /**
     * Update database
     **/
    $scope.update = function(){
        var data = {
            entitlement: $scope.data_update.entitlement.id,
            meal: $scope.data_update.rate_meal,
            hotel: $scope.data_update.rate_hotel,
            lodging: $scope.data_update.rate_lodging,
            region: $scope.data_update.region.code
        };
        $http({
            url: API_URL+'course-trip-allowance/'+$scope.data_update.id,
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                entitlement: obj.entitlement.id,
                hotel: obj.rate_hotel,
                lodging: obj.rate_lodging,
                meal: obj.rate_meal,
                region: obj.region.code
            };

            $http({
                url: API_URL+'course-trip-allowance/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };
});

settingsApp.controller('courseDailyRateController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.courseDailyRate_form = {};
    $scope.courseDailyRate_form.is_loading = true;
    $scope.courseDailyRate_form.rates_list = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    $http({
        url: API_URL+'course-daily-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.courseDailyRate_form.rates_list = data.results;
        $scope.courseDailyRate_form.is_loading = false;
    });

    /**
     * Insert new row
     */
    $scope.add_new_row = function () {
        $scope.new_rows.push({});
    };

    /**
     * Set update form
     **/
    $scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.courseDailyRate_form.rates_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var long_term = curr_obj.long_term;
        var short_term = curr_obj.short_term;
        var part_time = curr_obj.part_time;
        var meal_aid = curr_obj.meal_aid;
        var transport_aid = curr_obj.transport_aid;
        var course_location = $scope.getCourseLocationByCode(curr_obj.course_location);

        $scope.data_update.id = id;
        $scope.data_update.entitlement = entitlement;
        $scope.data_update.rate_long_term = long_term;
        $scope.data_update.rate_short_term = short_term;
        $scope.data_update.rate_part_time = part_time;
        $scope.data_update.rate_meal_aid = meal_aid;
        $scope.data_update.rate_transport_aid = transport_aid;
        $scope.data_update.course_location = course_location;

        $('#courseDailyRateUpdateForm').modal('show');
    };

    /**
     * Update database
     **/
    $scope.update = function(){
        var data = {
            entitlement: $scope.data_update.entitlement.id,
            long_term: $scope.data_update.rate_long_term,
            short_term: $scope.data_update.rate_short_term,
            part_time: $scope.data_update.rate_part_time,
            meal_aid: $scope.data_update.rate_meal_aid,
            transport_aid: $scope.data_update.rate_transport_aid,
            course_location: $scope.data_update.course_location.code
        };
        $http({
            url: API_URL+'course-daily-allowance/'+$scope.data_update.id,
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                entitlement: obj.entitlement.id,
                long_term: obj.rate_long_term,
                short_term: obj.rate_short_term,
                part_time: obj.rate_part_time,
                meal_aid: obj.rate_meal_aid,
                transport_aid: obj.rate_transport_aid,
                course_location: obj.course_location.code
            };

            $http({
                url: API_URL+'course-daily-allowance/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };
});

settingsApp.controller('overseaTravelEntitlementSetupController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.overseaTravelEntitlement_form = {};
    $scope.overseaTravelEntitlement_form.is_loading = true;
    $scope.overseaTravelEntitlement_form.salaryGroup_list = [];
    $scope.overseaTravelEntitlement_form.salaryGrade_list = [];
    $scope.overseaTravelEntitlement_form.overseaEntitlement_list = [];
    $scope.regionList = [];
    $scope.courseLocationList = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    var row_counter = 0;

    $scope.add_new_row = function () {
        $scope.new_rows.push({row_counter:row_counter});
        row_counter++;
    };

    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                effective_date: getDateStr($filter, obj.effectiveDate),
                ssm_salary_group: obj.salaryGroup.code,
                ssm_grade_from: obj.salaryGradeFrom.code,
                ssm_grade_to: obj.salaryGradeTo.code,
                ssm_salary_from: obj.salaryFrom,
                ssm_salary_to: obj.salaryTo
            };

            $http({
                url: API_URL+'oversea-entitlement/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };

    $http({
        url: API_URL+'oversea-entitlement/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.overseaTravelEntitlement_form.overseaEntitlement_list = data.results;
        $scope.overseaTravelEntitlement_form.is_loading = false;
    });

    $http({
        url: '/eclaim/masterfiles/region-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.regionList = data;
    });

    $http({
        url: '/eclaim/masterfiles/course-location-list/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.courseLocationList = data;
    });

    $http({
        url: API_URL+'salary-groups/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.overseaTravelEntitlement_form.salaryGroup_list = data.results;
    });

    $http({
        url: API_URL+'salary-grades/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.overseaTravelEntitlement_form.salaryGrade_list = data.results;
    });

    $scope.getEntitlementByID = function(id){
        var objSelect = $filter("filter")($scope.overseaTravelEntitlement_form.overseaEntitlement_list, {id:id});
        return objSelect[0];
    };

    $scope.getRegionByCode = function(code){
        var objSelect = $filter("filter")($scope.regionList, {code:code});
        return objSelect[0];
    };

    $scope.getCourseLocationByCode = function(code){
        var objSelect = $filter("filter")($scope.courseLocationList, {code:code});
        return objSelect[0];
    };
});

settingsApp.controller('officialDutyTripOverseaRateController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.officialDutyTripOverseaRate_form = {};
    $scope.officialDutyTripOverseaRate_form.is_loading = true;
    $scope.officialDutyTripOverseaRate_form.rates_list = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    $http({
        url: API_URL+'offduty-trip-oversea-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.officialDutyTripOverseaRate_form.rates_list = data.results;
        $scope.officialDutyTripOverseaRate_form.is_loading = false;
    });

    /**
     * Insert new row
     */
    $scope.add_new_row = function () {
        $scope.new_rows.push({});
    };

    /**
     * Set update form
     **/
    $scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.officialDutyTripOverseaRate_form.rates_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var meal = curr_obj.meal;
        var hotel = curr_obj.hotel;
        var lodging = curr_obj.lodging;

        $scope.data_update.id = id;
        $scope.data_update.entitlement = entitlement;
        $scope.data_update.rate_meal = meal;
        $scope.data_update.rate_hotel = hotel;
        $scope.data_update.rate_lodging = lodging;

        $('#offDutyTripOverseaUpdateForm').modal('show');
    };

    /**
     * Update database
     **/
    $scope.update = function(){
        var data = {
            entitlement: $scope.data_update.entitlement.id,
            meal: $scope.data_update.rate_meal,
            hotel: $scope.data_update.rate_hotel,
            lodging: $scope.data_update.rate_lodging
        };
        $http({
            url: API_URL+'offduty-trip-oversea-allowance/'+$scope.data_update.id,
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };

    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                entitlement: obj.entitlement.id,
                hotel: obj.rate_hotel,
                lodging: obj.rate_lodging,
                meal: obj.rate_meal
            };

            $http({
                url: API_URL+'offduty-trip-oversea-allowance/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };
});

settingsApp.controller('courseTripOverseaRateController', function ($scope, $http, $q, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.courseTripOverseaRate_form = {};
    $scope.courseTripOverseaRate_form.is_loading = true;
    $scope.courseTripOverseaRate_form.rates_list = [];
    $scope.new_rows = [];
    $scope.new_objects = [];

    /**
     * Insert new row
     */
    $scope.add_new_row = function () {
        $scope.new_rows.push({});
    };

    $http({
        url: API_URL+'course-trip-oversea-allowance/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.courseTripOverseaRate_form.rates_list = data.results;
        $scope.courseTripOverseaRate_form.is_loading = false;
    });

    /**
     * Set update form
     **/
    $scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.courseTripOverseaRate_form.rates_list[index];
        var id = curr_obj.id;
        var entitlement = $scope.getEntitlementByID(curr_obj.entitlement);
        var meal = curr_obj.meal;
        var hotel = curr_obj.hotel;
        var lodging = curr_obj.lodging;

        $scope.data_update.id = id;
        $scope.data_update.entitlement = entitlement;
        $scope.data_update.rate_meal = meal;
        $scope.data_update.rate_hotel = hotel;
        $scope.data_update.rate_lodging = lodging;

        $('#courseTripOverseaRateUpdateForm').modal('show');
    };

    /**
     * Update data
     **/
    $scope.update = function(){
        var data = {
            entitlement: $scope.data_update.entitlement.id,
            meal: $scope.data_update.rate_meal,
            hotel: $scope.data_update.rate_hotel,
            lodging: $scope.data_update.rate_lodging
        };
        $http({
            url: API_URL+'course-trip-oversea-allowance/'+$scope.data_update.id,
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };
    
    /**
     * Create new data
     **/
    $scope.submit = function () {
        var count = 0;

        $scope.new_rows.forEach(function(obj){
            count++;
            var data = {
                entitlement: obj.entitlement.id,
                hotel: obj.rate_hotel,
                lodging: obj.rate_lodging,
                meal: obj.rate_meal
            };

            $http({
                url: API_URL+'course-trip-oversea-allowance/',
                method: 'POST',
                data: data
            })
            .success(function (data, status, headers, config) {
                if ($scope.new_rows.length == count) {window.location.reload();}
            });
        });
    };
});
