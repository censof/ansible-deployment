/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Company Setup
 */

settingsApp.controller('companySetupController', function ($scope, $http) {
    /**
     * Set initial value for a select box
     */
    if (LEVEL_ID.length)
        $scope.ordering = LEVEL_ID;

    $scope.jump_to_level = function () {
        if ($scope.ordering)
            window.location.href = URL_COMPANY_SETUP+'?level='+$scope.ordering;
    }

    /**
     * Company information modal box
     */
    $scope.info = {};
    $scope.modal_loading = true;

    $scope.open_modal = function (code) {
        $http({
            url: API_URL+'companylevels/'+code+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $('#info-modal').modal('show');
            if (data.companylevelinfo) {
                var _id = data.companylevelinfo.id;
                $scope.info.company_level = code;
                $http({
                    url: API_URL+'companylevel-info/'+_id+'/',
                    method: 'GET'
                })
                .success(function (info_data, status, headers, config) {
                    $scope.info = info_data;
                    $scope.modal_loading = false;
                });
            } else {
                $scope.info = { company_level: code };
                $scope.modal_loading = false;
            }
        });
    }

    $scope.submit_modal = function () {
        var _url    = API_URL+'companylevel-info/',
            _method = 'POST';

        if ($scope.info.id) {
            _url += $scope.info.id + '/';
            _method = 'PUT';
        }
        $http({
            url: _url,
            method: _method,
            data: $scope.info
        })
        .success(function (data, status, headers, config) {
            $scope.modal_loading = true;
            window.location.reload();
        });
    }
});
