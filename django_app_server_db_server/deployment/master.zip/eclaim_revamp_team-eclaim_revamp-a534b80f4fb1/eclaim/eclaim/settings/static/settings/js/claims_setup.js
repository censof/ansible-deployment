/**
 * Django App: settings
 * Module:     settingsApp
 * Page:       Claims Setup
 */

settingsApp.controller('countrySetupController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.country_form = {};
    $scope.country_form.is_loading = true;
    $scope.country_form.country_list = [];
    $scope.category = [];

    var all_new_rows = [];

    $scope.add_new_country = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-country'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);

        /**
         * Display country code
         */
        var ngSelect2 = new_row.find('.ng-select2');

        ngSelect2.select2().on('change', function () {
            new_row.find('.country-code').html($(this).val());
        });
    }

    $scope.submit_countries = function () {
        if ($scope.country_form.$valid) {
            $.each(all_new_rows, function () {
                var row         = $(this),
                    country     = row.find('.ng-select2').val(),
                    category    = row.find('.country-category').val();

                if (country.length && category.length) {
                    var data = {
                        country: country,
                        category: category
                    };

                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'countries/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $scope.submit_category = function () {
        if ($scope.category_form.$valid) {
            /**
             * The AJAX Call to submit the form
             */
            var params = { title: $scope.category.title };

            $http({
                url: API_URL+'country-categories/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                window.location.reload();
            });
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    $http({
        url: API_URL+'countries/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.country_form.country_list = data.results;
        $scope.country_form.is_loading = false;
    });

    $http({
        url: API_URL+'country-categories/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.country_form.category_list = data.results;
    });
});

settingsApp.controller('categoryRateController', function ($scope, $http, $filter) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.category_rate_form = {};
    $scope.category_rate_form.is_loading = true;
    $scope.category_rate_form.category_list = [];
    var all_new_rows = [];

    $scope.add_new_category_rate = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-category-rate'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

	$scope.edit_item = function(index){
        $scope.data_update = {};

        var curr_obj = $scope.category_rate_form.category_list[index];
		var name = $scope.getEntitlementByName(curr_obj.category_name);
        //var name = curr_obj.category_name;
        var duty_meal = curr_obj.duty_meal;
        var duty_hotel = curr_obj.duty_hotel;
        var duty_lodging = curr_obj.duty_lodging;
        var course_meal = curr_obj.course_meal;
        var course_hotel = curr_obj.course_hotel;
        var course_lodging = curr_obj.course_lodging;

        //$scope.data_update.id_srw = id;
        $scope.data_update.category_rate = name;
        $scope.data_update.category_rate_duty_meal = duty_meal;
        $scope.data_update.category_rate_duty_hotel = duty_hotel;
        $scope.data_update.category_rate_duty_lodging = duty_lodging;
        $scope.data_update.category_rate_course_meal = course_meal;
        $scope.data_update.category_rate_course_hotel = course_hotel;
        $scope.data_update.category_rate_course_lodging = course_lodging;

        $('#categoryRateUpdateForm').modal('show');
    };
	
	/**
     * Update database
     **/
    $scope.update = function() {
        var data = {
            category: $scope.data_update.category_rate.category,
            duty_meal: $scope.data_update.category_rate_duty_meal,
            duty_hotel: $scope.data_update.category_rate_duty_hotel,
            duty_lodging: $scope.data_update.category_rate_duty_lodging,
            course_meal: $scope.data_update.category_rate_course_meal,
            course_hotel: $scope.data_update.category_rate_course_hotel,
            course_lodging: $scope.data_update.category_rate_course_lodging
        };
        $http({
            url: API_URL+'category-rates/'+$scope.data_update.category_rate.id+'/',
            method: 'PUT',
            data: data
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    };
	
    $scope.submit_category_rates = function () {
        if ($scope.category_rate_form.$valid) {
            $.each(all_new_rows, function () {
                var row         = $(this),
                    category    = row.find('.category').val();
					duty_meal 		= row.find('.duty_meal').val(),
					duty_hotel 		= row.find('.duty_hotel').val();
					duty_lodging 	= row.find('.duty_lodging').val();
					course_meal 	= row.find('.course_meal').val(),
					course_hotel 	= row.find('.course_hotel').val();
					course_lodging 	= row.find('.course_lodging').val();

                if (category.length && duty_meal.length && duty_hotel.length && duty_lodging.length && course_meal.length && course_hotel.length && course_lodging.length) {
                    var data = {
						category		:	category,
						duty_meal		:	duty_meal,
						duty_hotel		:	duty_hotel,
						duty_lodging	:	duty_lodging,
						course_meal		:	course_meal,
						course_hotel	:	course_hotel,
						course_lodging	:	course_lodging
					};
					
					/**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'category-rates/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
	$http({
        url: API_URL+'category-rates/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.category_rate_form.category_list = data.results;
        $scope.category_rate_form.is_loading = false;
    });
	$scope.getEntitlementByName = function(name){
        var objSelect = $filter("filter")($scope.category_rate_form.category_list, {category_name:name});
        return objSelect[0];
    };
});

settingsApp.controller('currencyCodeController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.currency_code_form = {};
    $scope.currency_code_form.is_loading = true;
    $scope.currency_code_form.currency_list = [];
    var all_new_rows = [];

    $scope.add_new_currency = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-currency'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);

        /**
         * Display currency code
         */
        var ngSelect2 = new_row.find('.ng-select2');

        ngSelect2.select2().on('change', function () {
            new_row.find('.currency-code').html($(this).val());
        });
    }

    $scope.submit_currency_codes = function () {
        if ($scope.currency_code_form.$valid) {
            $.each(all_new_rows, function () {
                var row         = $(this),
                    currency    = row.find('.ng-select2').val();

                if (currency.length) {
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'currencies/',
                        method: 'POST',
                        data: {currency: currency}
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    /**
     * The AJAX Call to render initial objects
     */
    $http({
        url: API_URL+'currencies/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.currency_code_form.currency_list = data.results;
        $scope.currency_code_form.is_loading = false;
    });
});

settingsApp.controller('currencyRateController', function ($scope, $http, Upload, $timeout) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.rate_scope = {};
    $scope.rate_scope.is_loading = true;
    $scope.rate_scope.is_uploading = false;
    $scope.rate_scope.rate_list = [];
    $scope.rate_scope.total_objects = 0;
    $scope.rate_scope.pagination = {current: 1};

    /**
     * The first call
     */
    fetch_objects(1);

    /**
     * The AJAX Call to render initial objects
     */
    function fetch_objects(page_number) {
        $http({
            url: API_URL+'currency-rates/?page='+page_number,
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.rate_scope.rate_list = data.results;
            $scope.rate_scope.total_objects = data.count;
            $scope.rate_scope.is_loading = false;
        });
    }

    $scope.uploadCSV = function(file, errFiles) {
        $scope.rate_scope.is_uploading = true;
        $scope.f = file;
        $scope.errFile = errFiles && errFiles[0];
        if (file) {
            file.upload = Upload.upload({
                url: URL_AJAX_IMPORT_CURRENCY_RATE_CSV,
                data: {file: file}
            }).success(function (fdata, fstatus, fheaders, fconfig) {
                //$scope.rate_scope.is_uploading = false;
                window.location.reload();
            });;

            file.upload.then(function (response) {
                $timeout(function () {
                    file.result = response.data;
                });
            }, function (response) {
                if (response.status > 0)
                    $scope.errorMsg = response.status + ': ' + response.data;
            }, function (evt) {
                file.progress = Math.min(100, parseInt(100.0 * evt.loaded / evt.total));
            });
        }
    }

    $scope.pageChanged = function(newPage) {
        fetch_objects(newPage);
    };
});

settingsApp.controller('fundTypeController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.fund_type_form = {};
    $scope.fund_type_form.is_loading = true;
    $scope.fund_type_form.fundType_list = [];
    $scope.updateFundType = {};

    var all_new_rows = [];

    $scope.add_new_fundType = function () {
        /**
         * Insert new row
         */
        var row     = $('#add_new_fundType'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_fund_types = function () {
        if ($scope.fund_type_form.$valid) {
            var cleaned_data = [];
            $.each(all_new_rows, function () {
                var row         = $(this),
                    code        = row.find('.group-code').val(),
                    description = row.find('.group-description').val(),
                    is_project  = row.find('.group-is_project').is(':checked'),
                    sequence    = row.find('.group-sequence').val();
                    policy      = row.find('.group-policy').val();
                if (code.length) {
                    cleaned_data.push({
                        code: code,
                        description: description,
                        is_project: is_project,
                        sequence: sequence,
                        policy: policy
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                        code: cleaned_data[i].code,
                        description: cleaned_data[i].description,
                        sequence: cleaned_data[i].sequence,
                        policy: cleaned_data[i].policy
                }
                if (cleaned_data[i].is_project) {
                    data.is_project = true;
                } else {
                    data.is_project = false;
                }
                $http({
                    url: API_URL+'fund-type/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    $scope.getToUpdate = function(indx){
        $('#fund-update').modal('show');
        $scope.updateFundType.code = $scope.fund_type_form.fundType_list[indx].code;
        $scope.updateFundType.description = $scope.fund_type_form.fundType_list[indx].description;
        $scope.updateFundType.isproject = $scope.fund_type_form.fundType_list[indx].is_project;
        $scope.updateFundType.sequence = $scope.fund_type_form.fundType_list[indx].sequence;
        $scope.updateFundType.policy = $scope.fund_type_form.fundType_list[indx].policy;
    }

    $scope.update_fundType = function(indx){
        fundTypeObj = {
            code : $scope.updateFundType.code,
            description : $scope.updateFundType.description,
            isproject : $scope.updateFundType.isproject,
            sequence : $scope.updateFundType.sequence,
            policy: $scope.updateFundType.policy
        }
        $http({
            url: '',
            method: 'POST',
            data: fundTypeObj
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    }

    function fetch_objects() {
        $http({
            url: API_URL+'fund-type/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.fund_type_form.fundType_list = data.results;
            $scope.fund_type_form.is_loading = false;
        });
    }
    fetch_objects();
});

settingsApp.controller('bankController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.bank_form = {};
    $scope.bank_form.is_loading = true;
    $scope.bank_form.bank_list = [];
    $scope.updateBank = {};

    var all_new_rows = [];

    $scope.add_new_bank = function () {
        /**
         * Insert new row
         */
        var row     = $('#add_new_bank'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_bank = function () {
        if ($scope.bank_form.$valid) {
            var cleaned_data = [];
            $.each(all_new_rows, function () {
                var row         = $(this),
                    name        = row.find('.group-name').val(),
                    code        = row.find('.group-code').val();
                if (code.length && name.length) {
                    cleaned_data.push({
                        name: name,
                        code: code
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                        name: cleaned_data[i].name,
                        code: cleaned_data[i].code
                }
                $http({
                    url: API_URL+'bank/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    $scope.getToUpdate = function(indx){
        $('#bank-update').modal('show');
        $scope.updateBank.bank_code = $scope.bank_form.bank_list[indx].code;
        $scope.updateBank.bank_name = $scope.bank_form.bank_list[indx].name;
    }

    $scope.update_bank = function(indx){
        bankObj = {
            code : $scope.updateBank.bank_code,
            name : $scope.updateBank.bank_name
        }
        $http({
            url: '',
            method: 'POST',
            data: bankObj
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    }

    function fetch_objects() {
        $http({
            url: API_URL+'bank/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.bank_form.bank_list = data.results;
            $scope.bank_form.is_loading = false;
        });
    }
    fetch_objects();
});

settingsApp.controller('miscellaneousTypeController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.miscellaneousType_form = {};
    $scope.miscellaneousType_form.is_loading = true;
    $scope.miscellaneousType_form.miscellaneousType_list = [];
    $scope.updateMisc = {};

    var all_new_rows = [];

    $scope.add_new_miscellaneousType = function () {
        /**
         * Insert new row
         */
        var row     = $('#add_new_miscellaneousType'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_miscellaneousType = function () {
        if ($scope.miscellaneousType_form.$valid) {
            var cleaned_data = [];
            $.each(all_new_rows, function () {
                var row            = $(this),
                    code           = row.find('.group-code').val(),
                    claim_type     = row.find('.group-claim-type').val(),
                    description    = row.find('.group-description').val(),
                    rate           = row.find('.group-rate').val(),
                    limit_claim       = row.find('.group-limit-claim').val(),
                    exp_code       = row.find('.group-exp-code').val(),
                    active         = row.find('.group-active').is(':checked');
                if (code.length) {
                    cleaned_data.push({
                        code: code,
                        claim_type: claim_type,
                        description: description,
                        rate: rate,
                        //check_per_year: check_per_year,
                        limit_claim: limit_claim,
                        exp_code: exp_code,
                        active: active
                    });
                }
            });

            for (var i = 0; i < cleaned_data.length; i++) {
                /**
                 * The AJAX Call to submit the form
                 */
                var data = {
                    code: cleaned_data[i].code,
                    claim_type: cleaned_data[i].claim_type,
                    description: cleaned_data[i].description,
                    rate: cleaned_data[i].rate,
                    limit_claim: cleaned_data[i].limit_claim,
                    exp_code: cleaned_data[i].exp_code,
                    active: cleaned_data[i].active
                }
                $http({
                    url: API_URL+'miscellaneous-type/',
                    method: 'POST',
                    data: data
                })
                .success(function (data, status, headers, config) {
                    if (cleaned_data.length == i)
                        window.location.reload();
                });
            }
        }
    }

    $scope.getToUpdate = function(indx){
        $('#misc-update').modal('show');
        $scope.updateMisc.code = $scope.miscellaneousType_form.miscellaneousType_list[indx].code;
        $scope.updateMisc.exp_code = $scope.miscellaneousType_form.miscellaneousType_list[indx].exp_code;
        $scope.updateMisc.claim_type = $scope.miscellaneousType_form.miscellaneousType_list[indx].claim_type;
        $scope.updateMisc.description = $scope.miscellaneousType_form.miscellaneousType_list[indx].description;
        $scope.updateMisc.rate = $scope.miscellaneousType_form.miscellaneousType_list[indx].rate;
        $scope.updateMisc.limit_claim = $scope.miscellaneousType_form.miscellaneousType_list[indx].limit_claim;
        $scope.updateMisc.active = $scope.miscellaneousType_form.miscellaneousType_list[indx].active;
    }

    $scope.update_misc = function(indx){
        miscObj = {
            code : $scope.updateMisc.code,
            exp_code : $scope.updateMisc.exp_code,
            claim_type : $scope.updateMisc.claim_type,
            description : $scope.updateMisc.description,
            rate : $scope.updateMisc.rate,
            limit_claim : $scope.updateMisc.limit_claim,
            active : $scope.updateMisc.active
        }
        $http({
            url: '',
            method: 'POST',
            data: miscObj
        })
        .success(function (data, status, headers, config) {
            window.location.reload();
        });
    }

    function fetch_objects() {
        $http({
            url: API_URL+'miscellaneous-type/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.miscellaneousType_form.miscellaneousType_list = data.results;
            $scope.miscellaneousType_form.is_loading = false;
        });
    }
    fetch_objects();
});

settingsApp.controller('mileageClassController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.mileClass_form = {};
    $scope.mileClass_form.is_loading = true;
    $scope.mileClass_form.mileClass_list = [];
    $scope.mileClass_form.mileClassName_list = [];
    $scope.className_form = {};

    var all_new_rows = [];

    $scope.add_new_mileClass = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-mileClass'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_mileClass = function () {
        if ($scope.mileClass_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                mileClassName = row.find('.mileClass-Name').val(),
                salaryFrom    = row.find('.salary-from').val(),
                salaryTo      = row.find('.salary-to').val(),
                ccFrom        = row.find('.cc-from').val(),
                ccTo          = row.find('.cc-to').val();

                if (mileClassName.length) {
                    var data = {
                        mileage_class_name : mileClassName,
                        salary_from    : salaryFrom,
                        salary_to      : salaryTo,
                        cc_from        : ccFrom,
                        cc_to          : ccTo
                    };

                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'mileage-class/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $scope.submit_class_name = function () {
        if ($scope.className_form.$valid) {
            /**
             * The AJAX Call to submit the form
             */
            var params = { mclass: $scope.className_form.mclass.$viewValue};

            $http({
                url: API_URL+'mileage-class-name/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                window.location.reload();
            });
        }
    }

    $http({
        url: API_URL+'mileage-class/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileClass_form.mileClass_list = data.results;
        $scope.mileClass_form.is_loading = false;
    });

    $http({
        url: API_URL+'mileage-class-name/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileClass_form.mileClassName_list = data.results;
    });
});

settingsApp.controller('mileageRangeController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.mileRange_form = {};
    $scope.mileRange_form.mileRange_list = [];
    $scope.mileRange_form.is_loading = true;

    var all_new_rows = [];

    $scope.add_new_range = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-range'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_mile_range = function () {
        if ($scope.mileRange_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                distance_min = row.find('.min-distance').val(),
                distance_max = row.find('.max-distance').val();

                if (distance_min.length && distance_max.length) {
                    var data = {
                        distance_min : distance_min,
                        distance_max : distance_max
                    };

                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'mileage-range/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'mileage-range/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileRange_form.mileRange_list = data.results;
        $scope.mileRange_form.is_loading = false;
    });
});

settingsApp.controller('mileageRateController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.mileRate_form = {};
    $scope.mileRate_form.mileRate_list = [];
    $scope.mileRate_form.is_loading = true;
    $scope.mileClass_list_rate = [];
    $scope.mileRange_list_rate = [];

    var all_new_rows = [];

    $scope.add_new_rate = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-rate'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_mile_rate = function () {
        if ($scope.mileRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this),
                mClaim_range = row.find('.mClaim-range').val(),
                mClaim_class = row.find('.mClaim-class').val(),
                rate         = row.find('.rate-add').val();

                if (mClaim_range.length && mClaim_class.length) {
                    var data = {
                        mileage_claim_range : parseInt(mClaim_range),
                        mileage_claim_class : parseInt(mClaim_class),
                        rate         : rate
                    };
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'mileage-rate/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $http({
        url: API_URL+'mileage-rate/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileRate_form.mileRate_list = data.results;
        $scope.mileRate_form.is_loading = false;
    });

    $http({
        url: API_URL+'mileage-range/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileRange_list_rate = data.results;
    });

    $http({
        url: API_URL+'mileage-class/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.mileClass_list_rate = data.results;
    });
});

settingsApp.controller('petrolController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.petrolRate_form = {};
    $scope.typeName_form = {};
    $scope.petrolRate_form.petrolRate_list = [];
    $scope.petrolRate_form.petrolType_list = [];
    $scope.rateList= [];
    $scope.is_loading = true;

    var all_new_rows = [];

    $scope.add_new_petrolRate = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-petrolRate'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_petrolRate = function () {
        if ($scope.petrolRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this);
                for(i=0; i<$scope.petrolRate_form.petrolType_list.length; i++)
                {
                    var petrol_type = $scope.petrolRate_form.petrolType_list[i],
                    date            = row.find('.petrol-rate-date').val(),
                    rate            = row.find('.get-rate[data-index="'+i+'"]').val();

                    var data = {
                        petrol_type : petrol_type.id,
                        date    : date,
                        rate      : rate,
                    }
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'petrol-rate/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $scope.submit_type_name = function () {
        if ($scope.typeName_form.$valid) {
            /**
             * The AJAX Call to submit the form
             */
            var params = { name: $scope.typeName_form.name.$viewValue};

            $http({
                url: API_URL+'petrol-type/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                window.location.reload();
            });
        }
    }

    function groupByDate(){

        var rateList = [];
        var group_by_date = [];
        var date = $scope.petrolRate_form.petrolRate_list[0].date;

        for (var i=0; i<$scope.petrolRate_form.petrolRate_list.length; i++)
        {
            if($scope.petrolRate_form.petrolRate_list[i].date == date){
                rateList.push($scope.petrolRate_form.petrolRate_list[i])
            }
            else{
                group_by_date.push(rateList);
                rateList = [];
                date = $scope.petrolRate_form.petrolRate_list[i].date;
                rateList.push($scope.petrolRate_form.petrolRate_list[i]);
            }
        }
        group_by_date.push(rateList);

        return group_by_date;
    }

    function addRateToType(groupededByDate){
        var list = [];
        list.push(groupededByDate[0].date);
        var j=0;
        for (var i=0; i<$scope.petrolRate_form.petrolType_list.length; i++){
            if(groupededByDate[j].petrol_type == $scope.petrolRate_form.petrolType_list[i].id){
                list.push(groupededByDate[j].rate)
                if(j<groupededByDate.length-1)
                    j++;
            }
            else{
                list.push('--');
            }
        }
        return list;
    }

    function groupByType(group_by_date){
        var rateListed = [];
        for(var i=0; i<group_by_date.length; i++){
            rateListed.push(addRateToType(group_by_date[i]));
        }
        return rateListed;
    }

    $http({
        url: API_URL+'petrol-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.petrolRate_form.petrolType_list = data.results;
    });

    $http({
        url: API_URL+'petrol-rate/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.petrolRate_form.petrolRate_list = data.results;
        $scope.is_loading = false;

        var group_by_date = groupByDate();
        $scope.rateList = groupByType(group_by_date);
    });
});

settingsApp.controller('vehicleController', function ($scope, $http) {
    /**
     * Initial values
     */
    $http.defaults.cache = false;
    $scope.vehicleRate_form = {};
    $scope.typeName_form = {};
    $scope.vehicleRate_form.vehicleRate_list = [];
    $scope.vehicleRate_form.vehicleType_list = [];
    $scope.rateList = [];
    $scope.is_loading = true;

    var all_new_rows = [];

    $scope.add_new_vehicleRate = function () {
        /**
         * Insert new row
         */
        var row     = $('#add-new-vehicleRate'),
            new_row = angular.copy(row);

        row.before(new_row);
        new_row.removeAttr('id').removeAttr('class');
        all_new_rows.push(new_row);
    }

    $scope.submit_vehicleRate = function () {
        if ($scope.vehicleRate_form.$valid) {
            $.each(all_new_rows, function () {
                var row       = $(this);
                for(i=0; i<$scope.vehicleRate_form.vehicleType_list.length; i++)
                {
                    var vehicle_type = $scope.vehicleRate_form.vehicleType_list[i],
                    date            = row.find('.vehicle-rate-date').val(),
                    rate            = row.find('.get-rate[data-index="'+i+'"]').val();

                    var data = {
                        vehicle_type : vehicle_type.id,
                        date    : date,
                        rate      : rate,
                    }
                    /**
                     * The AJAX Call to submit the form
                     */
                    $http({
                        url: API_URL+'vehicle-rate/',
                        method: 'POST',
                        data: data
                    })
                    .success(function (data, status, headers, config) {
                        window.location.reload();
                    });
                }
            });
        }
    }

    $scope.submit_type_name = function () {
        if ($scope.typeName_form.$valid) {
            /**
             * The AJAX Call to submit the form
             */
            var params = { name: $scope.typeName_form.name.$viewValue};

            $http({
                url: API_URL+'vehicle-type/',
                method: 'POST',
                data: params
            })
            .success(function (data, status, headers, config) {
                window.location.reload();
            });
        }
    }

    function groupByDate(){

        var rateList = [];
        var group_by_date = [];
        var date = $scope.vehicleRate_form.vehicleRate_list[0].date;

        for (var i=0; i<$scope.vehicleRate_form.vehicleRate_list.length; i++)
        {
            if($scope.vehicleRate_form.vehicleRate_list[i].date == date){
                rateList.push($scope.vehicleRate_form.vehicleRate_list[i])
            }
            else{
                group_by_date.push(rateList);
                rateList = [];
                date = $scope.vehicleRate_form.vehicleRate_list[i].date;
                rateList.push($scope.vehicleRate_form.vehicleRate_list[i]);
            }
        }
        group_by_date.push(rateList);

        return group_by_date;
    }

    function addRateToType(groupededByDate){
        var list = [];
        list.push(groupededByDate[0].date);
        var j=0;
        for (var i=0; i<$scope.vehicleRate_form.vehicleType_list.length; i++){
            if(groupededByDate[j].vehicle_type == $scope.vehicleRate_form.vehicleType_list[i].id){
                list.push(groupededByDate[j].rate)
                if(j<groupededByDate.length-1)
                    j++;
            }
            else{
                list.push('--');
            }
        }
        return list;
    }

    function groupByType(group_by_date){
        var rateListed = [];
        for(var i=0; i<group_by_date.length; i++){
            rateListed.push(addRateToType(group_by_date[i]));
        }
        return rateListed;
    }

    $http({
        url: API_URL+'vehicle-type/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.vehicleRate_form.vehicleType_list = data.results;
    });

    $http({
        url: API_URL+'vehicle-rate/',
        method: 'GET'
    })
    .success(function (data, status, headers, config) {
        $scope.vehicleRate_form.vehicleRate_list = data.results;
        $scope.is_loading = false;

        var group_by_date = groupByDate();
        $scope.rateList = groupByType(group_by_date);
    });
});
