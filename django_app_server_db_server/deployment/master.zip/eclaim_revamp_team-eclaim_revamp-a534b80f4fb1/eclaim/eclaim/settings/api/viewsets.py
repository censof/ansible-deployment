from django.db.models import Q, Max
from rest_framework import viewsets
from rest_framework.authentication import (
    SessionAuthentication, BasicAuthentication)
from eclaim.libs.viewsets import ModelViewSetMessagesMixin
from eclaim.masterfiles.models.company import CompanyLevel
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.entitlement import *
from eclaim.masterfiles.models.misc import *
from .serializers import *
from ..models import *


# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LevelViewSet',
    'CountryCategoryViewSet',
    'CountryViewSet',
    'CurrencyViewSet',
    'CurrencyRateViewSet',
    'FundTypeViewSet',
    'BankViewSet',
    'ExpenseViewSet',
    'MiscellaneousTypeViewSet',
    'MileageClassNameViewSet',
    'MileageClassViewSet',
    'MileageRangeViewSet',
    'MileageRateViewSet',
    'ConfigSetViewSet',
    'PetrolTypeViewSet',
    'PetrolRateViewSet',
    'VehicleTypeViewSet',
    'VehicleRateViewSet',
    'GSTTaxViewSet',
    'UserGroupViewSet',
    'WorkflowTemplateViewSet',
    'WorkflowTemplateLevelViewSet',
    'WorkflowTemplateDetailsViewSet',
    'WorkflowStatusViewSet',
    'WorkflowQueryViewSet',
    'WorkflowQueryTypeViewSet',
    'AssigneeViewSet',
    'SelectionFilteringViewSet',
    'WorkflowReasonViewSet',
    'FormDeclarationViewSet',
    'CategoryRateViewSet'
    ]


class CsrfExemptAuthentication(SessionAuthentication):
    def enforce_csrf(self, request):
        return  # To not perform the csrf check previously happening


class LevelViewSet(viewsets.ModelViewSet):
    serializer_class = LevelSerializer
    queryset = Level.objects.all()


class CountryCategoryViewSet(viewsets.ModelViewSet):
    serializer_class = CountryCategorySerializer
    queryset = CountryCategory.objects.all()


class CountryViewSet(viewsets.ModelViewSet):
    serializer_class = CountrySerializer
    queryset = Country.objects.all()


class MileageClassNameViewSet(viewsets.ModelViewSet):
    serializer_class = MileageClassNameSerializer
    queryset = MileageClaimClassName.objects.all()


class MileageClassViewSet(viewsets.ModelViewSet):
    serializer_class = MileageClassSerializer
    queryset = MileageClaimClass.objects.all()


class MileageRangeViewSet(viewsets.ModelViewSet):
    serializer_class = MileageRangeSerializer
    queryset = MileageClaimRange.objects.all()


class MileageRateViewSet(viewsets.ModelViewSet):
    serializer_class = MileageRateSerializer
    queryset = MileageClaimRate.objects.all()


class CurrencyViewSet(viewsets.ModelViewSet):
    serializer_class = CurrencySerializer
    queryset = Currency.objects.all()


class CurrencyRateViewSet(viewsets.ModelViewSet):
    serializer_class = CurrencyRateSerializer

    def get_queryset(self):
        qs = CurrencyRate.objects.all()
        date = self.request.GET.get('date')
        currency = self.request.GET.get('currency')
        if date and currency:
            for c in qs:
                if c.currency.currency == currency and str(c.date) == date:
                    return [c]
        return qs


class FundTypeViewSet(viewsets.ModelViewSet):
    serializer_class = FundTypeSerializer
    queryset = FundType.objects.all()


class BankViewSet(viewsets.ModelViewSet):
    serializer_class = BankSerializer
    queryset = Bank.objects.all()


class ExpenseViewSet(viewsets.ModelViewSet):
    serializer_class = ExpenseSerializer

    def get_queryset(self):
        qs = Expense.objects.all()
        claim_code = self.request.GET.get('claim_code')
        if claim_code:
            qs = qs.filter(claim_type__code=claim_code)
        return qs


class MiscellaneousTypeViewSet(viewsets.ModelViewSet):
    serializer_class = MiscellaneousTypeSerializer
    queryset = MiscellaneousType.objects.all()


class ConfigSetViewSet(viewsets.ModelViewSet):
    serializer_class = ConfigSetSerializer
    queryset = ConfigSet.objects.all()


class PetrolTypeViewSet(viewsets.ModelViewSet):
    serializer_class = PetrolTypeSerializer
    queryset = PetrolType.objects.all()


class PetrolRateViewSet(viewsets.ModelViewSet):
    serializer_class = PetrolRateSerializer
    queryset = PetrolRate.objects.all()


class VehicleTypeViewSet(viewsets.ModelViewSet):
    serializer_class = VehicleTypeSerializer
    queryset = VehicleType.objects.all()


class VehicleRateViewSet(viewsets.ModelViewSet):
    serializer_class = VehicleRateSerializer
    queryset = VehicleRate.objects.all()


class GSTTaxViewSet(viewsets.ModelViewSet):
    serializer_class = GSTTaxSerializer
    queryset = GSTTax.objects.all()


class UserGroupViewSet(viewsets.ModelViewSet):
    serializer_class = UserGroupSerializer

    def get_queryset(self):
        qs = UserGroup.objects.all()
        tmpl_id = self.request.GET.get('template')
        if tmpl_id:
            qs = qs.filter(workflowtemplatelevel__template__pk=tmpl_id)
        return qs


class WorkflowTemplateViewSet(viewsets.ModelViewSet):
    serializer_class = WorkflowTemplateSerializer

    def get_queryset(self):
        qs = WorkflowTemplate.objects.all()
        claim_type_id = self.request.GET.get('claim_type')
        if claim_type_id:
            qs = qs.filter(claimtype__pk=claim_type_id)
        return qs

    def perform_create(self, serializer):
        instance = serializer.save()
        idlist = serializer.initial_data.get('claim_types', [])
        claim_types = ClaimType.objects.filter(pk__in=idlist)
        claim_types.update(template=instance)


class WorkflowTemplateLevelViewSet(viewsets.ModelViewSet):
    serializer_class = WorkflowTemplateLevelSerializer

    def get_queryset(self):
        qs = WorkflowTemplateLevel.objects.all()
        tmpl_id = self.request.GET.get('template')
        group_id = self.request.GET.get('group')
        if tmpl_id:
            qs = qs.filter(template__pk=tmpl_id)
        if group_id:
            qs = qs.filter(group__pk=group_id)
        if 'query' in self.request.GET:
            qs = qs.filter(query=True)
        if 'has_filtering' in self.request.GET:
            _last_level = qs.aggregate(Max('ordering'))['ordering__max']
            if _last_level is not None:
                qs = qs.filter(selection_filtering=True,
                               ordering__lt=_last_level)
        if 'exclude_claimant' in self.request.GET:
            qs = qs.exclude(ordering=1)
        return qs


class WorkflowStatusViewSet(viewsets.ModelViewSet):
    serializer_class = WorkflowStatusSerializer
    queryset = WorkflowStatus.objects.all()


class WorkflowTemplateDetailsViewSet(viewsets.ModelViewSet):
    serializer_class = WorkflowTemplateDetailsSerializer

    def get_queryset(self):
        qs = WorkflowTemplateDetails.objects.all()
        group_id = self.request.GET.get('group')
        template_id = self.request.GET.get('template')
        if group_id:
            qs = qs.filter(template_level__group__pk=group_id)
        if template_id:
            qs = qs.filter(template_level__template__pk=template_id)
        return qs

    def perform_create(self, serializer):
        grades = GradeLevelCategory.objects.all()
        data = serializer.initial_data

        # If grades aren't provided by user, then assume the first
        # grade and the last one.
        _grade_kwargs = {}
        if not data.get('grade_from'):
            _grade_kwargs['grade_from'] = grades.first()
        if not data.get('grade_to'):
            _grade_kwargs['grade_to'] = grades.latest()

        if serializer.is_valid():
            instance = serializer.save(**_grade_kwargs)

            # Add company levels as m2m.
            levels = serializer.initial_data.get('levels', [])
            for pk in levels:
                complevel = CompanyLevel.objects.get(pk=pk)
                instance.levels.add(complevel)


class WorkflowQueryViewSet(viewsets.ModelViewSet):
    serializer_class = WorkflowQuerySerializer

    def get_queryset(self):
        qs = WorkflowQuery.objects.all()
        template_id = self.request.GET.get('template')
        if template_id:
            qs = qs.filter(template__pk=template_id)
        return qs


class WorkflowQueryTypeViewSet(viewsets.ModelViewSet):
    serializer_class = WorkflowQueryTypeSerializer

    def get_queryset(self):
        user = self.request.user

        if 'show_all' in self.request.GET:
            return WorkflowQueryType.objects.all()

        # Make sure that the user has permission to query.
        if hasattr(user, 'claimant') and hasattr(user.claimant, 'assignee'):
            pk_list = []
            claimant = user.claimant

            for obj in WorkflowQueryType.objects.all():
                for lvl in WorkflowTemplateLevel.objects.all():
                    if lvl.group in claimant.assignee.groups.all():
                        pk_list.append(obj.pk)

            return WorkflowQueryType.objects.filter(pk__in=pk_list)
        return WorkflowQueryType.objects.none()


class AssigneeViewSet(viewsets.ModelViewSet):
    serializer_class = AssigneeSerializer
    authentication_classes = (CsrfExemptAuthentication, BasicAuthentication)

    def get_queryset(self):
        qs = Assignee.objects.all()
        group = self.request.GET.get('group')
        if group:
            qs = qs.filter(groups__pk=group)
        return qs


class SelectionFilteringViewSet(ModelViewSetMessagesMixin,
                                viewsets.ModelViewSet):
    serializer_class = SelectionFilteringSerializer
    queryset = SelectionFiltering.objects.all()


class WorkflowReasonViewSet(ModelViewSetMessagesMixin, viewsets.ModelViewSet):
    serializer_class = WorkflowReasonSerializer

    def get_queryset(self):
        qs = WorkflowReason.objects.all()
        template_id = self.request.GET.get('template')
        reason = self.request.GET.get('reason')
        if template_id:
            qs = qs.filter(template__pk=template_id)
        if reason:
            qs = qs.filter(reason=int(reason))
        return qs


class FormDeclarationViewSet(ModelViewSetMessagesMixin, viewsets.ModelViewSet):
    serializer_class = FormDeclarationSerializer

    def get_queryset(self):
        qs = FormDeclaration.objects.all()
        claim_type_id = self.request.GET.get('claim_type')
        level_ordering = self.request.GET.get('level_ordering')
        if claim_type_id:
            qs = qs.filter(claim_type__pk=claim_type_id)
        if level_ordering:
            qs = qs.filter(level__ordering=level_ordering)
        return qs


class CategoryRateViewSet(viewsets.ModelViewSet):
    serializer_class = CategoryRateSerializer
    queryset = CategoryRate.objects.all()

    def get_queryset(self):
        qs = self.queryset
        category_id = self.request.GET.get('categoryId')
        if category_id:
            qs = qs.filter(category=category_id)
        return qs