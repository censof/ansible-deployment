from django.core.urlresolvers import reverse_lazy
from django.template.defaultfilters import linebreaksbr
from django.utils.encoding import force_text
from rest_framework import serializers
from moneyed import get_currency, CurrencyDoesNotExist
from django_countries.serializer_fields import CountryField
from eclaim.claim.models import ClaimType
from eclaim.masterfiles.models.misc import *
from eclaim.masterfiles.models.entitlement import *
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LevelSerializer',
    'CountryCategorySerializer',
    'CountrySerializer',
    'CurrencySerializer',
    'CurrencyRateSerializer',
    'FundTypeSerializer',
    'BankSerializer',
    'ExpenseSerializer',
    'MiscellaneousTypeSerializer',
    'MileageClassNameSerializer',
    'MileageClassSerializer',
    'MileageRangeSerializer',
    'MileageRateSerializer',
    'ConfigSetSerializer',
    'PetrolTypeSerializer',
    'PetrolRateSerializer',
    'VehicleTypeSerializer',
    'VehicleRateSerializer',
    'GSTTaxSerializer',
    'UserGroupSerializer',
    'WorkflowTemplateSerializer',
    'WorkflowTemplateLevelSerializer',
    'WorkflowTemplateDetailsSerializer',
    'WorkflowStatusSerializer',
    'WorkflowQuerySerializer',
    'WorkflowQueryTypeSerializer',
    'WorkflowReasonSerializer',
    'AssigneeSerializer',
    'SelectionFilteringSerializer',
    'FormDeclarationSerializer',
    'CategoryRateSerializer'
    ]


class LevelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Level
        depth = 1
        fields = ('id', 'title', 'ordering')


class CountryCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CountryCategory
        fields = ('id', 'title')


class CountrySerializer(serializers.ModelSerializer):
    country = CountryField()
    name = serializers.SerializerMethodField()
    category_name = serializers.SerializerMethodField()

    class Meta:
        model = Country
        fields = ('id', 'country', 'name', 'category', 'category_name')

    def get_name(self, obj):
        return unicode(obj.country.name)

    def get_category_name(self, obj):
        return unicode(obj.category)


class CurrencySerializer(serializers.ModelSerializer):
    name = serializers.SerializerMethodField()

    class Meta:
        model = Currency
        fields = ('currency', 'name')

    def get_name(self, obj):
        try:
            return get_currency(obj.currency).name
        except CurrencyDoesNotExist:
            return obj.currency


class CurrencyRateSerializer(serializers.ModelSerializer):
    currency_name = serializers.SerializerMethodField()

    class Meta:
        model = CurrencyRate
        fields = ('currency', 'currency_name', 'date', 'value')
        depth = 2

    def get_currency_name(self, obj):
        currency = obj.currency.currency
        try:
            return get_currency(currency).name
        except CurrencyDoesNotExist:
            return currency


class FundTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = FundType
        depth = 1
        fields = (
            'code',
            'description',
            'is_project',
            'sequence',
            'policy'
            )


class BankSerializer(serializers.ModelSerializer):
    class Meta:
        model = Bank
        depth = 1
        fields = (
            'id',
            'name',
            'code'
            )


class ExpenseSerializer(serializers.ModelSerializer):
    claim_type = serializers.PrimaryKeyRelatedField(queryset=ClaimType.objects.all())
    claim_type_name = serializers.SerializerMethodField()

    class Meta:
        model = Expense
        fields = (
            'id',
            'title',
            'claim_type',
            'claim_type_name',
            'type_code',
            'account_code'
            )

    def get_claim_type_name(self, obj):
        return unicode(obj.claim_type)


class MiscellaneousTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = MiscellaneousType
        depth = 2
        fields = (
            'id',
            'code',
            'claim_type',
            'description',
            'rate',
            'limit_claim',
            'exp_code',
            'active'
            )


class MileageClassNameSerializer(serializers.ModelSerializer):
    class Meta:
        model = MileageClaimClassName
        fields = '__all__'


class MileageClassSerializer(serializers.ModelSerializer):

    class Meta:
        model = MileageClaimClass
        fields = ('id', 'mileage_class_name', 'salary_from', 'salary_to', 'cc_from', 'cc_to')


class MileageRangeSerializer(serializers.ModelSerializer):
    title = serializers.SerializerMethodField()

    class Meta:
        model = MileageClaimRange
        fields = ('id', 'distance_min', 'distance_max', 'title')

    def get_title(self, obj):
        return unicode(obj)


class MileageRateSerializer(serializers.ModelSerializer):
    mileage_claim_range = serializers.PrimaryKeyRelatedField(queryset=MileageClaimRange.objects.all())
    mileage_claim_class = serializers.PrimaryKeyRelatedField(queryset=MileageClaimClass.objects.all())
    range_title = serializers.SerializerMethodField()
    class_title = serializers.SerializerMethodField()

    class Meta:
        model = MileageClaimRate
        fields = ('id', 'mileage_claim_range', 'mileage_claim_class', 'rate', 'range_title', 'class_title')

    def get_range_title(self, obj):
        return u"{} -- {}".format(obj.mileage_claim_range.distance_min, obj.mileage_claim_range.distance_max)

    def get_class_title(self, obj):
        return unicode(obj.mileage_claim_class.mileage_class_name)


class ConfigSetSerializer(serializers.ModelSerializer):

    class Meta:
        model = ConfigSet
        fields = '__all__'


class PetrolTypeSerializer(serializers.ModelSerializer):

    class Meta:
        depth = 1
        model = PetrolType
        fields = ('id', 'name')


class PetrolRateSerializer(serializers.ModelSerializer):
    petrol_type = serializers.PrimaryKeyRelatedField(queryset=PetrolType.objects.all())

    class Meta:
        depth = 2
        model = PetrolRate
        fields = ('id', 'petrol_type', 'date', 'rate')


class VehicleTypeSerializer(serializers.ModelSerializer):

    class Meta:
        depth = 1
        model = VehicleType
        fields = ('id', 'name')


class VehicleRateSerializer(serializers.ModelSerializer):
    vehicle_type = serializers.PrimaryKeyRelatedField(queryset=VehicleType.objects.all())

    class Meta:
        depth = 2
        model = VehicleRate
        fields = ('id', 'vehicle_type', 'date', 'rate')


class GSTTaxSerializer(serializers.ModelSerializer):

    class Meta:
        model = GSTTax
        fields = ('code', 'rate', 'description')


class UserGroupSerializer(serializers.ModelSerializer):
    claimants_total = serializers.SerializerMethodField()

    class Meta:
        model = UserGroup
        fields = ('id', 'title', 'status', 'claimants_total', 'created')

    def get_claimants_total(self, obj):
        return obj.assignee_set.all().count()


class WorkflowTemplateSerializer(serializers.ModelSerializer):
    claim_types = serializers.SerializerMethodField()

    class Meta:
        model = WorkflowTemplate
        fields = ('id', 'title', 'integrated_to_fs', 'claim_types')

    def get_claim_types(self, obj):
        _fields = ('pk', 'code', 'prefix', 'title', 'is_enabled')
        return obj.claimtype_set.values(*_fields)


class WorkflowTemplateLevelSerializer(serializers.ModelSerializer):
    group = serializers.PrimaryKeyRelatedField(queryset=UserGroup.objects.all())
    template = serializers.PrimaryKeyRelatedField(queryset=WorkflowTemplate.objects.all())
    group_name = serializers.SerializerMethodField()
    first_level_id = serializers.SerializerMethodField()

    class Meta:
        model = WorkflowTemplateLevel
        depth = 1
        fields = ('id', 'group', 'query', 'email_notif', 'template',
                  'ordering', 'group_name', 'selection_filtering',
                  'gl_distribution', 'budget_lock', 'first_level_id')

    def get_group_name(self, obj):
        if obj.group is not None:
            return force_text(obj.group)
        return "Claimant"

    def get_first_level_id(self, obj):
        try:
            level = WorkflowTemplateLevel.objects.get(
                template=obj.template,
                ordering=1
                )
        except WorkflowTemplateLevel.DoesNotExist:
            return
        return level.pk


class WorkflowTemplateDetailsSerializer(serializers.ModelSerializer):
    assignee = serializers.PrimaryKeyRelatedField(queryset=Assignee.objects.all())
    level_list = serializers.SerializerMethodField()
    groupid = serializers.SerializerMethodField()
    staff_no = serializers.SerializerMethodField()
    claimant_detail_url = serializers.SerializerMethodField()
    grade_from = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all(), required=False)
    grade_to = serializers.PrimaryKeyRelatedField(queryset=GradeLevelCategory.objects.all(), required=False)

    class Meta:
        model = WorkflowTemplateDetails
        fields = ('id', 'assignee', 'levels', 'template_level', 'grade_from',
                  'grade_to', 'level_list', 'groupid', 'claimant_detail_url',
                  'staff_no')

    def perform_create(self, serializer):
        assignee = serializer.save().assignee
        group_ids = serializer.initial_data.get('usergroups', [])
        groups = UserGroup.objects.filter(pk__in=group_ids)
        assignee.groups.add(*groups)

    def get_level_list(self, obj):
        return list(obj.levels.all().values('title', 'code', 'level__id'))

    def get_groupid(self, obj):
        return obj.template_level.group.pk

    def get_claimant_detail_url(self, obj):
        baseurl = reverse_lazy('settings_claimant_detail')
        return "{}?pk={}".format(baseurl, obj.assignee.claimant.pk)

    def get_staff_no(self, obj):
        return obj.assignee.claimant.staff_no


class WorkflowStatusSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkflowStatus
        fields = ('id', 'title', 'description')


class WorkflowQuerySerializer(serializers.ModelSerializer):
    level_name = serializers.SerializerMethodField()
    resubmit_to_name = serializers.SerializerMethodField()
    query_type_name = serializers.SerializerMethodField()
    query_to_name = serializers.SerializerMethodField()

    class Meta:
        model = WorkflowQuery
        fields = ('id', 'template', 'level', 'query_type', 'query_to',
                  'resubmit_to', 'level_name', 'resubmit_to_name',
                  'query_type_name', 'query_to_name')

    def get_level_name(self, obj):
        return force_text(obj.level)

    def get_resubmit_to_name(self, obj):
        return force_text(obj.resubmit_to)

    def get_query_type_name(self, obj):
        return force_text(obj.query_type)

    def get_query_to_name(self, obj):
        return force_text(obj.query_to)


class WorkflowQueryTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = WorkflowQueryType
        fields = ('id', 'title')


class WorkflowReasonSerializer(serializers.ModelSerializer):
    level_name = serializers.SerializerMethodField()
    reason_name = serializers.SerializerMethodField()
    template_name = serializers.SerializerMethodField()

    class Meta:
        model = WorkflowReason
        fields = ('code', 'description', 'level', 'reason', 'template',
                  'level_name', 'reason_name', 'template_name',
                  'description')

    def get_level_name(self, obj):
        return force_text(obj.level)

    def get_reason_name(self, obj):
        return obj.get_reason_display()

    def get_template_name(self, obj):
        return force_text(obj.template)


class AssigneeSerializer(serializers.ModelSerializer):
    groups = serializers.PrimaryKeyRelatedField(
        many=True, required=False, queryset=UserGroup.objects.all())
    name = serializers.SerializerMethodField()
    staff_no = serializers.SerializerMethodField()
    claimant_detail_url = serializers.SerializerMethodField()

    class Meta:
        model = Assignee
        fields = ('id', 'claimant', 'groups', 'created', 'name', 'staff_no',
                  'claimant_detail_url', 'added_via_workflow')

    def get_name(self, obj):
        return obj.name

    def get_staff_no(self, obj):
        return obj.claimant.staff_no

    def get_claimant_detail_url(self, obj):
        baseurl = reverse_lazy('settings_claimant_detail')
        return "{}?pk={}".format(baseurl, obj.claimant.pk)


class SelectionFilteringSerializer(serializers.ModelSerializer):
    company_level_name = serializers.SerializerMethodField()
    level_name = serializers.SerializerMethodField()
    template_name = serializers.SerializerMethodField()

    class Meta:
        model = SelectionFiltering
        fields = ('id', 'level', 'level_name', 'template_name',
                  'company_level', 'company_level_name')

    def get_level_name(self, obj):
        return force_text(obj.level)

    def get_template_name(self, obj):
        return force_text(obj.level.template)

    def get_company_level_name(self, obj):
        return force_text(obj.company_level)


class FormDeclarationSerializer(serializers.ModelSerializer):
    claim_type_name = serializers.SerializerMethodField()
    level_name = serializers.SerializerMethodField()
    content_en = serializers.SerializerMethodField()
    content_my = serializers.SerializerMethodField()

    class Meta:
        model = FormDeclaration
        fields = ('id', 'claim_type', 'level', 'claim_type_name', 'level_name',
                  'content_en', 'content_my')

    def get_claim_type_name(self, obj):
        return unicode(obj.claim_type)

    def get_level_name(self, obj):
        return unicode(obj.level)

    def get_content_en(self, obj):
        return linebreaksbr(obj.content_en)

    def get_content_my(self, obj):
        return linebreaksbr(obj.content_my)


class CategoryRateSerializer(serializers.ModelSerializer):
    category_name = serializers.SerializerMethodField()

    class Meta:
        model = CategoryRate
        fields = ('id', 'category', 'duty_meal', 'duty_hotel', 'duty_lodging', 'course_meal', 'course_hotel'
                , 'course_lodging', 'category_name')

    def get_category_name(self, obj):
        return unicode(obj.category)