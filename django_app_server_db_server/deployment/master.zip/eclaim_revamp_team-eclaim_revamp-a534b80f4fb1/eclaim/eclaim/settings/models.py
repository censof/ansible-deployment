from django.db import models
from django.db.models import Q
from django.db.models.signals import post_save
from django.contrib.contenttypes.fields import GenericForeignKey
from django.contrib.contenttypes.models import ContentType
from django.core.validators import MinValueValidator
from django.utils.encoding import force_text
from django.utils.translation import ugettext as _, get_language
from djmoney.models.fields import CurrencyField
from django_countries.fields import CountryField
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.models.company import CompanyLevel, GradeLevelCategory
from .signals import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'Settings',
    'Level',
    'Country',
    'CountryCategory',
    'Currency',
    'CurrencyRate',
    'Expense',
    'UserGroup',
    'Assignee',
    'SelectedAssignee',
    'SelectionFiltering',
    'WorkflowTemplate',
    'WorkflowTemplateDetails',
    'WorkflowTemplateLevel',
    'WorkflowStatus',
    'WorkflowQueryType',
    'WorkflowQuery',
    'WorkflowState',
    'WorkflowQueryState',
    'WorkflowStateLog',
    'WorkflowReason',
    'FormDeclaration',
    'CategoryRate'
    ]


class Settings(models.Model):
    """DEPRECATED"""
    implementation_locked = models.BooleanField(default=False)

    class Meta:
        verbose_name = _("Setting")
        verbose_name_plural = _("Settings")


class Level(models.Model):
    title = models.CharField(_("Name"), max_length=255)
    ordering = models.PositiveIntegerField(unique=True)

    class Meta:
        verbose_name = _("Company Level")
        verbose_name_plural = _("Company Levels")
        ordering = ['ordering']

    def __unicode__(self):
        return unicode(self.title)


class CountryCategory(models.Model):
    title = models.CharField(_("Title"), max_length=30, unique=True)

    class Meta:
        verbose_name = _("Country category")
        verbose_name_plural = _("Country categories")

    def __unicode__(self):
        return unicode(self.title)


class Country(models.Model):
    country = CountryField(unique=True)
    category = models.ForeignKey(CountryCategory, verbose_name=_("Category"))

    class Meta:
        verbose_name = _("Country")
        verbose_name_plural = _("Countries")

    def __unicode__(self):
        return unicode(self.country.name)


class Currency(models.Model):
    currency = CurrencyField(verbose_name=_("Currency"), unique=True)

    class Meta:
        verbose_name = _("Currency")
        verbose_name_plural = _("Currencies")
        ordering = ['currency']

    def __unicode__(self):
        return self.currency


class CurrencyRate(models.Model):
    date = models.DateField(_("Effective Date"))
    currency = models.ForeignKey('settings.Currency', verbose_name=_("Currency"))
    value = models.DecimalField(max_digits=20, decimal_places=6)

    class Meta:
        verbose_name = _("Currency rate")
        verbose_name_plural = _("Currency rates")
        ordering = ['date', 'currency']

    def __unicode__(self):
        return u"{} ({})".format(self.value, self.currency)


class Expense(models.Model):
    title = models.CharField(_("Title"), max_length=255)
    claim_type = models.ForeignKey('claim.ClaimType', verbose_name=_("Claim Type"))
    type_code = models.CharField(_("Type Code"), max_length=20)
    account_code = models.CharField(_("Account Code"), max_length=20)
    ordering = models.PositiveIntegerField(_("Ordering"), null=True)

    class Meta:
        verbose_name = _("Expense")
        verbose_name_plural = _("Expenses")
        ordering = ['ordering']

    def __unicode__(self):
        return unicode(self.title)


class WorkflowStatus(models.Model):
    title = models.CharField(_("Name"), max_length=255)
    description = models.TextField(_("Description"), blank=True)
    ordering = models.PositiveIntegerField(_("Ordering"), null=True)

    class Meta:
        verbose_name = _("Status")
        verbose_name_plural = _("Statuses")

    def __unicode__(self):
        return unicode(self.title)


class UserGroup(BaseModel):
    """Workflow group, which consists of assignees."""
    title = models.CharField(_("Name"), max_length=255)
    status = models.CharField(_("Status"), max_length=255, null=True)  # status label

    class Meta:
        verbose_name = _("Group")
        verbose_name_plural = _("Groups")

    def __unicode__(self):
        return unicode(self.title)


class Assignee(BaseModel):
    """Users who are allowed to approve/decline claims in various levels of
    workflow.
    """
    claimant = models.OneToOneField(Claimant, verbose_name=_("Assignee"))
    groups = models.ManyToManyField(UserGroup, verbose_name=_("Groups"))
    added_via_workflow = models.BooleanField(_("Added via workflow settings"), default=False)

    class Meta:
        verbose_name = _("Assignee")
        verbose_name_plural = _("Assignees")

    def __unicode__(self):
        return unicode(self.name)

    @property
    def name(self):
        """Return a claimant's full name."""
        return self.claimant.name


class WorkflowTemplate(models.Model):
    title = models.CharField(_("Name"), max_length=255, null=True, unique=True)
    integrated_to_fs = models.BooleanField(_("Integrated to Financial System"), default=True)

    class Meta:
        verbose_name = _("Template")
        verbose_name_plural = _("Templates")

    def __unicode__(self):
        return unicode(self.title)


class _MultipleBudgetLocksError(Exception):
    """Budget lock must be only per one level. Raise this error when
    multiple budget locks detected.
    """
    pass


class WorkflowTemplateLevel(models.Model):
    group = models.ForeignKey(UserGroup, verbose_name=_("Group"), null=True)
    status = models.ForeignKey(WorkflowStatus, verbose_name=_("Status"), null=True)
    query = models.BooleanField(_("Query"), help_text=_("Allow query"))
    email_notif = models.BooleanField(_("Email notification"))
    selection_filtering = models.BooleanField(_("Selection filtering"), default=False)
    gl_distribution = models.BooleanField(_("GL distribution"), default=False)
    budget_lock = models.BooleanField(_("Budget lock"), default=False)
    template = models.ForeignKey(WorkflowTemplate, verbose_name=_("Template"))
    ordering = models.PositiveIntegerField(validators=[MinValueValidator(2)], null=True)

    class Meta:
        verbose_name = _("Level")
        verbose_name_plural = _("Levels")
        unique_together = ('template', 'ordering')
        ordering = ('ordering', 'id')
        get_latest_by = 'ordering'

    def __unicode__(self):
        if self.ordering == 1:  # 'Submitted'
            return unicode(_("Claimant"))
        return unicode(self.group)

    def save(self, *args, **kwargs):
        # Attach a status label to a specific status object.
        self.status = WorkflowStatus.objects.get(ordering=self.ordering)

        self.validate_budget_lock()
        super(WorkflowTemplateLevel, self).save(*args, **kwargs)

    @classmethod
    def get_total_levels(cls, template):
        return cls.objects.filter(template=template).count()

    def validate_budget_lock(self):
        qs = WorkflowTemplateLevel.objects.filter(template=self.template,
                                                  budget_lock=True)
        if qs.count() > 1:
            errmsg = _("Budget lock must be only per one level. Multiple "
                       "detected instead.")
            raise _MultipleBudgetLocksError(errmsg)


post_save.connect(workflowlevel_postsave, sender=WorkflowTemplateLevel)


class SelectionFiltering(BaseModel):
    level = models.OneToOneField(WorkflowTemplateLevel, verbose_name=_("Level"))
    company_level = models.ForeignKey(Level, verbose_name=_("Company Level"), null=True)

    class Meta:
        verbose_name = _("Selection Filtering")
        verbose_name_plural = verbose_name

    def __unicode__(self):
        return u"{} ({})".format(self.level, self.company_level)


class SelectedAssignee(BaseModel):
    """An assignee who is to override a level group settings.

    An assignee can be manually chosen in a claim form. An instance of
    this model is created only when a selection filtering is enabled on
    a corresponding level.
    """
    assignee = models.ForeignKey(Assignee, verbose_name=_("Assignee"))
    level = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Level"))

    # Generic foreign key is attached to a claim, be it lecturer, oversea
    # travelling and so on.
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        verbose_name = _("Selected assignee")
        verbose_name_plural = _("Selected assignees")
        ordering = ['created']
        unique_together = ('level', 'content_type', 'object_id')

    def __unicode__(self):
        return unicode(self.assignee)

post_save.connect(selectedassignee_postsave, sender=SelectedAssignee)


class WorkflowTemplateDetails(models.Model):
    assignee = models.ForeignKey(Assignee, verbose_name=_("Assignee"), null=True)
    levels = models.ManyToManyField(CompanyLevel, verbose_name=_("Company Levels"))
    template_level = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Level"))
    grade_from = models.ForeignKey(GradeLevelCategory, verbose_name=_("Grade From"), related_name='workflowtemplatedetails_gradefrom')
    grade_to = models.ForeignKey(GradeLevelCategory, verbose_name=_("Grade To"), related_name='workflowtemplatedetails_gradeto')

    class Meta:
        verbose_name = _("Template Details")
        verbose_name_plural = _("Template Details")
        unique_together = ('assignee', 'template_level')

    def __unicode__(self):
        return unicode(self.assignee)

post_save.connect(workflowtemplatedetails_postsave,
                  sender=WorkflowTemplateDetails)


class WorkflowQueryType(BaseModel):
    title = models.CharField(_("Name"), max_length=255, unique=True)

    class Meta:
        verbose_name = _("Query Type")
        verbose_name_plural = _("Query Types")
        ordering = ['created']

    def __unicode__(self):
        return unicode(self.title)


class WorkflowQuery(models.Model):
    template = models.ForeignKey(WorkflowTemplate, verbose_name=_("Template"), null=True)  # TODO: remove field
    level = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Level"), related_name='workflowquery_level', null=True)
    query_type = models.ForeignKey(WorkflowQueryType, verbose_name=_("Type"), on_delete=models.PROTECT, null=True)
    query_to = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Query To"), related_name='workflowquery_queryto', blank=True, null=True)
    resubmit_to = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Re-submit To"), related_name='workflowquery_resubmitto', null=True)

    class Meta:
        verbose_name = _("Query")
        verbose_name_plural = _("Queries")
        unique_together = ('level', 'query_type')

    def __unicode__(self):
        return u"{} -> {} -> {}".format(self.level, self.query_to,
                                        self.resubmit_to)

    def save(self, *args, **kwargs):
        # Temporary solution: allow to query to claimant only. In the
        # future we might allow to query to other levels as well.
        if not self.query_to:
            self.query_to = WorkflowTemplateLevel.objects.get(
                #group=self.level.group,
                template=self.level.template,
                ordering=1  # 'Submitted' (Claimant)
                )
            self.save()

        super(WorkflowQuery, self).save(*args, **kwargs)


class WorkflowReason(BaseModel):
    QUERY = 1
    REJECT = 2
    REASON_LIST = (
        (QUERY, _("Query")),
        (REJECT, _("Reject"))
        )

    code = models.CharField(_("Code"), max_length=15, primary_key=True)
    level = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Level"), null=True)
    description = models.CharField(_("Description"), max_length=255, null=True)
    reason = models.PositiveIntegerField(_("Reason"), choices=REASON_LIST)
    template = models.ForeignKey(WorkflowTemplate, verbose_name=_("Template"), null=True)

    class Meta:
        verbose_name = _("Reason")
        verbose_name_plural = _("Reasons")
        ordering = ['created']
        get_latest_by = 'created'

    def __unicode__(self):
        return unicode(self.description)


class WorkflowState(BaseModel):
    level = models.ForeignKey(WorkflowTemplateLevel)
    claimant = models.ForeignKey(Claimant, verbose_name=_("Claimant"), null=True)
    is_approved = models.NullBooleanField(blank=True)
    approved_by = models.ForeignKey(Assignee, verbose_name=_("Approved/Rejected By"), blank=True, null=True)
    rejection_reason = models.ForeignKey(WorkflowReason, verbose_name=_("Rejection Reason"), blank=True, null=True)
    notes = models.TextField(blank=True, null=True)
    is_cancelled = models.BooleanField(_("Cancelled"), default=False)
    cancelled_by = models.ForeignKey(Assignee, verbose_name=_("Cancelled By"), blank=True, null=True, related_name='cancelled_workflowstate_set')

    # Generic foreign key is attached to a claim, be it lecturer, oversea
    # travelling and so on.
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE)
    object_id = models.PositiveIntegerField()
    content_object = GenericForeignKey('content_type', 'object_id')

    class Meta:
        verbose_name = _("State")
        verbose_name_plural = _("States")
        ordering = ['level__ordering', 'created']
        get_latest_by = 'level__ordering'

    def __unicode__(self):
        return u"{}: {}".format(self.level, self.content_object)

    @property
    def has_active_query(self):
        """Returns True if a claim is being edited by a claimant and pending
        re-submission.
        """
        query_states = self.query_states.all()
        if query_states.exists():
            return not query_states.latest().is_resubmitted
        return False

    @property
    def on_latest_level(self):
        """Check if a claim is on the latest workflow level at the present
        moment.
        """
        state = self.get_latest_state()
        tmpl = state.level.template
        total_levels = WorkflowTemplateLevel.get_total_levels(template=tmpl)
        return state.level.ordering == total_levels

    def get_latest_state(self):
        """Return the latest/current state of the claim for the latest
        level.
        """
        states = WorkflowState.objects.filter(
            claimant=self.claimant,
            content_type=self.content_type,
            object_id=self.object_id
            )
        return states.latest()

    @property
    def is_finally_approved(self):
        """Check whether a claim has been approved in every stage of the
        workflow.
        """
        total_levels = WorkflowTemplateLevel.get_total_levels(
            template=self.level.template
            )
        state = self.get_latest_state()
        return bool(state.is_approved) and state.level.ordering == total_levels

    @property
    def is_finally_rejected(self):
        """Check whether a claim has been rejected."""
        state = self.get_latest_state()
        return not state.is_approved and state.is_approved is not None

    @property
    def is_finally_cancelled(self):
        """Check whether a claim has been cancelled at any stage of the
        workflow.
        """
        return WorkflowState.objects.filter(object_id=self.object_id,
                                            content_type=self.content_type,
                                            is_cancelled=True
                                            ).exists()

    def get_status(self):
        """Return the current 'user-friendly' status of the state."""
        latest_level = self.get_latest_state().level

        if self.is_finally_approved:
            return latest_level.group.status
        elif self.is_finally_rejected:
            return _("Rejected")
        elif self.is_finally_cancelled:
            return _("Cancelled")

        if latest_level.ordering == 2:  # on the first 'Submitted' level
            return _("Submitted")

        try:
            prev_state = WorkflowState.objects.get(
                object_id=self.object_id,
                content_type=self.content_type,
                level__ordering=latest_level.ordering-1
                )
        except WorkflowState.DoesNotExist:
            return _("Submitted")

        return prev_state.level.group.status

    def get_assigned_entity(self):
        """Return an object of either one of these models: `SelectedAssignee`
        or `UserGroup`.
        """
        # Query.
        query_states = self.query_states.all()
        if query_states.exists():
            qstate = query_states.latest()
            if self.has_active_query:
                return qstate.query.query_to.group
            elif self.level.ordering == qstate.state.level.ordering:
                return qstate.query.resubmit_to.group

        # Normal flow.
        try:
            return SelectedAssignee.objects.get(
                content_type=self.content_type,
                object_id=self.object_id,
                level=self.level
                )
        except SelectedAssignee.DoesNotExist:
            return self.level.group


class WorkflowQueryState(BaseModel):
    state = models.ForeignKey(WorkflowState, verbose_name=_("State"), related_name='query_states')
    query = models.ForeignKey(WorkflowQuery, verbose_name=_("Query"))
    is_resubmitted = models.BooleanField(default=False, verbose_name=_("Re-submitted"))
    reason = models.ForeignKey(WorkflowReason, verbose_name=_("Reason"), null=True)
    notes = models.TextField(null=True)
    queried_by = models.ForeignKey(Assignee, verbose_name=_("Queried By"))

    class Meta:
        verbose_name = _("Query State")
        verbose_name_plural = _("Query States")
        ordering = ['-created']
        get_latest_by = 'created'

    def __unicode__(self):
        return u"[Query] {} -> {} -> {}".format(
            self.state.level,
            self.query.query_to,
            self.query.resubmit_to
            )

post_save.connect(workflowquerystate_postsave, sender=WorkflowQueryState)


class _WorkflowStateLogManager(models.Manager):
    """Excludes logs on the first 'Submitted' level.

    If you need to fetch all objects including on the first level, you can use
    `original_objects` manager instead.
    """
    def get_queryset(self):
        qs = super(_WorkflowStateLogManager, self).get_queryset()
        return qs.exclude(
            Q(state__level__ordering=1) |
            Q(query_state__state__level__ordering=1)
            )


class WorkflowStateLog(BaseModel):
    """This model is used to simplify claim serialization and to make it
    more flexible.

    A log instance is a final representation of a claim state to the user,
    which keeps a copy of the state data.
    """
    state = models.ForeignKey(WorkflowState, verbose_name=_("State"), blank=True, null=True, on_delete=models.SET_NULL)
    query_state = models.ForeignKey(WorkflowQueryState, verbose_name=_("Query State"), blank=True, null=True, on_delete=models.SET_NULL)

    # Keep a copy of the state data.
    level = models.ForeignKey(WorkflowTemplateLevel, null=True)
    claimant = models.ForeignKey(Claimant, verbose_name=_("Claimant"), null=True)
    is_approved = models.NullBooleanField(blank=True)
    approved_by = models.ForeignKey(Assignee, verbose_name=_("Approved/Rejected By"), blank=True, null=True)
    is_cancelled = models.BooleanField(default=False)
    cancelled_by = models.ForeignKey(Assignee, verbose_name=_("Cancelled By"), blank=True, null=True, related_name='cancelled_workflowstatelog_set')
    content_type = models.ForeignKey(ContentType, on_delete=models.CASCADE, null=True)
    object_id = models.PositiveIntegerField(null=True)
    content_object = GenericForeignKey('content_type', 'object_id')

    status = models.CharField(_("Status"), max_length=255, blank=True)
    current_assignee = models.CharField(_("Current Assignee"), max_length=255, blank=True)
    completed = models.DateTimeField(_("Completed On"), blank=True, null=True)

    # Keep a copy of the query data.
    query = models.BooleanField(default=False)
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    # Managers.
    objects = _WorkflowStateLogManager()
    original_objects = models.Manager()

    class Meta:
        verbose_name = _("State Log")
        verbose_name_plural = _("State Logs")
        ordering = ['created']
        get_latest_by = 'created'

    def __unicode__(self):
        _args = self.state.get_status(), self.content_object._meta.verbose_name
        if self.query:
            return u"[Query] {}: {}".format(*_args)
        return u"{}: {}".format(*_args)

    def save(self, *args, **kwargs):
        state = self.get_state()
        if state is not None:
            self.level = state.level
            self.claimant = state.claimant
            self.is_approved = state.is_approved
            self.approved_by = state.approved_by
            self.is_cancelled = state.is_cancelled
            self.cancelled_by = state.cancelled_by
            self.content_type = state.content_type
            self.object_id = state.object_id
            self.status = state.get_status()
            self.claim_no = state.content_object.claim_no
            assigned = state.get_assigned_entity()
            if assigned is not None:
                self.current_assignee = force_text(assigned)
        elif self.query_state is not None:
            self.query = True
        super(WorkflowStateLog, self).save(*args, **kwargs)

    def get_state(self):
        """Return the current state, be it a normal state or query."""
        if self.state is not None or self.query_state is not None:
            return self.state or self.query_state.state

    def is_latest(self):
        state = self.get_state()
        if state is None:
            return False
        latest = state.get_latest_state()
        return self == latest.workflowstatelog_set.latest()

    def is_latest_for_state(self):
        state = self.get_state()
        if state is None:
            return False
        return self == state.workflowstatelog_set.latest()


class FormDeclaration(BaseModel):
    claim_type = models.ForeignKey('claim.ClaimType', verbose_name=_("Claim Type"))
    level = models.ForeignKey(WorkflowTemplateLevel, verbose_name=_("Level"))
    content_en = models.TextField(_("Declaration in English"))
    content_my = models.TextField(_("Declaration in Malay"), blank=True)

    class Meta:
        verbose_name = _("Form declaration")
        verbose_name_plural = _("Form declarations")
        unique_together = ('claim_type', 'level')
        ordering = ['created']
        get_latest_by = 'created'

    def __unicode__(self):
        return u"[{}] {}".format(self.claim_type, self.level)

    def get_content(self):
        """Retrieve a content according to the current language set by user."""
        lang = get_language()
        return self.content_my if lang == 'ms-my' else self.content_en


class CategoryRate(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10)

    category = models.ForeignKey(CountryCategory, verbose_name=_("Category"))
    for item in ('duty_meal', 'duty_hotel', 'duty_lodging', 'course_meal', 'course_hotel', 'course_lodging'):
        exec("%s = models.DecimalField(**default_arguments)" % item)

    class Meta:
        verbose_name = _("Category rate")
        verbose_name_plural = _("Category rates")
        ordering = ['category']

    def __unicode__(self):
        return u"{} ({})".format(self.category, self.duty_meal, self.duty_hotel, self.duty_lodging
                                , self.course_meal, self.course_hotel, self.course_lodging)