/*
 ********************************************
 *      CREATED BY  :   MOHAMED FAUZI       *
 *      DATE        :   JANUARY 2016        *
 ********************************************
*/
console.log('Local Transfer Claim JS Loaded!!!');

uiBootstrapApp.controller('LocalTransferClaimCtrl', function ($scope, $sce, $log, $filter, $http, DataMain, DataFundType, DataFormDoc) {

    /*************** Initial Variable Start ***************/
	$scope.error_validation = false;
	$scope.claimant_no = '';
	$scope.draft_id = '';
	$scope.claim_no = '';
	$scope.object_pk = PK;
    $scope.showLocalTransferForm = true;
    $scope.url_query_pdf = '';
    $scope.expenses = [];
	$scope.salary_grade = '';
	$scope.basic_salary = '';
	$scope.total_dependent = 0;
    /*************** Initial Variable End ***************/

    /**
    *************************
    *   Start : Accordion   *
    *************************
   */
    $scope.oneAtATime = false;

    $scope.panels = [
        {name: 'panel1', open: false},
        {name: 'panel2', open: false},
        {name: 'panel3', open: true},
        {name: 'panel4', open: false},
        {name: 'panel5', open: false},
        {name: 'panel6', open: false},
        {name: 'panel7', open: false},
        {name: 'panel8', open: false}
    ];

    $scope.toggleAllPanels = function(){
        $scope.oneAtATime = false;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };

    $scope.closeAllPanels = function(){
        $scope.oneAtATime = true;
        $scope.panels.forEach(function (obj) {
            obj.open = !$scope.oneAtATime;
        });
    };
    /** End : Accordion */
	
	$scope.dateFormats = ['dd-MMMM-yyyy', 'yyyy/MM/dd', 'dd.MM.yyyy', 'shortDate', 'MM-yyyy'];
    
    $scope.standardDateOptions = {
        formatYear: 'yy',
        startingDay: 1
    };
    
    $scope.formatDate = $scope.dateFormats[0];

	$scope.initLocalTransferClaimCtrl = function() {
        console.log('Load initLocalTransferClaimCtrl (Default)');

		/* Start : General Config for Smart Table */
            $scope.pageSize = 5;
            $scope.currentPage = 1;
        /* End : General Config for Smart Table */
    };
	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.fundTypeSummary = newValue.description;
		}
	});
	$scope.initClaimantNo = function (claimant_no) {
		$scope.claimant_no = claimant_no;
		changeItemVal('claimant_no');
	};
	$scope.initSalaryGrade = function (salary_grade) {
		$scope.salary_grade = salary_grade;
		changeItemVal('salary_grade');
	};
	$scope.initBasicSalary = function (basic_salary) {
		$scope.basic_salary = basic_salary;
		changeItemVal('basic_salary');
	};

	var changeItemVal = function(obj) {
		if (obj == 'claimant_no') {
            DataMain.setClaimantNo($scope.claimant_no);
        }
		else if (obj == 'salary_grade') {
			DataMain.setSalaryGrade($scope.salary_grade);
		}
		else if (obj == 'basic_salary') {
			DataMain.setBasicSalary($scope.basic_salary);
		}
    };

	if (PK) {  // detail view
        $http({
            url: API_URL+'local-transfer-claims/'+PK+'/',
            method: 'GET'
        })
        .success(function (data, status, headers, config) {
            $scope.url_query_pdf = URL_QUERY_PDF+'?pk='+data.id+'&ctype_id='+data.claim_ctype_id;
            add_form_declaration($scope, $sce, 3, data.current_level_ordering);
        });
    } else {  // new claim
        add_form_declaration($scope, $sce, 3, 1);
    }

    var claim_api_url = API_URL+'local-transfer-claims/';
    init_workflow($scope, $http, 'localtransfer', 'LocalTransferClaim', PK, claim_api_url, WF_TEMPLATE);

    $scope.popup_query_pdf = function () {
        window.open($scope.url_query_pdf, '', 'width=800,height=600,left=200,resizable=0');
    }
});

uiBootstrapApp.controller('RatesCtrl', function ($scope, $log, DataRates) {
	$scope.TriggerRates = false;

	$scope.inwest_single3day = 0;
	$scope.inwest_married3day = 0;
	$scope.insarawak_single3day = 0;
	$scope.insarawak_married3day = 0;
	$scope.insabah_single3day = 0;
	$scope.insabah_married3day = 0;

	$scope.inwest_single5day = 0;
	$scope.inwest_married5day = 0;
	$scope.insarawak_single5day = 0;
	$scope.insarawak_married5day = 0;
	$scope.insabah_single5day = 0;
	$scope.insabah_married5day = 0;

	$scope.fromwest_single3day = 0;
	$scope.fromwest_married3day = 0;
	$scope.fromsarawak_single3day = 0;
	$scope.fromsarawak_married3day = 0;
	$scope.fromsabah_single3day = 0;
	$scope.fromsabah_married3day = 0;
	$scope.between_single3day = 0;
	$scope.between_married3day = 0;

	$scope.fromwest_single5day = 0;
	$scope.fromwest_married5day = 0;
	$scope.fromsarawak_single5day = 0;
	$scope.fromsarawak_married5day = 0;
	$scope.fromsabah_single5day = 0;
	$scope.fromsabah_married5day = 0;
	$scope.between_single5day = 0;
	$scope.between_married5day = 0;

	$scope.west_meal3day = 0;
	$scope.west_hotel3day = 0;
	$scope.west_lodging3day = 0;
	$scope.east_meal3day = 0;
	$scope.east_hotel3day = 0;
	$scope.east_lodging3day = 0;

	$scope.west_meal5day = 0;
	$scope.west_hotel5day = 0;
	$scope.west_lodging5day = 0;
	$scope.east_meal5day = 0;
	$scope.east_hotel5day = 0;
	$scope.east_lodging5day = 0;

	$scope.motorboat = 0;
	$scope.motorcycle = 0;
	$scope.car = 0;

	$scope.transport_0to50_west_single = 0;
	$scope.transport_0to50_west_married = 0;
	$scope.transport_0to50_east_single = 0;
	$scope.transport_0to50_east_married = 0;
	$scope.transport_51to250_west_single = 0;
	$scope.transport_51to250_west_married = 0;
	$scope.transport_51to250_east_single = 0;
	$scope.transport_51to250_east_married = 0;
	$scope.transport_251to500_west_single = 0;
	$scope.transport_251to500_west_married = 0;
	$scope.transport_251to500_east_single = 0;
	$scope.transport_251to500_east_married = 0;
	$scope.transport_501to750_west_single = 0;
	$scope.transport_501to750_west_married = 0;
	$scope.transport_501to750_east_single = 0;
	$scope.transport_501to750_east_married = 0;
	$scope.transport_751to1000_west_single = 0;
	$scope.transport_751to1000_west_married = 0;
	$scope.transport_751to1000_east_single = 0;
	$scope.transport_751to1000_east_married = 0;
	$scope.transport_1001to1250_west_single = 0;
	$scope.transport_1001to1250_west_married = 0;
	$scope.transport_1001to1250_east_single = 0;
	$scope.transport_1001to1250_east_married = 0;
	$scope.transport_1251to999999_west_single = 0;
	$scope.transport_1251to999999_west_married = 0;
	$scope.transport_1251to999999_east_single = 0;
	$scope.transport_1251to999999_east_married = 0;

	$scope.initRatesCtrl = function(jsonRateWithin, jsonRateFrom, jsonRateOthers, jsonRateVehicle, jsonRateTransport) {
		$scope.inwest_single5day = DataRates.getInWestSingleRate5Day();
		$scope.inwest_married5day = DataRates.getInWestMarriedRate5Day();
		$scope.insarawak_single5day = DataRates.getInSarawakSingleRate5Day();
		$scope.insarawak_married5day = DataRates.getInSarawakMarriedRate5Day();
		$scope.insabah_single5day = DataRates.getInSabahSingleRate5Day();
		$scope.insabah_married5day = DataRates.getInSabahMarriedRate5Day();

		$scope.fromwest_single5day = DataRates.getFromWestSingleRate5Day();
		$scope.fromwest_married5day = DataRates.getFromWestMarriedRate5Day();
		$scope.fromsarawak_single5day = DataRates.getFromSarawakSingleRate5Day();
		$scope.fromsarawak_married5day = DataRates.getFromSarawakMarriedRate5Day();
		$scope.fromsabah_single5day = DataRates.getFromSabahSingleRate5Day();
		$scope.fromsabah_married5day = DataRates.getFromSabahMarriedRate5Day();
		$scope.between_single5day = DataRates.getBetweenSingleRate5Day();
		$scope.between_married5day = DataRates.getBetweenMarriedRate5Day();

		$scope.west_meal5day = DataRates.getWestMealRate5Day();
		$scope.west_hotel5day = DataRates.getWestHotelRate5Day();
		$scope.west_lodging5day = DataRates.getWestLodgingRate5Day();
		$scope.east_meal5day = DataRates.getEastMealRate5Day();
		$scope.east_hotel5day = DataRates.getEastHotelRate5Day();
		$scope.east_lodging5day = DataRates.getEastLodgingRate5Day();

		$scope.motorboat = DataRates.getMotorboat();
		$scope.motorcycle = DataRates.getMotorcycle();
		$scope.car = DataRates.getCar();

		$scope.transport_0to50_west_single = DataRates.get0to50WestSingle();
		$scope.transport_0to50_west_married = DataRates.get0to50WestMarried();
		$scope.transport_0to50_east_single = DataRates.get0to50EastSingle();
		$scope.transport_0to50_east_married = DataRates.get0to50EastMarried();
		$scope.transport_51to250_west_single = DataRates.get51to250WestSingle();
		$scope.transport_51to250_west_married = DataRates.get51to250WestMarried();
		$scope.transport_51to250_east_single = DataRates.get51to250EastSingle();
		$scope.transport_51to250_east_married = DataRates.get51to250EastMarried();
		$scope.transport_251to500_west_single = DataRates.get251to500WestSingle();
		$scope.transport_251to500_west_married = DataRates.get251to500WestMarried();
		$scope.transport_251to500_east_single = DataRates.get251to500EastSingle();
		$scope.transport_251to500_east_married = DataRates.get251to500EastMarried();
		$scope.transport_501to750_west_single = DataRates.get501to750WestSingle();
		$scope.transport_501to750_west_married = DataRates.get501to750WestMarried();
		$scope.transport_501to750_east_single = DataRates.get501to750EastSingle();
		$scope.transport_501to750_east_married = DataRates.get501to750EastMarried();
		$scope.transport_751to1000_west_single = DataRates.get751to1000WestSingle();
		$scope.transport_751to1000_west_married = DataRates.get751to1000WestMarried();
		$scope.transport_751to1000_east_single = DataRates.get751to1000EastSingle();
		$scope.transport_751to1000_east_married = DataRates.get751to1000EastMarried();
		$scope.transport_1001to1250_west_single = DataRates.get1001to1250WestSingle();
		$scope.transport_1001to1250_west_married = DataRates.get1001to1250WestMarried();
		$scope.transport_1001to1250_east_single = DataRates.get1001to1250EastSingle();
		$scope.transport_1001to1250_east_married = DataRates.get1001to1250EastMarried();
		$scope.transport_1251to999999_west_single = DataRates.get1251to999999WestSingle();
		$scope.transport_1251to999999_west_married = DataRates.get1251to999999WestMarried();
		$scope.transport_1251to999999_east_single = DataRates.get1251to999999EastSingle();
		$scope.transport_1251to999999_east_married = DataRates.get1251to999999EastMarried();

		if (jsonRateWithin && jsonRateFrom && jsonRateOthers && jsonRateVehicle && jsonRateTransport) {
			console.log('Load Init RatesCtrl (Django Obj)');

			var angular_rates = getAngularObjFromJson(jsonRateWithin);
			var inwest_single3day = angular_rates.inwest_single3day;
			var inwest_married3day = angular_rates.inwest_married3day;
			var insarawak_single3day = angular_rates.insarawak_single3day;
			var insarawak_married3day = angular_rates.insarawak_married3day;
			var insabah_single3day = angular_rates.insabah_single3day;
			var insabah_married3day = angular_rates.insabah_married3day;

			var angular_rates = getAngularObjFromJson(jsonRateFrom);
			var fromwest_single3day = angular_rates.fromwest_single3day;
			var fromwest_married3day = angular_rates.fromwest_married3day;
			var fromsarawak_single3day = angular_rates.fromsarawak_single3day;
			var fromsarawak_married3day = angular_rates.fromsarawak_married3day;
			var fromsabah_single3day = angular_rates.fromsabah_single3day;
			var fromsabah_married3day = angular_rates.fromsabah_married3day;
			var between_single3day = angular_rates.between_single3day;
			var between_married3day = angular_rates.between_married3day;

			var angular_rates = getAngularObjFromJson(jsonRateOthers);
			var west_meal3day = angular_rates.west_meal3day;
			var west_hotel3day = angular_rates.west_hotel3day;
			var west_lodging3day = angular_rates.west_lodging3day;
			var east_meal3day = angular_rates.east_meal3day;
			var east_hotel3day = angular_rates.east_hotel3day;
			var east_lodging3day = angular_rates.east_lodging3day;

			var angular_rates = getAngularObjFromJson(jsonRateVehicle);
			var motorboat = angular_rates.motorboat;
			var motorcycle = angular_rates.motorcycle;
			var car = angular_rates.car;

			var angular_rates = getAngularObjFromJson(jsonRateTransport);
			var transport_0to50_west_single = angular_rates.Transport0To50WestSingle;
			var transport_0to50_west_married = angular_rates.Transport0To50WestMarried;
			var transport_0to50_east_single = angular_rates.Transport0To50EastSingle;
			var transport_0to50_east_married = angular_rates.Transport0To50EastMarried;
			var transport_51to250_west_single = angular_rates.Transport51To250WestSingle;
			var transport_51to250_west_married = angular_rates.Transport51To250WestMarried;
			var transport_51to250_east_single = angular_rates.Transport51To250EastSingle;
			var transport_51to250_east_married = angular_rates.Transport51To250EastMarried;
			var transport_251to500_west_single = angular_rates.Transport251To500WestSingle;
			var transport_251to500_west_married = angular_rates.Transport251To500WestMarried;
			var transport_251to500_east_single = angular_rates.Transport251To500EastSingle;
			var transport_251to500_east_married = angular_rates.Transport251To500EastMarried;
			var transport_501to750_west_single = angular_rates.Transport501To750WestSingle;
			var transport_501to750_west_married = angular_rates.Transport501To750WestMarried;
			var transport_501to750_east_single = angular_rates.Transport501To750EastSingle;
			var transport_501to750_east_married = angular_rates.Transport501To750EastMarried;
			var transport_751to1000_west_single = angular_rates.Transport751To1000WestSingle;
			var transport_751to1000_west_married = angular_rates.Transport751To1000WestMarried;
			var transport_751to1000_east_single = angular_rates.Transport751To1000EastSingle;
			var transport_751to1000_east_married = angular_rates.Transport751To1000EastMarried;
			var transport_1001to1250_west_single = angular_rates.Transport1001To1250WestSingle;
			var transport_1001to1250_west_married = angular_rates.Transport1001To1250WestMarried;
			var transport_1001to1250_east_single = angular_rates.Transport1001To1250EastSingle;
			var transport_1001to1250_east_married = angular_rates.Transport1001To1250EastMarried;
			var transport_1251to999999_west_single = angular_rates.Transport1251To999999WestSingle;
			var transport_1251to999999_west_married = angular_rates.Transport1251To999999WestMarried;
			var transport_1251to999999_east_single = angular_rates.Transport1251To999999EastSingle;
			var transport_1251to999999_east_married = angular_rates.Transport1251To999999EastMarried;

			$scope.inwest_single3day = inwest_single3day;
			$scope.inwest_married3day = inwest_married3day;
			$scope.insarawak_single3day = insarawak_single3day;
			$scope.insarawak_married3day = insarawak_married3day;
			$scope.insabah_single3day = insabah_single3day;
			$scope.insabah_married3day = insabah_married3day;

			$scope.fromwest_single3day = fromwest_single3day;
			$scope.fromwest_married3day = fromwest_married3day;
			$scope.fromsarawak_single3day = fromsarawak_single3day;
			$scope.fromsarawak_married3day = fromsarawak_married3day;
			$scope.fromsabah_single3day = fromsabah_single3day;
			$scope.fromsabah_married3day = fromsabah_married3day;
			$scope.between_single3day = between_single3day;
			$scope.between_married3day = between_married3day;

			$scope.west_meal3day = west_meal3day;
			$scope.west_hotel3day = west_hotel3day;
			$scope.west_lodging3day = west_lodging3day;
			$scope.east_meal3day = east_meal3day;
			$scope.east_hotel3day = east_hotel3day;
			$scope.east_lodging3day = east_lodging3day;

			$scope.motorboat = motorboat;
			$scope.motorcycle = motorcycle;
			$scope.car = car;

			$scope.transport_0to50_west_single = transport_0to50_west_single;
			$scope.transport_0to50_west_married = transport_0to50_west_married;
			$scope.transport_0to50_east_single = transport_0to50_east_single;
			$scope.transport_0to50_east_married = transport_0to50_east_married;
			$scope.transport_51to250_west_single = transport_51to250_west_single;
			$scope.transport_51to250_west_married = transport_51to250_west_married;
			$scope.transport_51to250_east_single = transport_51to250_east_single;
			$scope.transport_51to250_east_married = transport_51to250_east_married;
			$scope.transport_251to500_west_single = transport_251to500_west_single;
			$scope.transport_251to500_west_married = transport_251to500_west_married;
			$scope.transport_251to500_east_single = transport_251to500_east_single;
			$scope.transport_251to500_east_married = transport_251to500_east_married;
			$scope.transport_501to750_west_single = transport_501to750_west_single;
			$scope.transport_501to750_west_married = transport_501to750_west_married;
			$scope.transport_501to750_east_single = transport_501to750_east_single;
			$scope.transport_501to750_east_married = transport_501to750_east_married;
			$scope.transport_751to1000_west_single = transport_751to1000_west_single;
			$scope.transport_751to1000_west_married = transport_751to1000_west_married;
			$scope.transport_751to1000_east_single = transport_751to1000_east_single;
			$scope.transport_751to1000_east_married = transport_751to1000_east_married;
			$scope.transport_1001to1250_west_single = transport_1001to1250_west_single;
			$scope.transport_1001to1250_west_married = transport_1001to1250_west_married;
			$scope.transport_1001to1250_east_single = transport_1001to1250_east_single;
			$scope.transport_1001to1250_east_married = transport_1001to1250_east_married;
			$scope.transport_1251to999999_west_single = transport_1251to999999_west_single;
			$scope.transport_1251to999999_west_married = transport_1251to999999_west_married;
			$scope.transport_1251to999999_east_single = transport_1251to999999_east_single;
			$scope.transport_1251to999999_east_married = transport_1251to999999_east_married;

			DataRates.setInWestSingleRate3Day(inwest_single3day);
			DataRates.setInWestMarriedRate3Day(inwest_married3day);
			DataRates.setInSarawakSingleRate3Day(insarawak_single3day);
			DataRates.setInSarawakMarriedRate3Day(insarawak_married3day);
			DataRates.setInSabahSingleRate3Day(insabah_single3day);
			DataRates.setInSabahMarriedRate3Day(insabah_married3day);

			DataRates.setFromWestSingleRate3Day(fromwest_single3day);
			DataRates.setFromWestMarriedRate3Day(fromwest_married3day);
			DataRates.setFromSarawakSingleRate3Day(fromsarawak_single3day);
			DataRates.setFromSarawakMarriedRate3Day(fromsarawak_married3day);
			DataRates.setFromSabahSingleRate3Day(fromsabah_single3day);
			DataRates.setFromSabahMarriedRate3Day(fromsabah_married3day);
			DataRates.setBetweenSingleRate3Day(between_single3day);
			DataRates.setBetweenMarriedRate3Day(between_married3day);

			DataRates.setWestMealRate3Day(west_meal3day);
			DataRates.setWestHotelRate3Day(west_hotel3day);
			DataRates.setWestLodgingRate3Day(west_lodging3day);
			DataRates.setEastMealRate3Day(east_meal3day);
			DataRates.setEastHotelRate3Day(east_hotel3day);
			DataRates.setEastLodgingRate3Day(east_lodging3day);

			DataRates.setMotorboat(motorboat);
			DataRates.setMotorcycle(motorcycle);
			DataRates.setCar(car);

			DataRates.set0to50WestSingle(transport_0to50_west_single);
			DataRates.set0to50WestMarried(transport_0to50_west_married);
			DataRates.set0to50EastSingle(transport_0to50_east_single);
			DataRates.set0to50EastMarried(transport_0to50_east_married);
			DataRates.set51to250WestSingle(transport_51to250_west_single);
			DataRates.set51to250WestMarried(transport_51to250_west_married);
			DataRates.set51to250EastSingle(transport_51to250_east_single);
			DataRates.set51to250EastMarried(transport_51to250_east_married);
			DataRates.set251to500WestSingle(transport_251to500_west_single);
			DataRates.set251to500WestMarried(transport_251to500_west_married);
			DataRates.set251to500EastSingle(transport_251to500_east_single);
			DataRates.set251to500EastMarried(transport_251to500_east_married);
			DataRates.set501to750WestSingle(transport_501to750_west_single);
			DataRates.set501to750WestMarried(transport_501to750_west_married);
			DataRates.set501to750EastSingle(transport_501to750_east_single);
			DataRates.set501to750EastMarried(transport_501to750_east_married);
			DataRates.set751to1000WestSingle(transport_751to1000_west_single);
			DataRates.set751to1000WestMarried(transport_751to1000_west_married);
			DataRates.set751to1000EastSingle(transport_751to1000_east_single);
			DataRates.set751to1000EastMarried(transport_751to1000_east_married);
			DataRates.set1001to1250WestSingle(transport_1001to1250_west_single);
			DataRates.set1001to1250WestMarried(transport_1001to1250_west_married);
			DataRates.set1001to1250EastSingle(transport_1001to1250_east_single);
			DataRates.set1001to1250EastMarried(transport_1001to1250_east_married);
			DataRates.set1251to999999WestSingle(transport_1251to999999_west_single);
			DataRates.set1251to999999WestMarried(transport_1251to999999_west_married);
			DataRates.set1251to999999EastSingle(transport_1251to999999_east_single);
			DataRates.set1251to999999EastMarried(transport_1251to999999_east_married);
		}
	};
	$scope.$watch(function () { return DataRates.getTriggerRates(); }, function (newValue, oldValue) {
		$scope.initRatesCtrl();
		DataRates.setTriggerRates(false);
	});
});

uiBootstrapApp.controller('TransferDetailsCtrl', function($scope, $filter, $http, $q, DataFormDoc, DataMain, DataClaimant, DataRates, DataFundType, DataLookup, DataFormTransferDetails, DataFormClaimDetails) {

	$scope.transferDate = new Date();

    $scope.initTransferDetailsCtrl = function(jsonTransferDestinationList, jsonTransferMoverList, jsonChildren, draftID) {
        console.log('Load initTransferDetailsCtrl (Default)');
		$scope.claimant_no = DataMain.getClaimantNo();

		$scope.gradeAfter = [];
		$scope.transferVehicleList = [];
		$scope.spouseList = [];
		$scope.childrenList = [];
		$scope.transferDestinationList = [];
		$scope.transferMoverList = [];
		$scope.transferMover = {};
		$scope.transferDestination = {};
		$scope.transferVehicle = {};

		var promises = {
			salary_grade: $http({
					url: API_URL+'salary-grades/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.gradeAfter = data.results;
				}),
			vehicle_type: $http({
					url: API_URL+'vehicle-type/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.transferVehicleList = data.results;
				}),
			claimant_spouses: $http({
					url: API_URL+'claimant-spouses/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					$scope.spouseList = data.results;
					DataMain.setTotalSpouse($scope.spouseList.length);
					changeItemVal('spouseList')
					changeItemVal('total_dependent');
				}),
			document_list: $http({
					url: API_URL+'document-list/',
					method: 'GET',
					params: {'claim_type': 'LFC'}
				})
				.success(function (data, status, headers, config) {
					$scope.docs = data.results;
					DataFormDoc.setDocList(data.results);
				}),
			expenses_list: $http({
					url: API_URL+'expenses/',
					method: 'GET',
					params: {'claim_code':'LFC'}
				})
				.success(function (data, status, headers, config) {
					$scope.expenses = data.results;
					DataFormTransferDetails.setExpensesList($scope.expenses);
				}),
		}
		getAngularObjFromJson(jsonTransferMoverList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.transferMoverList.push({code:code, description:description});
		});
		getAngularObjFromJson(jsonTransferDestinationList).forEach(function (obj) {
			var code = obj['code'];
			var description = obj['description'];
			$scope.transferDestinationList.push({code:code, description:description});
		});
		getAngularObjFromJson(jsonChildren).forEach(function (obj) {
			data = obj.fields;
			var name = data['name'];
			var ic = data['ic'];
			var age = data['age'];
			var work_status = data['work_status'];
			var oku_status = data['oku_status'];
			var entitled = entitlement(age,work_status,oku_status);
			$scope.childrenList.push({name:name, ic:ic, age:age, work_status:work_status, oku_status:oku_status, entitled:entitled});
			changeItemVal('childrenList')
		});
		$scope.getDataByCode = function (code, dropdown) {
            var objSelect = $filter("filter")(dropdown, { code: code });
            return objSelect[0];
        };
		$scope.getDataById = function (id, dropdown) {
            var objSelect = $filter("filter")(dropdown, { id: id });
            return objSelect[0];
        };

		if (draftID || PK) {
			if (draftID) { // draft view
				$http({
					url: API_URL+'local-transfer-claim-drafts/'+draftID+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					dataSet(data);
				});
			} else if (PK) {  // detail view
				$http({
					url: API_URL+'local-transfer-claims/'+PK+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					dataSet(data);
				});
			}
        }
		
		var dataSet = function (data) {
			$q.all(promises).then(function (resolutions) {
				claim = data.claim_details.claim_details[0];
				address = data.claim_details.address_items[0];
				
				$scope.transferGradeAfter = $scope.getDataByCode(claim.grade_after_id, resolutions.salary_grade.data.results);
				changeItemVal('transferGradeAfter');
				$scope.transferDate = getDateStr($filter, claim.transfer_date);
				$scope.maritalStatus = { status: claim.marital_status };
				changeItemVal('maritalStatus');
				$scope.transferMover = $scope.getDataByCode(claim.mover, $scope.transferMoverList);
				changeItemVal('transferMover');
				$scope.transferDestination = $scope.getDataByCode(claim.destination, $scope.transferDestinationList);
				changeItemVal('transferDestination');
				$scope.transferVehicle = $scope.getDataById(claim.vehicle_id, resolutions.vehicle_type.data.results);
				changeItemVal('transferVehicle');
				DataFundType.setFundType(DataFundType.getFundTypeByCode(claim.fund_type_id));
				if (claim.project_code) {
					$scope.projectCode = claim.project_code;
				}
				$scope.distance = claim.distance;
				changeItemVal('distance');
				$scope.oldOfficeLine1 = address.old_office_line1;
				changeItemVal('oldOfficeLine1');
				$scope.oldOfficeLine2 = address.old_office_line2;
				changeItemVal('oldOfficeLine2');
				$scope.oldOfficeLine3 = address.old_office_line3;
				changeItemVal('oldOfficeLine3');
				$scope.oldOfficeLine4 = address.old_office_line4;
				changeItemVal('oldOfficeLine4');
				$scope.newOfficeLine1 = address.new_office_line1;
				changeItemVal('newOfficeLine1');
				$scope.newOfficeLine2 = address.new_office_line2;
				changeItemVal('newOfficeLine2');
				$scope.newOfficeLine3 = address.new_office_line3;
				changeItemVal('newOfficeLine3');
				$scope.newOfficeLine4 = address.new_office_line4;
				changeItemVal('newOfficeLine4');
				$scope.oldHomeLine1 = address.old_home_line1;
				changeItemVal('oldHomeLine1');
				$scope.oldHomeLine2 = address.old_home_line2;
				changeItemVal('oldHomeLine2');
				$scope.oldHomeLine3 = address.old_home_line3;
				changeItemVal('oldHomeLine3');
				$scope.oldHomeLine4 = address.old_home_line4;
				changeItemVal('oldHomeLine4');
				$scope.newHomeLine1 = address.new_home_line1;
				changeItemVal('newHomeLine1');
				$scope.newHomeLine2 = address.new_home_line2;
				changeItemVal('newHomeLine2');
				$scope.newHomeLine3 = address.new_home_line3;
				changeItemVal('newHomeLine3');
				$scope.newHomeLine4 = address.new_home_line4;
				changeItemVal('newHomeLine4');
		
				if (data.claim_details.spouse_items) {
					data.claim_details.spouse_items.forEach(function(obj) {
						$scope.addItemSpouse(obj);
					});
				};
				
				if (data.claim_details.children_items) {
					data.claim_details.children_items.forEach(function(obj) {
						$scope.addItemChildren(obj);
					});
				};
			});
		}
	};

	$scope.openTransferDate = function($event) {
        $scope.statusTransferDate.opened = true;
    };
	$scope.statusTransferDate = {
        opened: false
    };

	$scope.addItemSpouse = function(objDB) {
        getItemsSpouse().push(setRowSpouse(objDB));
    };
	
	var getItemsSpouse = function(itemIndex) {
        var obj = [];
        if (itemIndex == undefined) {
            obj = $scope.spouseList;
        } else {
            obj = $scope.spouseList[itemIndex];
        }
        return obj;
    };
		
	var setRowSpouse = function(objDB) {
        if (objDB) {
			$scope.name = objDB.name
			$scope.ic = objDB.ic_birthcert
			$scope.grade = objDB.grade
			$scope.position = objDB.position
			$scope.basic_salary = objDB.basic_salary
			$scope.employer_name = objDB.employer_name
        }
		return {
            name: $scope.name
			, ic: $scope.ic
			, grade: $scope.grade
			, position: $scope.position
			, basic_salary: get2Float($scope.basic_salary)
			, employer_name: $scope.employer_name
        };
    };
	
	$scope.addItemChildren = function(objDB) {
        getItemsChildren().push(setRowChildren(objDB));
    };
	
	var getItemsChildren = function(itemIndex) {
        var obj = [];
        if (itemIndex == undefined) {
            obj = $scope.childrenList;
        } else {
            obj = $scope.childrenList[itemIndex];
        }
        return obj;
    };
	
	var setRowChildren = function(objDB) {
        if (objDB) {
			$scope.name = objDB.name
			$scope.ic = objDB.ic_birthcert
			$scope.grade = objDB.age
			$scope.position = objDB.work_status
			$scope.oku_status = objDB.oku_status
			$scope.entitled = objDB.entitled
        }
		return {
            name: $scope.name
			, ic: $scope.ic
			, age: $scope.age
			, work_status: $scope.work_status
			, oku_status: $scope.oku_status
			, entitled: $scope.entitled
        };
    };
	
	var changeItemVal = function(obj) {
		if (obj == 'transferLocalFundType') {
            DataFormTransferDetails.setTransferLocalFundType(DataFundType.getFundType());
        } else if (obj == 'spouseList') {
			DataFormTransferDetails.setSpouseList($scope.spouseList);
		} else if (obj == 'childrenList') {
			DataFormTransferDetails.setChildrenList($scope.childrenList);
		} else if (obj == 'total_dependent') {
			$scope.total_dependent = entitle + DataMain.getTotalSpouse() + 1;
			DataMain.setTotalDependent($scope.total_dependent);
		} else if (obj == 'transferLocalProjectCode') {
            DataFormTransferDetails.setTransferLocalProjectCode(DataLookup.getProjectCode());
        } else if (obj == 'transferGradeAfter') {
            DataFormTransferDetails.setTransferGradeAfter($scope.transferGradeAfter);
        } else if (obj == 'transferDate') {
			DataFormTransferDetails.setTransferDate($scope.transferDate)
			DataFormTransferDetails.setTransferDateTxt(getDateStr($filter, $scope.transferDate));
        } else if (obj == 'maritalStatus') {
            DataFormTransferDetails.setMaritalStatus($scope.maritalStatus);
        } else if (obj == 'transferMover') {
            DataFormTransferDetails.setTransferMover($scope.transferMover);
        } else if (obj == 'transferDestination') {
            DataFormTransferDetails.setTransferDestination($scope.transferDestination);
        } else if (obj == 'transferVehicle') {
            DataFormTransferDetails.setVehicle($scope.transferVehicle);
        } else if (obj == 'distance') {
            DataFormTransferDetails.setDistance($scope.distance);
        } else if (obj == 'oldOfficeLine1') {
            DataFormTransferDetails.setOldOfficeLine1($scope.oldOfficeLine1);
        } else if (obj == 'oldOfficeLine2') {
            DataFormTransferDetails.setOldOfficeLine2($scope.oldOfficeLine2);
        } else if (obj == 'oldOfficeLine3') {
            DataFormTransferDetails.setOldOfficeLine3($scope.oldOfficeLine3);
        } else if (obj == 'oldOfficeLine4') {
            DataFormTransferDetails.setOldOfficeLine4($scope.oldOfficeLine4);
        } else if (obj == 'newOfficeLine1') {
            DataFormTransferDetails.setNewOfficeLine1($scope.newOfficeLine1);
        } else if (obj == 'newOfficeLine2') {
            DataFormTransferDetails.setNewOfficeLine2($scope.newOfficeLine2);
        } else if (obj == 'newOfficeLine3') {
            DataFormTransferDetails.setNewOfficeLine3($scope.newOfficeLine3);
        } else if (obj == 'newOfficeLine4') {
            DataFormTransferDetails.setNewOfficeLine4($scope.newOfficeLine4);
        } else if (obj == 'oldHomeLine1') {
            DataFormTransferDetails.setOldHomeLine1($scope.oldHomeLine1);
        } else if (obj == 'oldHomeLine2') {
            DataFormTransferDetails.setOldHomeLine2($scope.oldHomeLine2);
        } else if (obj == 'oldHomeLine3') {
            DataFormTransferDetails.setOldHomeLine3($scope.oldHomeLine3);
        } else if (obj == 'oldHomeLine4') {
            DataFormTransferDetails.setOldHomeLine4($scope.oldHomeLine4);
        } else if (obj == 'newHomeLine1') {
            DataFormTransferDetails.setNewHomeLine1($scope.newHomeLine1);
        } else if (obj == 'newHomeLine2') {
            DataFormTransferDetails.setNewHomeLine2($scope.newHomeLine2);
        } else if (obj == 'newHomeLine3') {
            DataFormTransferDetails.setNewHomeLine3($scope.newHomeLine3);
        } else if (obj == 'newHomeLine4') {
            DataFormTransferDetails.setNewHomeLine4($scope.newHomeLine4);
        }
    };

	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
        changeItemVal('transferLocalFundType');
    });
    $scope.$watch(function () { return DataLookup.getProjectCode(); }, function (newValue, oldValue) {
        changeItemVal('transferLocalProjectCode');
    });
	$scope.$watch('transferGradeAfter', function(newValue, oldValue){
        if (newValue != oldValue) {
			transferGradeAfterFunc();
			changeItemVal('transferGradeAfter');
		}
	});
	$scope.$watch('transferDate', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('transferDate');}
	});
	$scope.changeMaritalStatus = function () {
		claimantEntitlementSet();
		changeItemVal('maritalStatus');
	}
	$scope.$watch('transferMover', function(newValue, oldValue) {
        if (newValue != oldValue) {
			claimantEntitlementSet();
			changeItemVal('transferMover');
		}
	});
	$scope.$watch('transferDestination', function(newValue, oldValue) {
        if (newValue != oldValue) {
			claimantEntitlementSet();
			changeItemVal('transferDestination');
		}
	});
	$scope.$watch('transferVehicle', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('transferVehicle');
			var vehicleRate = 0;
			if ($scope.transferVehicle) {
				var vehicle = $scope.transferVehicle.name;
				if (vehicle == 'Motorcycle') {
					vehicleRate = DataRates.getMotorcycle();
				} else if (vehicle == 'Motorboat') {
					vehicleRate = DataRates.getMotorboat();
				} else if (vehicle == 'Car') {
					vehicleRate = DataRates.getCar();
				}
			}
			DataFormClaimDetails.setVehicleRate(get2Float(vehicleRate));
		}
	});
	$scope.$watch('distance', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('distance');}
	});
	$scope.$watch('oldOfficeLine1', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldOfficeLine1');}
	});
	$scope.$watch('oldOfficeLine2', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldOfficeLine2');}
	});
	$scope.$watch('oldOfficeLine3', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldOfficeLine3');}
	});
	$scope.$watch('oldOfficeLine4', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldOfficeLine4');}
	});
	$scope.$watch('newOfficeLine1', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newOfficeLine1');}
	});
	$scope.$watch('newOfficeLine2', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newOfficeLine2');}
	});
	$scope.$watch('newOfficeLine3', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newOfficeLine3');}
	});
	$scope.$watch('newOfficeLine4', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newOfficeLine4');}
	});
	$scope.$watch('oldHomeLine1', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldHomeLine1');}
	});
	$scope.$watch('oldHomeLine2', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldHomeLine2');}
	});
	$scope.$watch('oldHomeLine3', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldHomeLine3');}
	});
	$scope.$watch('oldHomeLine4', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('oldHomeLine4');}
	});
	$scope.$watch('newHomeLine1', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newHomeLine1');}
	});
	$scope.$watch('newHomeLine2', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newHomeLine2');}
	});
	$scope.$watch('newHomeLine3', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newHomeLine3');}
	});
	$scope.$watch('newHomeLine4', function(newValue, oldValue) {
        if (newValue != oldValue) {changeItemVal('newHomeLine4');}
	});
	
	var enableRoom2AndRoom3 = function () {
		angular.element(document.getElementById('hotelThreeDaysRoom2FirstdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom3FirstdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom2SeconddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom3SeconddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom2ThirddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom3ThirddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom2FirstdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom3FirstdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom2SeconddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom3SeconddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom2ThirddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom3ThirddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom2ForthdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom3ForthdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom2FifthdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom3FifthdayPrice'))[0].disabled = false;
	};

	var disableRoom2AndRoom3 = function () {
		angular.element(document.getElementById('hotelThreeDaysRoom2FirstdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom3FirstdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom2SeconddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom3SeconddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom2ThirddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom3ThirddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom2FirstdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom3FirstdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom2SeconddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom3SeconddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom2ThirddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom3ThirddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom2ForthdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom3ForthdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom2FifthdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom3FifthdayPrice'))[0].disabled = true;
	};

	var enableLodging3DaysAnd5Days = function () {
		angular.element(document.getElementById('lodgingThreeDaysAddress'))[0].disabled = false;
		angular.element(document.getElementById('lodgingThreeDaysNoofday'))[0].disabled = false;
		angular.element(document.getElementById('lodgingThreeDaysRateperday'))[0].disabled = false;
		angular.element(document.getElementById('lodgingThreeDaysTotal'))[0].disabled = false;
		angular.element(document.getElementById('lodgingFiveDaysAddress'))[0].disabled = false;
		angular.element(document.getElementById('lodgingFiveDaysNoofday'))[0].disabled = false;
		angular.element(document.getElementById('lodgingFiveDaysRateperday'))[0].disabled = false;
		angular.element(document.getElementById('lodgingFiveDaysTotal'))[0].disabled = false;
		angular.element(document.getElementById('lodgingTotalAllowance'))[0].disabled = false;
	};

	var disableLodging3DaysAnd5Days = function () {
		angular.element(document.getElementById('lodgingThreeDaysAddress'))[0].disabled = true;
		angular.element(document.getElementById('lodgingThreeDaysNoofday'))[0].disabled = true;
		angular.element(document.getElementById('lodgingThreeDaysRateperday'))[0].disabled = true;
		angular.element(document.getElementById('lodgingThreeDaysTotal'))[0].disabled = true;
		angular.element(document.getElementById('lodgingFiveDaysAddress'))[0].disabled = true;
		angular.element(document.getElementById('lodgingFiveDaysNoofday'))[0].disabled = true;
		angular.element(document.getElementById('lodgingFiveDaysRateperday'))[0].disabled = true;
		angular.element(document.getElementById('lodgingFiveDaysTotal'))[0].disabled = true;
		angular.element(document.getElementById('lodgingTotalAllowance'))[0].disabled = true;
	};

	var enablePublicTransport = function () {
		angular.element(document.getElementById('publicLandTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('publicLandTransportationTotal'))[0].disabled = false;
		angular.element(document.getElementById('publicSeaTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('publicSeaTransportationTotal'))[0].disabled = false;
		angular.element(document.getElementById('publicAirTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('publicAirTransportationTotal'))[0].disabled = false;
		angular.element(document.getElementById('publicTotalTransportation'))[0].disabled = false;
	};

	var disablePublicTransport = function () {
		angular.element(document.getElementById('publicLandTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('publicLandTransportationTotal'))[0].disabled = true;
		angular.element(document.getElementById('publicSeaTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('publicSeaTransportationTotal'))[0].disabled = true;
		angular.element(document.getElementById('publicAirTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('publicAirTransportationTotal'))[0].disabled = true;
		angular.element(document.getElementById('publicTotalTransportation'))[0].disabled = true;
	};

	var enableMileage = function () {
		angular.element(document.getElementById('mileageFrom'))[0].disabled = false;
		angular.element(document.getElementById('mileageTo'))[0].disabled = false;
		angular.element(document.getElementById('mileageKM'))[0].disabled = false;
		angular.element(document.getElementById('mileageTotal'))[0].disabled = false;
	};

	var disableMileage = function () {
		angular.element(document.getElementById('mileageFrom'))[0].disabled = true;
		angular.element(document.getElementById('mileageTo'))[0].disabled = true;
		angular.element(document.getElementById('mileageKM'))[0].disabled = true;
		angular.element(document.getElementById('mileageTotal'))[0].disabled = true;
	};

	var enableGoodsLand = function () {
		angular.element(document.getElementById('goodsLandTransportationKM'))[0].disabled = false;
		angular.element(document.getElementById('goodsLandTransportationTotal'))[0].disabled = false;
	};

	var disableGoodsLand = function () {
		angular.element(document.getElementById('goodsLandTransportationKM'))[0].disabled = true;
		angular.element(document.getElementById('goodsLandTransportationTotal'))[0].disabled = true;
	};

	var enableGoodsSea= function () {
		angular.element(document.getElementById('goodsSeaTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('goodsSeaTransportationTotal'))[0].disabled = false;
	};

	var disableGoodsSea = function () {
		angular.element(document.getElementById('goodsSeaTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('goodsSeaTransportationTotal'))[0].disabled = true;
	};

	var enableEverythingExceptOther6TopEnabled = function () {
		angular.element(document.getElementById('transferAllowance'))[0].disabled = false;
		angular.element(document.getElementById('mealThreeDaysRateperday'))[0].disabled = false;
		angular.element(document.getElementById('mealThreeDaysNoofperson'))[0].disabled = false;
		angular.element(document.getElementById('mealThreeDaysTotal'))[0].disabled = false;
		angular.element(document.getElementById('mealFiveDaysRateperday'))[0].disabled = false;
		angular.element(document.getElementById('mealFiveDaysNoofperson'))[0].disabled = false;
		angular.element(document.getElementById('mealFiveDaysTotal'))[0].disabled = false;
		angular.element(document.getElementById('totalMealAllowance'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom1FirstdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysFirstdayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom1SeconddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysSeconddayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysRoom1ThirddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysThirddayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelThreeDaysTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom1FirstdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysFirstdayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom1SeconddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysSeconddayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom1ThirddayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysThirddayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom1ForthdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysForthdayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysRoom1FifthdayPrice'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysFifthdayTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelFiveDaysTotal'))[0].disabled = false;
		angular.element(document.getElementById('hotelTotalAmount'))[0].disabled = false;
		angular.element(document.getElementById('hotelTotalGST'))[0].disabled = false;
		angular.element(document.getElementById('hotelReceiptNo'))[0].disabled = false;
	};

	var disableEverythingExceptOther6TopDisabled = function () {
		angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		angular.element(document.getElementById('mealThreeDaysRateperday'))[0].disabled = true;
		angular.element(document.getElementById('mealThreeDaysNoofperson'))[0].disabled = true;
		angular.element(document.getElementById('mealThreeDaysTotal'))[0].disabled = true;
		angular.element(document.getElementById('mealFiveDaysRateperday'))[0].disabled = true;
		angular.element(document.getElementById('mealFiveDaysNoofperson'))[0].disabled = true;
		angular.element(document.getElementById('mealFiveDaysTotal'))[0].disabled = true;
		angular.element(document.getElementById('totalMealAllowance'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom1FirstdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysFirstdayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom1SeconddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysSeconddayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysRoom1ThirddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysThirddayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelThreeDaysTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom1FirstdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysFirstdayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom1SeconddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysSeconddayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom1ThirddayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysThirddayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom1ForthdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysForthdayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysRoom1FifthdayPrice'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysFifthdayTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelFiveDaysTotal'))[0].disabled = true;
		angular.element(document.getElementById('hotelTotalAmount'))[0].disabled = true;
		angular.element(document.getElementById('hotelTotalGST'))[0].disabled = true;
		angular.element(document.getElementById('hotelReceiptNo'))[0].disabled = true;
	};
	
	var entitle = 0;
	var entitlement = function (age,work_status,oku_status) {
		var pass = true;
		var entitlement_status;
		if (parseInt(age) < 21) {
		    if(work_status == 'Student') {
				pass = true;
		    } else if (work_status == 'Employed') {
				pass = !!oku_status;
		    }
		} else {
		    if(work_status == 'Student') {
				pass = false;
		    } else if (work_status == 'Employed') {
				pass = !!oku_status;
		    }
		}
		if(pass) {
			entitlement_status = 'Layak'
			entitle = entitle + 1;
			changeItemVal('total_dependent');
		} else {
			entitlement_status = 'Tidak Layak'
		}
		return entitlement_status
	};
	
	var transferGradeAfterFunc  = function () {
		changeItemVal('transferGradeAfter');
		old_salary_grade = DataMain.getSalaryGrade();
		new_salary_grade = DataFormTransferDetails.getTransferGradeAfter().code;
		basic_salary = DataMain.getBasicSalary();

		$http({
			url: API_URL+'west-malaysia-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entWestMalaysiaTransferAllowance = data.results;
			var entWestMalaysiaTransferAllowance = $scope.entWestMalaysiaTransferAllowance;
			for (var i=0; i < entWestMalaysiaTransferAllowance.length; i++){
				DataRates.setInWestSingleRate5Day(entWestMalaysiaTransferAllowance[i].single)
				DataRates.setInWestMarriedRate5Day(entWestMalaysiaTransferAllowance[i].married)
				DataRates.setInWestMisc(entWestMalaysiaTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'sarawak-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entSarawakTransferAllowance = data.results;
			var entSarawakTransferAllowance = $scope.entSarawakTransferAllowance;
			for (var i=0; i < entSarawakTransferAllowance.length; i++){
				DataRates.setInSarawakSingleRate5Day(entSarawakTransferAllowance[i].single)
				DataRates.setInSarawakMarriedRate5Day(entSarawakTransferAllowance[i].married)
				DataRates.setInSarawakMisc(entSarawakTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'sabah-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entSabahTransferAllowance = data.results;
			var entSabahTransferAllowance = $scope.entSabahTransferAllowance;
			for (var i=0; i < entSabahTransferAllowance.length; i++){
				DataRates.setInSabahSingleRate5Day(entSabahTransferAllowance[i].single)
				DataRates.setInSabahMarriedRate5Day(entSabahTransferAllowance[i].married)
				DataRates.setInSabahMisc(entSabahTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'from-west-malaysia-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entFromWestMalaysiaTransferAllowance = data.results;
			var entFromWestMalaysiaTransferAllowance = $scope.entFromWestMalaysiaTransferAllowance;
			for (var i=0; i < entFromWestMalaysiaTransferAllowance.length; i++){
				DataRates.setFromWestSingleRate5Day(entFromWestMalaysiaTransferAllowance[i].single)
				DataRates.setFromWestMarriedRate5Day(entFromWestMalaysiaTransferAllowance[i].married)
				DataRates.setFromWestMisc(entFromWestMalaysiaTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'from-sarawak-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entFromSarawakTransferAllowance = data.results;
			var entFromSarawakTransferAllowance = $scope.entFromSarawakTransferAllowance;
			for (var i=0; i < entFromSarawakTransferAllowance.length; i++){
				DataRates.setFromSarawakSingleRate5Day(entFromSarawakTransferAllowance[i].single)
				DataRates.setFromSarawakMarriedRate5Day(entFromSarawakTransferAllowance[i].married)
				DataRates.setFromSarawakMisc(entFromSarawakTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'from-sabah-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entFromSabahTransferAllowance = data.results;
			var entFromSabahTransferAllowance = $scope.entFromSabahTransferAllowance;
			for (var i=0; i < entFromSabahTransferAllowance.length; i++){
				DataRates.setFromSabahSingleRate5Day(entFromSabahTransferAllowance[i].single)
				DataRates.setFromSabahMarriedRate5Day(entFromSabahTransferAllowance[i].married)
				DataRates.setFromSabahMisc(entFromSabahTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'between-sabah-sarawak-transfer-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entBetweenSabahSarawakTransferAllowance = data.results;
			var entBetweenSabahSarawakTransferAllowance = $scope.entBetweenSabahSarawakTransferAllowance;
			for (var i=0; i < entBetweenSabahSarawakTransferAllowance.length; i++){
				DataRates.setBetweenSingleRate5Day(entBetweenSabahSarawakTransferAllowance[i].single)
				DataRates.setBetweenMarriedRate5Day(entBetweenSabahSarawakTransferAllowance[i].married)
				DataRates.setBetweenMisc(entBetweenSabahSarawakTransferAllowance[i].miscellaneous)
			}
		});
		$http({
			url: API_URL+'offduty-trip-allowance/',
			method: 'GET',
			params: {'salaryGrade':new_salary_grade}
		})
		.success(function (data, status, headers, config) {
			$scope.entOfficialTripAllowance = data.results;
			var entOfficialTripAllowance = $scope.entOfficialTripAllowance;
			for (var i=0; i < entOfficialTripAllowance.length; i++){
				if (entOfficialTripAllowance[i].region == 'West') {
					DataRates.setWestMealRate5Day(entOfficialTripAllowance[i].meal)
					DataRates.setWestHotelRate5Day(entOfficialTripAllowance[i].hotel)
					DataRates.setWestLodgingRate5Day(entOfficialTripAllowance[i].lodging)
				} else {
					DataRates.setEastMealRate5Day(entOfficialTripAllowance[i].meal)
					DataRates.setEastHotelRate5Day(entOfficialTripAllowance[i].hotel)
					DataRates.setEastLodgingRate5Day(entOfficialTripAllowance[i].lodging)
					DataRates.setTriggerRates(true);
				}
			}
		});
	};

	var claimantEntitlementSet = function () {
		if ($scope.changeMaritalStatus && $scope.transferDestination && $scope.transferMover) {
			var status = $scope.maritalStatus.status;
			var mover = $scope.transferMover.code;
			var destination = $scope.transferDestination.code;
			var dependent = 0;
			var groupedGeneralData = [status, mover, destination]
			if (status == 's') {
				getSingleSetup(groupedGeneralData);
			} else if (status == 'mA') {
				getMarriedAloneSetup(groupedGeneralData);
			} else if (status == 'mF') {
				getMarriedSetup(groupedGeneralData);
			}
			entitlementRateSet(groupedGeneralData)
		}
	}

	var entitlementRateSet = function (groupedGeneralData) {
		var transferAllowance = 0;
		var meal3DayRate = 0;
		var meal5DayRate = 0;
		var hotel3DayRate = 0;
		var hotel5DayRate = 0;
		var lodging3DayRate = 0;
		var lodging5DayRate = 0;
		var miscPercentage = 0;
		var status = groupedGeneralData[0];
		var destination = groupedGeneralData[2];

		if (destination=='WithinPeninsular') {
			if (status == 'mF') {
				transferAllowance = DataRates.getInWestMarriedRate5Day();
			} else {transferAllowance = DataRates.getInWestSingleRate5Day();}
			meal3DayRate = DataRates.getWestMealRate3Day();
			meal5DayRate = DataRates.getWestMealRate5Day();
			hotel3DayRate = DataRates.getWestHotelRate3Day();
			hotel5DayRate = DataRates.getWestHotelRate5Day();
			lodging3DayRate = DataRates.getWestLodgingRate3Day();
			lodging5DayRate = DataRates.getWestLodgingRate5Day();
			miscPercentage = DataRates.getInWestMisc();
		} else if (destination=='WithinSabah') {
			if (status == 'mF') {
				transferAllowance = DataRates.getInSabahMarriedRate5Day();
			} else {transferAllowance = DataRates.getInSabahSingleRate5Day();}
			meal3DayRate = DataRates.getEastMealRate3Day();
			meal5DayRate = DataRates.getEastMealRate5Day();
			hotel3DayRate = DataRates.getEastHotelRate3Day();
			hotel5DayRate = DataRates.getEastHotelRate5Day();
			lodging3DayRate = DataRates.getEastLodgingRate3Day();
			lodging5DayRate = DataRates.getEastLodgingRate5Day();
			miscPercentage = DataRates.getInSabahMisc();
		} else if (destination=='WithinSarawak') {
			if (status == 'mF') {
				transferAllowance = DataRates.getInSarawakMarriedRate5Day();
			} else {transferAllowance = DataRates.getInSarawakSingleRate5Day();}
			meal3DayRate = DataRates.getEastMealRate3Day();
			meal5DayRate = DataRates.getEastMealRate5Day();
			hotel3DayRate = DataRates.getEastHotelRate3Day();
			hotel5DayRate = DataRates.getEastHotelRate5Day();
			lodging3DayRate = DataRates.getEastLodgingRate3Day();
			lodging5DayRate = DataRates.getEastLodgingRate5Day();
			miscPercentage = DataRates.getInSarawakMisc();
		} else if (destination=='FromPeninsulartoSabahSarawak') {
			if (status == 'mF') {
				transferAllowance = DataRates.getFromWestMarriedRate5Day();
			} else {transferAllowance = DataRates.getFromWestSingleRate5Day();}
			meal3DayRate = DataRates.getWestMealRate3Day();
			meal5DayRate = DataRates.getEastMealRate5Day();
			hotel3DayRate = DataRates.getWestHotelRate3Day();
			hotel5DayRate = DataRates.getEastHotelRate5Day();
			lodging3DayRate = DataRates.getWestLodgingRate3Day();
			lodging5DayRate = DataRates.getEastLodgingRate5Day();
			miscPercentage = DataRates.getFromWestMisc();
		} else if (destination=='FromSabahtoPeninsular') {
			if (status == 'mF') {
				transferAllowance = DataRates.getFromSabahMarriedRate5Day();
			} else {transferAllowance = DataRates.getFromSabahSingleRate5Day();}
			meal3DayRate = DataRates.getEastMealRate3Day();
			meal5DayRate = DataRates.getWestMealRate5Day();
			hotel3DayRate = DataRates.getEastHotelRate3Day();
			hotel5DayRate = DataRates.getWestHotelRate5Day();
			lodging3DayRate = DataRates.getEastLodgingRate3Day();
			lodging5DayRate = DataRates.getWestLodgingRate5Day();
			miscPercentage = DataRates.getFromSabahMisc();
		} else if (destination=='FromSarawaktoPeninsular') {
			if (status == 'mF') {
				transferAllowance = DataRates.getFromSarawakMarriedRate5Day();
			} else {transferAllowance = DataRates.getFromSarawakSingleRate5Day();}
			meal3DayRate = DataRates.getEastMealRate3Day();
			meal5DayRate = DataRates.getWestMealRate5Day();
			hotel3DayRate = DataRates.getEastHotelRate3Day();
			hotel5DayRate = DataRates.getWestHotelRate5Day();
			lodging3DayRate = DataRates.getEastLodgingRate3Day();
			lodging5DayRate = DataRates.getWestLodgingRate5Day();
			miscPercentage = DataRates.getFromSarawakMisc();
		} else if (destination=='BetweenSabahandSarawak') {
			if (status == 'mF') {
				transferAllowance = DataRates.getBetweenMarriedRate5Day();
			} else {transferAllowance = DataRates.getBetweenSingleRate5Day();}
			meal3DayRate = DataRates.getEastMealRate3Day();
			meal5DayRate = DataRates.getEastMealRate5Day();
			hotel3DayRate = DataRates.getEastHotelRate3Day();
			hotel5DayRate = DataRates.getEastHotelRate5Day();
			lodging3DayRate = DataRates.getEastLodgingRate3Day();
			lodging5DayRate = DataRates.getEastLodgingRate5Day();
			miscPercentage = DataRates.getBetweenMisc();
		}
		setRateAll(groupedGeneralData,transferAllowance,meal3DayRate,meal5DayRate,hotel3DayRate,hotel5DayRate,lodging3DayRate,lodging5DayRate,miscPercentage);
	}
	
	var getSingleSetup = function (groupedGeneralData) {
		dependent = DataFormClaimDetails.setDependent(1);
		mover = groupedGeneralData[1];
		disableRoom2AndRoom3();
		if (mover == 'MoverProvidedByOrganization') {
			enableLodging3DaysAnd5Days();
			enablePublicTransport();
			enableMileage();
			enableEverythingExceptOther6TopEnabled();
			disableGoodsLand();
			disableGoodsSea();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'MoverUnderClaimantsCost') {
			enableLodging3DaysAnd5Days();
			enablePublicTransport();
			enableMileage();
			enableGoodsLand();
			enableEverythingExceptOther6TopEnabled();
			disableGoodsSea();
		} else if (mover == 'HousemovingWithoutMover') {
			enableLodging3DaysAnd5Days();
			enablePublicTransport();
			enableMileage();
			enableGoodsLand();
			enableGoodsSea();
			enableEverythingExceptOther6TopEnabled();
		} else if (mover == 'TransferWithoutFamily') {
			disableLodging3DaysAnd5Days();
			disablePublicTransport();
			disableMileage();
			disableGoodsLand();
			disableGoodsSea();
			disableEverythingExceptOther6TopDisabled();
		} else if (mover == 'TransferOutsideNoHouseMoving') {
			enablePublicTransport();
			enableMileage();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			disableEverythingExceptOther6TopDisabled();
		}
	};

	var getMarriedAloneSetup = function (groupedGeneralData) {
		dependent = DataFormClaimDetails.setDependent(1);
		mover = groupedGeneralData[1];
		disableRoom2AndRoom3();
		if (mover == 'MoverProvidedByOrganization') {
			enablePublicTransport();
			enableMileage();
			enableEverythingExceptOther6TopEnabled();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'MoverUnderClaimantsCost') {
			enablePublicTransport();
			enableMileage();
			enableEverythingExceptOther6TopEnabled();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'HousemovingWithoutMover') {
			enablePublicTransport();
			enableMileage();
			enableGoodsLand();
			enableGoodsSea();
			enableEverythingExceptOther6TopEnabled();
			disableLodging3DaysAnd5Days();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'TransferWithoutFamily') {
			enablePublicTransport();
			enableMileage();
			enableEverythingExceptOther6TopEnabled();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'TransferOutsideNoHouseMoving') {
			enablePublicTransport();
			enableMileage();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			disableEverythingExceptOther6TopEnabled();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		}
	};

	var getMarriedSetup = function (groupedGeneralData) {
		dependent = DataFormClaimDetails.setDependent(DataMain.getTotalDependent());
		mover = groupedGeneralData[1];
		if (mover == 'MoverProvidedByOrganization') {
			enableRoom2AndRoom3();
			enablePublicTransport();
			enableMileage();
			enableLodging3DaysAnd5Days();
			enableEverythingExceptOther6TopEnabled();
			disableGoodsLand();
			disableGoodsSea();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'MoverUnderClaimantsCost') {
			enableRoom2AndRoom3();
			enablePublicTransport();
			enableMileage();
			enableLodging3DaysAnd5Days();
			enableGoodsLand();
			enableGoodsSea();
			enableEverythingExceptOther6TopEnabled();
		} else if (mover == 'HousemovingWithoutMover') {
			enablePublicTransport();
			enableMileage();
			enableRoom2AndRoom3();
			enableLodging3DaysAnd5Days();
			enableGoodsLand();
			enableGoodsSea();
			enableEverythingExceptOther6TopEnabled();
		} else if (mover == 'TransferWithoutFamily') {
			enablePublicTransport();
			enableMileage();
			enableEverythingExceptOther6TopEnabled();
			disableRoom2AndRoom3();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		} else if (mover == 'TransferOutsideNoHouseMoving') {
			enablePublicTransport();
			enableMileage();
			disableRoom2AndRoom3();
			disableLodging3DaysAnd5Days();
			disableGoodsLand();
			disableGoodsSea();
			disableEverythingExceptOther6TopDisabled();
			angular.element(document.getElementById('transferAllowance'))[0].disabled = true;
		}
	};

	var setRateAll = function (groupedGeneralData, transferAllowance, meal3DayRate, meal5DayRate, hotel3DayRate, hotel5DayRate, lodging3DayRate, lodging5DayRate, miscPercentage) {
		status = groupedGeneralData[0];
		mover = groupedGeneralData[1];
		if (mover == 'MoverProvidedByOrganization') {
			DataFormClaimDetails.setTransferAllowance(get2Float(0));
			DataFormClaimDetails.setMeal3Day(get2Float(meal3DayRate));
			DataFormClaimDetails.setMeal5Day(get2Float(meal5DayRate));
			DataFormClaimDetails.setHotel3Day(get2Float(hotel3DayRate));
			DataFormClaimDetails.setHotel5Day(get2Float(hotel5DayRate));
			DataFormClaimDetails.setLodging3Day(get2Float(lodging3DayRate));
			DataFormClaimDetails.setLodging5Day(get2Float(lodging5DayRate));
			DataFormClaimDetails.setOtherMiscPercentage(get2Float(miscPercentage));
		} else if (mover == 'MoverUnderClaimantsCost') {
			if (status == 'mA') {
				DataFormClaimDetails.setTransferAllowance(get2Float(0));
			} else {
				DataFormClaimDetails.setTransferAllowance(get2Float(transferAllowance));
			}
			DataFormClaimDetails.setMeal3Day(get2Float(meal3DayRate));
			DataFormClaimDetails.setMeal5Day(get2Float(meal5DayRate));
			DataFormClaimDetails.setHotel3Day(get2Float(hotel3DayRate));
			DataFormClaimDetails.setHotel5Day(get2Float(hotel5DayRate));
			DataFormClaimDetails.setLodging3Day(get2Float(lodging3DayRate));
			DataFormClaimDetails.setLodging5Day(get2Float(lodging5DayRate));
			DataFormClaimDetails.setOtherMiscPercentage(get2Float(miscPercentage));
		} else if (mover == 'HousemovingWithoutMover') {
			if (status == 'mA') {
				DataFormClaimDetails.setTransferAllowance(get2Float(0));
			} else {
				DataFormClaimDetails.setTransferAllowance(get2Float(transferAllowance));
			}
			DataFormClaimDetails.setMeal3Day(get2Float(meal3DayRate));
			DataFormClaimDetails.setMeal5Day(get2Float(meal5DayRate));
			DataFormClaimDetails.setHotel3Day(get2Float(hotel3DayRate));
			DataFormClaimDetails.setHotel5Day(get2Float(hotel5DayRate));
			DataFormClaimDetails.setLodging3Day(get2Float(lodging3DayRate));
			DataFormClaimDetails.setLodging5Day(get2Float(lodging5DayRate));
			DataFormClaimDetails.setOtherMiscPercentage(get2Float(miscPercentage));
		} else if (mover == 'TransferWithoutFamily') {
			if (status == 's') {
				DataFormClaimDetails.setTransferAllowance(get2Float(0));
				DataFormClaimDetails.setMeal3Day(get2Float(0));
				DataFormClaimDetails.setMeal5Day(get2Float(0));
			} else {
				DataFormClaimDetails.setTransferAllowance(get2Float(0));
				DataFormClaimDetails.setMeal3Day(get2Float(meal3DayRate));
				DataFormClaimDetails.setMeal5Day(get2Float(meal5DayRate));
			}
			DataFormClaimDetails.setHotel3Day(get2Float(hotel3DayRate));
			DataFormClaimDetails.setHotel5Day(get2Float(hotel5DayRate));
			DataFormClaimDetails.setLodging3Day(get2Float(lodging3DayRate));
			DataFormClaimDetails.setLodging5Day(get2Float(lodging5DayRate));
			DataFormClaimDetails.setOtherMiscPercentage(get2Float(miscPercentage));
		} else if (mover == 'TransferOutsideNoHouseMoving') {
			DataFormClaimDetails.setTransferAllowance(get2Float(0));
			DataFormClaimDetails.setMeal3Day(get2Float(0));
			DataFormClaimDetails.setMeal5Day(get2Float(0));
			DataFormClaimDetails.setHotel3Day(get2Float(hotel3DayRate));
			DataFormClaimDetails.setHotel5Day(get2Float(hotel5DayRate));
			DataFormClaimDetails.setLodging3Day(get2Float(lodging3DayRate));
			DataFormClaimDetails.setLodging5Day(get2Float(lodging5DayRate));
			DataFormClaimDetails.setOtherMiscPercentage(get2Float(miscPercentage));
		}
		DataFormClaimDetails.setTrigger(true);
	};
});

uiBootstrapApp.controller('ClaimDetailsCtrl', function($scope, $filter, $http, DataRates, DataFormTransferDetails, DataFormClaimDetails, DataEndowment) {
	$scope.Trigger = false;

	$scope.initClaimDetailsCtrl = function(draftID) {
        console.log('Load initClaimDetailsCtrl (Default)');

		$scope.miscItems = [];
		setEmptyTable();
		
		$scope.$watch(function () { return DataFormClaimDetails.getTrigger(); }, function (newValue, oldValue) {
			var transferall = DataFormClaimDetails.getTransferAllowance();
			var mrate3day = DataFormClaimDetails.getMeal3Day();
			var mrate5day = DataFormClaimDetails.getMeal5Day();
			var dependent = DataFormClaimDetails.getDependent();
			var lrate3day = DataFormClaimDetails.getLodging3Day();
			var lrate5day = DataFormClaimDetails.getLodging5Day();
			var miscPercentage = DataFormClaimDetails.getOtherMiscPercentage();

			$scope.transferAllowance = transferall;
			$scope.mealThreeDaysRateperday = mrate3day;
			$scope.mealFiveDaysRateperday = mrate5day;
			$scope.mealThreeDaysNoofperson = dependent;
			$scope.mealFiveDaysNoofperson = dependent;
			$scope.lodgingThreeDaysRateperday = lrate3day;
			$scope.lodgingFiveDaysRateperday = lrate5day;
			$scope.otherMiscPercentage = miscPercentage;

			calculateMeal();
			calculateClaimTotal();

			DataFormClaimDetails.setTrigger(false);
		});

		if (draftID || PK) {
			if (draftID) { // draft view
				$http({
					url: API_URL+'local-transfer-claim-drafts/'+draftID+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					dataSet(data);
				});
			} else if (PK) {  // detail view
				$http({
					url: API_URL+'local-transfer-claims/'+PK+'/',
					method: 'GET'
				})
				.success(function (data, status, headers, config) {
					dataSet(data);
				});
			}
        }
		
		var dataSet = function (data) {
			if (data.claim_details.claim_details[0]) {
				claim = data.claim_details.claim_details[0];
				$scope.transferAllowance = get2Float(claim.transfer_allowance);
				changeItemVal('transferAllowance');

				$scope.goodsLandTransportationKM = claim.goods_land_distance;
				changeItemVal('goodsLandTransportationKM');
				$scope.goodsLandTransportationTotal = get2Float(claim.goods_land_amount);
				changeItemVal('goodsLandTransportationTotal');
				$scope.goodsSeaTransportationReceiptNo = claim.goods_sea_receipt_no;
				changeItemVal('goodsSeaTransportationReceiptNo');
				$scope.goodsSeaTransportationTotal = get2Float(claim.goods_sea_amount);
				changeItemVal('goodsSeaTransportationTotal');

				$scope.otherMiscPercentage = get2Float(claim.other_misc_percentage);
				changeItemVal('otherMiscPercentage');
				$scope.otherMicsAmount = get2Float(claim.other_misc_amount);
				changeItemVal('otherMicsAmount');
			};

			if (data.claim_details.meal_items[0]) {
				meal = data.claim_details.meal_items[0];
				$scope.mealThreeDaysRateperday = get2Float(meal.meal_rate_before);
				changeItemVal('mealThreeDaysRateperday');
				$scope.mealThreeDaysNoofperson = meal.meal_no_of_person_before;
				changeItemVal('mealThreeDaysNoofperson');
				$scope.mealThreeDaysTotal = get2Float(meal.meal_total_before);
				changeItemVal('mealThreeDaysTotal');
				$scope.mealFiveDaysRateperday = get2Float(meal.meal_rate_after);
				changeItemVal('mealFiveDaysRateperday');
				$scope.mealFiveDaysNoofperson = meal.meal_no_of_person_after;
				changeItemVal('mealFiveDaysNoofperson');
				$scope.mealFiveDaysTotal = get2Float(meal.meal_total_after);
				changeItemVal('mealFiveDaysTotal');
				$scope.totalMealAllowance = get2Float(meal.meal_total_amount);
				changeItemVal('totalMealAllowance');
			};

			if (data.claim_details.hotel_items[0]) {
				hotel = data.claim_details.hotel_items[0];
				$scope.hotel3Day = get2Float(hotel.hotel_rate_before);
				changeItemVal('hotel3Day');
				$scope.hotelThreeDaysRoom1FirstdayPrice = get2Float(hotel.room_price_1_first_3);
				changeItemVal('hotelThreeDaysRoom1FirstdayPrice');
				$scope.hotelThreeDaysRoom2FirstdayPrice = get2Float(hotel.room_price_2_first_3);
				changeItemVal('hotelThreeDaysRoom2FirstdayPrice');
				$scope.hotelThreeDaysRoom3FirstdayPrice = get2Float(hotel.room_price_3_first_3);
				changeItemVal('hotelThreeDaysRoom3FirstdayPrice');
				$scope.hotelThreeDaysRoom1SeconddayPrice = get2Float(hotel.room_price_1_second_3);
				changeItemVal('hotelThreeDaysRoom1SeconddayPrice');
				$scope.hotelThreeDaysRoom2SeconddayPrice = get2Float(hotel.room_price_2_second_3);
				changeItemVal('hotelThreeDaysRoom2SeconddayPrice');
				$scope.hotelThreeDaysRoom3SeconddayPrice = get2Float(hotel.room_price_3_second_3);
				changeItemVal('hotelThreeDaysRoom3SeconddayPrice');
				$scope.hotelThreeDaysRoom1ThirddayPrice = get2Float(hotel.room_price_1_third_3);
				changeItemVal('hotelThreeDaysRoom1ThirddayPrice');
				$scope.hotelThreeDaysRoom2ThirddayPrice = get2Float(hotel.room_price_2_third_3);
				changeItemVal('hotelThreeDaysRoom2ThirddayPrice');
				$scope.hotelThreeDaysRoom3ThirddayPrice = get2Float(hotel.room_price_3_third_3);
				changeItemVal('hotelThreeDaysRoom3ThirddayPrice');
				$scope.hotelThreeDaysTotal = get2Float(hotel.hotel_total_amount_3);
				changeItemVal('hotelThreeDaysTotal');
				$scope.hotel5Day = get2Float(hotel.hotel_rate_after);
				changeItemVal('hotel5Day');
				$scope.hotelFiveDaysRoom1FirstdayPrice = get2Float(hotel.room_price_1_first_5);
				changeItemVal('hotelFiveDaysRoom1FirstdayPrice');
				$scope.hotelFiveDaysRoom2FirstdayPrice = get2Float(hotel.room_price_2_first_5);
				changeItemVal('hotelFiveDaysRoom2FirstdayPrice');
				$scope.hotelFiveDaysRoom3FirstdayPrice = get2Float(hotel.room_price_3_first_5);
				changeItemVal('hotelFiveDaysRoom3FirstdayPrice');
				$scope.hotelFiveDaysRoom1SeconddayPrice = get2Float(hotel.room_price_1_second_5);
				changeItemVal('hotelFiveDaysRoom1SeconddayPrice');
				$scope.hotelFiveDaysRoom2SeconddayPrice = get2Float(hotel.room_price_2_second_5);
				changeItemVal('hotelFiveDaysRoom2SeconddayPrice');
				$scope.hotelFiveDaysRoom3SeconddayPrice = get2Float(hotel.room_price_3_second_5);
				changeItemVal('hotelFiveDaysRoom3SeconddayPrice');
				$scope.hotelFiveDaysRoom1ThirddayPrice = get2Float(hotel.room_price_1_third_5);
				changeItemVal('hotelFiveDaysRoom1ThirddayPrice');
				$scope.hotelFiveDaysRoom2ThirddayPrice = get2Float(hotel.room_price_2_third_5);
				changeItemVal('hotelFiveDaysRoom2ThirddayPrice');
				$scope.hotelFiveDaysRoom3ThirddayPrice = get2Float(hotel.room_price_3_third_5);
				changeItemVal('hotelFiveDaysRoom3ThirddayPrice');
				$scope.hotelFiveDaysRoom1ForthdayPrice = get2Float(hotel.room_price_1_forth_5);
				changeItemVal('hotelFiveDaysRoom1ForthdayPrice');
				$scope.hotelFiveDaysRoom2ForthdayPrice = get2Float(hotel.room_price_2_forth_5);
				changeItemVal('hotelFiveDaysRoom2ForthdayPrice');
				$scope.hotelFiveDaysRoom3ForthdayPrice = get2Float(hotel.room_price_3_forth_5);
				changeItemVal('hotelFiveDaysRoom3ForthdayPrice');
				$scope.hotelFiveDaysRoom1FifthdayPrice = get2Float(hotel.room_price_1_fifth_5);
				changeItemVal('hotelFiveDaysRoom1FifthdayPrice');
				$scope.hotelFiveDaysRoom2FifthdayPrice = get2Float(hotel.room_price_2_fifth_5);
				changeItemVal('hotelFiveDaysRoom2FifthdayPrice');
				$scope.hotelFiveDaysRoom3FifthdayPrice = get2Float(hotel.room_price_3_fifth_5);
				changeItemVal('hotelFiveDaysRoom3FifthdayPrice');
				$scope.hotelFiveDaysTotal = get2Float(hotel.hotel_total_amount_5);
				changeItemVal('hotelFiveDaysTotal');
				$scope.hotelTotalAmount = get2Float(hotel.hotel_total_amount);
				changeItemVal('hotelTotalAmount');
				$scope.hotelTotalGST = get2Float(hotel.hotel_total_gst);
				changeItemVal('hotelTotalGST');
				$scope.hotelReceiptNo = hotel.hotel_receipt_no;
				changeItemVal('hotelReceiptNo');
			};

			if (data.claim_details.lodging_items[0]) {
				lodging = data.claim_details.lodging_items[0];
				$scope.lodgingThreeDaysAddress = lodging.lodging_add_before;
				changeItemVal('lodgingThreeDaysAddress');
				$scope.lodgingThreeDaysNoofday = lodging.lodging_no_of_days_before;
				changeItemVal('lodgingThreeDaysNoofday');
				$scope.lodgingThreeDaysRateperday = get2Float(lodging.lodging_rate_before);
				changeItemVal('lodgingThreeDaysRateperday');
				$scope.lodgingThreeDaysTotal = get2Float(lodging.lodging_total_before);
				changeItemVal('lodgingThreeDaysTotal');
				$scope.lodgingFiveDaysAddress = lodging.lodging_add_after;
				changeItemVal('lodgingFiveDaysAddress');
				$scope.lodgingFiveDaysNoofday = lodging.lodging_no_of_days_after;
				changeItemVal('lodgingFiveDaysNoofday');
				$scope.lodgingFiveDaysRateperday = get2Float(lodging.lodging_rate_after);
				changeItemVal('lodgingFiveDaysRateperday');
				$scope.lodgingFiveDaysTotal = get2Float(lodging.lodging_total_after);
				changeItemVal('lodgingFiveDaysTotal');
				$scope.lodgingTotalAllowance = get2Float(lodging.lodging_total_amount);
				changeItemVal('lodgingTotalAllowance');
			};

			if (data.claim_details.transport_items[0]) {
				transport = data.claim_details.transport_items[0];
				$scope.publicLandTransportationReceiptNo = transport.public_land_receipt_no;
				changeItemVal('publicLandTransportationReceiptNo');
				$scope.publicLandTransportationTotal = get2Float(transport.public_land_amount);
				changeItemVal('publicLandTransportationTotal');
				$scope.publicSeaTransportationReceiptNo = transport.public_sea_receipt_no;
				changeItemVal('publicSeaTransportationReceiptNo');
				$scope.publicSeaTransportationTotal = get2Float(transport.public_sea_amount);
				changeItemVal('publicSeaTransportationTotal');
				$scope.publicAirTransportationReceiptNo = transport.public_air_receipt_no;
				changeItemVal('publicAirTransportationReceiptNo');
				$scope.publicAirTransportationTotal = get2Float(transport.public_air_amount);
				changeItemVal('publicAirTransportationTotal');
				$scope.publicTotalTransportation = get2Float(transport.public_total_amount);
				changeItemVal('publicTotalTransportation');
			};

			if (data.claim_details.mileage_items[0]) {
				mileage = data.claim_details.mileage_items[0];
				$scope.mileageFrom = mileage.mileage_add_from;
				changeItemVal('mileageFrom');
				$scope.mileageTo = mileage.mileage_add_to;
				changeItemVal('mileageTo');
				$scope.mileageKM = mileage.mileage_distance;
				changeItemVal('mileageKM');
				$scope.mileageTotal = get2Float(mileage.mileage_total_amount);
				changeItemVal('mileageTotal');
			};

			if (data.claim_details.misc_items) {
				data.claim_details.misc_items.forEach(function(obj) {
					$scope.addItem(obj);
				});
			};

			DataEndowment.setClaimAmount(claim.claim_amount);
			DataEndowment.setEndowmentAmount(claim.endowment_amount);
			DataEndowment.setNetTotal(claim.net_total);
		}
	};

	$scope.$watch('mealThreeDaysRateperday', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('mealThreeDaysRateperday');}
	});
	$scope.$watch('mealThreeDaysNoofperson', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('mealThreeDaysNoofperson');}
	});
	$scope.$watch('mealThreeDaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('mealThreeDaysTotal');}
	});
	$scope.$watch('mealFiveDaysRateperday', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('mealFiveDaysRateperday');}
	});
	$scope.$watch('mealFiveDaysNoofperson', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('mealFiveDaysNoofperson');}
	});
	$scope.$watch('mealFiveDaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('mealFiveDaysTotal');}
	});
	$scope.$watch('totalMealAllowance', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('totalMealAllowance');}
	});
	$scope.$watch('hotel3Day', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotel3Day');}
	});
	$scope.$watch('hotel5Day', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotel5Day');}
	});
	$scope.$watch('hotelThreeDaysRoom1FirstdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom1FirstdayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom1FirstdayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysRoom2FirstdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom2FirstdayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom2FirstdayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysRoom3FirstdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom3FirstdayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom3FirstdayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysFirstdayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelThreeDaysFirstdayTotal');}
	});
	$scope.$watch('hotelThreeDaysRoom1SeconddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom1SeconddayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom1SeconddayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysRoom2SeconddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom2SeconddayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom2SeconddayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysRoom3SeconddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom3SeconddayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom3SeconddayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysSeconddayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelThreeDaysSeconddayTotal');}
	});
	$scope.$watch('hotelThreeDaysRoom1ThirddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom1ThirddayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom1ThirddayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysRoom2ThirddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom2ThirddayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom2ThirddayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysRoom3ThirddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelThreeDaysRoom3ThirddayPrice = calculateEachRoomBefore(parseFloat(newValue));
			changeItemVal('hotelThreeDaysRoom3ThirddayPrice');
		}
	});
	$scope.$watch('hotelThreeDaysThirddayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelThreeDaysThirddayTotal');}
	});
	$scope.$watch('hotelThreeDaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelThreeDaysTotal');}
	});
	$scope.$watch('hotelFiveDaysRoom1FirstdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom1FirstdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom1FirstdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom2FirstdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom2FirstdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom2FirstdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom3FirstdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom3FirstdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom3FirstdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysFirstdayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelFiveDaysFirstdayTotal');}
	});
	$scope.$watch('hotelFiveDaysRoom1SeconddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom1SeconddayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom1SeconddayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom2SeconddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom2SeconddayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom2SeconddayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom3SeconddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom3SeconddayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom3SeconddayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysSeconddayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelFiveDaysSeconddayTotal');}
	});
	$scope.$watch('hotelFiveDaysRoom1ThirddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom1ThirddayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom1ThirddayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom2ThirddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom2ThirddayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom2ThirddayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom3ThirddayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom3ThirddayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom3ThirddayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysThirddayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelFiveDaysThirddayTotal');}
	});
	$scope.$watch('hotelFiveDaysRoom1ForthdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom1ForthdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom1ForthdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom2ForthdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom2ForthdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom2ForthdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom3ForthdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom3ForthdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom3ForthdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysForthdayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelFiveDaysForthdayTotal');}
	});
	$scope.$watch('hotelFiveDaysRoom1FifthdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom1FifthdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom1FifthdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom2FifthdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom2FifthdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom2FifthdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysRoom3FifthdayPrice', function(newValue, oldValue) {
		if (newValue != oldValue) {
			$scope.hotelFiveDaysRoom3FifthdayPrice = calculateEachRoomAfter(parseFloat(newValue));
			changeItemVal('hotelFiveDaysRoom3FifthdayPrice');
		}
	});
	$scope.$watch('hotelFiveDaysFifthdayTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelFiveDaysFifthdayTotal');}
	});
	$scope.$watch('hotelFiveDaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelFiveDaysTotal');}
	});
	$scope.$watch('hotelTotalAmount', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('hotelTotalAmount');
			calculateClaimTotal();
		}
	});
	$scope.$watch('hotelTotalGST', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelTotalGST');}
	});
	$scope.$watch('hotelReceiptNo', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('hotelReceiptNo');}
	});
	$scope.$watch('lodgingThreeDaysAddress', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('lodgingThreeDaysAddress');}
	});
	$scope.$watch('lodgingThreeDaysNoofday',function() {
		var accommodation3DaysCount = 0;
		
		accommodation3DaysCount = accommodation3Days();

		if (accommodation3DaysCount <= 3) {
			calculateLodging();
		} else {$scope.lodgingThreeDaysNoofday = 0;}
		changeItemVal('lodgingThreeDaysNoofday')
	});
	$scope.$watch('lodgingThreeDaysRateperday', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('lodgingThreeDaysRateperday');}
	});
	$scope.$watch('lodgingThreeDaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('lodgingThreeDaysTotal');}
	});
	$scope.$watch('lodgingFiveDaysAddress', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('lodgingFiveDaysAddress');}
	});
	$scope.$watch('lodgingFiveDaysNoofday',function() {
		var accommodation5DaysCount = 0;
		
		accommodation5DaysCount = accommodation5Days();

		if (accommodation5DaysCount <= 5) {
			calculateLodging();
		} else {$scope.lodgingFiveDaysNoofday = 0;}
		changeItemVal('lodgingFiveDaysNoofday')
	});
	$scope.$watch('lodgingFiveDaysRateperday', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('lodgingFiveDaysRateperday');}
	});
	$scope.$watch('lodgingFiveDaysTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('lodgingFiveDaysTotal');}
	});
	$scope.$watch('lodgingTotalAllowance', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('lodgingTotalAllowance');
			calculateClaimTotal();
		}
	});
	$scope.$watch('publicLandTransportationReceiptNo', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicLandTransportationReceiptNo');
			publicMileage();
		}
	});
	$scope.$watch('publicLandTransportationTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicLandTransportationTotal');
			publicMileage();
			calculatePublicTransport();
		}
	});
	$scope.$watch('publicSeaTransportationReceiptNo', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicSeaTransportationReceiptNo');
			publicMileage();
		}
	});
	$scope.$watch('publicSeaTransportationTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicSeaTransportationTotal');
			publicMileage();
			calculatePublicTransport();
		}
	});
	$scope.$watch('publicAirTransportationReceiptNo', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicAirTransportationReceiptNo');
			publicMileage();
		}
	});
	$scope.$watch('publicAirTransportationTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicAirTransportationTotal');
			publicMileage();
			calculatePublicTransport();
		}
	});
	$scope.$watch('publicTotalTransportation', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('publicTotalTransportation');
			calculateClaimTotal();
		}
	});
	$scope.$watch('mileageFrom', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('mileageFrom');
			publicMileage();
		}
	});
	$scope.$watch('mileageTo', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('mileageTo');
			publicMileage();
		}
	});
	$scope.$watch('mileageKM', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('mileageKM');
			publicMileage();
			calculateMileage();
		}
	});
	$scope.$watch('mileageTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('mileageTotal');
			calculateClaimTotal();
		}
	});
	$scope.$watch(function () { return DataFormTransferDetails.getVehicle(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {calculateMileage();}
	});
	$scope.$watch('goodsLandTransportationKM', function(newValue, oldValue) {
		if ($scope.goodsLandTransportationKM == undefined || $scope.goodsLandTransportationKM == '') {
			enableGoodsSea();
		} else {
			if (newValue != oldValue) {
				changeItemVal('goodsLandTransportationKM');
				status = DataFormTransferDetails.getMaritalStatus().status;
				destination = DataFormTransferDetails.getTransferDestination().code;
				disableGoodsSea();
				calculateGoodsTransport(status, destination, newValue);
			}
		}
	});
	$scope.$watch('goodsLandTransportationTotal', function(newValue, oldValue) {
		if (newValue != oldValue) {
			changeItemVal('goodsLandTransportationTotal');
			calculateClaimTotal();
		}
	});
	$scope.$watch('goodsSeaTransportationReceiptNo', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('goodsSeaTransportationReceiptNo');}
	});
	$scope.$watch('goodsSeaTransportationTotal', function(newValue, oldValue){
		if ($scope.goodsSeaTransportationTotal == undefined || $scope.goodsSeaTransportationTotal == '') {
			enableGoodsLand();
		} else {
			disableGoodsLand();
			if (newValue != oldValue) {
				changeItemVal('goodsSeaTransportationTotal');
				calculateClaimTotal();
			}
		}
	});
	$scope.$watch('miscItems', function() {
        DataFormClaimDetails.setMiscItems($scope.miscItems);
		calculateClaimTotal();
    }, true);
	$scope.$watch('otherMiscPercentage', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('otherMiscPercentage');}
	});
	$scope.$watch('otherMicsAmount', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('otherMicsAmount');}
	});
	$scope.$watch(function () { return DataFormTransferDetails.getMaritalStatus(); }, function (newValue, oldValue) {
			if (newValue.status != 'mF') {clearRoom2AndRoom3();}
	}, true);
	$scope.$watch('claimAmount', function(newValue, oldValue) {
		if (newValue != oldValue) {changeItemVal('claimAmount');}
	});
	$scope.$watch(function () { return DataEndowment.getEndowmentAmount(); }, function (newValue, oldValue) {
        changeItemVal('endowmentAmount');
    });
	$scope.$watch(function () { return DataEndowment.getNetTotal(); }, function (newValue, oldValue) {
        changeItemVal('netTotal');
    });
	
	var disableEditMode = function() {
        $scope.isEditMode = false;
        $scope.directIndex = 0;
    };

	var setEmptyTable = function() {
        $scope.currIndex = '';
        $scope.isEmptyTable = true;
        disableEditMode();
    };
	
	var setEditMode = function(itemIndex) {
        setForm(getItems(itemIndex));
        $scope.currIndex = itemIndex;
        $scope.directIndex = itemIndex;
        $scope.isEditMode = true;
    };

	var getItems = function(index) {
        var obj = [];
        obj = $scope.miscItems;
        if (index != undefined) {
            obj = obj[index];
        }
        return obj;
    };

	$scope.gotoUpdateItem = function(direct) {
        /* direct = 'before' or 'next' */
        var currItem = '';
        var list = getItems();
        if (list.length > 0) {
            if ($scope.directIndex == list.length) {
                $scope.directIndex = list.length - 1;
            } else if ($scope.directIndex < 0) {
                $scope.directIndex = 0;
            }

            if (direct == 'previous' && !($scope.directIndex <= 0)) {
                $scope.directIndex--;
                setEditMode($scope.directIndex);
            } else if (direct == 'next' && !($scope.directIndex >= list.length-1)) {
                $scope.directIndex++;
                setEditMode($scope.directIndex);
            }
        }
    };

	$scope.addItem = function(objDB) {
        var items = getItems();
        items.push(setRow(objDB));
        $scope.isEmptyTable = false;
        resetForm();
        calculateMiscTotal();
    };
	
    $scope.deleteItem = function(itemIndex) {
        var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
		var items = [];
        items = getItems();
        items.splice(index, 1); //remove the object from the array based on index
        if (items.length == 0) {
            setEmptyTable();
        }
        calculateMiscTotal();
    };

    $scope.editItem = function(itemIndex) {
		var index = itemIndex + ($scope.currentPage - 1) * $scope.pageSize;
        $scope.isEditMode = true;
        $scope.currIndex = index;
        $scope.directIndex = index;
        $scope.openModal('editForm');
        setForm(getItems(index));
    };

	$scope.openModal = function(mode) {
        $('#miscModalForm').modal('show');
        if (mode == 'newForm') {
            $scope.isEditMode = false;
            resetForm();
        } else if (mode == 'editForm') {
            $scope.isEditMode = true;
        }
    };
	
    var setRow = function(objDB) {
        if (objDB) {
			$scope.miscDate = getDateFromStr(objDB.misc_date);
			$scope.miscType = objDB.misc_type;
			$scope.miscReceiptNo = objDB.misc_receipt_no;
			$scope.miscAmount = objDB.misc_amount;
			$scope.miscTotal = objDB.misc_total;
        }
        return {
			miscDate: $scope.miscDate
			, miscDateTxt: getDateStr($filter, $scope.miscDate)
            , miscType: $scope.miscType
            , miscReceiptNo: $scope.miscReceiptNo
			, miscAmount: $scope.miscAmount
			, miscTotal: $scope.miscTotal
        };
    };

    var setForm = function(currItem) {
        $scope.miscDate = currItem.miscDate;
		$scope.miscType = currItem.miscType;
		$scope.miscReceiptNo = currItem.miscReceiptNo
		$scope.miscAmount = currItem.miscAmount
		$scope.miscTotal = currItem.miscTotal
    }
	
	var resetForm = function() {
        $scope.miscDate = '';
        $scope.miscType = '';
        $scope.miscReceiptNo = '';
        $scope.miscAmount = '';
    };
	
	$scope.openMiscDate = function($event) {
        $scope.statusMiscDate.opened = true;
    };
	$scope.statusMiscDate = {
        opened: false
	};
	
	var changeItemVal = function(obj) {
        if ($scope.isEditMode && !$scope.isDBMode) {
            var currItem = getItems($scope.currIndex);
            if (obj == 'miscDate') {
                currItem.miscDate = $scope.miscDate
				currItem.miscDateTxt = getDateStr($filter, $scope.miscDate);
            } else if (obj == 'miscType') {
                currItem.miscType = $scope.miscType;
            } else if (obj == 'miscReceiptNo') {
                currItem.miscReceiptNo = $scope.miscReceiptNo;
            } else if (obj == 'miscAmount') {
                currItem.miscAmount = $scope.miscAmount;
            }
        }
		else if (obj == 'transferAllowance') {
            DataFormClaimDetails.setTransferAllowance($scope.transferAllowance);
        }
		else if (obj == 'mealThreeDaysRateperday') {
            DataFormClaimDetails.setMealRatePer3Day($scope.mealThreeDaysRateperday);
        }
		else if (obj == 'mealThreeDaysNoofperson') {
            DataFormClaimDetails.setMealNoPerson3Day($scope.mealThreeDaysNoofperson);
        }
		else if (obj == 'mealThreeDaysTotal') {
            DataFormClaimDetails.setMealTotal3Day($scope.mealThreeDaysTotal);
        }
		else if (obj == 'mealFiveDaysRateperday') {
            DataFormClaimDetails.setMealRatePer5Day($scope.mealFiveDaysRateperday);
        }
		else if (obj == 'mealFiveDaysNoofperson') {
            DataFormClaimDetails.setMealNoPerson5Day($scope.mealFiveDaysNoofperson);
        }
		else if (obj == 'mealFiveDaysTotal') {
            DataFormClaimDetails.setMealTotal5Day($scope.mealFiveDaysTotal);
        }
		else if (obj == 'totalMealAllowance') {
            DataFormClaimDetails.setMealTotalAmount($scope.totalMealAllowance);
        }
		else if (obj == 'hotel3Day') {
			DataFormClaimDetails.setHotel3Day($scope.hotel3Day);
		}
		else if (obj == 'hotelThreeDaysRoom1FirstdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1First3($scope.hotelThreeDaysRoom1FirstdayPrice);
		}
		else if (obj == 'hotelThreeDaysRoom2FirstdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2First3($scope.hotelThreeDaysRoom2FirstdayPrice);
		}
		else if (obj == 'hotelThreeDaysRoom3FirstdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3First3($scope.hotelThreeDaysRoom3FirstdayPrice);
		}
		else if (obj == 'hotelThreeDaysFirstdayTotal') {
			DataFormClaimDetails.setHotelTotalFirst3Day($scope.hotelThreeDaysFirstdayTotal);
		}
		else if (obj == 'hotelThreeDaysRoom1SeconddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Second3($scope.hotelThreeDaysRoom1SeconddayPrice);
		}
		else if (obj == 'hotelThreeDaysRoom2SeconddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Second3($scope.hotelThreeDaysRoom2SeconddayPrice);
		}
		else if (obj == 'hotelThreeDaysRoom3SeconddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Second3($scope.hotelThreeDaysRoom3SeconddayPrice);
		}
		else if (obj == 'hotelThreeDaysSeconddayTotal') {
			DataFormClaimDetails.setHotelTotalSecond3Day($scope.hotelThreeDaysSeconddayTotal);
		}
		else if (obj == 'hotelThreeDaysRoom1ThirddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Third3($scope.hotelThreeDaysRoom1ThirddayPrice);
		}
		else if (obj == 'hotelThreeDaysRoom2ThirddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Third3($scope.hotelThreeDaysRoom2ThirddayPrice);
		}
		else if (obj == 'hotelThreeDaysRoom3ThirddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Third3($scope.hotelThreeDaysRoom3ThirddayPrice);
		}
		else if (obj == 'hotelThreeDaysThirddayTotal') {
			DataFormClaimDetails.setHotelTotalThird3Day($scope.hotelThreeDaysThirddayTotal);
		}
		else if (obj == 'hotelThreeDaysTotal') {
			DataFormClaimDetails.setHotelTotal3Day($scope.hotelThreeDaysTotal);
		}
		else if (obj == 'hotel5Day') {
			DataFormClaimDetails.setHotel5Day($scope.hotel5Day);
		}
		else if (obj == 'hotelFiveDaysRoom1FirstdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1First5($scope.hotelFiveDaysRoom1FirstdayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom2FirstdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2First5($scope.hotelFiveDaysRoom2FirstdayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom3FirstdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3First5($scope.hotelFiveDaysRoom3FirstdayPrice);
		}
		else if (obj == 'hotelFiveDaysFirstdayTotal') {
			DataFormClaimDetails.setHotelTotalFirst5Day($scope.hotelFiveDaysFirstdayTotal);
		}
		else if (obj == 'hotelFiveDaysRoom1SeconddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Second5($scope.hotelFiveDaysRoom1SeconddayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom2SeconddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Second5($scope.hotelFiveDaysRoom2SeconddayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom3SeconddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Second5($scope.hotelFiveDaysRoom3SeconddayPrice);
		}
		else if (obj == 'hotelFiveDaysSeconddayTotal') {
			DataFormClaimDetails.setHotelTotalSecond5Day($scope.hotelFiveDaysSeconddayTotal);
		}
		else if (obj == 'hotelFiveDaysRoom1ThirddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Third5($scope.hotelFiveDaysRoom1ThirddayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom2ThirddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Third5($scope.hotelFiveDaysRoom2ThirddayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom3ThirddayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Third5($scope.hotelFiveDaysRoom3ThirddayPrice);
		}
		else if (obj == 'hotelFiveDaysThirddayTotal') {
			DataFormClaimDetails.setHotelTotalThird5Day($scope.hotelFiveDaysThirddayTotal);
		}
		else if (obj == 'hotelFiveDaysRoom1ForthdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Forth5($scope.hotelFiveDaysRoom1ForthdayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom2ForthdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Forth5($scope.hotelFiveDaysRoom2ForthdayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom3ForthdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Forth5($scope.hotelFiveDaysRoom3ForthdayPrice);
		}
		else if (obj == 'hotelFiveDaysForthdayTotal') {
			DataFormClaimDetails.setHotelTotalForth5Day($scope.hotelFiveDaysForthdayTotal);
		}
		else if (obj == 'hotelFiveDaysRoom1FifthdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice1Fifth5($scope.hotelFiveDaysRoom1FifthdayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom2FifthdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice2Fifth5($scope.hotelFiveDaysRoom2FifthdayPrice);
		}
		else if (obj == 'hotelFiveDaysRoom3FifthdayPrice') {
			DataFormClaimDetails.setHotelRoomPrice3Fifth5($scope.hotelFiveDaysRoom3FifthdayPrice);
		}
		else if (obj == 'hotelFiveDaysFifthdayTotal') {
			DataFormClaimDetails.setHotelTotalFifth5Day($scope.hotelFiveDaysFifthdayTotal);
		}
		else if (obj == 'hotelFiveDaysTotal') {
			DataFormClaimDetails.setHotelTotal5Day($scope.hotelFiveDaysTotal);
		}
		else if (obj == 'hotelTotalAmount') {
			DataFormClaimDetails.setHotelTotalAmount($scope.hotelTotalAmount);
		}
		else if (obj == 'hotelTotalGST') {
			DataFormClaimDetails.setHotelTotalGST($scope.hotelTotalGST);
		}
		else if (obj == 'hotelReceiptNo') {
			DataFormClaimDetails.setHotelReceiptNo($scope.hotelReceiptNo);
		}
		else if (obj == 'lodgingThreeDaysAddress') {
			DataFormClaimDetails.setLodging3DayAddress($scope.lodgingThreeDaysAddress);
		}
		else if (obj == 'lodgingThreeDaysNoofday') {
			DataFormClaimDetails.setLodging3DayNoDays($scope.lodgingThreeDaysNoofday);
		}
		else if (obj == 'lodgingThreeDaysRateperday') {
			DataFormClaimDetails.setLodging3DayRate($scope.lodgingThreeDaysRateperday);
		}
		else if (obj == 'lodgingThreeDaysTotal') {
			DataFormClaimDetails.setLodging3DayTotal($scope.lodgingThreeDaysTotal);
		}
		else if (obj == 'lodgingFiveDaysAddress') {
			DataFormClaimDetails.setLodging5DayAddress($scope.lodgingFiveDaysAddress);
		}
		else if (obj == 'lodgingFiveDaysNoofday') {
			DataFormClaimDetails.setLodging5DayNoDays($scope.lodgingFiveDaysNoofday);
		}
		else if (obj == 'lodgingFiveDaysRateperday') {
			DataFormClaimDetails.setLodging5DayRate($scope.lodgingFiveDaysRateperday);
		}
		else if (obj == 'lodgingFiveDaysTotal') {
			DataFormClaimDetails.setLodging5DayTotal($scope.lodgingFiveDaysTotal);
		}
		else if (obj == 'lodgingTotalAllowance') {
			DataFormClaimDetails.setLodgingTotalAmount($scope.lodgingTotalAllowance);
		}
		else if (obj == 'publicLandTransportationReceiptNo') {
			DataFormClaimDetails.setPublicLandReceiptNo($scope.publicLandTransportationReceiptNo);
		}
		else if (obj == 'publicLandTransportationTotal') {
			DataFormClaimDetails.setPublicLandTotal($scope.publicLandTransportationTotal);
		}
		else if (obj == 'publicSeaTransportationReceiptNo') {
			DataFormClaimDetails.setPublicSeaReceiptNo($scope.publicSeaTransportationReceiptNo);
		}
		else if (obj == 'publicSeaTransportationTotal') {
			DataFormClaimDetails.setPublicSeaTotal($scope.publicSeaTransportationTotal);
		}
		else if (obj == 'publicAirTransportationReceiptNo') {
			DataFormClaimDetails.setPublicAirReceiptNo($scope.publicAirTransportationReceiptNo);
		}
		else if (obj == 'publicAirTransportationTotal') {
			DataFormClaimDetails.setPublicAirTotal($scope.publicAirTransportationTotal);
		}
		else if (obj == 'publicTotalTransportation') {
			DataFormClaimDetails.setPublicTotalAmount($scope.publicTotalTransportation);
		}
		else if (obj == 'mileageFrom') {
			DataFormClaimDetails.setMileageFrom($scope.mileageFrom);
		}
		else if (obj == 'mileageTo') {
			DataFormClaimDetails.setMileageTo($scope.mileageTo);
		}
		else if (obj == 'mileageKM') {
			DataFormClaimDetails.setMileageKM($scope.mileageKM);
		}
		else if (obj == 'mileageTotal') {
			DataFormClaimDetails.setMileageTotal($scope.mileageTotal);
		}
		else if (obj == 'goodsLandTransportationKM') {
			DataFormClaimDetails.setGoodsLandKM($scope.goodsLandTransportationKM);
		}
		else if (obj == 'goodsLandTransportationTotal') {
			DataFormClaimDetails.setGoodsLandTotal($scope.goodsLandTransportationTotal);
		}
		else if (obj == 'goodsSeaTransportationReceiptNo') {
			DataFormClaimDetails.setGoodsSeaReceiptNo($scope.goodsSeaTransportationReceiptNo);
		}
		else if (obj == 'goodsSeaTransportationTotal') {
			DataFormClaimDetails.setGoodsSeaTotal($scope.goodsSeaTransportationTotal);
		}
		else if (obj == 'otherMiscPercentage') {
			DataFormClaimDetails.setOtherMiscPercentage($scope.otherMiscPercentage);
		}
		else if (obj == 'otherMicsAmount') {
			DataFormClaimDetails.setOtherMiscAmount($scope.otherMicsAmount);
		}
		else if (obj == 'claimAmount') {
			DataFormClaimDetails.setClaimAmount($scope.claimAmount);
			DataEndowment.setClaimAmount(DataFormClaimDetails.getClaimAmount());
        }
		else if (obj == 'endowmentAmount') {
            DataFormClaimDetails.setEndowmentAmount($scope.endowmentAmount);
        }
		else if (obj == 'netTotal') {
            DataFormClaimDetails.setNetTotal($scope.netTotal);
        }
    };

	var clearRoom2AndRoom3 = function () {
		$scope.hotelThreeDaysRoom2FirstdayPrice = '';
		$scope.hotelThreeDaysRoom3FirstdayPrice = '';
		$scope.hotelThreeDaysRoom2SeconddayPrice = '';
		$scope.hotelThreeDaysRoom3SeconddayPrice = '';
		$scope.hotelThreeDaysRoom2ThirddayPrice = '';
		$scope.hotelThreeDaysRoom3ThirddayPrice = '';
		$scope.hotelFiveDaysRoom2FirstdayPrice = '';
		$scope.hotelFiveDaysRoom3FirstdayPrice = '';
		$scope.hotelFiveDaysRoom2SeconddayPrice = '';
		$scope.hotelFiveDaysRoom3SeconddayPrice = '';
		$scope.hotelFiveDaysRoom2ThirddayPrice = '';
		$scope.hotelFiveDaysRoom3ThirddayPrice = '';
		$scope.hotelFiveDaysRoom2ForthdayPrice = '';
		$scope.hotelFiveDaysRoom3ForthdayPrice = '';
		$scope.hotelFiveDaysRoom2FifthdayPrice = '';
		$scope.hotelFiveDaysRoom3FifthdayPrice = '';
		calculateHotel();
	};
	
	var enablePublicTransport = function () {
		angular.element(document.getElementById('publicLandTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('publicLandTransportationTotal'))[0].disabled = false;
		angular.element(document.getElementById('publicSeaTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('publicSeaTransportationTotal'))[0].disabled = false;
		angular.element(document.getElementById('publicAirTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('publicAirTransportationTotal'))[0].disabled = false;
		angular.element(document.getElementById('publicTotalTransportation'))[0].disabled = false;
	};

	var disablePublicTransport = function () {
		angular.element(document.getElementById('publicLandTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('publicLandTransportationTotal'))[0].disabled = true;
		angular.element(document.getElementById('publicSeaTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('publicSeaTransportationTotal'))[0].disabled = true;
		angular.element(document.getElementById('publicAirTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('publicAirTransportationTotal'))[0].disabled = true;
		angular.element(document.getElementById('publicTotalTransportation'))[0].disabled = true;
	};

	var enableMileage = function () {
		angular.element(document.getElementById('mileageFrom'))[0].disabled = false;
		angular.element(document.getElementById('mileageTo'))[0].disabled = false;
		angular.element(document.getElementById('mileageKM'))[0].disabled = false;
		angular.element(document.getElementById('mileageTotal'))[0].disabled = false;
	};

	var disableMileage = function () {
		angular.element(document.getElementById('mileageFrom'))[0].disabled = true;
		angular.element(document.getElementById('mileageTo'))[0].disabled = true;
		angular.element(document.getElementById('mileageKM'))[0].disabled = true;
		angular.element(document.getElementById('mileageTotal'))[0].disabled = true;
	};

	var enableGoodsLand = function () {
		angular.element(document.getElementById('goodsLandTransportationKM'))[0].disabled = false;
		angular.element(document.getElementById('goodsLandTransportationTotal'))[0].disabled = false;
	};

	var disableGoodsLand = function () {
		angular.element(document.getElementById('goodsLandTransportationKM'))[0].disabled = true;
		angular.element(document.getElementById('goodsLandTransportationTotal'))[0].disabled = true;
	};

	var enableGoodsSea= function () {
		angular.element(document.getElementById('goodsSeaTransportationReceiptNo'))[0].disabled = false;
		angular.element(document.getElementById('goodsSeaTransportationTotal'))[0].disabled = false;
	};

	var disableGoodsSea = function () {
		angular.element(document.getElementById('goodsSeaTransportationReceiptNo'))[0].disabled = true;
		angular.element(document.getElementById('goodsSeaTransportationTotal'))[0].disabled = true;
	};

	var calculateMeal = function () {
		$scope.mealThreeDaysRateperday = DataFormClaimDetails.getMeal3Day();
		$scope.mealThreeDaysNoofperson = DataFormClaimDetails.getDependent();
		var total3DayMeal  = parseFloat($scope.mealThreeDaysRateperday) * parseFloat($scope.mealThreeDaysNoofperson)

		$scope.mealFiveDaysRateperday = DataFormClaimDetails.getMeal5Day();
		$scope.mealFiveDaysNoofperson = DataFormClaimDetails.getDependent();
		var total5DayMeal  = parseFloat($scope.mealFiveDaysRateperday) * parseFloat($scope.mealFiveDaysNoofperson)

		var total3DayMealBefore = parseFloat(total3DayMeal) * 3
		var total5DayMealAfter = parseFloat(total5DayMeal) * 5

		$scope.mealThreeDaysTotal = get2Float(total3DayMealBefore);
		$scope.mealFiveDaysTotal = get2Float(total5DayMealAfter);

		totalmeal = parseFloat(total3DayMealBefore) + parseFloat(total5DayMealAfter);
		$scope.totalMealAllowance = get2Float(totalmeal);
	};
	
	var accommodation3Days = function() {
		var firstDay3 = 0;
		var secondDay3 = 0;
		var thirdDay3 = 0;
		var lodging3DayCount = 0;
		var allDay3 = 0;

		if ($scope.hotelThreeDaysRoom1FirstdayPrice || $scope.hotelThreeDaysRoom2FirstdayPrice || $scope.hotelThreeDaysRoom3FirstdayPrice) {
			firstDay3 = 1;}
		if ($scope.hotelThreeDaysRoom1SeconddayPrice || $scope.hotelThreeDaysRoom2SeconddayPrice || $scope.hotelThreeDaysRoom3SeconddayPrice) {
			secondDay3 = 1;}
		if ($scope.hotelThreeDaysRoom1ThirddayPrice || $scope.hotelThreeDaysRoom2ThirddayPrice || $scope.hotelThreeDaysRoom3ThirddayPrice) {
			thirdDay3 = 1;}
		if ($scope.lodgingThreeDaysNoofday) {
			lodging3DayCount = $scope.lodgingThreeDaysNoofday;}
		return allDay3 = getNumber(firstDay3) + getNumber(secondDay3) + getNumber(thirdDay3) + getNumber(lodging3DayCount);
	};
	
	var accommodation5Days = function() {
		var firstDay5 = 0;
		var secondDay5 = 0;
		var thirdDay5 = 0;
		var forthDay5 = 0;
		var fifthDay5 = 0;
		var lodging5DayCount = 0;
		var allDay5 = 0;

		if ($scope.hotelFiveDaysRoom1FirstdayPrice || $scope.hotelFiveDaysRoom2FirstdayPrice || $scope.hotelFiveDaysRoom3FirstdayPrice) {
			firstDay5 = 1;}
		if ($scope.hotelFiveDaysRoom1SeconddayPrice || $scope.hotelFiveDaysRoom2SeconddayPrice || $scope.hotelFiveDaysRoom3SeconddayPrice) {
			secondDay5 = 1;}
		if ($scope.hotelFiveDaysRoom1ThirddayPrice || $scope.hotelFiveDaysRoom2ThirddayPrice || $scope.hotelFiveDaysRoom3ThirddayPrice) {
			thirdDay5 = 1;}
		if ($scope.hotelFiveDaysRoom1ForthdayPrice || $scope.hotelFiveDaysRoom2ForthdayPrice || $scope.hotelFiveDaysRoom3ForthdayPrice) {
			forthDay5 = 1;}
		if ($scope.hotelFiveDaysRoom1FifthdayPrice || $scope.hotelFiveDaysRoom2FifthdayPrice || $scope.hotelFiveDaysRoom3FifthdayPrice) {
			fifthDay5 = 1;}
		if ($scope.lodgingFiveDaysNoofday) {
			lodging5DayCount = $scope.lodgingFiveDaysNoofday;}
		return allDay5 = getNumber(firstDay5) + getNumber(secondDay5) + getNumber(thirdDay5) + getNumber(forthDay5) + getNumber(fifthDay5 )+ getNumber(lodging5DayCount);
	};
	
	var calculateEachRoomBefore = function(userInput) {
		var accommodation3DaysCount = 0;
		accommodation3DaysCount = accommodation3Days();
		if (accommodation3DaysCount <= 3) {
			var hRate = parseFloat(DataFormClaimDetails.getHotel3Day());
			if (hRate >= userInput) {
				hClaim = userInput;
			} else if (hRate < userInput) {
				hClaim = get2Float(hRate);
			} else {
				hClaim = '';
			}
		} else {
			hClaim = '';
		}
		calculateHotel();
		return hClaim
	}
	
	var calculateEachRoomAfter = function(userInput) {
		var accommodation5DaysCount = 0;
		accommodation5DaysCount = accommodation5Days();
		if (accommodation5DaysCount <= 5) {
			var hRate = parseFloat(DataFormClaimDetails.getHotel5Day());
			if (hRate >= userInput) {
				hClaim = userInput;
			} else if (hRate < userInput) {
				hClaim = get2Float(hRate);
			} else {
				hClaim = '';
			}
		} else {
			hClaim = '';
		}
		calculateHotel();
		return hClaim
	}
	
	var calculateHotel = function () {
		var hotel311 = get2Float($scope.hotelThreeDaysRoom1FirstdayPrice);
		var hotel321 = get2Float($scope.hotelThreeDaysRoom2FirstdayPrice);
		var hotel331 = get2Float($scope.hotelThreeDaysRoom3FirstdayPrice);
		var hotel31 = parseFloat(hotel311) + parseFloat(hotel321) + parseFloat(hotel331);
		$scope.hotelThreeDaysFirstdayTotal = get2Float(hotel31);

		var hotel312 = get2Float($scope.hotelThreeDaysRoom1SeconddayPrice);
		var hotel322 = get2Float($scope.hotelThreeDaysRoom2SeconddayPrice);
		var hotel332 = get2Float($scope.hotelThreeDaysRoom3SeconddayPrice);
		var hotel32 = parseFloat(hotel312) + parseFloat(hotel322) + parseFloat(hotel332);
		$scope.hotelThreeDaysSeconddayTotal = get2Float(hotel32);

		var hotel313 = get2Float($scope.hotelThreeDaysRoom1ThirddayPrice);
		var hotel323 = get2Float($scope.hotelThreeDaysRoom2ThirddayPrice);
		var hotel333 = get2Float($scope.hotelThreeDaysRoom3ThirddayPrice);
		var hotel33 = parseFloat(hotel313) + parseFloat(hotel323) + parseFloat(hotel333);
		$scope.hotelThreeDaysThirddayTotal = get2Float(hotel33);

		total3 = parseFloat(hotel31) + parseFloat(hotel32) + parseFloat(hotel33);
		$scope.hotelThreeDaysTotal = get2Float(total3);

		var hotel511 = get2Float($scope.hotelFiveDaysRoom1FirstdayPrice);
		var hotel521 = get2Float($scope.hotelFiveDaysRoom2FirstdayPrice);
		var hotel531 = get2Float($scope.hotelFiveDaysRoom3FirstdayPrice);
		var hotel51 = parseFloat(hotel511) + parseFloat(hotel521) + parseFloat(hotel531);
		$scope.hotelFiveDaysFirstdayTotal = get2Float(hotel51);

		var hotel512 = get2Float($scope.hotelFiveDaysRoom1SeconddayPrice);
		var hotel522 = get2Float($scope.hotelFiveDaysRoom2SeconddayPrice);
		var hotel532 = get2Float($scope.hotelFiveDaysRoom3SeconddayPrice);
		var hotel52 = parseFloat(hotel512) + parseFloat(hotel522) + parseFloat(hotel532);
		$scope.hotelFiveDaysSeconddayTotal = get2Float(hotel52);

		var hotel513 = get2Float($scope.hotelFiveDaysRoom1ThirddayPrice);
		var hotel523 = get2Float($scope.hotelFiveDaysRoom2ThirddayPrice);
		var hotel533 = get2Float($scope.hotelFiveDaysRoom3ThirddayPrice);
		var hotel53 = parseFloat(hotel513) + parseFloat(hotel523) + parseFloat(hotel533);
		$scope.hotelFiveDaysThirddayTotal = get2Float(hotel53);

		var hotel514 = get2Float($scope.hotelFiveDaysRoom1ForthdayPrice);
		var hotel524 = get2Float($scope.hotelFiveDaysRoom2ForthdayPrice);
		var hotel534 = get2Float($scope.hotelFiveDaysRoom3ForthdayPrice);
		var hotel54 = parseFloat(hotel514) + parseFloat(hotel524) + parseFloat(hotel534);
		$scope.hotelFiveDaysForthdayTotal = get2Float(hotel54);

		var hotel515 = get2Float($scope.hotelFiveDaysRoom1FifthdayPrice);
		var hotel525 = get2Float($scope.hotelFiveDaysRoom2FifthdayPrice);
		var hotel535 = get2Float($scope.hotelFiveDaysRoom3FifthdayPrice);
		var hotel55 = parseFloat(hotel515) + parseFloat(hotel525) + parseFloat(hotel535);
		$scope.hotelFiveDaysFifthdayTotal = get2Float(hotel55);

		var total5 = parseFloat(hotel51) + parseFloat(hotel52) + parseFloat(hotel53) + parseFloat(hotel54) + parseFloat(hotel55);
		$scope.hotelFiveDaysTotal = get2Float(total5);

		var totalHotel = parseFloat(total3) + parseFloat(total5);
		$scope.hotelTotalAmount = get2Float(totalHotel);
	};

	var calculateLodging = function () {
		var lodging3dayno = $scope.lodgingThreeDaysNoofday;
		var lodging3dayrate = get2Float($scope.lodgingThreeDaysRateperday);
		var total3daylodging = getNumber(lodging3dayno) * parseFloat(lodging3dayrate)
		$scope.lodgingThreeDaysTotal = get2Float(total3daylodging);

		var lodging5dayno = $scope.lodgingFiveDaysNoofday;
		var lodging5dayrate = get2Float($scope.lodgingFiveDaysRateperday);
		var total5daylodging = getNumber(lodging5dayno) * parseFloat(lodging5dayrate);
		$scope.lodgingFiveDaysTotal = get2Float(total5daylodging);

		var totallodging = parseFloat(total3daylodging) + parseFloat(total5daylodging);
		$scope.lodgingTotalAllowance = get2Float(totallodging);
	};
	
	var publicMileage = function () {
		if ($scope.publicLandTransportationReceiptNo || $scope.publicSeaTransportationReceiptNo || $scope.publicAirTransportationReceiptNo
			|| $scope.publicLandTransportationTotal || $scope.publicSeaTransportationTotal || $scope.publicAirTransportationTotal) {
			disableMileage();
		} else {enableMileage();}

		if ($scope.mileageFrom || $scope.mileageTo || $scope.mileageKM) {
			disablePublicTransport();
		} else {enablePublicTransport();}
	};
	
	var calculatePublicTransport = function () {
		var publicLand = get2Float($scope.publicLandTransportationTotal);
		var publicSea = get2Float($scope.publicSeaTransportationTotal);
		var publicAir = get2Float($scope.publicAirTransportationTotal);
		var publicTotal = parseFloat(publicLand) + parseFloat(publicSea) + parseFloat(publicAir);
		$scope.publicTotalTransportation = get2Float(publicTotal);
	};

	var calculateMileage = function () {
		if (DataFormClaimDetails.getVehicleRate() > 0) {
			var mileageKM = $scope.mileageKM;
			var mileageRate = get2Float(DataFormClaimDetails.getVehicleRate());
			var mileageTotal = getNumber(mileageKM) * parseFloat(mileageRate);
			$scope.mileageTotal = get2Float(mileageTotal);
			$scope.errMileage = '';
		} else {$scope.errMileage = 'Please select Transfer Vehicle in Transfer Details Tab!';}
	};

	var calculateGoodsTransport = function (status, destination, newValue) {
		$scope.goodsLandTransportationKM = DataFormClaimDetails.getGoodsLandKM();
		if (newValue > 0 && newValue <= 50) {
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates = DataRates.get0to50WestSingle();
					$scope.goodsLandTransportationTotal = rates;
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates = DataRates.get0to50EastSingle();
					$scope.goodsLandTransportationTotal = rates;
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates = DataRates.get0to50WestMarried();
					$scope.goodsLandTransportationTotal = rates;
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates = DataRates.get0to50EastMarried();
					$scope.goodsLandTransportationTotal = rates;
				}
			}
		} else if (newValue >= 51 && newValue <= 250) {
			balance = newValue - 50
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestSingle();
					rates = DataRates.get51to250WestSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastSingle();
					rates = DataRates.get51to250EastSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestMarried();
					rates = DataRates.get51to250WestMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastMarried();
					rates = DataRates.get51to250EastMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			}
		} else if (newValue >= 251 && newValue <= 500) {
			balance = newValue - 250
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestSingle();
					rates51to250 = DataRates.get51to250WestSingle();
					rates = DataRates.get251to500WestSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastSingle();
					rates51to250 = DataRates.get51to250EastSingle();
					rates = DataRates.get251to500EastSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestMarried();
					rates51to250 = DataRates.get51to250WestMarried();
					rates = DataRates.get251to500WestMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastMarried();
					rates51to250 = DataRates.get51to250EastMarried();
					rates = DataRates.get251to500EastMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			}
		} else if (newValue >= 501 && newValue <= 750) {
			balance = newValue - 500
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestSingle();
					rates51to250 = DataRates.get51to250WestSingle();
					rates251to500 = DataRates.get251to500WestSingle();
					rates = DataRates.get501to750WestSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastSingle();
					rates51to250 = DataRates.get51to250EastSingle();
					rates251to500 = DataRates.get251to500EastSingle();
					rates = DataRates.get501to750EastSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestMarried();
					rates51to250 = DataRates.get51to250WestMarried();
					rates251to500 = DataRates.get251to500WestMarried();
					rates = DataRates.get501to750WestMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastMarried();
					rates51to250 = DataRates.get51to250EastMarried();
					rates251to500 = DataRates.get251to500EastMarried();
					rates = DataRates.get501to750EastMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			}
		} else if (newValue >= 751 && newValue <= 1000) {
			balance = newValue - 750
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestSingle();
					rates51to250 = DataRates.get51to250WestSingle();
					rates251to500 = DataRates.get251to500WestSingle();
					rates501to750 = DataRates.get501to750WestSingle();
					rates = DataRates.get751to1000WestSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastSingle();
					rates51to250 = DataRates.get51to250EastSingle();
					rates251to500 = DataRates.get251to500EastSingle();
					rates501to750 = DataRates.get501to750EastSingle();
					rates = DataRates.get751to1000EastSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestMarried();
					rates51to250 = DataRates.get51to250WestMarried();
					rates251to500 = DataRates.get251to500WestMarried();
					rates501to750 = DataRates.get501to750WestMarried();
					rates = DataRates.get751to1000WestMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastMarried();
					rates51to250 = DataRates.get51to250EastMarried();
					rates251to500 = DataRates.get251to500EastMarried();
					rates501to750 = DataRates.get501to750EastMarried();
					rates = DataRates.get751to1000EastMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			}
		} else if (newValue >= 1001 && newValue <= 1250) {
			balance = newValue - 1000
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestSingle();
					rates51to250 = DataRates.get51to250WestSingle();
					rates251to500 = DataRates.get251to500WestSingle();
					rates501to750 = DataRates.get501to750WestSingle();
					rates751to1000 = DataRates.get751to1000WestSingle();
					rates = DataRates.get1001to1250WestSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastSingle();
					rates51to250 = DataRates.get51to250EastSingle();
					rates251to500 = DataRates.get251to500EastSingle();
					rates501to750 = DataRates.get501to750EastSingle();
					rates751to1000 = DataRates.get751to1000EastSingle();
					rates = DataRates.get1001to1250EastSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestMarried();
					rates51to250 = DataRates.get51to250WestMarried();
					rates251to500 = DataRates.get251to500WestMarried();
					rates501to750 = DataRates.get501to750WestMarried();
					rates751to1000 = DataRates.get751to1000WestMarried();
					rates = DataRates.get1001to1250WestMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastMarried();
					rates51to250 = DataRates.get51to250EastMarried();
					rates251to500 = DataRates.get251to500EastMarried();
					rates501to750 = DataRates.get501to750EastMarried();
					rates751to1000 = DataRates.get751to1000EastMarried();
					rates = DataRates.get1001to1250EastMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			}
		} else if (newValue >= 1251 && newValue <= 999999) {
			balance = newValue - 1250
			if (status == 's' || status == 'mA') {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestSingle();
					rates51to250 = DataRates.get51to250WestSingle();
					rates251to500 = DataRates.get251to500WestSingle();
					rates501to750 = DataRates.get501to750WestSingle();
					rates751to1000 = DataRates.get751to1000WestSingle();
					rates1001to1250 = DataRates.get1001to1250WestSingle();
					rates = DataRates.get1251to999999WestSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000)) + (250 * parseFloat(rates1001to1250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastSingle();
					rates51to250 = DataRates.get51to250EastSingle();
					rates251to500 = DataRates.get251to500EastSingle();
					rates501to750 = DataRates.get501to750EastSingle();
					rates751to1000 = DataRates.get751to10000EastSingle();
					rates1001to1250 = DataRates.get1001to1250EastSingle();
					rates = DataRates.get1251to999999EastSingle();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000)) + (250 * parseFloat(rates1001to1250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			} else {
				if (destination == 'WithinPeninsular') {
					rates0to50 = DataRates.get0to50WestMarried();
					rates51to250 = DataRates.get51to250WestMarried();
					rates251to500 = DataRates.get251to500WestMarried();
					rates501to750 = DataRates.get501to750WestMarried();
					rates751to1000 = DataRates.get751to10000WestMarried();
					rates1001to1250 = DataRates.get1001to1250WestMarried();
					rates = DataRates.get1251to999999WestMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000)) + (250 * parseFloat(rates1001to1250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				} else if (destination == 'WithinSabah' || destination == 'WithinSarawak') {
					rates0to50 = DataRates.get0to50EastMarried();
					rates51to250 = DataRates.get51to250EastMarried();
					rates251to500 = DataRates.get251to500EastMarried();
					rates501to750 = DataRates.get501to750EastMarried();
					rates751to1000 = DataRates.get751to10000EastMarried();
					rates1001to1250 = DataRates.get1001to1250EastMarried();
					rates = DataRates.get1251to999999EastMarried();
					total = parseFloat(rates0to50) + (balance * parseFloat(rates)) + (200 * parseFloat(rates51to250))
							+ (250 * parseFloat(rates251to500)) + (250 * parseFloat(rates501to750))
							+ (250 * parseFloat(rates751to1000)) + (250 * parseFloat(rates1001to1250));
					$scope.goodsLandTransportationTotal = get2Float(total);
				}
			}
		} else {
			$scope.goodsLandTransportationTotal = '';
		}
	};
	
	var calculateMiscTotal = function() {
		var miscTotal = 0;

		angular.forEach(getItems(), function(obj) {
			miscTotal = miscTotal + parseFloat(obj.miscAmount);
		});
		$scope.miscTotal = get2Float(miscTotal);
		DataFormClaimDetails.setMiscTotal($scope.miscTotal);
	};

	var calculateClaimTotal = function() {
		var transferAllowanceTotal = 0;
		var mealAllowanceTotal = 0;
		var hotelTotal = 0;
		var lodgingTotal = 0;
		var gstTotal = 0;
		var publicTotal = 0;
		var mileageTotal = 0;
		var goodsLandTotal = 0;
		var goodsSeaTotal = 0;
		var miscTotal = 0;
		var percentage = 0;
		var percentageTotal = 0;
		var claimTotal = 0;
		var claimAmount = 0;

		transferAllowanceTotal = get2Float(DataFormClaimDetails.getTransferAllowance());
		mealAllowanceTotal = get2Float(DataFormClaimDetails.getMealTotalAmount());
		hotelTotal = get2Float(DataFormClaimDetails.getHotelTotalAmount());
		lodgingTotal = get2Float(DataFormClaimDetails.getLodgingTotalAmount());
		gstTotal = get2Float(DataFormClaimDetails.getHotelTotalGST());
		publicTotal = get2Float(DataFormClaimDetails.getPublicTotalAmount());
		mileageTotal = get2Float(DataFormClaimDetails.getMileageTotal());
		goodsLandTotal = get2Float(DataFormClaimDetails.getGoodsLandTotal());
		goodsSeaTotal = get2Float(DataFormClaimDetails.getGoodsSeaTotal());
		miscTotal = get2Float(DataFormClaimDetails.getMiscTotal());
		percentage = get2Float(DataFormClaimDetails.getOtherMiscPercentage());

		claimTotal = parseFloat(transferAllowanceTotal) + parseFloat(mealAllowanceTotal) + parseFloat(hotelTotal)
					 + parseFloat(lodgingTotal) + parseFloat(gstTotal) + parseFloat(publicTotal) + parseFloat(mileageTotal)
					 + parseFloat(goodsLandTotal) + parseFloat(goodsSeaTotal) + parseFloat(miscTotal)

		percentageTotal = ((parseFloat(claimTotal) * parseFloat(percentage)) / 100);

		$scope.otherMicsAmount = get2Float(percentageTotal);
		
		claimAmount = parseFloat(claimTotal) + parseFloat(percentageTotal)

		$scope.claimAmount = get2Float(claimAmount);
	};
});

uiBootstrapApp.controller('SummaryCtrl', function($http, $scope, DataFundType, DataEndowment, DataFormTransferDetails, DataFormClaimDetails) {
    $scope.masterExpensesSummary = [];
    $scope.claimGrandTotal = get2Float(0);
    $scope.claimNettTotal = get2Float(0);

	var ALLOWANCE       	= {codeMap: 'ALLOWANCE'};
	var MEAL				= {codeMap: 'MEAL'};
	var ACCOMMODATION  		= {codeMap: 'ACCOMMODATION'};
	var PUBLIC_TRANSPORT	= {codeMap: 'PUBLIC_TRANSPORT'};
	var MILEAGE          	= {codeMap: 'MILEAGE'};
	var GOODS_LAND       	= {codeMap: 'GOODS_LAND'};
	var GOODS_SEA        	= {codeMap: 'GOODS_SEA'};
	var GST 				= {codeMap: 'GST'};
	var MISC  				= {codeMap: 'MISC'};

	var HOTEL   		= {codeMap: ''};
    var LODGING			= {codeMap: ''};
	var GENERAL_MISC   	= {codeMap: ''};
    var OTHER_MISC		= {codeMap: ''};

    ACCOMMODATION.itemsMix = [HOTEL, LODGING];
	
    $scope.setExpenses = [ALLOWANCE, MEAL, ACCOMMODATION, PUBLIC_TRANSPORT, MILEAGE, GOODS_LAND, GOODS_SEA, GST, MISC];

    var loadSummary = function() {

		var claimFundType = '';
		var claimGrandTotal = 0;
		var claimNettTotal = 0;

		claimFundType = DataFundType.getFundType();
		claimGrandTotal = DataFormClaimDetails.getClaimAmount();
		claimNettTotal = DataEndowment.getNetTotal();

		$scope.claimFundType = claimFundType;
		$scope.claimGrandTotal = get2Float(claimGrandTotal);
		$scope.claimNettTotal = get2Float(claimNettTotal);

		HOTEL.items 		= DataFormClaimDetails.getHotelTotalAmount();
        LODGING.items 		= DataFormClaimDetails.getLodgingTotalAmount();
		GENERAL_MISC.items 	= DataFormClaimDetails.getMiscTotal();
        OTHER_MISC.items 	= DataFormClaimDetails.getOtherMiscAmount();

		$scope.setExpenses[0].items		= DataFormClaimDetails.getTransferAllowance();
        $scope.setExpenses[1].items 	= DataFormClaimDetails.getMealTotalAmount();
		$scope.setExpenses[2].itemsMix	= [HOTEL, LODGING];
		$scope.setExpenses[3].items 	= DataFormClaimDetails.getPublicTotalAmount();
		$scope.setExpenses[4].items 	= DataFormClaimDetails.getMileageTotal();
		$scope.setExpenses[5].items 	= DataFormClaimDetails.getGoodsLandTotal();
		$scope.setExpenses[6].items 	= DataFormClaimDetails.getGoodsSeaTotal();
		$scope.setExpenses[7].items 	= DataFormClaimDetails.getHotelTotalGST();
		$scope.setExpenses[8].itemsMix	= [GENERAL_MISC, OTHER_MISC];

        $scope.masterExpensesSummary = DataFormTransferDetails.getExpensesList();

        $scope.masterExpensesSummary.forEach(function (obj) {
            obj.show = false;
            obj.amount = get2Float(0);

            $scope.setExpenses.forEach(function (objSet) {
				if (obj.type_code == objSet.codeMap) {
					var amount = get2Float(0);
					if (objSet.itemsMix) {
						objSet.itemsMix.forEach(function (objMix) {
							if (objMix.items) {
								amount = parseFloat(amount) + parseFloat(objMix.items);
							}
						});
					} else if (objSet.items) {
						if (objSet.items) {
							amount = objSet.items;
						}
					}
					angular.merge(obj, {show: true, amount: get2Float(amount)});
				}
            });
        });
    };
	$scope.$watch(function () { return DataFundType.getFundType(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {loadSummary();}
	});
	$scope.$watch(function () { return DataFormClaimDetails.getClaimAmount(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {loadSummary();}
	});
	$scope.$watch(function () { return DataEndowment.getNetTotal(); }, function (newValue, oldValue) {
		if (newValue != oldValue) {loadSummary();}
	});
});

uiBootstrapApp.controller('SubmitCtrl', ['$scope', '$uibModal', '$http', '$window', 'DataMain', 'DataEndowment', 'DataFormDoc', 'DataFormTransferDetails', 'DataFormClaimDetails', function ($scope, $uibModal, $http, $window, DataMain, DataEndowment, DataFormDoc, DataFormTransferDetails, DataFormClaimDetails) {

	$scope.animationsEnabled = true;

	$scope.submit = function(btnMode) {
		console.log(btnMode);
		
		form_data = {
			btn_mode:btnMode,
			transferGradeAfter:DataFormTransferDetails.getTransferGradeAfter().code,
			transferDate:DataFormTransferDetails.getTransferDate(),
			transferDateTxt:DataFormTransferDetails.getTransferDateTxt(),
			fundType:DataFormTransferDetails.getTransferLocalFundType(),
			projectCode:DataFormTransferDetails.getTransferLocalProjectCode(),
			maritalStatus:DataFormTransferDetails.getMaritalStatus().status,
			transferMover:DataFormTransferDetails.getTransferMover().code,
			transferDestination:DataFormTransferDetails.getTransferDestination().code,
			vehicle:DataFormTransferDetails.getVehicle().name,
			distance:DataFormTransferDetails.getDistance(),

			spouseList:DataFormTransferDetails.getSpouseList(),
			childrenList:DataFormTransferDetails.getChildrenList(),

			oldOfficeLine1:DataFormTransferDetails.getOldOfficeLine1(),
			oldOfficeLine2:DataFormTransferDetails.getOldOfficeLine2(),
			oldOfficeLine3:DataFormTransferDetails.getOldOfficeLine3(),
			oldOfficeLine4:DataFormTransferDetails.getOldOfficeLine4(),
			newOfficeLine1:DataFormTransferDetails.getNewOfficeLine1(),
			newOfficeLine2:DataFormTransferDetails.getNewOfficeLine2(),
			newOfficeLine3:DataFormTransferDetails.getNewOfficeLine3(),
			newOfficeLine4:DataFormTransferDetails.getNewOfficeLine4(),
			oldHomeLine1:DataFormTransferDetails.getOldHomeLine1(),
			oldHomeLine2:DataFormTransferDetails.getOldHomeLine2(),
			oldHomeLine3:DataFormTransferDetails.getOldHomeLine3(),
			oldHomeLine4:DataFormTransferDetails.getOldHomeLine4(),
			newHomeLine1:DataFormTransferDetails.getNewHomeLine1(),
			newHomeLine2:DataFormTransferDetails.getNewHomeLine2(),
			newHomeLine3:DataFormTransferDetails.getNewHomeLine3(),
			newHomeLine4:DataFormTransferDetails.getNewHomeLine4(),

			transferAllowance:DataFormClaimDetails.getTransferAllowance(),

			mealRateBefore:DataFormClaimDetails.getMeal3Day(),
			mealRateAfter:DataFormClaimDetails.getMeal5Day(),
			mealNoOfPersonBefore:DataFormClaimDetails.getDependent(),
			mealNoOfPersonAfter:DataFormClaimDetails.getDependent(),
			mealTotalBefore:DataFormClaimDetails.getMealTotal3Day(),
			mealTotalAfter:DataFormClaimDetails.getMealTotal5Day(),
			mealTotalAmount:DataFormClaimDetails.getMealTotalAmount(),

			hotelRateBefore:DataFormClaimDetails.getHotel3Day(),
			hotelRateAfter:DataFormClaimDetails.getHotel5Day(),
			roomPrice1First3:DataFormClaimDetails.getHotelRoomPrice1First3(),
			roomPrice2First3:DataFormClaimDetails.getHotelRoomPrice2First3(),
			roomPrice3First3:DataFormClaimDetails.getHotelRoomPrice3First3(),
			hotelTotalFirst3:DataFormClaimDetails.getHotelTotalFirst3Day(),
			roomPrice1Second3:DataFormClaimDetails.getHotelRoomPrice1Second3(),
			roomPrice2Second3:DataFormClaimDetails.getHotelRoomPrice2Second3(),
			roomPrice3Second3:DataFormClaimDetails.getHotelRoomPrice3Second3(),
			hotelTotalSecond3:DataFormClaimDetails.getHotelTotalSecond3Day(),
			roomPrice1Third3:DataFormClaimDetails.getHotelRoomPrice1Third3(),
			roomPrice2Third3:DataFormClaimDetails.getHotelRoomPrice2Third3(),
			roomPrice3Third3:DataFormClaimDetails.getHotelRoomPrice3Third3(),
			hotelTotalThird3:DataFormClaimDetails.getHotelTotalThird3Day(),
			hotelTotalAmount3:DataFormClaimDetails.getHotelTotal3Day(),
			roomPrice1First5:DataFormClaimDetails.getHotelRoomPrice1First5(),
			roomPrice2First5:DataFormClaimDetails.getHotelRoomPrice2First5(),
			roomPrice3First5:DataFormClaimDetails.getHotelRoomPrice3First5(),
			hotelTotalFirst5:DataFormClaimDetails.getHotelTotalFirst5Day(),
			roomPrice1Second5:DataFormClaimDetails.getHotelRoomPrice1Second5(),
			roomPrice2Second5:DataFormClaimDetails.getHotelRoomPrice2Second5(),
			roomPrice3Second5:DataFormClaimDetails.getHotelRoomPrice3Second5(),
			hotelTotalSecond5:DataFormClaimDetails.getHotelTotalSecond5Day(),
			roomPrice1Third5:DataFormClaimDetails.getHotelRoomPrice1Third5(),
			roomPrice2Third5:DataFormClaimDetails.getHotelRoomPrice2Third5(),
			roomPrice3Third5:DataFormClaimDetails.getHotelRoomPrice3Third5(),
			hotelTotalThird5:DataFormClaimDetails.getHotelTotalThird5Day(),
			roomPrice1Forth5:DataFormClaimDetails.getHotelRoomPrice1Forth5(),
			roomPrice2Forth5:DataFormClaimDetails.getHotelRoomPrice2Forth5(),
			roomPrice3Forth5:DataFormClaimDetails.getHotelRoomPrice3Forth5(),
			hotelTotalForth5:DataFormClaimDetails.getHotelTotalForth5Day(),
			roomPrice1Fifth5:DataFormClaimDetails.getHotelRoomPrice1Fifth5(),
			roomPrice2Fifth5:DataFormClaimDetails.getHotelRoomPrice2Fifth5(),
			roomPrice3Fifth5:DataFormClaimDetails.getHotelRoomPrice3Fifth5(),
			hotelTotalFifth5:DataFormClaimDetails.getHotelTotalFifth5Day(),
			hotelTotalAmount5:DataFormClaimDetails.getHotelTotal5Day(),
			hotelTotalAmount:DataFormClaimDetails.getHotelTotalAmount(),
			hotelTotalGST:DataFormClaimDetails.getHotelTotalGST(),
			hotelReceiptNo:DataFormClaimDetails.getHotelReceiptNo(),

			lodgingAddressBefore:DataFormClaimDetails.getLodging3DayAddress(),
			lodgingAddressAfter:DataFormClaimDetails.getLodging5DayAddress(),
			lodgingRateBefore:DataFormClaimDetails.getLodging3DayRate(),
			lodgingRateAfter:DataFormClaimDetails.getLodging5DayRate(),
			lodgingNoOfDaysBefore:DataFormClaimDetails.getLodging3DayNoDays(),
			lodgingNoOfDaysAfter:DataFormClaimDetails.getLodging5DayNoDays(),
			lodgingTotalBefore:DataFormClaimDetails.getLodging3DayTotal(),
			lodgingTotalAfter:DataFormClaimDetails.getLodging5DayTotal(),
			lodgingTotalAmount:DataFormClaimDetails.getLodgingTotalAmount(),

			publicLandReceiptNo:DataFormClaimDetails.getPublicLandReceiptNo(),
			publicLandAmount:DataFormClaimDetails.getPublicLandTotal(),
			publicSeaReceiptNo:DataFormClaimDetails.getPublicSeaReceiptNo(),
			publicSeaAmount:DataFormClaimDetails.getPublicSeaTotal(),
			publicAirReceiptNo:DataFormClaimDetails.getPublicAirReceiptNo(),
			publicAirAmount:DataFormClaimDetails.getPublicAirTotal(),
			publicTotalAmount:DataFormClaimDetails.getPublicTotalAmount(),

			mileageAddFrom:DataFormClaimDetails.getMileageFrom(),
			mileageAddTo:DataFormClaimDetails.getMileageTo(),
			mileageDistance:DataFormClaimDetails.getMileageKM(),
			mileageTotalAmount:DataFormClaimDetails.getMileageTotal(),

			goodsLandDistance:DataFormClaimDetails.getGoodsLandKM(),
			goodsLandAmount:DataFormClaimDetails.getGoodsLandTotal(),
			goodsSeaReceiptNo:DataFormClaimDetails.getGoodsSeaReceiptNo(),
			goodsSeaAmount:DataFormClaimDetails.getGoodsSeaTotal(),

			miscItems: DataFormClaimDetails.getMiscItems(),
			miscTotal: DataFormClaimDetails.getMiscTotal(),

			otherMiscPercentage: DataFormClaimDetails.getOtherMiscPercentage(),
			otherMiscAmount: DataFormClaimDetails.getOtherMiscAmount(),
			
			claimAmount: DataEndowment.getClaimAmount(),
			endowmentAmount: DataEndowment.getEndowmentAmount(),
			netTotal: DataEndowment.getNetTotal(),
			
			supportingDocs: DataFormDoc.getDBItems(),
			
			claimant_no:DataMain.getClaimantNo(),
			draft_id:DataMain.getDraftID()
		}

		if ($scope.filtering.assignee)
            form_data.assignee = $scope.filtering.assignee.staff_no;

		var instance_controller = '';

		if (btnMode == 'save_draft') {
			instance_controller = 'ModalInstanceSaveCtrl';
			ng_template = 'SaveConformation.html';
		}else if (btnMode == 'submit'){
			instance_controller = 'ModalInstanceSubmitCtrl';
			ng_template = 'SubmitConformation.html';
		}

		var modalInstance = $uibModal.open({
			animation: $scope.animationsEnabled,
			templateUrl: ng_template,
			controller: instance_controller,
			size: 'sm',
			resolve: {
				data: function () {
					return form_data;
				}
			}
		});

		modalInstance.result.then(
			function () {
				console.log('OK, conformation box closed');
                disable_claim_controls();

				if (PK && $scope.claim.query) {  // Re-submission
                    var params = {
                        claim_no: $scope.claim.claim_no,
                        claim_ctype: $scope.claim.claim_ctype_id
                    };

                    $http({
                        url: URL_AJAX_RESUBMIT_TO,
                        method: 'POST',
                        data: params
                    })
                    .success(function (data, status, headers, config) {
                        $window.location.href = URL_HOMEPAGE;
                    });
                }
				else
				{
					$http({
						url: '',
						method: 'POST',
						data: form_data
					})
					.success(function (data, status, headers, config) {
                        enable_claim_controls();
						var submit_success_url = data.submit_success_url;

						if (btnMode == 'submit') {
							$window.location.href = submit_success_url;
						} else if (btnMode == 'save_draft') {
							$scope.initSubmitCtrl(data.draft_id);
							$uibModal.open({
								animation: $scope.animationsEnabled,
								templateUrl: 'SaveSuccess.html',
								controller: 'ModalInstanceInfoCtrl',
								size: 'sm', // sm = small size box, '' = medium size box, lg = large size box
								resolve: {
								  data: function () {
									return data;
								  }
								}
							});
                            $window.location.href = submit_success_url;
						}
					}).error(function () {
                        enable_claim_controls();
                    });
				}
			},
			function () {
				console.log('Cancel, conformation box closed');
			}
		);
	};

	$scope.initSubmitCtrl = function(draft_id){
		$scope.draft_id = draft_id;
		DataMain.setDraftID(draft_id);
	};
}]);

uiBootstrapApp.factory('DataMain', function ($filter) {
	var data = {
			error_validation : '',
			claimant_no : '',
			salary_grade : '',
			basic_salary : '',
			total_spouse : 0,
			total_dependent : 0,
			draft_id : '',
			claim_id : ''
		};
	return {
        getErrorValidation: function () {
            return data.error_validation;
        },
        setErrorValidation: function (obj) {
            data.error_validation = obj;
        },
        getClaimantNo: function () {
            return data.claimant_no;
        },
        setClaimantNo: function (obj) {
            data.claimant_no = obj;
        },
		getSalaryGrade: function () {
            return data.salary_grade;
        },
        setSalaryGrade: function (obj) {
            data.salary_grade = obj;
        },
		getBasicSalary: function () {
            return data.basic_salary;
        },
        setBasicSalary: function (obj) {
            data.basic_salary = obj;
        },
		getTotalSpouse: function () {
            return data.total_spouse;
        },
        setTotalSpouse: function (obj) {
            data.total_spouse = obj;
        },
		getTotalDependent: function () {
            return data.total_dependent;
        },
        setTotalDependent: function (obj) {
            data.total_dependent = obj;
        },
        getDraftID: function () {
            return data.draft_id;
        },
        setDraftID: function (obj) {
            data.draft_id = obj;
        },
        getClaimID: function () {
            return data.claim_id;
        },
        setClaimID: function (obj) {
            data.claim_id = obj;
        }
	};
});

uiBootstrapApp.factory('DataRates', function () {
	var data = {
		TriggerRates : false,

		InWestMisc : 0,
		InSarawakMisc : 0,
		InSabahMisc : 0,
		FromWestMisc : 0,
		FromSarawakMisc : 0,
		FromSabahMisc : 0,
		BetweenMisc : 0,

		InWestSingleRate3Day : 0,
		InWestMarriedRate3Day : 0,
		InSarawakSingleRate3Day : 0,
		InSarawakMarriedRate3Day : 0,
		InSabahSingleRate3Day : 0,
		InSabahMarriedRate3Day : 0,

		FromWestSingleRate3Day : 0,
		FromWestMarriedRate3Day : 0,
		FromSarawakSingleRate3Day : 0,
		FromSarawakMarriedRate3Day : 0,
		FromSabahSingleRate3Day : 0,
		FromSabahMarriedRate3Day : 0,
		BetweenSingleRate3Day : 0,
		BetweenMarriedRate3Day : 0,

		InWestSingleRate5Day : 0,
		InWestMarriedRate5Day : 0,
		InSarawakSingleRate5Day : 0,
		InSarawakMarriedRate5Day : 0,
		InSabahSingleRate5Day : 0,
		InSabahMarriedRate5Day : 0,

		FromWestSingleRate5Day : 0,
		FromWestMarriedRate5Day : 0,
		FromSarawakSingleRate5Day : 0,
		FromSarawakMarriedRate5Day : 0,
		FromSabahSingleRate5Day : 0,
		FromSabahMarriedRate5Day : 0,
		BetweenSingleRate5Day : 0,
		BetweenMarriedRate5Day : 0,

		WestMealRate3Day : 0,
		WestHotelRate3Day : 0,
		WestLodgingRate3Day : 0,
		EastMealRate3Day : 0,
		EastHotelRate3Day : 0,
		EastLodgingRate3Day : 0,

		WestMealRate5Day : 0,
		WestHotelRate5Day : 0,
		WestLodgingRate5Day : 0,
		EastMealRate5Day : 0,
		EastHotelRate5Day : 0,
		EastLodgingRate5Day : 0,

		motorboat : 0,
		motorcycle : 0,
		car : 0,

		transport0to50WestSingle : 0,
		transport0to50WestMarried : 0,
		transport0to50EastSingle : 0,
		transport0to50EastMarried : 0,
		transport51to250WestSingle : 0,
		transport51to250WestMarried : 0,
		transport51to250EastSingle : 0,
		transport51to250EastMarried : 0,
		transport251to500WestSingle : 0,
		transport251to500WestMarried : 0,
		transport251to500EastSingle : 0,
		transport251to500EastMarried : 0,
		transport501to750WestSingle : 0,
		transport501to750WestMarried : 0,
		transport501to750EastSingle : 0,
		transport501to750EastMarried : 0,
		transport751to1000WestSingle : 0,
		transport751to1000WestMarried : 0,
		transport751to1000EastSingle : 0,
		transport751to1000EastMarried : 0,
		transport1001to1250WestSingle : 0,
		transport1001to1250WestMarried : 0,
		transport1001to1250EastSingle : 0,
		transport1001to1250EastMarried : 0,
		transport1251to999999WestSingle : 0,
		transport1251to999999WestMarried : 0,
		transport1251to999999EastSingle : 0,
		transport1251to999999EastMarried : 0,
	};

	return {
		getInWestMisc : function(){
			return data.InWestMisc;
		},
		setInWestMisc : function(obj){
			return data.InWestMisc = obj;
		},
		getInSarawakMisc : function(){
			return data.InSarawakMisc;
		},
		setInSarawakMisc : function(obj){
			return data.InSarawakMisc = obj;
		},
		getInSabahMisc : function(){
			return data.InSabahMisc;
		},
		setInSabahMisc : function(obj){
			return data.InSabahMisc = obj;
		},
		getFromWestMisc : function(){
			return data.FromWestMisc;
		},
		setFromWestMisc : function(obj){
			return data.FromWestMisc = obj;
		},
		getFromSarawakMisc : function(){
			return data.FromSarawakMisc;
		},
		setFromSarawakMisc : function(obj){
			return data.FromSarawakMisc = obj;
		},
		getFromSabahMisc : function(){
			return data.FromSabahMisc;
		},
		setFromSabahMisc : function(obj){
			return data.FromSabahMisc = obj;
		},
		getBetweenMisc : function(){
			return data.BetweenMisc;
		},
		setBetweenMisc : function(obj){
			return data.BetweenMisc = obj;
		},
		getInWestSingleRate3Day : function(){
			return data.InWestSingleRate3Day;
		},
		setInWestSingleRate3Day : function(obj){
			return data.InWestSingleRate3Day = obj;
		},
		getInWestMarriedRate3Day : function(){
			return data.InWestMarriedRate3Day;
		},
		setInWestMarriedRate3Day : function(obj){
			return data.InWestMarriedRate3Day = obj;
		},
		getInSarawakSingleRate3Day : function(){
			return data.InSarawakSingleRate3Day;
		},
		setInSarawakSingleRate3Day : function(obj){
			return data.InSarawakSingleRate3Day = obj;
		},
		getInSarawakMarriedRate3Day : function(){
			return data.InSarawakMarriedRate3Day;
		},
		setInSarawakMarriedRate3Day : function(obj){
			return data.InSarawakMarriedRate3Day = obj;
		},
		getInSabahSingleRate3Day : function(){
			return data.InSabahSingleRate3Day;
		},
		setInSabahSingleRate3Day : function(obj){
			return data.InSabahSingleRate3Day = obj;
		},
		getInSabahMarriedRate3Day : function(){
			return data.InSabahMarriedRate3Day;
		},
		setInSabahMarriedRate3Day : function(obj){
			return data.InSabahMarriedRate3Day = obj;
		},
		getFromWestSingleRate3Day : function(){
			return data.FromWestSingleRate3Day;
		},
		setFromWestSingleRate3Day : function(obj){
			return data.FromWestSingleRate3Day = obj;
		},
		getFromWestMarriedRate3Day : function(){
			return data.FromWestMarriedRate3Day;
		},
		setFromWestMarriedRate3Day : function(obj){
			return data.FromWestMarriedRate3Day = obj;
		},
		getFromSarawakSingleRate3Day : function(){
			return data.FromSarawakSingleRate3Day;
		},
		setFromSarawakSingleRate3Day : function(obj){
			return data.FromSarawakSingleRate3Day = obj;
		},
		getFromSarawakMarriedRate3Day : function(){
			return data.FromSarawakMarriedRate3Day;
		},
		setFromSarawakMarriedRate3Day : function(obj){
			return data.FromSarawakMarriedRate3Day = obj;
		},
		getFromSabahSingleRate3Day : function(){
			return data.FromSabahSingleRate3Day;
		},
		setFromSabahSingleRate3Day : function(obj){
			return data.FromSabahSingleRate3Day = obj;
		},
		getFromSabahMarriedRate3Day : function(){
			return data.FromSabahMarriedRate3Day;
		},
		setFromSabahMarriedRate3Day : function(obj){
			return data.FromSabahMarriedRate3Day = obj;
		},
		getBetweenSingleRate3Day : function(){
			return data.BetweenSingleRate3Day;
		},
		setBetweenSingleRate3Day : function(obj){
			return data.BetweenSingleRate3Day = obj;
		},
		getBetweenMarriedRate3Day : function(){
			return data.BetweenMarriedRate3Day;
		},
		setBetweenMarriedRate3Day : function(obj){
			return data.BetweenMarriedRate3Day = obj;
		},
		getInWestSingleRate5Day : function(){
			return data.InWestSingleRate5Day;
		},
		setInWestSingleRate5Day : function(obj){
			return data.InWestSingleRate5Day = obj;
		},
		getInWestMarriedRate5Day : function(){
			return data.InWestMarriedRate5Day;
		},
		setInWestMarriedRate5Day : function(obj){
			return data.InWestMarriedRate5Day = obj;
		},
		getInSarawakSingleRate5Day : function(){
			return data.InSarawakSingleRate5Day;
		},
		setInSarawakSingleRate5Day : function(obj){
			return data.InSarawakSingleRate5Day = obj;
		},
		getInSarawakMarriedRate5Day : function(){
			return data.InSarawakMarriedRate5Day;
		},
		setInSarawakMarriedRate5Day : function(obj){
			return data.InSarawakMarriedRate5Day = obj;
		},
		getInSabahSingleRate5Day : function(){
			return data.InSabahSingleRate5Day;
		},
		setInSabahSingleRate5Day : function(obj){
			return data.InSabahSingleRate5Day = obj;
		},
		getInSabahMarriedRate5Day : function(){
			return data.InSabahMarriedRate5Day;
		},
		setInSabahMarriedRate5Day : function(obj){
			return data.InSabahMarriedRate5Day = obj;
		},
		getFromWestSingleRate5Day : function(){
			return data.FromWestSingleRate5Day;
		},
		setFromWestSingleRate5Day : function(obj){
			return data.FromWestSingleRate5Day = obj;
		},
		getFromWestMarriedRate5Day : function(){
			return data.FromWestMarriedRate5Day;
		},
		setFromWestMarriedRate5Day : function(obj){
			return data.FromWestMarriedRate5Day = obj;
		},
		getFromSarawakSingleRate5Day : function(){
			return data.FromSarawakSingleRate5Day;
		},
		setFromSarawakSingleRate5Day : function(obj){
			return data.FromSarawakSingleRate5Day = obj;
		},
		getFromSarawakMarriedRate5Day : function(){
			return data.FromSarawakMarriedRate5Day;
		},
		setFromSarawakMarriedRate5Day : function(obj){
			return data.FromSarawakMarriedRate5Day = obj;
		},
		getFromSabahSingleRate5Day : function(){
			return data.FromSabahSingleRate5Day;
		},
		setFromSabahSingleRate5Day : function(obj){
			return data.FromSabahSingleRate5Day = obj;
		},
		getFromSabahMarriedRate5Day : function(){
			return data.FromSabahMarriedRate5Day;
		},
		setFromSabahMarriedRate5Day : function(obj){
			return data.FromSabahMarriedRate5Day = obj;
		},
		getBetweenSingleRate5Day : function(){
			return data.BetweenSingleRate5Day;
		},
		setBetweenSingleRate5Day : function(obj){
			return data.BetweenSingleRate5Day = obj;
		},
		getBetweenMarriedRate5Day : function(){
			return data.BetweenMarriedRate5Day;
		},
		setBetweenMarriedRate5Day : function(obj){
			return data.BetweenMarriedRate5Day = obj;
		},
		getWestMealRate3Day : function(){
			return data.WestMealRate3Day;
		},
		setWestMealRate3Day : function(obj){
			return data.WestMealRate3Day = obj;
		},
		getWestHotelRate3Day : function(){
			return data.WestHotelRate3Day;
		},
		setWestHotelRate3Day : function(obj){
			return data.WestHotelRate3Day = obj;
		},
		getWestLodgingRate3Day : function(){
			return data.WestLodgingRate3Day;
		},
		setWestLodgingRate3Day : function(obj){
			return data.WestLodgingRate3Day = obj;
		},
		getEastMealRate3Day : function(){
			return data.EastMealRate3Day;
		},
		setEastMealRate3Day : function(obj){
			return data.EastMealRate3Day = obj;
		},
		getEastHotelRate3Day : function(){
			return data.EastHotelRate3Day;
		},
		setEastHotelRate3Day : function(obj){
			return data.EastHotelRate3Day = obj;
		},
		getEastLodgingRate3Day : function(){
			return data.EastLodgingRate3Day;
		},
		setEastLodgingRate3Day : function(obj){
			return data.EastLodgingRate3Day = obj;
		},
		getWestMealRate5Day : function(){
			return data.WestMealRate5Day;
		},
		setWestMealRate5Day : function(obj){
			return data.WestMealRate5Day = obj;
		},
		getWestHotelRate5Day : function(){
			return data.WestHotelRate5Day;
		},
		setWestHotelRate5Day : function(obj){
			return data.WestHotelRate5Day = obj;
		},
		getWestLodgingRate5Day : function(){
			return data.WestLodgingRate5Day;
		},
		setWestLodgingRate5Day : function(obj){
			return data.WestLodgingRate5Day = obj;
		},
		getEastMealRate5Day : function(){
			return data.EastMealRate5Day;
		},
		setEastMealRate5Day : function(obj){
			return data.EastMealRate5Day = obj;
		},
		getEastHotelRate5Day : function(){
			return data.EastHotelRate5Day;
		},
		setEastHotelRate5Day : function(obj){
			return data.EastHotelRate5Day = obj;
		},
		getEastLodgingRate5Day : function(){
			return data.EastLodgingRate5Day;
		},
		setEastLodgingRate5Day : function(obj){
			return data.EastLodgingRate5Day = obj;
		},
		getMotorboat : function(){
			return data.motorboat;
		},
		setMotorboat : function(obj){
			return data.motorboat = obj;
		},
		getMotorcycle : function(){
			return data.motorcycle;
		},
		setMotorcycle : function(obj){
			return data.motorcycle = obj;
		},
		getCar : function(){
			return data.car;
		},
		setCar : function(obj){
			return data.car = obj;
		},
		get0to50WestSingle : function(){
			return data.transport0to50WestSingle;
		},
		set0to50WestSingle : function(obj){
			return data.transport0to50WestSingle = obj;
		},
		get0to50WestMarried : function(){
			return data.transport0to50WestMarried;
		},
		set0to50WestMarried : function(obj){
			return data.transport0to50WestMarried = obj;
		},
		get0to50EastSingle : function(){
			return data.transport0to50EastSingle;
		},
		set0to50EastSingle : function(obj){
			return data.transport0to50EastSingle = obj;
		},
		get0to50EastMarried : function(){
			return data.transport0to50EastMarried;
		},
		set0to50EastMarried : function(obj){
			return data.transport0to50EastMarried = obj;
		},
		get51to250WestSingle : function(){
			return data.transport51to250WestSingle;
		},
		set51to250WestSingle : function(obj){
			return data.transport51to250WestSingle = obj;
		},
		get51to250WestMarried : function(){
			return data.transport51to250WestMarried;
		},
		set51to250WestMarried : function(obj){
			return data.transport51to250WestMarried = obj;
		},
		get51to250EastSingle : function(){
			return data.transport51to250EastSingle;
		},
		set51to250EastSingle : function(obj){
			return data.transport51to250EastSingle = obj;
		},
		get51to250EastMarried : function(){
			return data.transport51to250EastMarried;
		},
		set51to250EastMarried : function(obj){
			return data.transport51to250EastMarried = obj;
		},
		get251to500WestSingle : function(){
			return data.transport251to500WestSingle;
		},
		set251to500WestSingle : function(obj){
			return data.transport251to500WestSingle = obj;
		},
		get251to500WestMarried : function(){
			return data.transport251to500WestMarried;
		},
		set251to500WestMarried : function(obj){
			return data.transport251to500WestMarried = obj;
		},
		get251to500EastSingle : function(){
			return data.transport251to500EastSingle;
		},
		set251to500EastSingle : function(obj){
			return data.transport251to500EastSingle = obj;
		},
		get251to500EastMarried : function(){
			return data.transport251to500EastMarried;
		},
		set251to500EastMarried : function(obj){
			return data.transport251to500EastMarried = obj;
		},
		get501to750WestSingle : function(){
			return data.transport501to750WestSingle;
		},
		set501to750WestSingle : function(obj){
			return data.transport501to750WestSingle = obj;
		},
		get501to750WestMarried : function(){
			return data.transport501to750WestMarried;
		},
		set501to750WestMarried : function(obj){
			return data.transport501to750WestMarried = obj;
		},
		get501to750EastSingle : function(){
			return data.transport501to750EastSingle;
		},
		set501to750EastSingle : function(obj){
			return data.transport501to750EastSingle = obj;
		},
		get501to750EastMarried : function(){
			return data.transport501to750EastMarried;
		},
		set501to750EastMarried : function(obj){
			return data.transport501to750EastMarried = obj;
		},
		get751to1000WestSingle : function(){
			return data.transport751to1000WestSingle;
		},
		set751to1000WestSingle : function(obj){
			return data.transport751to1000WestSingle = obj;
		},
		get751to1000WestMarried : function(){
			return data.transport751to1000WestMarried;
		},
		set751to1000WestMarried : function(obj){
			return data.transport751to1000WestMarried = obj;
		},
		get751to1000EastSingle : function(){
			return data.transport751to1000EastSingle;
		},
		set751to1000EastSingle : function(obj){
			return data.transport751to1000EastSingle = obj;
		},
		get751to1000EastMarried : function(){
			return data.transport751to1000EastMarried;
		},
		set751to1000EastMarried : function(obj){
			return data.transport751to1000EastMarried = obj;
		},
		get1001to1250WestSingle : function(){
			return data.transport1001to1250WestSingle;
		},
		set1001to1250WestSingle : function(obj){
			return data.transport1001to1250WestSingle = obj;
		},
		get1001to1250WestMarried : function(){
			return data.transport1001to1250WestMarried;
		},
		set1001to1250WestMarried : function(obj){
			return data.transport1001to1250WestMarried = obj;
		},
		get1001to1250EastSingle : function(){
			return data.transport1001to1250EastSingle;
		},
		set1001to1250EastSingle : function(obj){
			return data.transport1001to1250EastSingle = obj;
		},
		get1001to1250EastMarried : function(){
			return data.transport1001to1250EastMarried;
		},
		set1001to1250EastMarried : function(obj){
			return data.transport1001to1250EastMarried = obj;
		},
		get1251to999999WestSingle : function(){
			return data.transport1251to999999WestSingle;
		},
		set1251to999999WestSingle : function(obj){
			return data.transport1251to999999WestSingle = obj;
		},
		get1251to999999WestMarried : function(){
			return data.transport1251to999999WestMarried;
		},
		set1251to999999WestMarried : function(obj){
			return data.transport1251to999999WestMarried = obj;
		},
		get1251to999999EastSingle : function(){
			return data.transport1251to999999EastSingle;
		},
		set1251to999999EastSingle : function(obj){
			return data.transport1251to999999EastSingle = obj;
		},
		get1251to999999EastMarried : function(){
			return data.transport1251to999999EastMarried;
		},
		set1251to999999EastMarried : function(obj){
			return data.transport1251to999999EastMarried = obj;
		},
		getTriggerRates: function () {
            return data.TriggerRates;
        },
        setTriggerRates: function (val) {
            data.TriggerRates = val;
        },
	};
});

uiBootstrapApp.factory('DataFormTransferDetails', function ($filter) {

    var data = {
		expensesList : [],
		spouseList : [],
		childrenList : [],
		transferDate : '',
		transferDateTxt : '',
		transferGradeAfter : '',
		maritalStatus : '',
		transferMover : '',
		transferDestination : '',
		transferLocalFundType : '',
		transferLocalProjectCode : '',
		vehicle : '',
		distance : 0,
		oldOfficeLine1 : '',
		oldOfficeLine2 : '',
		oldOfficeLine3 : '',
		oldOfficeLine4 : '',
		newOfficeLine1 : '',
		newOfficeLine2 : '',
		newOfficeLine3 : '',
		newOfficeLine4 : '',
		oldHomeLine1 : '',
		oldHomeLine2 : '',
		oldHomeLine3 : '',
		oldHomeLine4 : '',
		newHomeLine1 : '',
		newHomeLine2 : '',
		newHomeLine3 : '',
		newHomeLine4 : '',
    };

    return {
		getExpensesList: function () {
            return data.expensesList;
        },
        setExpensesList: function (obj) {
            data.expensesList = obj;
        },
		getSpouseList: function () {
            return data.spouseList;
        },
        setSpouseList: function (obj) {
            data.spouseList = obj;
        },
		getChildrenList: function () {
            return data.childrenList;
        },
        setChildrenList: function (obj) {
            data.childrenList = obj;
        },
		getTransferDate: function () {
            return data.transferDate;
        },
        setTransferDate: function (obj) {
            data.transferDate = obj;
        },
		getTransferDateTxt: function () {
            return data.transferDateTxt;
        },
        setTransferDateTxt: function (obj) {
            data.transferDateTxt = obj;
        },
		getTransferLocalFundType: function () {
            return data.transferLocalFundType;
        },
        setTransferLocalFundType: function (obj) {
            data.transferLocalFundType = obj;
        },
		getTransferLocalProjectCode: function () {
            return data.transferLocalProjectCode;
        },
        setTransferLocalProjectCode: function (obj) {
            data.transferLocalProjectCode = obj;
        },
		getTransferGradeAfter: function () {
            return data.transferGradeAfter;
        },
        setTransferGradeAfter: function (obj) {
            data.transferGradeAfter = obj;
        },
        getMaritalStatus: function () {
            return data.maritalStatus;
        },
        setMaritalStatus: function (obj) {
            data.maritalStatus = obj;
        },
		getTransferMover: function () {
            return data.transferMover;
        },
        setTransferMover: function (obj) {
            data.transferMover = obj;
        },
		getTransferDestination: function () {
            return data.transferDestination;
        },
        setTransferDestination: function (obj) {
            data.transferDestination = obj;
        },
		getVehicle: function () {
            return data.vehicle;
        },
        setVehicle: function (obj) {
            data.vehicle = obj;
        },
		getDistance: function () {
            return data.distance;
        },
        setDistance: function (obj) {
            data.distance = obj;
        },
		getOldOfficeLine1: function () {
            return data.oldOfficeLine1;
        },
        setOldOfficeLine1: function (obj) {
            data.oldOfficeLine1 = obj;
        },
		getOldOfficeLine2: function () {
            return data.oldOfficeLine2;
        },
        setOldOfficeLine2: function (obj) {
            data.oldOfficeLine2 = obj;
        },
		getOldOfficeLine3: function () {
            return data.oldOfficeLine3;
        },
        setOldOfficeLine3: function (obj) {
            data.oldOfficeLine3 = obj;
        },
		getOldOfficeLine4: function () {
            return data.oldOfficeLine4;
        },
        setOldOfficeLine4: function (obj) {
            data.oldOfficeLine4 = obj;
        },
		getNewOfficeLine1: function () {
            return data.newOfficeLine1;
        },
        setNewOfficeLine1: function (obj) {
            data.newOfficeLine1 = obj;
        },
		getNewOfficeLine2: function () {
            return data.newOfficeLine2;
        },
        setNewOfficeLine2: function (obj) {
            data.newOfficeLine2 = obj;
        },
		getNewOfficeLine3: function () {
            return data.newOfficeLine3;
        },
        setNewOfficeLine3: function (obj) {
            data.newOfficeLine3 = obj;
        },
		getNewOfficeLine4: function () {
            return data.newOfficeLine4;
        },
        setNewOfficeLine4: function (obj) {
            data.newOfficeLine4 = obj;
        },
		getOldHomeLine1: function () {
            return data.oldHomeLine1;
        },
        setOldHomeLine1: function (obj) {
            data.oldHomeLine1 = obj;
        },
		getOldHomeLine2: function () {
            return data.oldHomeLine2;
        },
        setOldHomeLine2: function (obj) {
            data.oldHomeLine2 = obj;
        },
		getOldHomeLine3: function () {
            return data.oldHomeLine3;
        },
        setOldHomeLine3: function (obj) {
            data.oldHomeLine3 = obj;
        },
		getOldHomeLine4: function () {
            return data.oldHomeLine4;
        },
        setOldHomeLine4: function (obj) {
            data.oldHomeLine4 = obj;
        },
		getNewHomeLine1: function () {
            return data.newHomeLine1;
        },
        setNewHomeLine1: function (obj) {
            data.newHomeLine1 = obj;
        },
		getNewHomeLine2: function () {
            return data.newHomeLine2;
        },
        setNewHomeLine2: function (obj) {
            data.newHomeLine2 = obj;
        },
		getNewHomeLine3: function () {
            return data.newHomeLine3;
        },
        setNewHomeLine3: function (obj) {
            data.newHomeLine3 = obj;
        },
		getNewHomeLine4: function () {
            return data.newHomeLine4;
        },
        setNewHomeLine4: function (obj) {
            data.newHomeLine4 = obj;
        },
    };
});

uiBootstrapApp.factory('DataFormClaimDetails', function ($filter) {

    var data = {
		miscItems : [],
		Trigger : false,
		transferAllowance : 0,

		dependent : 0,
		meal3Day : 0,
		mealRatePer3Day : 0,
		mealNoPerson3Day : 0,
		mealTotal3Day : 0,
		meal5Day : 0,
		mealRatePer5Day : 0,
		mealNoPerson5Day : 0,
		mealTotal5Day : 0,
		mealTotalAmount : 0,

		hotel3Day : 0,
		hotel5Day : 0,
		hotelRoomPrice1First3 : 0,
		hotelRoomPrice2First3 : 0,
		hotelRoomPrice3First3 : 0,
		hotelTotalFirst3Day : 0,
		hotelRoomPrice1Second3 : 0,
		hotelRoomPrice2Second3 : 0,
		hotelRoomPrice3Second3 : 0,
		hotelTotalSecond3Day : 0,
		hotelRoomPrice1Third3 : 0,
		hotelRoomPrice2Third3 : 0,
		hotelRoomPrice3Third3 : 0,
		hotelTotalThird3Day : 0,
		hotelTotal3Day : 0,
		hotelRoomPrice1First5 : 0,
		hotelRoomPrice2First5 : 0,
		hotelRoomPrice3First5 : 0,
		hotelTotalFirst5Day : 0,
		hotelRoomPrice1Second5 : 0,
		hotelRoomPrice2Second5 : 0,
		hotelRoomPrice3Second5 : 0,
		hotelTotalSecond5Day : 0,
		hotelRoomPrice1Third5 : 0,
		hotelRoomPrice2Third5 : 0,
		hotelRoomPrice3Third5 : 0,
		hotelTotalThird5Day : 0,
		hotelRoomPrice1Forth5 : 0,
		hotelRoomPrice2Forth5 : 0,
		hotelRoomPrice3Forth5 : 0,
		hotelTotalForth5Day : 0,
		hotelRoomPrice1Fifth5 : 0,
		hotelRoomPrice2Fifth5 : 0,
		hotelRoomPrice3Fifth5 : 0,
		hotelTotalFifth5Day : 0,
		hotelTotal5Day : 0,
		hotelTotalAmount : 0,
		hotelTotalGST : 0,
		hotelReceiptNo : 0,

		lodging3Day : 0,
		lodging5Day : 0,
		lodging3DayAddress : '',
		lodging3DayNoDays : 0,
		lodging3DayRates : 0,
		lodging3DayTotal : 0,
		lodging5DayAddress : '',
		lodging5DayNoDays : 0,
		lodging5DayRates : 0,
		lodging5DayTotal : 0,
		lodgingTotalAmount : 0,

		publicLandReceiptNo : '',
		publicLandTotal : 0,
		publicSeaReceiptNo : '',
		publicSeaTotal : 0,
		publicAirReceiptNo : '',
		publicAirTotal : 0,
		publicTotalAmount : 0,
		vehicleRate : 0,
		mileageFrom : '',
		mileageTo : '',
		mileageKM : 0,
		mileageTotal : 0,

		goodsLandKM : 0,
		goodsLandTotal : 0,
		goodsSeaReceiptNo : '',
		goodsSeaTotal : 0,

		miscTotal : 0,

		otherMiscPercentage : 0,
		otherMiscTotalAmount : 0,

		claimAmount : 0,
		endowmentAmount : 0,
		netTotal : 0,
    };

    return {
		getMiscItems: function () {
            return data.miscItems;
        },
        setMiscItems: function (obj) {
            data.miscItems = obj;
        },
		getTransferAllowance: function () {
            return data.transferAllowance;
        },
        setTransferAllowance: function (obj) {
            data.transferAllowance = obj;
        },
		getDependent: function () {
            return data.dependent;
        },
        setDependent: function (obj) {
            data.dependent = obj;
        },
		getMeal3Day: function () {
            return data.meal3Day;
        },
        setMeal3Day: function (obj) {
            data.meal3Day = obj;
        },
		getMealRatePer3Day: function () {
            return data.mealRatePer3Day;
        },
        setMealRatePer3Day: function (obj) {
            data.mealRatePer3Day = obj;
        },
		getMealNoPerson3Day: function () {
            return data.mealNoPerson3Day;
        },
        setMealNoPerson3Day: function (obj) {
            data.mealNoPerson3Day = obj;
        },
		getMealTotal3Day: function () {
            return data.mealTotal3Day;
        },
        setMealTotal3Day: function (obj) {
            data.mealTotal3Day = obj;
        },
		getMeal5Day: function () {
            return data.meal5Day;
        },
        setMeal5Day: function (obj) {
            data.meal5Day = obj;
        },
		getMealRatePer5Day: function () {
            return data.mealRatePer5Day;
        },
        setMealRatePer5Day: function (obj) {
            data.mealRatePer5Day = obj;
        },
		getMealNoPerson5Day: function () {
            return data.mealNoPerson5Day;
        },
        setMealNoPerson5Day: function (obj) {
            data.mealNoPerson5Day = obj;
        },
		getMealTotal5Day: function () {
            return data.mealTotal5Day;
        },
        setMealTotal5Day: function (obj) {
            data.mealTotal5Day = obj;
        },
		getMealTotalAmount: function () {
            return data.mealTotalAmount;
        },
        setMealTotalAmount: function (obj) {
            data.mealTotalAmount = obj;
        },
		getHotel3Day: function () {
            return data.hotel3Day;
        },
        setHotel3Day: function (obj) {
            data.hotel3Day = obj;
        },
		getHotelRoomPrice1First3: function () {
            return data.hotelRoomPrice1First3;
        },
        setHotelRoomPrice1First3: function (obj) {
            data.hotelRoomPrice1First3 = obj;
        },
		getHotelRoomPrice2First3: function () {
            return data.hotelRoomPrice2First3;
        },
        setHotelRoomPrice2First3: function (obj) {
            data.hotelRoomPrice2First3 = obj;
        },
		getHotelRoomPrice3First3: function () {
            return data.hotelRoomPrice3First3;
        },
        setHotelRoomPrice3First3: function (obj) {
            data.hotelRoomPrice3First3 = obj;
        },
		getHotelTotalFirst3Day: function () {
            return data.hotelTotalFirst3Day;
        },
        setHotelTotalFirst3Day: function (obj) {
            data.hotelTotalFirst3Day = obj;
        },
		getHotelRoomPrice1Second3: function () {
            return data.hotelRoomPrice1Second3;
        },
        setHotelRoomPrice1Second3: function (obj) {
            data.hotelRoomPrice1Second3 = obj;
        },
		getHotelRoomPrice2Second3: function () {
            return data.hotelRoomPrice2Second3;
        },
        setHotelRoomPrice2Second3: function (obj) {
            data.hotelRoomPrice2Second3 = obj;
        },
		getHotelRoomPrice3Second3: function () {
            return data.hotelRoomPrice3Second3;
        },
        setHotelRoomPrice3Second3: function (obj) {
            data.hotelRoomPrice3Second3 = obj;
        },
		getHotelTotalSecond3Day: function () {
            return data.hotelTotalSecond3Day;
        },
        setHotelTotalSecond3Day: function (obj) {
            data.hotelTotalSecond3Day = obj;
        },
		getHotelRoomPrice1Third3: function () {
            return data.hotelRoomPrice1Third3;
        },
        setHotelRoomPrice1Third3: function (obj) {
            data.hotelRoomPrice1Third3 = obj;
        },
		getHotelRoomPrice2Third3: function () {
            return data.hotelRoomPrice2Third3;
        },
        setHotelRoomPrice2Third3: function (obj) {
            data.hotelRoomPrice2Third3 = obj;
        },
		getHotelRoomPrice3Third3: function () {
            return data.hotelRoomPrice3Third3;
        },
        setHotelRoomPrice3Third3: function (obj) {
            data.hotelRoomPrice3Third3 = obj;
        },
		getHotelTotalThird3Day: function () {
            return data.hotelTotalThird3Day;
        },
        setHotelTotalThird3Day: function (obj) {
            data.hotelTotalThird3Day = obj;
        },
		getHotelTotal3Day: function () {
            return data.hotelTotal3Day;
        },
        setHotelTotal3Day: function (obj) {
            data.hotelTotal3Day = obj;
        },
		getHotel5Day: function () {
            return data.hotel5Day;
        },
        setHotel5Day: function (obj) {
            data.hotel5Day = obj;
        },
		getHotelRoomPrice1First5: function () {
            return data.hotelRoomPrice1First5;
        },
        setHotelRoomPrice1First5: function (obj) {
            data.hotelRoomPrice1First5 = obj;
        },
		getHotelRoomPrice2First5: function () {
            return data.hotelRoomPrice2First5;
        },
        setHotelRoomPrice2First5: function (obj) {
            data.hotelRoomPrice2First5 = obj;
        },
		getHotelRoomPrice3First5: function () {
            return data.hotelRoomPrice3First5;
        },
        setHotelRoomPrice3First5: function (obj) {
            data.hotelRoomPrice3First5 = obj;
        },
		getHotelTotalFirst5Day: function () {
            return data.hotelTotalFirst5Day;
        },
        setHotelTotalFirst5Day: function (obj) {
            data.hotelTotalFirst5Day = obj;
        },
		getHotelRoomPrice1Second5: function () {
            return data.hotelRoomPrice1Second5;
        },
        setHotelRoomPrice1Second5: function (obj) {
            data.hotelRoomPrice1Second5 = obj;
        },
		getHotelRoomPrice2Second5: function () {
            return data.hotelRoomPrice2Second5;
        },
        setHotelRoomPrice2Second5: function (obj) {
            data.hotelRoomPrice2Second5 = obj;
        },
		getHotelRoomPrice3Second5: function () {
            return data.hotelRoomPrice3Second5;
        },
        setHotelRoomPrice3Second5: function (obj) {
            data.hotelRoomPrice3Second5 = obj;
        },
		getHotelTotalSecond5Day: function () {
            return data.hotelTotalSecond5Day;
        },
        setHotelTotalSecond5Day: function (obj) {
            data.hotelTotalSecond5Day = obj;
        },
		getHotelRoomPrice1Third5: function () {
            return data.hotelRoomPrice1Third5;
        },
        setHotelRoomPrice1Third5: function (obj) {
            data.hotelRoomPrice1Third5 = obj;
        },
		getHotelRoomPrice2Third5: function () {
            return data.hotelRoomPrice2Third5;
        },
        setHotelRoomPrice2Third5: function (obj) {
            data.hotelRoomPrice2Third5 = obj;
        },
		getHotelRoomPrice3Third5: function () {
            return data.hotelRoomPrice3Third5;
        },
        setHotelRoomPrice3Third5: function (obj) {
            data.hotelRoomPrice3Third5 = obj;
        },
		getHotelTotalThird5Day: function () {
            return data.hotelTotalThird5Day;
        },
        setHotelTotalThird5Day: function (obj) {
            data.hotelTotalThird5Day = obj;
        },
		getHotelRoomPrice1Forth5: function () {
            return data.hotelRoomPrice1Forth5;
        },
        setHotelRoomPrice1Forth5: function (obj) {
            data.hotelRoomPrice1Forth5 = obj;
        },
		getHotelRoomPrice2Forth5: function () {
            return data.hotelRoomPrice2Forth5;
        },
        setHotelRoomPrice2Forth5: function (obj) {
            data.hotelRoomPrice2Forth5 = obj;
        },
		getHotelRoomPrice3Forth5: function () {
            return data.hotelRoomPrice3Forth5;
        },
        setHotelRoomPrice3Forth5: function (obj) {
            data.hotelRoomPrice3Forth5 = obj;
        },
		getHotelTotalForth5Day: function () {
            return data.hotelTotalForth5Day;
        },
        setHotelTotalForth5Day: function (obj) {
            data.hotelTotalForth5Day = obj;
        },
		getHotelRoomPrice1Fifth5: function () {
            return data.hotelRoomPrice1Fifth5;
        },
        setHotelRoomPrice1Fifth5: function (obj) {
            data.hotelRoomPrice1Fifth5 = obj;
        },
		getHotelRoomPrice2Fifth5: function () {
            return data.hotelRoomPrice2Fifth5;
        },
        setHotelRoomPrice2Fifth5: function (obj) {
            data.hotelRoomPrice2Fifth5 = obj;
        },
		getHotelRoomPrice3Fifth5: function () {
            return data.hotelRoomPrice3Fifth5;
        },
        setHotelRoomPrice3Fifth5: function (obj) {
            data.hotelRoomPrice3Fifth5 = obj;
        },
		getHotelTotalFifth5Day: function () {
            return data.hotelTotalFifth5Day;
        },
        setHotelTotalFifth5Day: function (obj) {
            data.hotelTotalFifth5Day = obj;
        },
		getHotelTotal5Day: function () {
            return data.hotelTotal5Day;
        },
        setHotelTotal5Day: function (obj) {
            data.hotelTotal5Day = obj;
        },
		getHotelTotalAmount: function () {
            return data.hotelTotalAmount;
        },
        setHotelTotalAmount: function (obj) {
            data.hotelTotalAmount = obj;
        },
		getHotelTotalGST: function () {
            return data.hotelTotalGST;
        },
        setHotelTotalGST: function (obj) {
            data.hotelTotalGST = obj;
        },
		getHotelReceiptNo: function () {
            return data.hotelReceiptNo;
        },
        setHotelReceiptNo: function (obj) {
            data.hotelReceiptNo = obj;
        },
		getLodging3Day: function () {
            return data.lodging3Day;
        },
        setLodging3Day: function (obj) {
            data.lodging3Day = obj;
        },
		getLodging3DayAddress: function () {
            return data.lodging3DayAddress;
        },
        setLodging3DayAddress: function (obj) {
            data.lodging3DayAddress = obj;
        },
		getLodging3DayNoDays: function () {
            return data.lodging3DayNoDays;
        },
        setLodging3DayNoDays: function (obj) {
            data.lodging3DayNoDays = obj;
        },
		getLodging3DayRate: function () {
            return data.lodging3DayRate;
        },
        setLodging3DayRate: function (obj) {
            data.lodging3DayRate = obj;
        },
		getLodging3DayTotal: function () {
            return data.lodging3DayTotal;
        },
        setLodging3DayTotal: function (obj) {
            data.lodging3DayTotal = obj;
        },
		getLodging5Day: function () {
            return data.lodging5Day;
        },
        setLodging5Day: function (obj) {
            data.lodging5Day = obj;
        },
		getLodging5DayAddress: function () {
            return data.lodging5DayAddress;
        },
        setLodging5DayAddress: function (obj) {
            data.lodging5DayAddress = obj;
        },
		getLodging5DayNoDays: function () {
            return data.lodging5DayNoDays;
        },
        setLodging5DayNoDays: function (obj) {
            data.lodging5DayNoDays = obj;
        },
		getLodging5DayRate: function () {
            return data.lodging5DayRate;
        },
        setLodging5DayRate: function (obj) {
            data.lodging5DayRate = obj;
        },
		getLodging5DayTotal: function () {
            return data.lodging5DayTotal;
        },
        setLodging5DayTotal: function (obj) {
            data.lodging5DayTotal = obj;
        },
		getLodgingTotalAmount: function () {
            return data.lodgingTotalAmount;
        },
        setLodgingTotalAmount: function (obj) {
            data.lodgingTotalAmount = obj;
        },
		getVehicleRate: function () {
            return data.vehicleRate;
        },
        setVehicleRate: function (obj) {
            data.vehicleRate = obj;
        },
		getPublicLandReceiptNo: function () {
            return data.publicLandReceiptNo;
        },
        setPublicLandReceiptNo: function (obj) {
            data.publicLandReceiptNo = obj;
        },
		getPublicLandTotal: function () {
            return data.publicLandTotal;
        },
        setPublicLandTotal: function (obj) {
            data.publicLandTotal = obj;
        },
		getPublicSeaReceiptNo: function () {
            return data.publicSeaReceiptNo;
        },
        setPublicSeaReceiptNo: function (obj) {
            data.publicSeaReceiptNo = obj;
        },
		getPublicSeaTotal: function () {
            return data.publicSeaTotal;
        },
        setPublicSeaTotal: function (obj) {
            data.publicSeaTotal = obj;
        },
		getPublicAirReceiptNo: function () {
            return data.publicAirReceiptNo;
        },
        setPublicAirReceiptNo: function (obj) {
            data.publicAirReceiptNo = obj;
        },
		getPublicAirTotal: function () {
            return data.publicAirTotal;
        },
        setPublicAirTotal: function (obj) {
            data.publicAirTotal = obj;
        },
		getPublicTotalAmount: function () {
            return data.publicTotalAmount;
        },
        setPublicTotalAmount: function (obj) {
            data.publicTotalAmount = obj;
        },
		getMileageFrom: function () {
            return data.mileageFrom;
        },
        setMileageFrom: function (obj) {
            data.mileageFrom = obj;
        },
		getMileageTo: function () {
            return data.mileageTo;
        },
        setMileageTo: function (obj) {
            data.mileageTo = obj;
        },
		getMileageKM: function () {
            return data.mileageKM;
        },
        setMileageKM: function (obj) {
            data.mileageKM = obj;
        },
		getMileageTotal: function () {
            return data.mileageTotal;
        },
        setMileageTotal: function (obj) {
            data.mileageTotal = obj;
        },
		getGoodsLandKM: function () {
            return data.goodsLandKM;
        },
        setGoodsLandKM: function (obj) {
            data.goodsLandKM = obj;
        },
		getGoodsLandTotal: function () {
            return data.goodsLandTotal;
        },
        setGoodsLandTotal: function (obj) {
            data.goodsLandTotal = obj;
        },
		getGoodsSeaReceiptNo: function () {
            return data.goodsSeaReceiptNo;
        },
        setGoodsSeaReceiptNo: function (obj) {
            data.goodsSeaReceiptNo = obj;
        },
		getGoodsSeaTotal: function () {
            return data.goodsSeaTotal;
        },
        setGoodsSeaTotal: function (obj) {
            data.goodsSeaTotal = obj;
        },
		getMiscTotal: function () {
            return data.miscTotal;
        },
        setMiscTotal: function (obj) {
            data.miscTotal = obj;
        },
		getOtherMiscPercentage: function () {
            return data.otherMiscPercentage;
        },
        setOtherMiscPercentage: function (obj) {
            data.otherMiscPercentage = obj;
        },
		getOtherMiscAmount: function () {
            return data.otherMiscAmount;
        },
        setOtherMiscAmount: function (obj) {
            data.otherMiscAmount = obj;
        },
		getClaimAmount: function () {
            return data.claimAmount;
        },
        setClaimAmount: function (obj) {
            data.claimAmount = obj;
        },
		getEndowmentAmount: function () {
            return data.endowmentAmount;
        },
        setEndowmentAmount: function (obj) {
            data.endowmentAmount = obj;
        },
		getNetTotal: function () {
            return data.netTotal;
        },
        setNetTotal: function (obj) {
            data.netTotal = obj;
        },
		getTrigger: function () {
            return data.Trigger;
        },
        setTrigger: function (val) {
            data.Trigger = val;
        },
		reset: function (){

        }
    };
});
