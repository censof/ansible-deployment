import json
import datetime
from decimal import Decimal

from django.db.models import Max

from eclaim.masterfiles.models.misc import VehicleType, VehicleRate, TransportationFare
from eclaim.masterfiles.models.entitlement import *


def get_lfc_within_rate(salary_grade, basic_salary):
    rate = {}
    salary = Decimal(basic_salary)
    if str(salary_grade).isdigit():
        gradelevel = int(salary_grade)
    else:
        gradelevel = salary_grade

    entitlements = TransferWithinStateEntitlement.objects.filter(effective_date__lte=datetime.date.today()).annotate(Max('effective_date'))

    entitlement = None
    m = [i for i in entitlements if str(i.ssm_grade_from.code).isdigit() and str(i.ssm_grade_to.code).isdigit()]
    if m:
        n = [i for i in m if gradelevel >= int(i.ssm_grade_from.code) and gradelevel <= int(i.ssm_grade_to.code)]
    else:
        n = [i for i in m if gradelevel >= i.ssm_grade_from.code and gradelevel <= i.ssm_grade_to.code]

    max_salary = Decimal('0.00')
    if len(n) == 1:
        entitlement = n[0]
    else:
        for i in n:
            if i.ssm_salary_to > max_salary:
                max_salary = i.ssm_salary_to
            if i.ssm_salary_from != '0.00' and i.ssm_salary_to != '0.00':
                if salary >= i.ssm_salary_from and salary <= i.ssm_salary_to:
                    entitlement = i
            else:
                entitlement = i

    if entitlement is None:
        for i in n:
            if i.ssm_salary_to == max_salary:
                entitlement = i

    inWest = WestMalaysiaTransferAllowance.objects.filter(entitlement=entitlement)
    for i in inWest:
        rate['inwest_single3day'] = str(i.single)
        rate['inwest_married3day'] = str(i.married)

    inSarawak = SarawakTransferAllowance.objects.filter(entitlement=entitlement)
    for i in inSarawak:
        rate['insarawak_single3day'] = str(i.single)
        rate['insarawak_married3day'] = str(i.married)

    inSabah = SabahTransferAllowance.objects.filter(entitlement=entitlement)
    for i in inSabah:
        rate['insabah_single3day'] = str(i.single)
        rate['insabah_married3day'] = str(i.married)

    return json.dumps(rate)


def get_lfc_from_rate(salary_grade, basic_salary):
    rate = {}
    salary = Decimal(basic_salary)
    if str(salary_grade).isdigit():
        gradelevel = int(salary_grade)
    else:
        gradelevel = salary_grade

    entitlements = TransferBetweenStateEntitlement.objects.filter(effective_date__lte=datetime.date.today()).annotate(Max('effective_date'))

    entitlement = None
    m = [i for i in entitlements if str(i.ssm_grade_from.code).isdigit() and str(i.ssm_grade_to.code).isdigit()]
    if m:
        n = [i for i in m if gradelevel >= int(i.ssm_grade_from.code) and gradelevel <= int(i.ssm_grade_to.code)]
    else:
        n = [i for i in m if gradelevel >= i.ssm_grade_from.code and gradelevel <= i.ssm_grade_to.code]

    max_salary = Decimal('0.00')
    if len(n) == 1:
        entitlement = n[0]
    else:
        for i in n:
            if i.ssm_salary_to > max_salary:
                max_salary = i.ssm_salary_to
            if i.ssm_salary_from != '0.00' and i.ssm_salary_to != '0.00':
                if salary >= i.ssm_salary_from and salary <= i.ssm_salary_to:
                    entitlement = i
            else:
                entitlement = i

    if entitlement is None:
        for i in n:
            if i.ssm_salary_to == max_salary:
                entitlement = i

    fromWest = FromWestMalaysiaTransferAllowance.objects.filter(entitlement=entitlement)
    for i in fromWest:
        rate['fromwest_single3day'] = str(i.single)
        rate['fromwest_married3day'] = str(i.married)

    fromSarawak = FromSarawakTransferAllowance.objects.filter(entitlement=entitlement)
    for i in fromSarawak:
        rate['fromsarawak_single3day'] = str(i.single)
        rate['fromsarawak_married3day'] = str(i.married)

    fromSabah = FromSabahTransferAllowance.objects.filter(entitlement=entitlement)
    for i in fromSabah:
        rate['fromsabah_single3day'] = str(i.single)
        rate['fromsabah_married3day'] = str(i.married)

    between = BetweenSabahSarawakTransferAllowance.objects.filter(entitlement=entitlement)
    for i in between:
        rate['between_single3day'] = str(i.single)
        rate['between_married3day'] = str(i.married)

    return json.dumps(rate)


def get_lfc_others_rate(salary_grade, basic_salary):
    rate = {}
    salary = Decimal(basic_salary)
    if str(salary_grade).isdigit():
        gradelevel = int(salary_grade)
    else:
        gradelevel = salary_grade

    entitlements = InMalaysiaEntitlement.objects.filter(effective_date__lte=datetime.date.today()).annotate(Max('effective_date'))

    entitlement = None
    m = [i for i in entitlements if str(i.ssm_grade_from.code).isdigit() and str(i.ssm_grade_to.code).isdigit()]
    if m:
        n = [i for i in m if gradelevel >= int(i.ssm_grade_from.code) and gradelevel <= int(i.ssm_grade_to.code)]
    else:
        n = [i for i in m if gradelevel >= i.ssm_grade_from.code and gradelevel <= i.ssm_grade_to.code]

    max_salary = Decimal('0.00')
    if len(n) == 1:
        entitlement = n[0]
    else:
        for i in n:
            if i.ssm_salary_to > max_salary:
                max_salary = i.ssm_salary_to
            if i.ssm_salary_from != '0.00' and i.ssm_salary_to != '0.00':
                if salary >= i.ssm_salary_from and salary <= i.ssm_salary_to:
                    entitlement = i
            else:
                entitlement = i

    if entitlement is None:
        for i in n:
            if i.ssm_salary_to == max_salary:
                entitlement = i

    tlcOthersWest = OfficialTripAllowance.objects.filter(entitlement=entitlement, region='West')
    for i in tlcOthersWest:
        rate['west_meal3day'] = str(i.meal)
        rate['west_hotel3day'] = str(i.hotel)
        rate['west_lodging3day'] = str(i.lodging)

    tlcOthersEast = OfficialTripAllowance.objects.filter(entitlement=entitlement, region='East')
    for i in tlcOthersEast:
        rate['east_meal3day'] = str(i.meal)
        rate['east_hotel3day'] = str(i.hotel)
        rate['east_lodging3day'] = str(i.lodging)

    return json.dumps(rate)


def get_lfc_vehicle_rate():
    rate = {}
    vehicle_type = VehicleType.objects.all()

    for i in vehicle_type:
        vehicle_rates = VehicleRate.objects.filter(vehicle_type_id=i.id)
        for vehicle_rate in vehicle_rates:
            rate[i.name.lower()] = str(vehicle_rate.rate)

    return json.dumps(rate)


def get_lfc_transportation_fare():
    rate = {}
    transportation_fare = TransportationFare.objects.all()

    for fare in transportation_fare:
        min_max = [(0, 50), (51, 250), (251, 500), (501, 750), (751, 1000), (1001, 1250), (1251, 999999)]
        for min, max in min_max:
            if fare.distance_min == min and fare.distance_max == max:
                rate['Transport%sTo%sWestSingle' % (min, max)] = str(fare.west_single)
                rate['Transport%sTo%sWestMarried' % (min, max)] = str(fare.west_married)
                rate['Transport%sTo%sEastSingle' % (min, max)] = str(fare.east_single)
                rate['Transport%sTo%sEastMarried' % (min, max)] = str(fare.east_married)

    return json.dumps(rate)