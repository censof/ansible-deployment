from decimal import *
from django.db import models
from django.core.urlresolvers import reverse_lazy
from eclaim.claim.models import ClaimType
from eclaim.libs.models import BaseModel
from eclaim.masterfiles.models.misc import FundType, VehicleType, TRANSFER_DESTINATION_LIST, TYPE_OF_MOVER_LIST
from eclaim.masterfiles.models.claimant import Claimant
from eclaim.masterfiles.models.company import GradeLevelCategory
from eclaim.masterfiles.models.default_attribute import CLAIM_NO_MAX_LENGTH
from eclaim.masterfiles.common import CLAIM_STATUS

# claim_type pk for Local Transfer Claim is 3
LOCAL_TRANSFER_CLAIM_TYPE = 3


class LocalTransferClaimAbstract(BaseModel):
    status = models.CharField(max_length=CLAIM_STATUS.DEFAULT_LENGTH)
    apply_date = models.DateField()

    class Meta:
        app_label = 'localtransfer'
        abstract = True

    @staticmethod
    def get_claim_type():
        return ClaimType.objects.get(pk=LOCAL_TRANSFER_CLAIM_TYPE)


class LocalTransferClaimItemAbstract(models.Model):
    grade_after = models.ForeignKey(GradeLevelCategory, null=True)
    transfer_date = models.DateField(null=True)
    fund_type = models.ForeignKey(FundType, null=True)
    project_code = models.CharField(max_length=10, null=True)
    marital_status = models.CharField(max_length=2)
    mover = models.CharField(max_length=30, choices=TYPE_OF_MOVER_LIST, null=True)
    destination = models.CharField(max_length=30, choices=TRANSFER_DESTINATION_LIST, null=True)
    vehicle = models.ForeignKey(VehicleType, null=True)
    distance = models.IntegerField(null=True, default=0)
    goods_land_distance = models.IntegerField(null=True, default=0)
    goods_sea_receipt_no = models.CharField(max_length=30, null=True)

    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    for details in ('transfer_allowance', 'goods_land_amount', 'goods_sea_amount', 'misc_total'
                    , 'other_misc_percentage', 'other_misc_amount', 'claim_amount', 'endowment_amount', 'net_total'):
        exec("%s = models.DecimalField(**default_arguments)" % details)

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class LocalTransferClaim(LocalTransferClaimAbstract):
    claim_no = models.CharField(max_length=CLAIM_NO_MAX_LENGTH, blank=True)

    class Meta(LocalTransferClaimAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Local Transfer Claim'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return "{}?pk={}".format(reverse_lazy('localtransfer_detail'), self.pk)


class LocalTransferClaimItem(LocalTransferClaimItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(LocalTransferClaimItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Local Transfer Claim Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class LocalTransferClaimDraft(LocalTransferClaimAbstract):

    class Meta(LocalTransferClaimAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Local Transfer Claim Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']

    def get_absolute_url(self):
        return reverse_lazy('localtransfer_draft', args=[self.pk])


class LocalTransferClaimItemDraft(LocalTransferClaimItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(LocalTransferClaimItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Local Transfer Claim Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class DependentItemAbstract(models.Model):
    name = models.CharField(max_length=255, null=True)
    age = models.IntegerField(null=True)
    ic_birthcert = models.CharField(max_length=30, null=True)
    relation = models.CharField(max_length=10, null=True)

    # Used for Spouse
    grade = models.CharField(max_length=50, null=True)
    position = models.CharField(max_length=50, null=True)
    basic_salary = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))
    employer_name = models.TextField(null=True)

    # Used for Children
    work_status = models.CharField(max_length=25, null=True)
    oku_status = models.CharField(max_length=5, null=True)
    entitled = models.CharField(max_length=25, null=True)

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class DependentItem(DependentItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(DependentItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Dependent Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class DependentItemDraft(DependentItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(DependentItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Dependent Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class AddressItemAbstract(models.Model):
    for address in ('old_office_line', 'new_office_line', 'old_home_line', 'new_home_line'):
        for repeater in ('1', '2', '3', '4'):
            exec("%s%s = models.TextField(null=True)" % (address, repeater))

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class AddressItem(AddressItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(AddressItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Address Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class AddressItemDraft(AddressItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(AddressItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Address Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class MealItemAbstract(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    for meal in ('meal_rate_before', 'meal_rate_after', 'meal_total_before', 'meal_total_after', 'meal_total_amount'):
        exec("%s = models.DecimalField(**default_arguments)" % meal)

    meal_no_of_person_before = models.IntegerField(null=True, default=0)
    meal_no_of_person_after = models.IntegerField(null=True, default=0)

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class MealItem(MealItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(MealItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Meal Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class MealItemDraft(MealItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(MealItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Meal Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class HotelItemAbstract(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    for hotel in ('first_3', 'second_3', 'third_3', 'first_5', 'second_5', 'third_5', 'forth_5', 'fifth_5'):
        for repeater in ('1', '2', '3'):
            exec("room_price_%s_%s = models.DecimalField(**default_arguments)" % (repeater, hotel))

    for hotel2 in ('first_3', 'second_3', 'third_3', 'first_5', 'second_5', 'third_5', 'forth_5', 'fifth_5'
                   , 'amount_3', 'amount_5', 'amount', 'gst'):
        exec("hotel_total_%s = models.DecimalField(**default_arguments)" % (hotel2))

    hotel_rate_before = models.DecimalField(**default_arguments)
    hotel_rate_after = models.DecimalField(**default_arguments)
    hotel_receipt_no = models.TextField(null=True)

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class HotelItem(HotelItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(HotelItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Hotel Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class HotelItemDraft(HotelItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(HotelItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Hotel Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class LodgingItemAbstract(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    for lodging in ('lodging_rate_before', 'lodging_rate_after', 'lodging_total_before', 'lodging_total_after'
                    , 'lodging_total_amount'):
        exec("%s = models.DecimalField(**default_arguments)" % lodging)

    lodging_add_before = models.CharField(max_length=30, null=True)
    lodging_add_after = models.CharField(max_length=30, null=True)
    lodging_no_of_days_before = models.IntegerField(null=True, default=0)
    lodging_no_of_days_after = models.IntegerField(null=True, default=0)

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class LodgingItem(LodgingItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(LodgingItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Lodging Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class LodgingItemDraft(LodgingItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(LodgingItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Lodging Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class PublicTransportItemAbstract(models.Model):
    default_arguments = dict(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    for transport in ('land_amount', 'sea_amount', 'air_amount', 'total_amount'):
        exec("public_%s = models.DecimalField(**default_arguments)" % (transport))

    public_land_receipt_no = models.CharField(max_length=30, null=True)
    public_sea_receipt_no = models.CharField(max_length=30, null=True)
    public_air_receipt_no = models.CharField(max_length=30, null=True)

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class PublicTransportItem(PublicTransportItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(PublicTransportItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Public Transport Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class PublicTransportItemDraft(PublicTransportItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(PublicTransportItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Public Transport Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class MileageItemAbstract(models.Model):
    mileage_add_from = models.CharField(max_length=20, null=True)
    mileage_add_to = models.CharField(max_length=20, null=True)
    mileage_distance = models.IntegerField(null=True, default=0)
    mileage_total_amount = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class MileageItem(MileageItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(MileageItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Mileage Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class MileageItemDraft(MileageItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(MileageItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Mileage Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']


class MiscItemAbstract(models.Model):
    misc_date = models.DateField(null=True)
    misc_type = models.CharField(max_length=20, null=True)
    misc_receipt_no = models.CharField(max_length=30, null=True)
    misc_amount = models.DecimalField(decimal_places=2, max_digits=10, null=True, default=Decimal('0.00'))

    class Meta:
        app_label = 'localtransfer'
        abstract = True


class MiscItem(MiscItemAbstract):
    local_transfer_claim = models.ForeignKey(LocalTransferClaim)

    class Meta(MiscItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Misc Item'
        verbose_name_plural = verbose_name
        ordering = ['id']


class MiscItemDraft(MiscItemAbstract):
    local_transfer_claim_draft = models.ForeignKey(LocalTransferClaimDraft)

    class Meta(MiscItemAbstract.Meta):
        app_label = 'localtransfer'
        verbose_name = 'Misc Item Draft'
        verbose_name_plural = verbose_name
        ordering = ['id']
