from eclaim.libs.tests import TestCase
from eclaim.localtransfer.processes import (local_transfer_claim_process,
                                            submit_claim)
from mock import patch, Mock, call
from django.views.generic import TemplateView
from django.test import TestCase, RequestFactory, Client
from django.contrib.auth.models import User
from django.core.urlresolvers import reverse_lazy


class LocalTransferTests(TestCase):

    def setUp(self):
        # self.local_transfer_index = LocalTransferIndexView()
        pass

    def tearDown(self):
        pass


    @patch('eclaim.localtransfer.processes.save_draft')
    def test_local_transfer_claim_process(self, mock_save_draft):
        local_transfer_claim_process('save_draft', {'a': 'a'},
                                     created_by='The Creator')
        assert(mock_save_draft.called)
        assert(mock_save_draft.call_args, call({'a': 'a'}, 'The Creator'))


    @patch('eclaim.localtransfer.processes.submit_claim')
    def test_local_transfer_claim_process(self, mock_submit_claim):
        local_transfer_claim_process('submit', {'a': 'a'},
                                     created_by='The Creator')
        assert(mock_submit_claim.called)
        assert(mock_submit_claim.call_args, call({'a': 'a'}, 'The Creator'))


    @patch('eclaim.localtransfer.processes.save_claimant_history')
    @patch('eclaim.localtransfer.processes.save_local_transfer_claim')
    def test_submit_with_claim_id(self, mock_save_claimant_history, mock_save_local_transfer_claim):
        result = submit_claim({'claimaint_no': '123456',
                               'draft_id': ''})
        self.assertEqual(result, 1)


    @patch('eclaim.localtransfer.processes.save_claimant_history')
    @patch('eclaim.localtransfer.processes.save_local_transfer_claim')
    @patch('eclaim.localtransfer.processes.delete_local_transfer_claim_draft')
    def test_submit_without_claim_id(self, mock_save_claimant_history,
                                     mock_save_local_transfer_claim,
                                     mock_delete_local_transfer_claim_draft):
        
        result = submit_claim({'claimaint_no': '123456',
                               'draft_id': '123456'})
        assert mock_delete_local_transfer_claim_draft.called
        self.assertEqual(result, 1)

class LocalTransferViewsTest(TestCase):

    def login(self):
        self.client.login(username='551212-10-6175', password='12345')

    def logout(self):
        self.client.logout()

    def setUp(self):
        self.client = Client()
        self.login()

    def tearDown(self):
        self.logout()

    def test_local_transfer_index_view(self):
        response = self.client.get('/eclaim/claim-forms/localtransfer/', follow=True)
        self.assertEqual(response.status_code, 200)

    @patch('eclaim.localtransfer.models.ClaimType.objects.get')
    def test_local_transfer_create(self, mock_objects):
        mock_objects.return_value = {'abc': 123}
        from eclaim.localtransfer.models import (LocalTransferClaim,
                                                 LocalTransferClaimItem,
                                                 AddressItem,
                                                 DependentItem,
                                                 MealItem,
                                                 HotelItem,
                                                 LodgingItem,
                                                 PublicTransportItem,
                                                 MileageItem)

        local_transfer_entry = LocalTransferClaim()
        local_transfer_entry.apply_date = '2016-04-01'
        local_transfer_entry.save()
        url = local_transfer_entry.get_absolute_url()
        self.assertEqual(
            url,
            '/eclaim/claim-forms/localtransfer/detail/?pk=%s' % local_transfer_entry.pk)
        self.assertEqual(local_transfer_entry.get_claim_type(),
                         {'abc': 123})
        assert mock_objects.call_args == call(pk=3)

        model_list = (LocalTransferClaimItem,
                      AddressItem,
                      DependentItem,
                      MealItem,
                      HotelItem,
                      LodgingItem,
                      PublicTransportItem,
                      MileageItem)

        for model in model_list:
            model.objects.create(local_transfer_claim=local_transfer_entry)
            manager = getattr(local_transfer_entry, '%s_set' % model.__name__.lower())
            self.assertEqual(manager.all().count(), 1)
