from django.conf.urls import patterns, url

from .views import LocalTransferIndexView, LocalTransferDetailView, LocalTransferDraftView

urlpatterns = patterns('',
    url(r'^$', LocalTransferIndexView.as_view(), name='localtransfer_index'),
    url(r'^detail/$', LocalTransferDetailView.as_view(), name='localtransfer_detail'),
    url(r'^draft/(?P<draft_id>[0-9]+)/$', LocalTransferDraftView.as_view(), name='localtransfer_draft')
)