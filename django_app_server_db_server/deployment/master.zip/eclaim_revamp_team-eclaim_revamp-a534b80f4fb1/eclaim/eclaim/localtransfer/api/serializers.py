from rest_framework import serializers
from eclaim.libs.api.serializers import BaseClaimSerializer
from ..models import *

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTransferClaimSerializer',
    'LocalTransferClaimDraftSerializer'
    ]


class LocalTransferClaimSerializer(BaseClaimSerializer):
    claim_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTransferClaim
        fields = BaseClaimSerializer.Meta.fields + ('claim_details',)

    def get_claim_details(self, obj):
        claim_details = obj.localtransferclaimitem_set.all()
        claim_details_pk = claim_details.values_list('pk', flat=True)
        address_items = AddressItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        meal_items = MealItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        hotel_items = HotelItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        lodging_items = LodgingItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        transport_items = PublicTransportItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        mileage_items = MileageItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        misc_items = MiscItem.objects.filter(local_transfer_claim__in=claim_details_pk)
        spouse_items = DependentItem.objects.filter(local_transfer_claim__in=claim_details_pk, relation='Spouse')
        children_items = DependentItem.objects.filter(local_transfer_claim__in=claim_details_pk, relation='Children')
        return {'claim_details': claim_details.values()
                ,'address_items': address_items.values()
                ,'meal_items': meal_items.values()
                ,'hotel_items': hotel_items.values()
                ,'hotel_items': hotel_items.values()
                ,'lodging_items': lodging_items.values()
                ,'transport_items': transport_items.values()
                ,'mileage_items': mileage_items.values()
                ,'misc_items': misc_items.values()
                ,'spouse_items': spouse_items.values()
                ,'children_items': children_items.values()
        }


class LocalTransferClaimDraftSerializer(serializers.ModelSerializer):
    claim_details = serializers.SerializerMethodField()

    class Meta:
        model = LocalTransferClaimDraft
        fields = '__all__'

    def get_claim_details(self, obj):
        claim_details = obj.localtransferclaimitemdraft_set.all()
        claim_details_pk = claim_details.values_list('pk', flat=True)
        address_items = AddressItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        meal_items = MealItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        hotel_items = HotelItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        lodging_items = LodgingItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        transport_items = PublicTransportItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        mileage_items = MileageItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        misc_items = MiscItemDraft.objects.filter(local_transfer_claim_draft__in=claim_details_pk)
        spouse_items = DependentItemDraft.objects.filter(local_transfer_claim__in=claim_details_pk, relation='Spouse')
        children_items = DependentItemDraft.objects.filter(local_transfer_claim__in=claim_details_pk, relation='Children')
        return {'claim_details': claim_details.values()
                ,'address_items': address_items.values()
                ,'meal_items': meal_items.values()
                ,'hotel_items': hotel_items.values()
                ,'hotel_items': hotel_items.values()
                ,'lodging_items': lodging_items.values()
                ,'transport_items': transport_items.values()
                ,'mileage_items': mileage_items.values()
                ,'misc_items': misc_items.values()
                ,'spouse_items': spouse_items.values()
                ,'children_items': children_items.values()
        }
