from rest_framework import viewsets
from .serializers import LocalTransferClaimSerializer, LocalTransferClaimDraftSerializer
from ..models import LocalTransferClaim, LocalTransferClaimDraft

# Use only public names in `__all__` when importing from outside of
# this module.
__all__ = [
    'LocalTransferClaimViewSet',
    'LocalTransferClaimDraftViewSet'
    ]


class LocalTransferClaimViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTransferClaimSerializer
    queryset = LocalTransferClaim.objects.all()


class LocalTransferClaimDraftViewSet(viewsets.ModelViewSet):
    serializer_class = LocalTransferClaimDraftSerializer
    queryset = LocalTransferClaimDraft.objects.all()