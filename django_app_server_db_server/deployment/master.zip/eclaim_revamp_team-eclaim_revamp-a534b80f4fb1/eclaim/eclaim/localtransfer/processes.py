import datetime
from decimal import *

from eclaim.masterfiles.models.misc import FundType, VehicleType
from eclaim.masterfiles.models.claimant import Claimant, ClaimantHistory
from eclaim.masterfiles.models.company import GradeLevelCategory
from eclaim.masterfiles.models.document import DocumentListItem, DocumentListItemDraft
from eclaim.masterfiles.utils import save_claimant_history, save_document_list_item_draft, save_document_list_item
from eclaim.utils.date import get_date_from_str
from eclaim.utils.common import generate_claim_no, get_claim_type_code, get_claim_type_prefix
from .models import (LOCAL_TRANSFER_CLAIM_TYPE, LocalTransferClaim, LocalTransferClaimItem, LocalTransferClaimDraft
                    , LocalTransferClaimItemDraft, DependentItem, DependentItemDraft, AddressItem, AddressItemDraft
                    , MealItem, MealItemDraft, HotelItem, HotelItemDraft, LodgingItem, LodgingItemDraft
                    , PublicTransportItem, PublicTransportItemDraft, MileageItem, MileageItemDraft, MiscItem
                    , MiscItemDraft)


__ClaimType__ = get_claim_type_code(LOCAL_TRANSFER_CLAIM_TYPE)
__ClaimPrefix__ = get_claim_type_prefix(LOCAL_TRANSFER_CLAIM_TYPE)


def local_transfer_claim_process(btn_mode, form_data, created_by=None):
    draft_id = None
    claim_id = None

    if btn_mode in ['save_draft']:
        draft_id = save_draft(form_data, created_by)
    elif btn_mode in ['submit']:
        claim_id = submit_claim(form_data)

    return draft_id, claim_id


def save_draft(form_data, created_by=None):
    draft_id = form_data.get('draft_id')

    draft_id = None if (draft_id is None or draft_id == '') else int(draft_id)
    status = '' if draft_id else 'D'
    created_by = '' if (created_by is None) else created_by
    claim_draft = LocalTransferClaimDraft(id=draft_id)
    claim_draft.apply_date = datetime.date.today()
    claim_draft.save()
    save_local_transfer_claim('save_draft', claim_draft, form_data)

    if draft_id:
        return draft_id
    else:
        return claim_draft.id


def submit_claim(form_data):
    claimant_no = form_data.get('claimant_no')
    draft_id = form_data.get('draft_id')

    claim = LocalTransferClaim()
    claim.status = 'S'
    claim.apply_date = datetime.date.today()
    claim.save()

    claim.claim_no = generate_claim_no(__ClaimPrefix__, claim.id)
    claim.save()

    save_claimant_history(claimant_no, claim.id, __ClaimType__)
    save_local_transfer_claim('submit_claim', claim, form_data)

    if draft_id != '':
        delete_local_transfer_claim_draft(LocalTransferClaimDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(DependentItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(AddressItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(MealItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(HotelItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(LodgingItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(PublicTransportItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(MileageItemDraft(id=int(draft_id)))
        delete_local_transfer_claim_draft(MiscItemDraft(id=int(draft_id)))

    return claim.id


def save_local_transfer_claim(mode, localtransfer, form_data):

    if mode in ['save_draft']:
        saveObjClaim = LocalTransferClaimItemDraft()
        saveObjAddress = AddressItemDraft()
        saveObjMeal = MealItemDraft()
        saveObjHotel = HotelItemDraft()
        saveObjLodging = LodgingItemDraft()
        saveObjPublicTransport = PublicTransportItemDraft()
        saveObjMileage = MileageItemDraft()

        saveObjClaim.local_transfer_claim_draft = localtransfer
        saveObjAddress.local_transfer_claim_draft = localtransfer
        saveObjMeal.local_transfer_claim_draft = localtransfer
        saveObjHotel.local_transfer_claim_draft = localtransfer
        saveObjLodging.local_transfer_claim_draft = localtransfer
        saveObjPublicTransport.local_transfer_claim_draft = localtransfer
        saveObjMileage.local_transfer_claim_draft = localtransfer

    elif mode in ['submit_claim']:
        saveObjClaim = LocalTransferClaimItem()
        saveObjAddress = AddressItem()
        saveObjMeal = MealItem()
        saveObjHotel = HotelItem()
        saveObjLodging = LodgingItem()
        saveObjPublicTransport = PublicTransportItem()
        saveObjMileage = MileageItem()

        saveObjClaim.local_transfer_claim = localtransfer
        saveObjAddress.local_transfer_claim = localtransfer
        saveObjMeal.local_transfer_claim = localtransfer
        saveObjHotel.local_transfer_claim = localtransfer
        saveObjLodging.local_transfer_claim = localtransfer
        saveObjPublicTransport.local_transfer_claim = localtransfer
        saveObjMileage.local_transfer_claim = localtransfer

    saveObjClaim.grade_after = GradeLevelCategory.objects.get(code=form_data['transferGradeAfter'])
    saveObjClaim.transfer_date = get_date_from_str(form_data.get('transferDateTxt'))
    saveObjClaim.fund_type = FundType.objects.get(code=form_data['fundType'].get('code'))
    saveObjClaim.project_code = form_data.get('projectCode')
    saveObjClaim.marital_status = form_data.get('maritalStatus')
    saveObjClaim.mover = form_data.get('transferMover')
    saveObjClaim.destination = form_data.get('transferDestination')
    saveObjClaim.vehicle = VehicleType.objects.get(name=form_data['vehicle'])
    saveObjClaim.distance = form_data.get('distance')
    saveObjClaim.transfer_allowance = form_data.get('transferAllowance')
    saveObjClaim.goods_land_distance = form_data.get('goodsLandDistance')
    saveObjClaim.goods_land_amount = form_data.get('goodsLandAmount')
    saveObjClaim.goods_sea_receipt_no = form_data.get('goodsSeaReceiptNo')
    saveObjClaim.goods_sea_amount = form_data.get('goodsSeaAmount')
    saveObjClaim.misc_total = form_data.get('miscTotal')
    saveObjClaim.other_misc_percentage = form_data.get('otherMiscPercentage')
    saveObjClaim.other_misc_amount = form_data.get('otherMiscAmount')
    saveObjClaim.claim_amount = form_data.get('claimAmount')
    saveObjClaim.endowment_amount = form_data.get('endowmentAmount')
    saveObjClaim.net_total = form_data.get('netTotal')
    saveObjClaim.save()

    for status in ('old', 'new'):
        for address in ('office_line', 'home_line'):
            for repeater in ('1', '2', '3', '4'):
                exec("saveObjAddress.%s_%s%s = form_data.get('%s%s%s')" % (status, address, repeater, status, ''.join([x.capitalize() for x in address.split('_')]), repeater))
    saveObjAddress.save()

    if form_data.get('mealTotalAmount') > 0:
        for meal in ('rate_before', 'rate_after', 'no_of_person_before', 'no_of_person_after', 'total_before', 'total_after'
                     , 'total_amount'):
            exec("saveObjMeal.meal_%s = form_data.get('meal%s')" % (meal, ''.join([x.capitalize() for x in meal.split('_')])))
        saveObjMeal.save()

    if form_data.get('hotelTotalAmount') > 0:
        for hotel in ('first_3', 'second_3', 'third_3', 'first_5', 'second_5', 'third_5', 'forth_5', 'fifth_5'):
            for repeater in ('1', '2', '3'):
                exec("saveObjHotel.room_price_%s_%s = form_data.get('roomPrice%s%s')" % (repeater, hotel, repeater, ''.join([x.capitalize() for x in hotel.split('_')])))

        for hotel2 in ('first_3', 'second_3', 'third_3', 'first_5', 'second_5', 'third_5', 'forth_5', 'fifth_5'
                       , 'amount_3', 'amount_5', 'amount'):
            exec("saveObjHotel.hotel_total_%s = form_data.get('hotelTotal%s')" % (hotel2, ''.join([x.capitalize() for x in hotel2.split('_')])))

        saveObjHotel.hotel_rate_before = form_data.get('hotelRateBefore')
        saveObjHotel.hotel_rate_after = form_data.get('hotelRateAfter')
        saveObjHotel.hotel_total_gst = form_data.get('hotelTotalGST')
        saveObjHotel.hotel_receipt_no = form_data.get('hotelReceiptNo')
        saveObjHotel.save()

    if form_data.get('lodgingTotalAmount') > 0:
        for lodging in ('add_before', 'add_after', 'rate_before', 'rate_after', 'no_of_days_before', 'no_of_days_after'
                        , 'total_before', 'total_after', 'total_amount'):
            exec("saveObjLodging.lodging_%s = form_data.get('lodging%s')" % (lodging, ''.join([x.capitalize()+'ress' if x == 'add' else x.capitalize() for x in lodging.split("_")])))
        saveObjLodging.save()

    if form_data.get('publicTotalAmount') > 0:
        for public in ('land_receipt_no', 'land_amount', 'sea_receipt_no', 'sea_amount', 'air_receipt_no', 'air_amount'
                       , 'total_amount'):
            exec("saveObjPublicTransport.public_%s = form_data.get('public%s')" % (public, ''.join([x.capitalize() for x in public.split('_')])))
        saveObjPublicTransport.save()

    if form_data.get('mileageTotal') > 0:
        for mileage in ('add_from', 'add_to', 'distance', 'total_amount'):
            exec("saveObjMileage.mileage_%s = form_data.get('mileage%s')" % (mileage, ''.join([x.capitalize() for x in mileage.split('_')])))
        saveObjMileage.save()

    if form_data.get('maritalStatus') == 'mF':
        if form_data.get('spouseList'):
            for spouse in form_data.get('spouseList'):

                if mode in ['save_draft']:
                    saveObjDependent = DependentItemDraft()
                    saveObjDependent.local_transfer_claim_draft = localtransfer

                elif mode in ['submit_claim']:
                    saveObjDependent = DependentItem()
                    saveObjDependent.local_transfer_claim = localtransfer

                saveObjDependent.name = spouse['name']
                saveObjDependent.ic_birthcert = spouse['ic']
                saveObjDependent.relation = 'Spouse'
                saveObjDependent.grade = spouse['grade']
                saveObjDependent.position = spouse['position']
                saveObjDependent.basic_salary = spouse['basic_salary']
                saveObjDependent.employer_name = spouse['employer_name']
                saveObjDependent.save()

        if form_data.get('childrenList'):
            for children in form_data.get('childrenList'):

                if mode in ['save_draft']:
                    saveObjDependent = DependentItemDraft()
                    saveObjDependent.local_transfer_claim_draft = localtransfer

                elif mode in ['submit_claim']:
                    saveObjDependent = DependentItem()
                    saveObjDependent.local_transfer_claim = localtransfer

                saveObjDependent.name = children['name']
                saveObjDependent.age = children['age']
                saveObjDependent.ic_birthcert = children['ic']
                saveObjDependent.relation = 'Children'
                saveObjDependent.work_status = children['work_status']
                saveObjDependent.oku_status = children['oku_status']
                saveObjDependent.entitled = children['entitled']
                saveObjDependent.save()

    if form_data.get('miscItems'):
        for misc in form_data.get('miscItems'):

            if mode in ['save_draft']:
                saveObjMisc = MiscItemDraft()
                saveObjMisc.local_transfer_claim_draft = localtransfer

            elif mode in ['submit_claim']:
                saveObjMisc = MiscItem()
                saveObjMisc.local_transfer_claim = localtransfer

            saveObjMisc.misc_date = get_date_from_str(misc['miscDateTxt'])
            saveObjMisc.misc_type = misc['miscType']
            saveObjMisc.misc_receipt_no = misc['miscReceiptNo']
            saveObjMisc.misc_amount = misc['miscAmount']
            saveObjMisc.save()


def delete_local_transfer_claim_draft(draft):
    deleteObj = draft
    deleteObj.delete()