# Comitting work guidelines

1. Branch from production
2. Branch name convention - <Ticket number>-<YYYYMMDD>-<Short description about ticket>
3. Do you work, then commit to branch created in #2.
4. Push changes to your remote branch.
5. Submit for PR. 
6. Once that is done, merge back to master, then to Staging
7. QA
8. Passed QA, then merge to production.
9. For non trivial merges use "--no-ff" so that changes can always be tracked back to original branch.

